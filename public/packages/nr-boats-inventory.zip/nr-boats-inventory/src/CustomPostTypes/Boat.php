<?php


namespace NativerankInventory\CustomPostTypes;


use TypeRocket\Register\Registry;

class Boat {
	public function __construct() {

		add_rewrite_tag( '%condition%', '(.+)' );
		add_rewrite_tag( '%brand%', '(.+)' );

		$boat = tr_post_type( 'Boat' );
		$boat->setArgument( 'supports', [ 'title', 'custom-fields', 'revisions' ] );
		$boat->disableArchivePage();
		$boat->setIcon( 'droplet' );
		$boat->setRest();
		$boat->setTitlePlaceholder( 'Enter Boat Model' );
		Registry::addPostTypeResource( 'boat', [
			'boat', // singular
			'boats', // plural
			'\App\Models\Boat',
			'App\Controllers\BoatController'
		] );

		add_filter( 'register_post_type_args', function ( $args, $post_type ) {
			if ( 'boat' != $post_type ) {
				return $args;
			}
			$args['rewrite'] = [ 'slug' => '%condition%-%brand%-boats-for-sale-colorado' ];

			return $args;
		}, 10, 2 );

		add_filter( 'post_type_link', function ( $post_link, $id = 0 ) {
			$post = get_post( $id );
			if ( is_object( $post ) && $post->post_type === 'boat' ) {
				$condition = wp_get_object_terms( $post->ID, 'usage' );
				$brand     = wp_get_object_terms( $post->ID, 'brand' );

				if ( isset( $condition[0] ) ) {
					$post_link = str_replace( '%condition%', sanitize_title( $condition[0]->name ), $post_link );
				} else {
					$post_link = str_replace( '%condition%', 'new', $post_link );
				}

				if ( isset( $brand[0] ) ) {
					$post_link = str_replace( '%brand%', sanitize_title( $brand[0]->name ), $post_link );
				} else {
					$re    = '/[\d]+[\s]{0,2}([\w]+)/m';
					$brand = $post->post_title;
					preg_match_all( $re, $brand, $matches, PREG_SET_ORDER, 0 );
					if ( ! empty( $matches ) ) {
						$post_link = str_replace( '%brand%', sanitize_title( $matches[0][1] ), $post_link );
					}
				}

			}

			return $post_link;
		}, 1, 3 );


		$taxonomies = array(
			array( 'Boat Type', 'Boat Type' ),
			array( 'Brand', 'Brand', 'brand' ),
			array( 'Class', 'Class', 'class' ),
			array( 'Model Year', 'Model Year', 'model_year' ),
			array( 'Length Overall', 'Length Overall', 'boat_length' ),
			array( 'Engine Type', 'Engine Type', 'engine_type' ),
			array( 'Engine Make', 'Engine Make', 'engine_make' ),
			array( 'Horsepower', 'Horsepower', 'horsepower' ),
			array( 'Location', 'Location' )
		);

		foreach ( $taxonomies as $tax ):
			if ( isset( $tax[1] ) ):
				$boat->apply( tr_taxonomy( $tax[0], $tax[1] ) );
			else:
				$boat->apply( tr_taxonomy( $tax[0] )->setHierarchical( true ) );
			endif;
		endforeach;

		$boat->addColumn( 'boat_stocknumber', true, 'Stocknumber', function ( $value ) {
			if ( is_array( $value ) ) {
				echo implode( ' ', $value );

				return;
			}
			echo $value;
		}, 'string' );
		$boat->addColumn( 'boat_model', true, 'Model', function ( $value ) {
			if ( is_array( $value ) ) {
				echo implode( ' ', $value );

				return;
			}
			echo $value;
		}, 'string' );

		$boat->register();

		$usage = tr_taxonomy( 'Usage', 'Usage' );
		$usage->addPostType( 'boat' );
		$usage->addPostType( 'brand' );


		$boxPosts = tr_meta_box( 'Boat Details' );
		$boxPosts->addPostType( $boat->getId() );

		$boxPosts->setCallback( function () {
			$tabs = tr_tabs();

			$form = tr_form();
			$tabs->setForm( $form );


			$tabs->addTab( 'Description', function () use ( $form ) {
				echo $form->row(
					$form->column(
						$form->text( 'Boat Color' )
					),
					$form->column(
						$form->text( 'Boat Condition' )
					)
				);
				echo $form->editor( 'Boat Description' );
			} );

			$tabs->addTab( 'Price', function () use ( $form ) {
				echo $form->row(
					$form->column(
						$form->text( 'Boat Price' )->setType( 'number' )
					),
					$form->column(
						$form->text( 'Boat Price Currency' )
					)
				);

			} );

			$tabs->addTab( 'Images', function () use ( $form ) {
				echo $form->repeater( 'Images' )->setFields( [
					$form->text( 'URL' )
				] )->contracted();


			} );
			$tabs->addTab( 'Attributes', function () use ( $form ) {
				echo $form->repeater( 'Attributes' )->setFields( [
					$form->text( 'Attribute' )
				] )->contracted();
			} );

			$tabs->render( 'box' );

			echo $form->row(
				$form->column(
					$form->text( 'Boat ID' )->setAttribute( 'readonly', 'readonly' ),
					$form->text( 'Boat Stocknumber' )->setLabel( 'Boat Stock #' ),
				),
				$form->column(
					$form->text( 'Boat VIN' ),
					$form->text( 'Boat Model' )
				),
				$form->column(
					$form->text( 'Vendor Modified At' )->setType( 'datetime-local' )->setLabel( 'Date Updated' )->setAttribute( 'readonly', 'readonly' )
				)
			);


			echo "<script defer>
			jQuery('document').ready(function($){
    			let src;
    			jQuery('[data-id=\"images\"]').next('.tr-repeater-fields').find('input[type=\"text\"]').each(function(){
         			src = $(this).val();
         			$(this).css({display: 'none'})
         			$(this).parent().prev().hide()
        			$(this).after('<a href=\"'+src+'\" target=\"blank\"><img width=\"150\" src=\"'+src +'\" style=\"padding-left: 15px;\"/></a>')
    			})
			})
			</script>";

			echo "<style>
			.tr-repeater-fields {
			    display: flex;
    			flex-direction: column;
    			flex-wrap: wrap;
    			max-height: 60vh;
    		}
			</style>";
		} );

	}

}
