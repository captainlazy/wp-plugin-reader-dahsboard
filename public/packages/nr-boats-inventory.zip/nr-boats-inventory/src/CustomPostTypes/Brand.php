<?php


namespace NativerankInventory\CustomPostTypes;


class Brand {

	public function __construct() {
		$brand = tr_post_type( 'Brand' );
		$brand->setIcon( 'node-tree' );

		$brand->setTitlePlaceholder( 'Enter Brand Name' );
		$brand->setArgument( 'supports', [ 'title', 'custom-fields', 'revisions' ] );

		$brand->register();

		$boxPosts = tr_meta_box( 'Brand Message' );
		$boxPosts->addPostType( $brand->getId() );

		$boxPosts->setCallback( function () {
			$form = tr_form();
			echo $form->textarea( 'Brand Description' );
		} );

	}


}