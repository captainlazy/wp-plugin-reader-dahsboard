<?php


namespace NativerankInventory;

use SimpleXMLElement;

class Updater extends Boat {
	private $fileUpdated = false;
	private $rawXml;
	private $remoteUpdatedAt;
	private $xmlFileName;
	private $xmlFilePath;
	private $xmlFileUrl;
	private $timeOfJob;
	private $log;

	protected $boatTaxonomies;
	protected $xmlData;
	protected $boatsInStock = array();
	protected $forceAll = false;

	public function __construct( $force = false, $forceAll = false ) {
		$this->log            = (object) array();
		$this->timeOfJob      = time();
		$this->fileUpdated    = $force;
		$this->forceAll       = $forceAll;
		$this->boatTaxonomies = array(
			'Length Overall' => 'length_overall',
			'Engine Make'    => 'engine_make',
			'Engine Type'    => 'engine_type',
			'Horsepower'     => 'horsepower',
			'Type'           => 'boat_type',
			'Usage'          => 'usage',
			'Brand'          => 'brand',
			'Class'          => 'class',
			'Model Year'     => 'model_year'
		);

		$this->getInventory();
		$this->checkIfUpdated();

		$logger = new Logger( $this->timeOfJob );
		if ( $this->fileUpdated ) {
			$this->updateInventory();
			$this->logArray();
			$logger->inventoryUpdated( $this->log );
		}
	}

	private function getInventory() {
		$this->rawXml          = file_get_contents( NR_INVENTORY_API_URL );
		$this->xmlData         = new SimpleXMLElement( $this->rawXml, LIBXML_NOCDATA | LIBXML_PARSEHUGE );
		$this->remoteUpdatedAt = $this->xml2array( $this->xmlData )['modified'];

		return true;
	}


	private function checkIfUpdated() {
		if ( strtotime( get_option( 'nr_1055_remote_inventory_updated_at' ) ) < strtotime( $this->remoteUpdatedAt ) ):
			$this->fileUpdated = true;
		endif;

		return;

	}

	private function updateInventory() {
		global $wpdb;
		$this->boatsInStock = $wpdb->get_results( $wpdb->prepare(
			"SELECT posts.ID, pmSN.meta_value as boat_stocknumber, pmID.meta_value as boat_id, pmMA.meta_value as vendor_modified_at FROM $wpdb->posts as posts
LEFT JOIN $wpdb->postmeta as pmSN ON (posts.ID = pmSN.post_id)
LEFT JOIN $wpdb->postmeta as pmID ON (posts.ID = pmID.post_id)
LEFT JOIN $wpdb->postmeta as pmMA ON (posts.ID = pmMA.post_id) 
WHERE posts.post_type = %s AND posts.post_status = %s AND pmSN.meta_key = %s AND pmID.meta_key = %s AND pmMA.meta_key = %s ", 'boat', 'publish', 'boat_stocknumber', 'boat_id', 'vendor_modified_at' ) );

		foreach ( $this->xmlData->item as $newBoat ):
			$this->checkPrepareAndGroupBoat( $newBoat );
		endforeach;


		$this->updateBoats();
		$this->createNewBoats();

		$this->checkForDelete();
		$this->deleteBoats();

		$this->xmlFileName = sanitize_file_name( str_replace( 'T', '_', str_replace( ':', '-', $this->remoteUpdatedAt ) ) ) . '.xml';
		$xmlFileandFolder  = 'xmlFiles/' . $this->xmlFileName;
		$this->xmlFilePath = plugin_dir_path( __DIR__ . '..' ) . $xmlFileandFolder;
		$this->xmlFileUrl  = plugin_dir_url( __DIR__ . '..' ) . $xmlFileandFolder;
		file_exists( $this->xmlFilePath ) ?: file_put_contents( $this->xmlFilePath, $this->rawXml );
		update_option( 'nr_1055_remote_inventory_updated_at', $this->remoteUpdatedAt );

	}

	public function getResults() {
		$results = array();
		if ( $this->fileUpdated ):
			$logs     = json_encode( get_option( 'nr_1055_inventory_log' ) );
			$cronLogs = get_option( 'nr_1055_inventory_cron_log' );
			foreach ( $cronLogs as $cronLog ):
				$cronLogObj[] = array( "time" => $cronLog );
			endforeach;
			$cronLogs           = json_encode( $cronLogObj );
			$results['message'] = '<b>Inventory Updated</b><script>var nr_ev_response = new CustomEvent("log_updated", {detail: ' . $logs . '}); document.dispatchEvent(nr_ev_response); var nr_cron_ev_response = new CustomEvent("cron_log_updated", {detail: ' . $cronLogs . '}); document.dispatchEvent(nr_cron_ev_response);</script>';
			$results['updated'] = 1;

			return $results;
		else:
			$cronLogs = get_option( 'nr_1055_inventory_cron_log' );
			foreach ( $cronLogs as $cronLog ):
				$cronLogObj[] = array( "time" => $cronLog );
			endforeach;
			$cronLogs           = json_encode( $cronLogObj );
			$results['message'] = '<b>Remote inventory has not been modified since last update, nothing to update</b><script>var nr_cron_ev_response = new CustomEvent("cron_log_updated", {detail: ' . $cronLogs . '}); document.dispatchEvent(nr_cron_ev_response);</script>';

			return $results;
		endif;
	}

	private function logArray() {
		$this->log->xmlFileName     = $this->xmlFileName;
		$this->log->recentlyCreated = $this->recentlyCreated;
		$this->log->recentlyUpdated = $this->recentlyUpdated;
		$this->log->recentlyDeleted = $this->recentlyDeleted;
		$this->log->xmlFileUrl      = $this->xmlFileUrl;
	}


}
