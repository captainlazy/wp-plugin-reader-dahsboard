<?php


namespace NativerankInventory;


use function _\flattenDeep;

class Boat {

	private $newBoats = array();
	private $updatedBoats = array();
	private $boatsToDelete = array();

	protected $recentlyUpdated = array();
	protected $recentlyCreated = array();
	protected $recentlyDeleted = array();

	private $taxonomyKeySwitches = [
		'model_type'      => 'boat_type',
		'usage'           => 'usage',
		'manufacturer'    => 'brand',
		'model_typestyle' => 'class',
		'year'            => 'model_year',
	];

	private $metaKeySwitches = [
		'updated'     => [ 'key' => 'vendor_modified_at', 'default' => '' ],
		'id'          => [ 'key' => 'boat_id', 'default' => '' ],
		'stocknumber' => [ 'key' => 'boat_stocknumber', 'default' => '' ],
		'description' => [ 'key' => 'boat_description', 'default' => '' ],
		'price'       => [ 'key' => 'boat_price', 'default' => 0.000 ],
		'price_type'  => [ 'key' => 'boat_price_currency', 'default' => 'USD' ],
		'vin'         => [ 'key' => 'boat_vin', 'default' => '' ],
		'color'       => [ 'key' => 'boat_color', 'default' => '' ],
		'model_name'  => [ 'key' => 'boat_model', 'default' => '' ],
		'trim_name'   => [ 'key' => 'boat_trim', 'default' => '' ],
		'trim_color'  => [ 'key' => 'boat_trim_color', 'default' => '' ],
		'condition'   => [ 'key' => 'boat_condition', 'default' => '' ],
		'miles'       => [ 'key' => 'boat_miles', 'default' => 0 ],
	];

	protected function checkPrepareAndGroupBoat( $xmlBoat ) {

		$postID    = $this->compareBoatIds( 'id', $xmlBoat, 'boat_id', $this->boatsInStock );
		$boatArray = $this->prepareBoatArray( $xmlBoat );
		$hash      = $boatArray['attributes']['meta_input']['special_boat_hash'] = $this->getHash( $boatArray );

		if ( ! $postID ) {
			$this->newBoats[] = $boatArray;

			return;
		}

		if ( $this->forceAll ) {
			$boatArray['postID']  = $postID;
			$this->updatedBoats[] = $boatArray;

			return;
		}

		if ( $this->boatHasBeenUpdated( $hash, $postID ) ) {
			$boatArray['postID']  = $postID;
			$this->updatedBoats[] = $boatArray;

		}


	}

	private function compareBoatIds( $id1, $entry, $id2, $arr ) {
		foreach ( $arr as $item ) {
			if ( trim( strtoupper( $entry->$id1 ) ) === trim( strtoupper( $item->$id2 ) ) ) {
				if ( isset( $item->ID ) ):
					return $item->ID;
				endif;
				if ( isset( $entry->ID ) ):
					return $entry->ID;
				endif;
			}
		}

		return false;
	}

	private function getHash( $array ) {
		$array = flattenDeep( $array );

		return $this->recursive_implode( $array, '' );
	}

	/**
	 * Recursively implodes an array with optional key inclusion
	 *
	 * Example of $include_keys output: key, value, key, value, key, value
	 *
	 * @access  public
	 *
	 * @param array $array multi-dimensional array to recursively implode
	 * @param string $glue value that glues elements together
	 * @param bool $include_keys include keys before their values
	 * @param bool $trim_all trim ALL whitespace from string
	 *
	 * @return  string  imploded array
	 */
	public function recursive_implode( array $array, $glue = ',', $include_keys = false, $trim_all = true ) {
		$glued_string = '';

		// Recursively iterates array and adds key/value to glued string
		array_walk_recursive( $array, function ( $value, $key ) use ( $glue, $include_keys, &$glued_string ) {
			$include_keys and $glued_string .= $key . $glue;
			$glued_string .= $value . $glue;
		} );

		// Removes last $glue from string
		strlen( $glue ) > 0 and $glued_string = substr( $glued_string, 0, - strlen( $glue ) );

		// Trim ALL whitespace
		$trim_all and $glued_string = preg_replace( "/(\s)/ixsm", '', $glued_string );

		return (string) $glued_string;
	}

	private function boatHasBeenUpdated( $newHash, $postID ) {
		$oldHash = get_post_meta( $postID, 'special_boat_hash', true );

		return $newHash !== $oldHash;
	}

	protected function updateBoats() {
		foreach ( $this->updatedBoats as $updatedBoat ):
			$updatedBoat = $this->createPostObject( $updatedBoat );
			$result      = wp_update_post( $updatedBoat, true );
			if ( $result instanceof \WP_Error || $result === 0 ) {
				$error = $result === 0 ? 'Insert post failed' : $result->get_error_code() . " " . $result->get_error_data() . " " . $result->get_error_message() . "\n";
				file_put_contents( NR_INVENTORY_PLUGIN_DIR . '/boats.log', $error, FILE_APPEND );
			} else {
				$this->setTerms( array_merge( $updatedBoat, [ 'ID' => $result ] ) );
			}
			$this->recentlyUpdated[] = $updatedBoat['meta_input']['boat_stocknumber'];
		endforeach;
	}

	protected function createNewBoats() {
		foreach ( $this->newBoats as $newXmlBoat ):
			$newXmlBoat = $this->createPostObject( $newXmlBoat );
			$result     = wp_insert_post( $newXmlBoat, true );
			if ( $result instanceof \WP_Error || $result === 0 ) {
				$error = $result === 0 ? 'Insert post failed' : $result->get_error_code() . " " . $result->get_error_data() . " " . $result->get_error_message() . "\n";
				file_put_contents( NR_INVENTORY_PLUGIN_DIR . '/boats.log', $error, FILE_APPEND );
			} else {
				$this->setTerms( array_merge( $newXmlBoat, [ 'ID' => $result ] ) );
			}
			$this->recentlyCreated[] = is_array( $newXmlBoat['meta_input']['boat_stocknumber'] ) ? 'N/A' : $newXmlBoat['meta_input']['boat_stocknumber'];
		endforeach;
	}

	protected function setTerms( $boat ) {
		if ( ! isset( $boat['ID'] ) ) {
			$error = json_encode( $boat, JSON_PRETTY_PRINT );
			$error = "Post ID is required: {$error} \n";
			file_put_contents( NR_INVENTORY_PLUGIN_DIR . '/boats.log', $error, FILE_APPEND );

			return $error;
		}

		foreach ( $boat['tax_input'] as $taxonomy => $terms ) {
			if ( is_string( $terms ) ) {
				$comma = _x( ',', 'tag delimiter' );
				if ( ',' !== $comma ) {
					$terms = str_replace( $comma, ',', $terms );
				}
				$terms  = str_replace( ',', '', $terms );
				$termID = $this->getTermID( $terms, $taxonomy );
				$terms  = $termID ?: $terms;
			}

			if ( is_array( $terms ) ) {
				foreach ( $terms as $index => $term ) {
					$termID          = $this->getTermID( $term, $taxonomy );
					$terms[ $index ] = $termID ?: $term;
				}
			}

			if ( ! is_array( $terms ) ) {
				$terms = [ $terms ];
			}

			$result = wp_set_object_terms( $boat['ID'], $terms, $taxonomy );
			if ( $result instanceof \WP_Error ) {
				$error = $result->get_error_code() . " " . $result->get_error_data() . " " . $result->get_error_message() . "\n";
				file_put_contents( NR_INVENTORY_PLUGIN_DIR . '/boats.log', $error, FILE_APPEND );
			}
		}
	}

	protected function getTermID( $term, $taxonomy ) {
		$termObject = get_term_by( 'slug', $term, $taxonomy );
		if ( $termObject === false ) {
			$termObject = get_term_by( 'name', $term, $taxonomy );
		}

		return $termObject ? $termObject->term_id : false;
	}

	private function prepareBoatArray( $boatXML ) {
		$boatArray = $this->xml2array( $boatXML );

		$boatArray['attributes'] = $this->setAttributes( $boatArray );

		return $boatArray;
	}

	private function createPostObject( $boatArray ) {

		if ( isset( $boatArray['images']['imageurl'] ) && is_array( $boatArray['images']['imageurl'] ) ):
			$boatImages = array_map( function ( $url ) {
				return array( 'url' => trim( $url ) );
			}, $boatArray['images']['imageurl'] );
		else:
			if ( isset( $boatArray['images']['imageurl'] ) ):
				$boatImages = array( 'url' => trim( $boatArray['images']['imageurl'] ) );
			endif;
		endif;

		if ( isset( $boatArray['attributes']['miscellaneous_attributes'] ) && is_array( $boatArray['attributes']['miscellaneous_attributes'] ) ):
			$boatMiscAttrs = array_map( function ( $attr ) {
				return array( 'attribute' => $attr );
			}, $boatArray['attributes']['miscellaneous_attributes'] );
		else:
			if ( isset( $boatArray['attributes']['miscellaneous_attributes'] ) ):
				$boatMiscAttrs = array( 'attribute' => $boatArray['attributes']['miscellaneous_attributes'] );
			endif;
		endif;

		$meta_input = $boatArray['attributes']['meta_input'] ?? [];

		$boatPost = array(
			'post_title'  => $boatArray['title'],
			'post_type'   => 'boat',
			'post_status' => 'publish',
			'meta_input'  => $meta_input,
			'tax_input'   => array_merge( array(
				'location' => array( $boatArray['location'] ),
			), $boatArray['attributes']['taxonomies'] ?? [] )
		);

		if ( isset( $boatImages ) ):
			$boatPost['meta_input']['images'] = $boatImages;
		endif;

		if ( isset( $boatMiscAttrs ) ):
			$boatPost['meta_input']['attributes'] = $boatMiscAttrs;
		endif;

		if ( isset( $boatArray['postID'] ) ) {
			$boatPost['ID'] = $boatArray['postID'];
		}


		return $boatPost;
	}

	protected function checkForDelete() {
		foreach ( $this->boatsInStock as $boatInStock ):
			if ( $this->compareBoatIds( 'boat_id', $boatInStock, 'id', $this->xmlData->item ) ):
				continue;
			endif;
			$this->boatsToDelete[] = $boatInStock;
		endforeach;
	}

	protected function deleteBoats() {
		foreach ( $this->boatsToDelete as $boatToDelete ):
			$this->recentlyDeleted[] = $boatToDelete->boat_stocknumber == 'a:0:{}' ? 'N/A' : $boatToDelete->boat_stocknumber;
			wp_delete_post( $boatToDelete->ID );
		endforeach;
	}

	protected function xml2array( $xmlObject, $out = array() ) {
		foreach ( (array) $xmlObject as $index => $node ) {
			$out[ $index ] = ( is_object( $node ) ) ? $this->xml2array( $node ) : $node;
		}

		return $out;
	}

	private function setAttributes( $boatArray ) {
		$boatAttrs = array();
		foreach ( $this->xml2array( $boatArray['attributes'] ?? [] ) as $attr ):
			$attrArray = $this->xml2array( $attr );
			foreach ( $attrArray as $attrKey => $attrValue ):
				if ( $attrKey === 'name' ):
					if ( isset( $this->boatTaxonomies[ $attrValue ] ) ):
						$boatAttrs['taxonomies'][ $this->boatTaxonomies[ $attrValue ] ] = $attrArray['value'] ?? null;
					else:
						$boatAttrs['miscellaneous_attributes'][] = $attrArray[ $attrKey ] . ": " . $attrArray['value'] ?? null;
					endif;
				else:
					if ( isset( $attrValue['name'] ) ):
						if ( isset( $this->boatTaxonomies[ $attrValue['name'] ] ) ):
							$boatAttrs['taxonomies'][ $this->boatTaxonomies[ $attrValue['name'] ] ?? $attrValue['name'] ] = ( $attrValue['value'] ?? null );
						else:
							$boatAttrs['miscellaneous_attributes'][] = $attrValue['name'] . ": " . ( $attrValue['value'] ?? null );
						endif;
					endif;
				endif;
			endforeach;
		endforeach;

		foreach ( $this->taxonomyKeySwitches as $key => $switch ) {
			$boatAttrs['taxonomies'][ $switch ] = $boatArray[ $key ] ?? '';
		}

		foreach ( $this->metaKeySwitches as $key => $switch ) {
			$boatAttrs['meta_input'][ $switch['key'] ] = $boatArray[ $key ] ?? $switch['default'];
		}

		return $boatAttrs;
	}
}
