<?php


namespace NativerankInventory;

class Scheduler {

	public function __construct() {

		add_filter( 'boats_cron_hook', [ $this, 'boats_cron_callback' ] );
		if ( ! wp_next_scheduled( 'boats_cron_hook' ) ) {
			wp_schedule_event( time(), 'hourly', 'boats_cron_hook' );
		}
	}

	public function boats_cron_callback() {
		$updater = new Updater();
	}
}