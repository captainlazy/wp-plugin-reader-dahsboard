<?php


namespace NativerankInventory;


use NativerankInventory\Location\City;

class Shortcode
{
    public function __construct()
    {
        add_shortcode('boat_archive_template', [$this, 'archiveTemplate']);

    }

    public function archiveTemplate($atts = null)
    {
        $shortcodeFilters = [];
        if (isset($atts['reactivefilters'])) {
            $explodedShortCodeFilters = explode(',', $atts['reactivefilters']);

            foreach ($explodedShortCodeFilters as $filter) {
                $filter = explode('=', $filter);
                $shortcodeFilters[$filter[0]] = $filter[1];
            }
        }
        include NR_INVENTORY_PLUGIN_DIR . '/src/Views/archive.php';
        return;
    }


    public function boat_locations_all()
    {
        $data = [
            'Used' => [],
            'New' => []
        ];
        $cities = (new City())->slugify()->all();
        foreach ($cities as $slug => $label) {
            $city = ['slug' => $slug, 'label' => $label];
            $data['Used'][] = $city;
            $data['New'][] = $city;
        }

        return $data;
    }
}
