<?php


namespace NativerankInventory\Location;


use TypeRocket\Utility\Sanitize;

class City
{

    protected $cities = [
        "Aurora",
        "Boulder",
        "Broomfield",
        "Centennial",
        "Colorado Springs",
        "Denver",
        "Durango",
        "Fort Collins",
        "Grand Junction",
        "Greeley",
        "Highlands Ranch",
        "Littleton",
        "Longmont",
        "Loveland",
        "Montrose",
        "Parker",
        "Pueblo"
    ];

    protected $result;


    public function __construct()
    {
        $this->result = $this->cities;
    }

    public function all()
    {
        return $this->result;
    }

    public function slugify()
    {
        if (is_array($this->result)) {
            $this->result = array_map(function ($item) {
                return Sanitize::dash($item);
            }, $this->result);
        }

        $this->result = array_combine($this->result, $this->cities);
        return $this;
    }
}
