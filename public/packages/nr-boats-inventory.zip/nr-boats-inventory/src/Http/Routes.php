<?php


namespace NativerankInventory\Http;


use NativerankInventory\Utility\Inventory;

class Routes
{


    public function regester()
    {
        add_action('rest_api_init', function () {
            register_rest_route('nr_boats/v1', '/search/(?P<search>.+?)', array(
                'methods' => 'GET',
                'callback' => function (\WP_REST_Request $request) {
                    $query = $request['search'];
                    $Inventory = new Inventory([
                        'posts_per_page' => -1,
                        'paged' => 1,
                        's' => $query
                    ]);
                    $Inventory->query()->withAttributes()->withFields();

                    wp_send_json([
                        'boats' => $Inventory->getBoats(),
                        'startingBoatNum' => $Inventory->startingBoatNum,
                        'boatsDisplaying' => $Inventory->boatsDisplaying,
                        'totalBoats' => $Inventory->totalBoats
                    ]);
                },
            ));
        });
    }
}
