<?php


namespace NativerankInventory\Database;


class Register
{
    public $wpdb;

    public function __construct()
    {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public function all()
    {
        $this->offer();
    }

    public function offer()
    {
        $charset_collate = $this->wpdb->get_charset_collate();
        $table_name = $this->wpdb->prefix . 'offers';

        $sql = "CREATE TABLE $table_name (
        id int(11) unsigned NOT NULL AUTO_INCREMENT,
        name varchar(255) DEFAULT NULL,
        ad_link varchar(255) DEFAULT NULL,
        image_id  int(11) NULL,   
		UNIQUE KEY id (id)
	) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }
}
