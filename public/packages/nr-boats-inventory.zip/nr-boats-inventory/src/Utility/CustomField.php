<?php


namespace NativerankInventory\Utility;


use TypeRocket\Utility\Sanitize;

class CustomField
{
    protected $postId;
    protected $taxonomies;

    public function __construct($postId)
    {
        $this->postId = $postId;
        $this->getTaxonomies();
    }


    private function getTaxonomies()
    {
        $taxonomies = get_post_taxonomies($this->postId);
        $this->taxonomies = $taxonomies;

    }

    public function get($field_name)
    {

        $field_name = Sanitize::underscore($field_name);

        if (in_array($field_name, $this->taxonomies)) {
            return $this->getTerms($field_name);
        }
        return get_post_meta($this->postId, $field_name, true);
    }

    public function getAll($field_names = [])
    {
        $result = [];
        foreach ($field_names as $field_name) {
            $result[$field_name] = $this->get($field_name);
        }
        return $result;

    }

    private function isRepeater($taxonomy_name)
    {
        return $taxonomy_name === 'images';
    }

    private function getTerms($taxonomy_name)
    {
        $terms = get_the_terms($this->postId, $taxonomy_name);

        $terms = is_array($terms) ? array_map(function ($item) {
            return $item->name;
        }, $terms) : null;

        if (is_array($terms) && count($terms) === 1) {
            return $terms[0];
        }
        return $terms;
    }
}
