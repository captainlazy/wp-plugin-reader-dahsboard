<?php


namespace NativerankInventory\Utility;


class Filters
{
    public $all;

    public function __construct()
    {
        $this->all = get_object_taxonomies('boat');
        return $this;
    }

    /**
     * @return array|int|\WP_Error
     */
    public function allTermsTaxonomies()
    {
        $cache = new Cache('allTermsTaxonomies');
        $organizedTerms = $cache->get();
        if (!$organizedTerms) {
            $allTerms = get_terms($this->all);
            $organizedTerms = [];
            if (!is_array($allTerms))
                return $allTerms;

            foreach ($allTerms as $term) {
                if (!isset($organizedTerms[$term->taxonomy])) {
                    $organizedTerms[$term->taxonomy] = [];
                }
                $organizedTerms[$term->taxonomy][$term->name] = ['count' => $term->count];
                ksort($organizedTerms[$term->taxonomy]);
            }

            $cache->set($organizedTerms)->attachHook('create_term');
        }

        return $organizedTerms;
    }
}
