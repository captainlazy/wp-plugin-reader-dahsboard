<?php


namespace NativerankInventory\Utility;


class Cache
{

    protected $group;
    protected $key;

    /**
     * Cache constructor.
     * @param $key
     * @param string $group
     */
    public function __construct($key, $group = 'nr_boats')
    {
        $this->key = $key;
        $this->group = $group;

    }

    /**
     * @param $data
     * @return $this
     */
    public function set($data)
    {
        wp_cache_set($this->key, $data, $this->group);
        return $this;
    }

    public function get()
    {
        return wp_cache_get($this->key, $this->group, true);
    }

    /**
     * @param $hook //clear cache on this hook
     * @return Cache
     */
    public function attachHook($hook)
    {
//        add_action($hook, [$this, 'clear']);
        return $this;
    }

    public function clear()
    {
        wp_cache_delete($this->key, $this->group);
        return $this;
    }
}
