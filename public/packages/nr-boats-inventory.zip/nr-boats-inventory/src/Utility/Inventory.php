<?php


namespace NativerankInventory\Utility;


class Inventory
{

    protected $args;
    public $totalPages;
    public $totalBoats;
    public $query;
    /**
     * @var int
     */
    public $boatsDisplaying;
    /**
     * @var float|int
     */
    public $startingBoatNum;
    public $tax_query;


    public function __construct($args = ['paged' => 1])
    {

        $this->args = $args;
    }

    public function query()
    {
        $defaults = [
            'post_type' => 'boat',
            'posts_per_page' => 10,
            'tax_query' => $this->tax_query
        ];

        $this->query = new \WP_Query(array_merge($defaults, $this->args));
        wp_reset_query();

        $multipliyer = 0;
        if (isset($this->query->query['paged']) && $this->query->query['paged'] > 10) {
            $multipliyer = 40;
        }
        $this->startingBoatNum = ($this->query->query['paged'] * $this->query->post_count) - ($this->query->query['posts_per_page'] - 1) + $multipliyer;
        $this->totalBoats = $this->query->found_posts;
        $this->totalPages = $this->query->max_num_pages;
        $this->boatsDisplaying = $this->query->post_count * $this->query->query['paged'] + $multipliyer;
        return $this;

    }


    public function filter($args = ['taxonomy_name' => 'term_name', 'year' => [2009, 2007]])
    {

        if (empty($args)) {
            return $this;
        }

        $args = array_map(function ($term, $taxonomy_name) {
            return [
                'taxonomy' => $taxonomy_name,
                'field' => 'name',
                'terms' => $term,
                'operator' => 'IN'
            ];
        }, $args, array_keys($args));

        $tax_query = [
            'relation' => 'AND',
            $args
        ];
        $this->tax_query = $tax_query;

        return $this;
    }

    //Passes all the attributes to each boat object
    public function withAttributes()
    {
        $Filters = new Filters();

        foreach ($this->query->posts as $post) {
            $taxonomy = wp_get_post_terms($post->ID, $Filters->all);
            $attr = [];
            foreach ($taxonomy as $t) {
                $attr[$t->taxonomy] = $t->name;
            }
            $post->attributes = $attr;
        }
        return $this;
    }

    public function withFields($fields = ['images', 'class', 'boat_stocknumber', 'boat_price', 'usage', 'boat_condition', 'boat_color'])
    {
        foreach ($this->query->posts as $post) {
            foreach ($fields as $field) {
                $post->{$field} = $this->getField($post->ID, $field);
            }
        }
        return $this;
    }

    public function getField($postId, $field_name)
    {
        $field = new CustomField($postId);
        return $field->get($field_name);
    }

    public function getBoats()
    {
        return $this->query->posts;
    }

}
