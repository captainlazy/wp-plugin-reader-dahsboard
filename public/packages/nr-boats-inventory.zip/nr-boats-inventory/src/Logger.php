<?php


namespace NativerankInventory;


class Logger {
	private $time;
	private $xmlFiles = array();
	private $log = array();

	public function __construct( $time ) {
		$this->time = $time;
		$cronLog    = get_option( 'nr_1055_inventory_cron_log' );
		if ( count( $cronLog ) > 36 ):
			array_shift( $cronLog );
		endif;
		$cronLog[] = $this->time;
		update_option( 'nr_1055_inventory_cron_log', $cronLog );
	}

	public function inventoryUpdated( $log ) {

		$this->xmlFiles = array_values( array_diff( scandir( plugin_dir_path( __DIR__ . '..' ) . '/xmlFiles/' ), array(
			'.',
			'..'
		) ) );

		if ( count( $this->xmlFiles ) > 36 ):
			unlink( plugin_dir_path( __DIR__ . '..' ) . '/xmlFiles/' . array_shift( $this->xmlFiles ) );
		endif;

		$this->log = get_option( 'nr_1055_inventory_log' );

		if ( is_array( $this->log ) && count( $this->log ) > 36 ):
			array_shift( $this->log );
		endif;


		if ( ! is_array( $this->log ) ) {
			$this->log = [];
		}

		$log->time   = $this->time;
		$this->log[] = $log;

		update_option( 'nr_1055_inventory_log', $this->log );

	}


}