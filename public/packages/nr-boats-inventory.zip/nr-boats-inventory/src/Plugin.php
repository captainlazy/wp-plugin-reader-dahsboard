<?php


namespace NativerankInventory;


use NativerankInventory\CustomPostTypes\Boat;
use NativerankInventory\Resource\Offer;
use Puc_v4_Factory;

class Plugin
{
	private $updateChecker;

	public function boot()
	{
		$this->registerCustomPostTypes();
		$this->registerCustomResources();
		$this->registerAdminPages();
		$this->registerShortcodes();

	}

	private function registerCustomPostTypes()
	{
		new Boat();
//        new Brand();
	}

	private function registerCustomResources()
	{
		new Offer();
	}

	private function registerAdminPages()
	{
		$invLogPage = tr_page('inventoryLog', 'index', 'Boat Update Logs', ['position' => 57]);
		$invLogPage->useController();
	}

	private function registerShortcodes()
	{
		new Shortcode();
	}

}
