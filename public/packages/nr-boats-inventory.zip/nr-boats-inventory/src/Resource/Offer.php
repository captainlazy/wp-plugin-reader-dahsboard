<?php


namespace NativerankInventory\Resource;


class Offer
{
    public function __construct()
    {
        tr_resource_pages('Offer')->setIcon('price-tags')->useController()->adminBar('nr_boats_offers');
    }
}
