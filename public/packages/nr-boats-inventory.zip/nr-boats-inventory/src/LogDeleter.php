<?php


namespace NativerankInventory;


class LogDeleter {
	private $xmlFiles;

	public function __construct() {
		$this->xmlFiles = array_values( array_diff( scandir( plugin_dir_path( __DIR__ . '..' ) . '/xmlFiles/' ), array(
			'.',
			'..'
		) ) );
		foreach ( $this->xmlFiles as $xmlFile ):
			unlink( plugin_dir_path( __DIR__ . '..' ) . '/xmlFiles/' . $xmlFile );

		endforeach;
		update_option( 'nr_1055_inventory_log', array(
			array(
				'time'            => time(),
				'xmlFileName'     => 'Logs and XML Files Deleted',
				"recentlyCreated" => '',
				"recentlyUpdated" => '',
				"recentlyDeleted" => '',
				'xmlFileUrl'      => '#'
			)
		) );
		update_option( 'nr_1055_inventory_cron_log', array( time() ) );
	}

	public function getResults()
	{
		$results  = [];
		$logs     = json_encode(get_option('nr_1055_inventory_log'));
		$cronLogs = get_option('nr_1055_inventory_cron_log');

		foreach ($cronLogs as $cronLog):
			$cronLogObj[] = array("time" => $cronLog);
		endforeach;
		$cronLogs = json_encode($cronLogObj);

		$results['message'] = '<b>Logs and XML Files Deleted</b><script>var nr_ev_response = new CustomEvent("log_updated", {detail: ' . $logs . '}); document.dispatchEvent(nr_ev_response); var nr_cron_ev_response = new CustomEvent("cron_log_updated", {detail: ' . $cronLogs . '}); document.dispatchEvent(nr_cron_ev_response);</script>';
		return $results;
	}
}