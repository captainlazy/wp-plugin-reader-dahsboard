<?php

use NativerankInventory\Utility\Filters;
use NativerankInventory\Utility\Inventory;


$city = get_query_var('city') ?? false;

$paged = isset($_REQUEST['_p']) ? $_REQUEST['_p'] : 1;
$limit = 20;
$Inventory = new Inventory([
    'posts_per_page' => -1,
    'paged' => $paged
]);

$Filters = new Filters();

$Inventory->query()->withAttributes()->withFields();

$allBoats = array_chunk($Inventory->getBoats(), $limit);

if ($paged > count($allBoats)) {
    $paged = count($allBoats);
}

array_unshift($allBoats, []);
$state = 'Colorado';

$boatType = isset($shortcodeFilters['boat_type']) ? $shortcodeFilters['boat_type'] : 'Boats';
$boatType = isset($shortcodeFilters['class']) ? $shortcodeFilters['class'] : $boatType;
$boatType = isset($shortcodeFilters['usage']) ? $shortcodeFilters['usage'] . ' ' . $boatType : $boatType;

// if middle slug page is passes from nr-boats.php. Dynamic Page
$boatTypePage = !empty(get_query_var('middle_slug_page')) ? get_query_var('middle_slug_page') : get_post();

if (!empty($boatTypePage) && str_contains('boats', strtolower($boatTypePage->post_title))) {

    $boatType = explode(' ', $boatTypePage->post_title)[0] . ' Boats';
}

//
//if (strtolower($boatType) === 'boats')
//    $boatType = false;
?>
    <style xmlns="http://www.w3.org/1999/html">
        [v-cloak] {
            height: 800px;
            overflow: hidden;
        }

        [v-cloak] * {
            display: none;
        }

        [v-cloak]:after {
            margin: 30px;
            content: '';
            display: block;
            height: 100%;
            background-image: linear-gradient(100deg, rgba(255, 255, 255, 0), rgba(255, 255, 255, 0.35) 50%, rgba(255, 255, 255, 0) 80%),
            linear-gradient(lightgray 20px, transparent 0),
            linear-gradient(lightgray 10px, transparent 0),
            linear-gradient(lightgray 10px, transparent 0),
            linear-gradient(lightgray 10px, transparent 0);

            background-repeat: repeat-y;

            background-size: 50px 100px,
            150px 100px,
            280px 100px,
            280px 100px,
            280px 100px;

            background-position: 0 0,
            0 0,
            0 30px,
            0 50px,
            0 70px;

            animation: skel 1s infinite;
        }


        @keyframes skel {
            to {
                background-position: 100% 0,
                0 0,
                0 30px,
                0 50px,
                0 70px;
            }
        }

    </style>

    <div id="inventory-app">
        <header class="in_nav uk-section-default" style="border-top:1px solid #cfcfcf;">
            <div class="uk-container">
                <div class="uk-grid uk-flex-between uk-flex-bottom" uk-grid>
                    <div>
                        <ul class="uk-breadcrumb uk-margin-remove">
                            <li>
                                <a href="<?= get_site_url() ?>">Home</a>
                            </li>
                            <li>
                                <a href="<?= get_site_url() ?>/colorado-boats-for-sale/">Boats For Sale</a>
                            </li>
                            <?php if (!empty($boatType && strtolower(explode(' ', $boatTypePage->post_title)[0]) !== 'boat')) : ?>
                                <li>
                                    <a href="<?= get_permalink($boatTypePage->ID) ?>"><?= explode(' ', $boatTypePage->post_title)[0] ?></a>
                                </li>
                            <?php endif; ?>
                            <li>
                                <span><?= $state ?></span>
                            </li>
                            <?php if (!empty($city)) : ?>
                                <li>
                                <span>
                                    <?= $city->label ?>
                                </span>
                                </li>
                            <?php endif; ?>
                        </ul>
                        <h1 class="uk-h4 uk-margin-remove-bottom el-title">
                            <?= $boatType ?> For Sale In <?= empty($city) ? '' : "{$city->label}, " ?> <?= $state ?>
                        </h1>
                    </div>

                    <div class="uk-width-auto@m">
                        <div class="uk-grid uk-child-width-auto@m">
                            <div>
                                <span uk-spinner="" v-if="loading" class="uk-text-primary"></span>

                                <div class="uk-inline page search">
                                    <span class="uk-form-icon uk-form-icon-flip" uk-icon="icon: search"></span>
                                    <input class="uk-input" id="searchInventory" type="search"
                                           placeholder="Search Inventory"
                                           v-model="search">
                                </div>
                            </div>
                            <div>
                                <select name="sort-by" class="uk-select" v-model="sortBy">
                                    <option> Sort By</option>
                                    <option v-for="option in sortOptions" :key="option.value" :value="option.value">
                                        {{option.label}}
                                    </option>
                                </select>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </header>
        <section class="uk-section uk-section-muted body">
            <div class="uk-container">
                <div class="uk-grid uk-child-width-expand@m" uk-grid="">
                    <div class="uk-width-1-4@m">
                        <div class="uk-hidden@m">
                            <button class="uk-button filter-enable uk-button-small uk-button-primary"
                                    uk-toggle="target:#filtersPanel;cls:uk-active">
                                Filters
                            </button>
                        </div>
                        <div class="uk-tile uk-tile-default" v-cloak id="filtersPanel"
                             uk-accordion="multiple: true; targets: > .filter-part">
                            <section class="filter-part uk-open" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Boat Type
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.boat_type)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.boat_type.length + ' Selected'">{{userFilter.boat_type.length}}</span>
                                        <span class="action"
                                              @click="userFilter.boat_type=[], track({eventAction: 'Clear', eventLabel: 'boat_type'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list">
                                        <li v-for="(filter, label) in filtersPersistent.boat_type" :key="label"
                                            :class="{'disabled_inventory_item' : !compareFilter('boat_type', label)}">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label" v-model="userFilter.boat_type"
                                                       :disabled="!compareFilter('boat_type', label)"

                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                    ({{compareFilter('boat_type', label)}})
                                                </span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>

                            <section class="filter-part uk-open" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Condition <span class="selected_filter" v-if="!_.isEmpty(userFilter.usage)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.usage.length + ' Selected'">{{userFilter.usage.length}}</span>
                                        <span class="action"
                                              @click="userFilter.usage=[], track({eventAction: 'Clear', eventLabel: 'usage'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list uk-flex uk-flex-middle">
                                        <li v-for="(filter, label) in filtersPersistent.usage"
                                            :class="{'disabled_inventory_item' : !compareFilter('usage', label)}"
                                            :key="label">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label"
                                                       :disabled="!compareFilter('usage', label)"
                                                       v-model="userFilter.usage"

                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                    ({{compareFilter('usage', label)}})
                                                </span>

                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>
                            <section class="filter-part" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Brand
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.brand)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.brand.length + ' Selected'">{{userFilter.brand.length}}</span>
                                        <span class="action"
                                              @click="userFilter.brand=[], track({eventAction: 'Clear', eventLabel: 'brand'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list large">
                                        <li v-for="(filter, label) in sortFilters('brand')"
                                            :class="{'disabled_inventory_item' : !compareFilter('brand', label)}"
                                            :key="label">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label"
                                                       style
                                                       v-model="userFilter.brand"
                                                       :disabled="!compareFilter('brand', label)"
                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                    ({{compareFilter('brand', label)}})
                                                </span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>

                            <section class="filter-part" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Style
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.class)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.class.length + ' Selected'">{{userFilter.class.length}}</span>
                                        <span class="action"
                                              @click="userFilter.class=[], track({eventAction: 'Clear', eventLabel: 'class'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list large">
                                        <li
                                                :class="{'disabled_inventory_item' : !compareFilter('class', label)}"

                                                v-for="(filter, label) in sortFilters('class')"
                                                :key="label">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label"
                                                       style
                                                       v-model="userFilter.class"
                                                       :disabled="!compareFilter('class', label)"
                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                                                                        ({{compareFilter('class', label)}})
                                                </span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>

                            <section class="filter-part" tabindex="-1">
                                <h4 class="uk-accordion-title" :class="!_.isEmpty(userFilter.model_year)">
                                    Model Year
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.model_year)">

                                        <span class="action"
                                              @click="userFilter.model_year=[], years.min = '', years.max = '', track({eventAction: 'Clear', eventLabel: '= '}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <div class="uk-panel">
                                        <div uk-grid="" class="uk-grid uk-child-width-expand@s uk-grid-small">
                                            <div>
                                                <div class="slot number uk-position-relative">
                                                    <input type="number" class="uk-input" min="1980" max="2030"
                                                           v-model="years.min"
                                                           placeholder="Min Year"/>
                                                    <div class="controls uk-position-right uk-flex uk-flex-column">
                                                        <div class="uk-height-1-2"
                                                             @click="(!years.min && String(years.min).length < 1 && (years.min = 1981)) || (years.min++)">
                                                            <span uk-icon="chevron-up"></span>
                                                        </div>

                                                        <div class="uk-height-1-2"
                                                             @click="(!years.min && String(years.min).length < 1 && (years.min = 2019)) || (years.min--)">
                                                            <span uk-icon="chevron-down"></span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div>
                                                <div class="slot uk-position-relative number">
                                                    <input type="number" class="uk-input" min="1980" max="2030"
                                                           placeholder="Max Year" v-model="years.max"/>
                                                    <div class="controls uk-position-right uk-flex uk-flex-column">
                                                        <div class="uk-height-1-2"
                                                             @click="(!years.max && String(years.max).length < 1 && (years.max = 2000)) || (years.max++)">
                                                            <span uk-icon="chevron-up"></span>
                                                        </div>

                                                        <div class="uk-height-1-2"
                                                             @click="(!years.max && String(years.max).length < 1 && (years.max = 2021)) || (years.max--)">
                                                            <span uk-icon="chevron-down"></span>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                            <section class="filter-part" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Engine Type
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.engine_type)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.engine_type.length + ' Selected'">{{userFilter.engine_type.length}}</span>
                                        <span class="action"
                                              @click="userFilter.engine_type=[], track({eventAction: 'Clear', eventLabel: 'engine_type'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list large">
                                        <li
                                                v-for="(filter, label) in sortFilters('engine_type')"
                                                :class="{'disabled_inventory_item' : !compareFilter('engine_type', label)}"

                                                :key="label">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label"
                                                       :disabled="!compareFilter('engine_type', label)"
                                                       style
                                                       v-model="userFilter.engine_type"
                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                    ({{compareFilter('engine_type', label)}})
                                                </span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>
                            <section class="filter-part" tabindex="-1">
                                <h4 class="uk-accordion-title">
                                    Engine Make
                                    <span class="selected_filter" v-if="!_.isEmpty(userFilter.engine_make)">
                                        <span class="number"
                                              :uk-tooltip="userFilter.engine_make.length + ' Selected'">{{userFilter.engine_make.length}}</span>
                                        <span class="action"
                                              @click="userFilter.engine_make=[], track({eventAction: 'Clear', eventLabel: 'engine_make'}, $el)">Clear</span></span>
                                </h4>
                                <div class="uk-accordion-content">
                                    <ul class="uk-list large">
                                        <li v-for="(filter, label) in sortFilters('engine_make')"
                                            :class="{'disabled_inventory_item' : !compareFilter('engine_make', label)}"
                                            :key="label">
                                            <label class="checkbox uk-cursor-pointer">
                                                <input type="checkbox" :value="label"
                                                       style
                                                       v-model="userFilter.engine_make"
                                                       :disabled="!compareFilter('engine_make', label)"
                                                       class="uk-checkbox">
                                                <span class="uk-text-middle">{{label}}</span>
                                                <span class="uk-text-small uk-text-small meta_count">
                                                    ({{compareFilter('engine_make', label)}})
                                                </span>
                                            </label>
                                        </li>
                                    </ul>
                                </div>
                            </section>

                        </div>
                        <div class="uk-text-right uk-margin-top uk-width-1-1 makeItSticky uk-visible@m">
                            <a href="#" uk-totop uk-scroll></a>
                        </div>
                    </div>
                    <div>
                        <div class="uk-panel uk-margin-remove-last-child" v-if="!reactive">
                            <h4 class="uk-text-small uk-margin-small-bottom uk-text-bold" style="color:#6e6e6e">
                                Showing <?= $limit * ($paged - 1) + 1 ?>
                                - <?= $limit * ($paged - 1) + count($allBoats[$paged]) ?>
                                of <?= $Inventory->totalBoats ?> Boats</h4>
                            <div>
                                <?php
                                foreach ($allBoats[$paged] as $boat) {
                                    $field = new \NativerankInventory\Utility\CustomField($boat->ID);
                                    include(NR_INVENTORY_PLUGIN_DIR . '/src/Views/single.php');
                                }
                                ?>
                            </div>

                            <hr>
                            <div class="uk-flex uk-flex-center">
                                <ul class="uk-pagination uk-margin-auto">
                                    <?= $paged != 1 ? '<li><a href="?_p=' . ($paged - 1) . '" @click.prevent="changePage(' . ($paged - 1) . ')"><span uk-pagination-previous></span></a></li>' : '' ?>

                                    <?php $pageNum = 1;
                                    while ($pageNum <= count($allBoats) - 1): ?>
                                        <li <?= $pageNum == $paged ? 'class="uk-active"' : '' ?>><a
                                                    @click.prevent="changePage(<?= $pageNum ?>)"
                                                    href="?_p=<?= $pageNum ?>"><?= $pageNum ?></a></li>
                                        <?php $pageNum++; endwhile; ?>
                                    <?= $paged != count($allBoats) - 1 ? '<li><a @click.prevent="changePage(' . ($paged + 1) . ')" href="?_p=' . ($paged + 1) . '"><span uk-pagination-next></span></a></li>' : '' ?>
                                </ul>
                            </div>
                        </div>
                        <div v-else class="uk-panel">
                            <div v-if="rawBoats && rawBoats.length > 0">
                                <h4 class="uk-text-small uk-margin-small-bottom uk-text-bold" style="color:#6e6e6e">
                                    Showing {{ pagination.limit * (pagination.paged - 1) + 1}}
                                    - {{ pagination.limit * (pagination.paged - 1) + allBoats[pagination.paged].length
                                    }}
                                    of {{ rawBoats.length }} Boats</h4>
                                <div>
                                    <div v-for="boat in allBoats[pagination.paged]" :key="boat.ID">
                                        <div>
                                            <boat-single :boat="boat"/>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="uk-flex uk-flex-center">
                                    <ul class="uk-pagination uk-margin-auto">

                                        <li v-if="pagination.paged != 1"><a :href="'?_p='+(pagination.paged - 1)"
                                                                            @click.prevent="changePage(pagination.paged-1)"><span
                                                        uk-pagination-previous></span></a></li>
                                        <li :class="{'uk-active' : pagination.paged == n}"
                                            v-for="n in allBoats.length - 1" :key="'pag_' + n"><a
                                                    :href="'?_p='+n" @click.prevent="changePage(n)">{{n}}</a></li>
                                        <li v-if="pagination.paged !== (allBoats.length - 1)"><a
                                                    :href="'?_p='+(pagination.paged + 1)"
                                                    @click.prevent="changePage(pagination.paged+1)"><span
                                                        uk-pagination-next></span></a></li>
                                    </ul>
                                </div>
                            </div>
                            <div v-else>
                                <h2>Sorry, We couldn't find any boats with current selection.</h2>
                                <button class="uk-button uk-button-secondary"
                                        @click.prevent="_.mapValues(userFilter, function() {return []})">
                                    Clear Filters
                                </button>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/vue/dist/vue.js"></script>
    <script src="https://unpkg.com/lodash@4.16.0"></script>


    <script>

		Vue.component('boat-single', {
			data: function () {
				return {
					count: 0,
				}
			},
			props: {
				boat: {
					type: Object,
					required: true
				}
			},
			template: `<?= trim(preg_replace('/\s+/', ' ', file_get_contents(NR_INVENTORY_PLUGIN_DIR . '/src/Views/components/BoatSingle.vue'))) ?>`
		})


		new Vue({
			el: '#inventory-app',
			data() {
				return {
					firstFilter: null,
					reactive: false,
					//sortOptions: Sort options in the drop down
					sortOptions: [
						{
							value: 'attributes.model_year:desc',
							label: 'Sort - Newest'
						},
						{
							value: 'attributes.model_year:asc',
							label: 'Sort - Oldest'
						},
						{
							value: 'boat_price:asc',
							label: 'Price - Lowest'
						},
						{
							value: 'boat_price:desc',
							label: 'Price - Highest'
						}
					],
					//sortBy: Value of the Sort By dropdown
					sortBy: 'Sort By',
					//userFilter:  userSelected filters from the filter panel on the left hand side
					userFilter: {
						usage: [],
						boat_type: [],
						brand: [],
						class: [],
						model_year: [],
						engine_type: [],
						engine_make: []
					},
					loading: false,
					//search: user search query
					search: '<?= $_GET['search'] ?? ""?>',
					//searchedBoats: filtered boats received from api usuinbg user search query
					searchedBoats: null,
					pagination: {
						limit: <?= $limit ?>,
						paged: <?= $paged ?>,
						totalPages: <?= $Inventory->totalPages ?>
					},
					custom_filters: {},
					//years: two user selected years
					years: {
						min: '',
						max: ''
					},

					//filtersPersistent: all possible filter options
					filtersPersistent: <?= json_encode($Filters->allTermsTaxonomies()) ?>,
					settings: <?= json_encode([
                        'boats' => $Inventory->getBoats(),
                        'startingBoatNum' => $Inventory->startingBoatNum,
                        'boatsDisplaying' => $Inventory->boatsDisplaying,
                        'totalBoats' => $Inventory->totalBoats
                    ]) ?>,
					shortcodeFilters: <?= json_encode($shortcodeFilters) ?>
				}
			},
			watch: {
				years: {
					handler() {
						this.userFilter.model_year = this.getYearsArray(this.years.min, this.years.max)
					},
					deep: true
				},
				userFilter: {
					handler(val) {
						let firstTruthUserFilter = _.findKey(this.userFilter, item => (!_.isEmpty(item)))

						if (!this.firstFilter) {
							this.firstFilter = firstTruthUserFilter
						}

						if (_.isUndefined(firstTruthUserFilter)) {
							this.firstFilter = null
						}

						this.updateInventory(1)
					},
					deep: true
				},
				sortBy: function () {
					this.updateInventory(1)

				},
				search: _.debounce(function (oldValue, newValue) {
					if (oldValue === newValue) {
						return
					}

					this.loading = true
					if (_.isEmpty(this.search) || this.search === '') {
						this.searchedBoats = null
						this.updateInventory(1)

						return

					}
					this.getFilteredBoats()
				}, 500)
			},
			computed: {
				rawBoats: function () {
					let boats = this.settings.boats;

					if (this.searchedBoats) {
						boats = this.searchedBoats.boats
					}

					let userFilters = this.cleanUserFilters();

					// Filter Boats using user filters
					if (!_.isEmpty(userFilters)) {
						boats = this.filter(boats, userFilters)
					}

					// Sort boats using sortBy value
					if (!_.isEmpty(this.sortBy) && this.sortBy !== 'Sort By') {

						let attr = this.sortBy

						attr = {
							order: attr.split(':')[1],
							key: attr.split(':')[0]

						}
						boats = _.orderBy(boats, o => {
							let newOrder = {
								asc: 999999,
								desc: 0
							}

							let newVal = Number(_.get(o, attr.key, 0))


							if (newVal === 0) {
								return newOrder[attr.order]
							}

							return newVal
						}, attr.order)

					}

					return boats;

				},
				allBoats: function () {

					let chunkedBoats = _.chunk(this.rawBoats, this.pagination.limit);
					chunkedBoats.unshift(null)
					return chunkedBoats
				},
				//These filter values change as the user filter change
				reactiveFilters: function () {
					return this.getAllFilters(this.rawBoats)
				},
			},
			methods: {
				sortFilters(filter_key) {
					let filters = this.filtersPersistent[filter_key]
					if (this.firstFilter && this.firstFilter !== filter_key) {
						let sortedAr = _.reverse(_.sortBy(filters, (item) => {
							let label = _.findKey(filters, function (x) {
								return item === x
							})
							item.label = label;
							return item.count;
						}))
						filters = {}


						_.each(sortedAr, fil => {


								filters[fil.label] = (fil)
							}
						)
					}
					return filters
				},
				getFilteredBoats() {
					UIkit.util.ajax('<?= get_site_url()?>/wp-json/nr_boats/v1/search/' + this.search, {responseType: 'json'})
						.then(({response}) => {
							this.searchedBoats = response
							this.updateInventory(1)
							this.loading = false
						});
				},
				track(payload, el) {
					let defaults = {
						eventCategory: 'UX',
						eventAction: 'Click',
						eventLabel: el.innerText,
					}
					payload = _.defaults(payload, defaults)

					if (_.isFunction(window.ga)) {
						console.log({analytics: payload})
						// ga('send', 'event', payload);
					}
				},
				//years:  Creates an array of years(range) using the two user selected years
				getYearsArray(startYear, endYear) {
					let years = [];
					endYear = Number((_.isEmpty(endYear) ? new Date().getFullYear() : endYear))

					if (endYear < 1980)
						endYear = new Date().getFullYear()

					if (startYear < 1980)
						startYear = 1970

					startYear = Number((_.isEmpty(startYear) ? 1980 : startYear))

					while (startYear <= endYear) {
						years.push(String(startYear++));
					}
					return years;
				},

				updateFilters(filter_name) {
					if (_.isString(filter_name))
						filter_name = [filter_name]
					_.each(filter_name, filter_key => {
						this.custom_filters[filter_key] = this.reactiveFilters[filter_key]
					})

				},
				filter(boats, filters) {

					let filter_val
					Object.keys(filters).forEach(filter_key => {
						filter_val = filters[filter_key]
						boats = boats.filter(boat => {
							return _.includes(filter_val, boat['attributes'][filter_key]) || _.includes(filter_val, boat[filter_key])
						})
					})


					return boats
				},
				getAllFilters(boats) {
					let res = {}
					boats.map(boat => {
						let bAtts = boat.attributes
						Object.keys(bAtts).map((val) => {
							key = bAtts[val]
							if (!(val in res)) {
								res[val] = {}
							}
							if (!(key in res[val])) {
								res[val][key] = {
									count: 1
								}
							} else {
								res[val][key].count++
							}
						})

					})

					let orderedRes = {}

					_.each(res, (val, key) => {
						_(res[key]).keys().sort().each(k => {
							!orderedRes.hasOwnProperty(key) && (orderedRes[key] = {})
							!orderedRes[key].hasOwnProperty(k) && (orderedRes[key][k] = {})
							orderedRes[key][k] = res[key][k]
						})
					})
					return orderedRes
				},
				compareFilter(filter_key, label) {
					let res
					if (this.firstFilter !== filter_key) {
						res = this.reactiveFilters[filter_key];
					} else {
						res = this.filtersPersistent[filter_key]
					}

					return (res && res[label] ? res[label].count : 0)

				},
				cleanUserFilters() {
					return _.pickBy(this.userFilter, obj => !_.isEmpty(obj))
				},
				changePage(paged) {
					if(typeof UIkit !== 'undefined') {
					UIkit.scroll('.makeItSticky').scrollTo('#')
					}
					this.reactive = true
					this.pagination.paged = (paged ? paged : this.pagination.paged)
				},
				updateInventory(paged) {
					this.$nextTick(() => {
						this.loading = false
						this.changePage(paged)

					})
				},
				filterFromShortcode() {
					if (this.shortcodeFilters.length !== 0) {
						_.forEach(this.shortcodeFilters, (filterValue, filterName) => {
							this.userFilter[filterName].push(filterValue)
						})
					}
				}
			},
			created() {
				if (!_.isEmpty(this.search)) {
					this.getFilteredBoats()
				}
				this.filterFromShortcode()
			},
			mounted() {
				_.forEach(this.custom_filters, (filterValues, filterName) => {
					this.custom_filters[filterName] = this.filtersPersistent[filterName]
				})
			}
		})

    </script>


    <style>

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .uk-text-meta {
            color: #b6b6b6;
        }

        .uk-label {

            font-size: 0.7rem;
        }

        .uk-dotnav > * > * {
            width: 5px;
            height: 5px;
        }

        .uk-button-secondary.outlined {
            background: transparent;
            color: #30a325;
            border-color: #30a325;
        }

        .single_boat_card {
            box-shadow: rgba(25, 41, 61, 0.18) 0px 2px 3px 1px;
            padding: 30px 15px;
            background: #fff;
        }

        .single_boat_card:hover {
            box-shadow: rgba(24, 41, 61, 0.1) 0px 14px 21px;
            transition: all 0.2s ease 0s;
        }

        .single_boat_card * {
            transition: opacity 0.2s ease 0s;
        }

        .blur * {
            opacity: 0.99;
        }

        .single_boat_card .el-title {
            font-size: 18px;
            font-weight: 700;
            white-space: nowrap;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        @keyframes shine {
            to {
                background-position-x: 300px;
            }
        }

        .filter-part * {
            -webkit-touch-callout: none;
            -webkit-user-select: none;
            -khtml-user-select: none;
            -moz-user-select: none;
            -ms-user-select: none;
            -o-user-select: none;
            user-select: none;
        }

        .single_boat_card .uk-card-media:hover .uk-slideshow-items {
            background-image: linear-gradient(90deg, rgba(35, 35, 35, 0), rgba(0, 0, 0, 0.08), rgba(35, 35, 35, 0));
            background-repeat: repeat-y;
            background-position-x: -130px;
            animation: shine 1s infinite;
        }

        .disabled_inventory_item input {
            border: 2px solid rgb(89, 99, 110) !important;
        }

        .disabled_inventory_item label.checkbox {
            cursor: not-allowed !important;
        }

        .disabled_inventory_item {
            opacity: 0.6;
        }

        .tm-header .uk-logo {
            top: -41px;
            width: 127px;
        }


        .uk-pagination > * {
            padding-left: 0;
        }

        .uk-pagination > * > * {
            display: block;
            background: #fff;
            box-sizing: border-box;
            min-width: 0;
            padding: 6px 12px;
            line-height: 1.5;
            text-align: center;
            transition: .1s ease-in-out;
            transition-property: color, background-color, border-color, box-shadow;
            font-size: 16px;
            color: #6d7782;
        }

        .uk-pagination > * > *:hover {
            background: #e1e4e8
        }


        .uk-pagination > .uk-active > * {
            background: #36b82a;
            color: #fff;
        }

        #filtersPanel {
            box-shadow: 0 1px 4px 1px rgba(0, 0, 0, .1);
            border-color: #e1e4e8;
            border-radius: 4px;
            padding-bottom: 20px;
        }

        .filter-part .uk-accordion-title {
            margin: 0 !important;
            cursor: pointer;
            padding: 16px;
        }

        .filter-part .uk-accordion-content {
            padding: 0 16px;
            margin-top: 0;
        }

        .filter-part .uk-accordion-content ul {
            margin: 0 !important;

        }

        .filter-part .uk-accordion-content ul.large {
            max-height: 280px;
            height: auto;
            overflow-y: auto;
        }

        .filter-part label.checkbox {
            cursor: pointer;
            display: block;
        }

        .filter-part .uk-checkbox {
            margin-right: 6px;
            height: 14px;
            width: 14px;
            overflow: hidden;
            margin-top: 0;
            background-size: 80%;
            border: 2px solid rgb(89, 99, 110);
            border-radius: 2px;
            transition-property: background-color, box-shadow;
        }

        .meta_count {
            color: rgba(89, 99, 110, 0.5);
        }

        .filter-part label:hover .uk-checkbox:not(:checked) {
            border-color: #36b82a;
        }

        .filter-part .uk-checkbox:checked {
            color: #fff;
            background-color: #36b82a;
            border-color: #36b82a;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='11' stroke-width='2' stroke='%23ffffff'%3E%3Cpath fill='%23ffffff' d='M12 1L5 7.5 2 5l-1 .5L5 10l8-8.5z'/%3E%3C/svg%3E");
        }

        .uk-list.uk-flex li:not(:first-child) {
            margin-left: 20px;
        }

        .uk-list.uk-flex li {
            margin-top: 0;
        }

    </style>
    <style>
        #progressBar {
            position: fixed;
            top: 100px;
            left: 0;
            right: 0;
            z-index: 9999;
        }

        .progress-linear {
            background: transparent;
            overflow: hidden;
            position: relative;
            transition: 0.2s;
            width: 100%;
        }

        .progress-linear__buffer {
            height: inherit;
            left: 0;
            position: absolute;
            top: 0;
            transition: inherit;
            width: 100%;
            z-index: 1;
        }

        .progress-linear__background {
            bottom: 0;
            left: 0;
            position: absolute;
            top: 0;
            transition: inherit;
        }

        .progress-linear__indeterminate .long, .progress-linear__indeterminate .short {
            background-color: inherit;
            bottom: 0;
            height: inherit;
            left: 0;
            position: absolute;
            top: 0;
            width: auto;
            will-change: left, right;
        }

        .progress-linear__indeterminate--active .long {
            -webkit-animation: indeterminate;
            animation: indeterminate;
            -webkit-animation-duration: 2.2s;
            animation-duration: 2.2s;
            -webkit-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
        }

        .progress-linear__indeterminate--active .short {
            -webkit-animation: indeterminate-short;
            animation: indeterminate-short;
            -webkit-animation-duration: 2.2s;
            animation-duration: 2.2s;
            -webkit-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
        }

        .accent-4, .progress-linear__indeterminate .accent-4 {
            background-color: #30a325;
        }

        @-webkit-keyframes indeterminate {
            0% {
                left: -90%;
                right: 100%;
            }
            60% {
                left: -90%;
                right: 100%;
            }
            100% {
                left: 100%;
                right: -35%;
            }
        }

        @keyframes indeterminate {
            0% {
                left: -90%;
                right: 100%;
            }
            60% {
                left: -90%;
                right: 100%;
            }
            100% {
                left: 100%;
                right: -35%;
            }
        }

        @-webkit-keyframes indeterminate-short {
            0% {
                left: -200%;
                right: 100%;
            }
            60% {
                left: 107%;
                right: -8%;
            }
            100% {
                left: 107%;
                right: -8%;
            }
        }

        @keyframes indeterminate-short {
            0% {
                left: -200%;
                right: 100%;
            }
            60% {
                left: 107%;
                right: -8%;
            }
            100% {
                left: 107%;
                right: -8%;
            }
        }

    </style>

    <script>
		window.onload = function () {
			if(typeof UIkit !== 'undefined') {
			    var misHeight = UIkit.util.height(UIkit.util.$('.makeItSticky'))
 			    UIkit.sticky('.makeItSticky', {offset: 130, top: 400, bottom: true})
			}
		}
    </script>
<?php
