<article class="uk-margin-bottom single_boat_card">
    <div class="uk-grid uk-child-width-expand@m uk-grid-margin-small uk-grid-match" uk-grid>
        <div class="uk-width-1-3@s">
            <div class="uk-card-media uk-cover-container">
                <?php
                $images = array_slice($field->get('images'), 0, 5);
                if (isset($images['url']))
                    $images = [['url' => $images['url']]];
                ?>
                <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1"
                     uk-slideshow="minHeight: 182">
                    <ul class="uk-slideshow-items">
                        <?php foreach ($images as $image): ?>
                            <li>
                                <img uk-img data-src="<?= $image['url'] ?>" uk-cover>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous
                       uk-slideshow-item="previous"></a>
                    <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next
                       uk-slideshow-item="next"></a>
                    <ul class="uk-slideshow-nav uk-dotnav uk-position-bottom-center uk-margin-small-bottom"></ul>
                </div>
            </div>
        </div>
        <div>
            <div class="uk-grid uk-child-width-expand@m" uk-grid>
                <div>
                    <div class="uk-panel">

                        <span class="uk-text-meta" title="Boat Style" uk-tooltip="Boat Style">
                <?= isset($boat->attributes['class']) ? $boat->attributes['class'] : (isset($boat->attributes['boat_type']) ? $boat->attributes['boat_type'] : '') ?>
            </span>
                        <a href="<?= get_permalink($boat->ID) ?>" class="uk-link-reset">
                            <h3 class="uk-margin-remove uk-h4 el-title"
                                title="<?= $boat->post_title ?>"><?= $boat->usage ?> <?= $boat->post_title ?></h3>
                        </a>
                        <div class="attributes uk-margin-small-top">
                            <table class="uk-table uk-table-small uk-table-hover">
                                <?php if (!empty($boat->boat_condition)): ?>
                                    <tr>
                                        <td>Condition</td>
                                        <td><?= $boat->boat_condition ?> </td>
                                    </tr>
                                <?php endif; ?>

                                <?php if (!empty($boat->attributes['length_overall'])): ?>
                                    <tr>
                                        <td>Overall Length</td>
                                        <td><?= $boat->attributes['length_overall'] ?> ft.</td>
                                    </tr>
                                <?php endif; ?>


                                <?php if (!empty($boat->boat_color)): ?>
                                    <tr>
                                        <td>Color</td>
                                        <td title="<?= $boat->boat_color ?>"><span
                                                    class="color_value"><?= $boat->boat_color ?></span></td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="uk-width-1-3@m">
                    <div class="uk-panel">
            <span class="uk-label uk-text-small">
                In Stock
            </span>
                        <div class="price uk-h4 uk-margin-small-bottom uk-margin-remove-top uk-text-bold">
                            <?php if (empty((int)$boat->boat_price)): ?>
                                Call For Price
                            <?php else: ?>
                                $<?= number_format($boat->boat_price, 0, '.', ','); ?>
                            <?php endif ?>
                        </div>
                        <div uk-margin>
                            <div>
                                <a href="tel:+19702256666"
                                   class="uk-button uk-button-secondary uk-button-small uk-width-1-1">
                                    (970) 225-6666
                                </a>
                            </div>
                            <div>
                                <a href="<?= get_permalink($boat->ID) ?>"
                                   class="uk-button outlined uk-button-secondary uk-button-small uk-width-1-1">
                                    Request Quote
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <hr class="uk-margin-small">
            <div class="uk-grid uk-flex-between uk-flex-middle uk-child-width-expand" uk-grid>
                <div>
                    <?php if (!empty($boat->boat_stocknumber)) : ?> <span
                            title="Stock Number"
                            uk-tooltip="Stock Number"
                            class="stock_num-label">#<?= $boat->boat_stocknumber ?></span><?php endif; ?>
                    <?php if (!empty($boat->attributes['location'])) : ?> <span
                            title="Location"
                            uk-tooltip="Location"
                            class="location-label"><span
                                uk-icon="icon:location;ratio:.8"></span> Fort Collins</span><?php endif; ?>
                </div>
                <div class="uk-width-auto@m">
                    <a href="<?= get_permalink($boat->ID) ?>"
                       class="uk-button  uk-button-small uk-width-1-1 awk-link">
                        <span class="uk-text-middle">View Boat</span> <span uk-icon="icon:arrow-right"></span>
                    </a>
                </div>
            </div>

        </div>
    </div>
</article>

