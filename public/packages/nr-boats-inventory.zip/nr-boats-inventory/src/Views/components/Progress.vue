<div role="progressbar" aria-valuemin="0" aria-valuemax="100"
     class="progress-linear progress-linear--rounded theme--light" style="height: 6px;">
    <div class="progress-linear__background  accent-4" style="opacity: 0.3; left: 0%; width: 100%;"></div>
    <div class="progress-linear__buffer"></div>
    <div class="progress-linear__indeterminate progress-linear__indeterminate--active">
        <div class="progress-linear__indeterminate long  accent-4"></div>
        <div class="progress-linear__indeterminate short  accent-4"></div>
    </div>
</div>
