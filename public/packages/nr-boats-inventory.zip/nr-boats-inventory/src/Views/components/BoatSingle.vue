<article class="uk-margin-bottom single_boat_card">
    <div class="uk-grid uk-child-width-expand@m uk-grid-margin-small uk-grid-match" uk-grid>
        <div class="uk-width-1-3@s">
            <div class="uk-card-media uk-cover-container">

                <div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow="">

                    <ul class="uk-slideshow-items" v-if="_.size(boat.images) > 0">
                        <li v-for="(image, idx) in (Array.isArray(boat.images) && _.size(boat.images) > 6 ? boat.images.splice(0, 5) : boat.images )"
                            :key=" boat.ID + 'images' + idx">
                            <img uk-img :data-src="image.url || image" uk-cover>
                        </li>

                    </ul>
                    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous
                       uk-slideshow-item="previous"></a>
                    <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next
                       uk-slideshow-item="next"></a>
                    <ul class="uk-slideshow-nav uk-dotnav uk-position-bottom-center uk-margin-small-bottom"></ul>
                </div>
            </div>

        </div>
        <div>
            <div class="uk-grid uk-child-width-expand@m" uk-grid>
                <div>
                    <div class="uk-panel">
            <span class="uk-text-meta" title="Boat Style" uk-tooltip="Boat Style" v-if="boat.class">
                {{ boat.class }}
            </span>
                        <a :href="'?p=' + boat.ID" class="uk-link-reset"><h3 class="uk-margin-remove uk-h4 el-title"
                                                                             :title="boat.title">{{boat.usage}}
                            {{boat.post_title}}</h3>
                        </a>
                        <div class="attributes uk-margin-small-top">
                            <table class="uk-table uk-table-small uk-table-hover">

                                <tr v-if="boat.boat_condition">
                                    <td>Condition</td>
                                    <td>{{boat.boat_condition}}</td>
                                </tr>
                                <tr v-if="boat.attributes.length_overall">
                                    <td>Overall Length</td>
                                    <td>{{boat.attributes.length_overall}} ft.</td>
                                </tr>
                                <tr v-if="!_.isEmpty(boat.boat_color)">
                                    <td>Color</td>
                                    <td :title="boat.boat_color"><span
                                            class="color_value">{{boat.boat_color}}</span></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="uk-width-1-3@m">
                    <div class="uk-panel">
            <span class="uk-label uk-text-small">
                In Stock
            </span>
                        <div class="price uk-h4 uk-margin-small-bottom uk-margin-remove-top uk-text-bold">
                            {{Number(boat.boat_price) !== 0 ? Number(boat.boat_price).toLocaleString('en-US', {style:
                            "currency", currency: "USD", minimumFractionDigits: 0}) : 'Call For Price'}}
                        </div>

                        <div uk-margin>
                            <div>
                                <a href="tel:+19702256666"
                                   class="uk-button uk-button-secondary uk-button-small uk-width-1-1">
                                    (970) 225-6666
                                </a>
                            </div>
                            <div>
                                <a :href="'?p=' + boat.ID"
                                   class="uk-button outlined uk-button-secondary uk-button-small uk-width-1-1">
                                    Request Quote
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <hr class="uk-margin-small">
            <div class="uk-grid uk-flex-between uk-flex-middle uk-child-width-expand@m" uk-grid>
                <div>
                     <span
                             v-if="boat.boat_stocknumber"
                             title="Stock Number"
                             uk-tooltip="Stock Number"
                             class="stock_num-label">#{{boat.boat_stocknumber}}</span>\
                    <span
                            title="Location"
                            uk-tooltip="Location"
                            class="location-label"><span
                            uk-icon="icon:location;ratio:.8"></span> Fort Collins</span>
                </div>
                <div class="uk-width-auto@m">
                    <a :href="'?p=' + boat.ID"
                       class="uk-button  uk-button-small uk-width-1-1 awk-link">
                        <span class="uk-text-middle">View Boat</span> <span uk-icon="icon:arrow-right"></span>
                    </a>
                </div>
            </div>

        </div>
    </div>
</article>

