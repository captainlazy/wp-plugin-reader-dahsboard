<?php
/**
 * Plugin Name: NR Boats Inventory
 * Plugin URI: https://nativerank.com
 * Description: NR Boats Inventory allows you to manage a boat inventory and allows users to view, filter and search that inventory on your website.
 * Version: 1.1.6
 * Author: Native Rank
 * Author URI: https://nativerank.com
 */

use NativerankInventory\Database\Register;
use NativerankInventory\Http\Routes;
use NativerankInventory\Scheduler;

if ( class_exists( 'NativerankInventory' ) ) {
	die();
}

define( 'NR_BOATS_ARCHIVE_SLUG', 'colorado-boats-for-sale' );

require( 'typerocket/init.php' );

require_once 'vendor/autoload.php';


add_action( 'template_redirect', function () {
	global $wp_rewrite;

	if ( is_search() && ! empty ( $_GET['s'] ) ) {
		$s        = sanitize_text_field( $_GET['s'] ); // or get_query_var( 's' )
		$location = '/';
		$location .= trailingslashit( '/colorado-boats-for-sale/' );
		$location .= '?search=' . $s;
		$location = home_url( $location );
		wp_redirect( $location, 301 );
		exit;
	}
} );


$database = new Register();
register_activation_hook( __FILE__, [ $database, 'all' ] );

define( 'NR_INVENTORY_API_URL', 'https://secure.islandlakemarine.com/unitinventory_univ.xml' );
define( 'NR_INVENTORY_TEST_URL', plugin_dir_path( __FILE__ ) . '0unitinventory_univ_TESTING.xml' );
define( 'NR_INVENTORY_PLUGIN_DIR', __DIR__ );
define( 'NR_INVENTORY_PLUGIN_DIR_NAME', basename( __DIR__ ) );
define( 'NR_INVENTORY_PLUGIN_MAIN_FILE', __FILE__ );


add_action( 'typerocket_loaded', function () {
	( new Routes )->regester();
	$plugin = new NativerankInventory\Plugin;
	$plugin->boot();
	new Scheduler();
} );


add_action( 'init', function () {
	global $wp_rewrite;
	$rule    = 'colorado-boats-for-sale/(.+?)/(.+?)/?$';
	$rewrite = 'index.php?pagename=colorado-boats-for-sale&middle_slug=$matches[1]&city=$matches[2]';
	add_rewrite_rule( $rule, $rewrite, 'top' );
	$wp_rewrite->flush_rules();
} );


//disable potentialAction Yoast schema
add_action( 'wpseo_schema_website', function ( $data ) {
	$data['potentialAction']['target'] = str_replace( '/?s=', '/' . NR_BOATS_ARCHIVE_SLUG . '/?search=', $data['potentialAction']['target'] );

	return $data;
} );

add_filter( 'query_vars',
	function ( $query_vars ) {
		$query_vars[] = 'middle_slug';
		$query_vars[] = 'city';

		return $query_vars;
	} );


$nr_boats_it = 1;
add_action( 'parse_query', function () {
	global $nr_boats_it;

	if ( $nr_boats_it === 1 ) {
		$nr_boats_it ++;

		$handle404 = function () {
			add_action( 'wp', function () {
				global $wp_query;
				$wp_query->set_404();
				status_header( 404 );
				nocache_headers();
				include( get_query_template( '404' ) );
				die();
			} );
		};

		global $wp_query;


		$city             = $wp_query->get( 'city' );
		$middle_slug      = $wp_query->get( 'middle_slug' );
		$middle_slug_page = get_page_by_path( '/colorado-boats-for-sale/' . $middle_slug );


		if ( ! empty( ( $city ) ) ) {
			$page = get_page_by_path( 'colorado-boats-for-sale/' . $wp_query->get( 'middle_slug' ) );
			if ( is_page( $page ) ) {
				$wp_query->set( 'pagename', null );
				$wp_query->set( 'page_id', $page->ID );
			}


			$cities     = new \NativerankInventory\Location\City();
			$cities_all = $cities->slugify()->all();
			$city       = \TypeRocket\Utility\Sanitize::dash( $city );
			$city       = isset( $cities_all[ $city ] ) ? $city : false;


			if ( empty( $city ) ) {
				$handle404();
			}

			if ( empty( $middle_slug ) || empty( $middle_slug_page ) ) {
				$handle404();
			}


			$wp_query->set( 'middle_slug_page', $middle_slug_page );

			$city_data = (object) [ 'label' => $cities_all[ $city ], 'slug' => $city ];
			$wp_query->set( 'city', $city_data );

			add_filter( 'wpseo_metadesc', function ( $trim ) use ( $city_data ) {
				return str_replace( 'Colorado', $city_data->label . ', CO', $trim );
			}, 10, 1 );

			add_filter( 'wpseo_title', function ( $trim ) use ( $city_data ) {
				return str_replace( 'Colorado', $city_data->label . ', CO', $trim );
			}, 10, 1 );

			add_filter( 'page_link', function ( $url, $post_id, $sample ) use ( $middle_slug, $city ) {
				$slugs = [
					'buy-new-boats',
					'buy-used-boats'
				];

				if ( in_array( basename( $url, "/" ), $slugs ) ) {
					return rtrim( $url, '/' ) . '/' . $city;
				}

				return $url;
			}, 9999, 3 );


		}


	}

} );

function nr_1055_boat_inventory_save_boat_action( $post_id ) {
	$post   = get_post( $post_id );
	$boatID = get_post_meta( $post->ID, 'boat_id', true );
	remove_action( 'save_post_boat', 'nr_1055_boat_inventory_save_boat_action' );
	if ( ! $boatID ) {
		$boatID = $post->ID;
		update_post_meta( $post->ID, 'boat_id', $boatID );
	}

	update_post_meta( $post->ID, 'boat_make', nr_1055_boat_inventory_implode_brand_terms( $post_id ) );
	add_action( 'save_post_boat', 'nr_1055_boat_inventory_save_boat_action' );
}

function nr_1055_boat_inventory_implode_brand_terms( $post_id ) {
	$terms     = get_the_terms( $post_id, 'brand' );
	$termNames = [];
	if ( ! $terms ) {
		return '';
	}
	foreach ( $terms as $term ) {
		$termNames[] = $term->name;
	}

	return implode( ', ', $termNames );
}

function nr_1055_boat_inventory_update_checker() {
	Puc_v4_Factory::buildUpdateChecker(
		'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_INVENTORY_PLUGIN_DIR_NAME,
		NR_INVENTORY_PLUGIN_MAIN_FILE,
		NR_INVENTORY_PLUGIN_DIR_NAME
	);
}

add_action( 'save_post_boat', 'nr_1055_boat_inventory_save_boat_action' );

add_filter( 'manage_boat_posts_columns', function ( $columns ) {
	$columns['make'] = 'Make';

	return $columns;
} );

add_action( 'manage_boat_posts_custom_column', function ( $column, $post_id ) {
	if ( 'make' === $column ) {
		echo( nr_1055_boat_inventory_implode_brand_terms( $post_id ) );
	}
}, 10, 2 );

add_filter( 'manage_edit-boat_sortable_columns', function ( $columns ) {
	$columns['make'] = 'boat_make';

	return $columns;
} );

add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() || ! $query->is_main_query() ) {
		return;
	}

	if ( 'boat_make' === $query->get( 'orderby' ) ) {
		$query->set( 'orderby', 'meta_value' );
		$query->set( 'meta_key', 'boat_make' );
	}
} );


add_action( 'plugins_loaded', 'nr_1055_boat_inventory_update_checker' );

