<?php
namespace App\Models;

use \TypeRocket\Models\WPPost;

class Boat extends WPPost
{
    protected $postType = 'boat';

}