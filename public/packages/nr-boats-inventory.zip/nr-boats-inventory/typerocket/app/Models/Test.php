<?php
namespace App\Models;

use \TypeRocket\Models\Model;

class Test extends Model
{
    protected $resource = 'tests';
}