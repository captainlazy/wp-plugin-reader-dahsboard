<?php
namespace App\Models;

use \TypeRocket\Models\Model;

class Updater extends Model
{
    protected $resource = 'updaters';
}