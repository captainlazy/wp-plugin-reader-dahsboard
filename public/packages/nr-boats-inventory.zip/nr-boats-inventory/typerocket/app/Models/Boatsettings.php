<?php
namespace App\Models;

use \TypeRocket\Models\Model;

class Boatsettings extends Model
{
    protected $resource = 'boatsettings';
}