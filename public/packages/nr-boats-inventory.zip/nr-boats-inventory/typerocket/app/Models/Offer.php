<?php
namespace App\Models;

use \TypeRocket\Models\Model;

class Offer extends Model
{
    protected $resource = 'offers';
}