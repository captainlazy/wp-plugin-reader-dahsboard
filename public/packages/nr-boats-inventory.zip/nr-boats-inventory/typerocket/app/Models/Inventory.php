<?php
namespace App\Models;

use \TypeRocket\Models\Model;

class Inventory extends Model
{
    protected $resource = 'inventories';
}