<?php

namespace App\Controllers;

use App\Models\Boatsettings;
use \TypeRocket\Controllers\Controller;

class InventorylogController extends Controller
{

	protected $modelClass = Boatsettings::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index()
	{
		$view = tr_view('boats.inventoryLog');
		return $view;
	}

}