<?php

namespace App\Controllers;

error_reporting(-1);
ini_set('display_errors', 'On');

use NativerankInventory\LogDeleter;
use NativerankInventory\Updater;
use TypeRocket\Controllers\Controller;
use TypeRocket\Http\Response;

class UpdaterController extends Controller
{
	public function update()
	{
		$updater        = new Updater();
		$updaterResults = $updater->getResults();
		$response       = new Response();
		$response->setMessage($updaterResults['message']);
		$response->exitJson(200);

		return;
	}

	public function forceUpdate()
	{
		$updater        = new Updater($force = true);
		$updaterResults = $updater->getResults();
		$response       = new Response();

		$response->setMessage($updaterResults['message']);
		$response->exitJson(200);

		return;
	}

	public function forceUpdateAll()
	{
		$updater        = new Updater($force = true, $forceAll = true);
		$updaterResults = $updater->getResults();
		$response       = new Response();

		$response->setMessage($updaterResults['message']);
		$response->exitJson(200);

		return;
	}

	public function delete()
	{
		$deleter        = new LogDeleter();
		$deleterResults = $deleter->getResults();

		$response = new Response();
		$response->setMessage($deleterResults['message']);
		$response->exitJson(200);

		return;
	}

}
