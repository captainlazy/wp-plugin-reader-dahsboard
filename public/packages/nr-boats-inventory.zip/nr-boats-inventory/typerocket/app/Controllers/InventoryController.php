<?php

namespace App\Controllers;

use NativerankInventory\Utility\Inventory;
use TypeRocket\Controllers\Controller;
use TypeRocket\Http\Request;

class InventoryController extends Controller
{


    public function find()
    {
        $request = new Request();

        $args = json_decode($request->getDataPost('args'), true);

        $Inventory = new Inventory(
            $args
        );

        $filters = json_decode($request->getDataPost('reactiveFilters'), true);

        $Inventory->filter($filters)->query()->withAttributes()->withFields();

        return ['boats' => $Inventory->getBoats(), 'startingBoatNum' => $Inventory->startingBoatNum, 'boatsDisplaying' => $Inventory->boatsDisplaying, 'totalBoats' => $Inventory->totalBoats, 'totalPages' => $Inventory->totalPages];

    }

}
