<?php

namespace App\Controllers;

use App\Models\Offer;
use TypeRocket\Controllers\Controller;

class OfferController extends Controller
{

    protected $modelClass = Offer::class;

    /**
     * The index page for admin
     *
     * @return mixed
     */

    public function index()
    {
        return tr_view('offers.index');
    }

    /**
     * The add page for admin
     *
     * @return mixed
     */
    public function add()
    {
        $form = tr_form('offer', 'create');
        return tr_view('offers.add', ['form' => $form]);
    }

    /**
     * Create item
     *
     * AJAX requests and normal requests can be made to this action
     *
     * @return mixed
     */
    public function create()
    {
        $offer = new Offer();
        $offer->name = $this->request->getFields('name');
        $offer->ad_link = $this->request->getFields('ad_link');
        $offer->image_id = $this->request->getFields('image_id');
        $offer->save();
        $this->response->flashNext('Offer created!');
        return tr_redirect()->toPage('offer', 'index');
    }

    /**
     * The edit page for admin
     *
     * @param string $id
     *
     * @return mixed
     */
    public function edit($id)
    {

        $form = tr_form('offer', 'update', $id);
        return tr_view('offers.edit', ['form' => $form]);
    }

    /**
     * Update item
     *
     * AJAX requests and normal requests can be made to this action
     *
     * @param string $id
     *
     * @param Offer $offer
     * @return mixed
     */
    public function update($id, Offer $offer)
    {
        $offer->name = $this->request->getFields('name');
        $offer->image_id = $this->request->getFields('image_id');
        $offer->ad_link = $this->request->getFields('ad_link');
        $offer->save();
        $this->response->flashNext('Offer updated!');
        return tr_redirect()->toPage('offer', 'edit', $id);
    }

    /**
     * The show page for admin
     *
     * @param string $id
     *
     * @param Offer $offer
     * @return mixed
     */
    public function show($id, Offer $offer)
    {
        return tr_view('offers.show', ['offer' => $offer]);
    }

    /**
     * The delete page for admin
     *
     * @param string $id
     *
     * @return mixed
     */
    public function delete($id)
    {
        // TODO: Implement delete() method.
    }

    /**
     * Destroy item
     *
     * AJAX requests and normal requests can be made to this action
     *
     * @param string $id
     *
     * @return mixed
     */
    public function destroy($id)
    {
        $offer = new Offer();
        $offer->findOrDie($id);
        $offer->delete();
        $this->response->flashNext('Offer deleted!', 'warning');
        return tr_redirect()->toPage('offer', 'index');
    }
}
