<?php

namespace App\Controllers;

use App\Models\Boat;
use TypeRocket\Controllers\WPPostController;

class BoatController extends WPPostController
{
    protected $modelClass = Boat::class;

    public function index()
    {
        $ourView = tr_view('boats.settings');
        return $ourView;
    }

    public function showRest()
    {
        return ['boat' => true];
    }


}
