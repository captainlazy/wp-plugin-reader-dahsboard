<link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
<script defer src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>


<style>
    table.logs {
        margin-bottom: 30px;
    }

    table.logs th, table.logs td {
        border: 1px solid black;
        padding: 10px;
        min-width: 100px;
    }

    table.logs td {
        text-align: center;
        padding: 10px 5px 10px;
    }

    table.logs td a {
        width: 100%;
        text-decoration: none;
        box-sizing: border-box;
        background-origin: border-box;
        background: #007cba;
        color: #fff;
        padding: 5px 20px;
    }
</style>

<?php
$logs    = get_option('nr_1055_inventory_log');
$cronLog = get_option('nr_1055_inventory_cron_log');
?>

<script>
    var $_nr_log = JSON.parse(`<?= json_encode($logs); ?>`)
    var $_nr_cron_log = JSON.parse(`<?= json_encode($cronLog); ?>`)
</script>

<hr>

<h2>Updates to Inventory</h2>

<table id="log" class="hover row-border stripe">

</table>

<hr>

<h2>Tasks Run</h2>

<table id="cron-log" class="hover row-border stripe">

</table>

<hr>

<script>
    try {
        Object.keys($_nr_log[0]).map(item => {
            return {data: item}
        })
        jQuery(document).ready(function ($) {
            window.logTable = $('#log').DataTable({
                data: $_nr_log,
                order: [[0, "desc"]],
                columns: [
                    {
                        data: "time",
                        title: "Timestamp",
                        classname: 'dt-head-left',
                        render: time => time ? new Date(Number(time) * 1000).toLocaleString() : ''
                    },
                    {data: "xmlFileName", title: 'File Name', className: 'dt-head-left'},
                    {
                        data: "recentlyCreated",
                        title: '# Created',
                        render: data => '<span title= "' + data + '">' + data.length + '</span>',
                        className: 'dt-body-center'
                    },
                    {
                        data: "recentlyUpdated",
                        render: data => '<span title= "' + data + '">' + data.length + '</span>',
                        title: '# Updated',
                        className: 'dt-body-center'
                    },
                    {
                        data: "recentlyDeleted",
                        title: '# Deleted',
                        render: data => '<span title= "' + data + '">' + data.length + '</span>',
                        className: 'dt-body-center'
                    },
                    {
                        data: "xmlFileUrl",
                        title: 'Link',
                        render: link => link == '#' ? '' : `<a href="${link}" target="_blank">View File</a>`,
                        className: 'dt-body-center'
                    }
                ]
            });
            window.cronLogTable = $('#cron-log').DataTable({
                data: $_nr_cron_log.map(time => {
                    return {time}
                }),
                order: [[0, "desc"]],
                columns: [
                    {
                        data: 'time',
                        title: 'Time',
                        render: time => time ? new Date(Number(time) * 1000).toLocaleString() : ''
                    }
                ]

            });
        })

    } catch (e) {
        console.log({e})
    }
</script>

<table>
    <tr>
        <td>
			<?php
			$form = tr_form()->useAjax()->useUrl('get', '/boatInventory/updateInventory');
			echo $form->open();
			echo $form->submit('Update Inventory Now');
			echo $form->close();

			echo "</td><td>";
			$forceForm = tr_form()->useAjax()->useUrl('get', '/boatInventory/forceUpdateInventory');
			echo $forceForm->open();
			echo $forceForm->submit('Force Update Inventory');
			echo $form->close();

			echo "</td><td>";
			$forceAll = tr_form()->useAjax()->useUrl('get', '/boatInventory/forceUpdateAll');
			echo $forceAll->open();
			echo $forceAll->submit('Force Update All Inventory Items');
			echo $forceAll->close();

			echo "</td><td>";
			$deleteXmlFiles = tr_form()->useAjax()->useUrl('get', '/boatInventory/deleteXmlFiles');
			echo $deleteXmlFiles->open();
			echo $deleteXmlFiles->submit('Delete Log and XML Backups');
			echo $deleteXmlFiles->close();
			?>
        </td>
    </tr>
</table>
<script>
    jQuery(document).ready(function ($) {

        document.addEventListener('log_updated', d => {
            logTable.clear()
            logTable.rows.add(d.detail).draw()
        })
        document.addEventListener('cron_log_updated', t => {
            cronLogTable.clear()
            cronLogTable.rows.add(t.detail).draw()
        })
    })
</script>