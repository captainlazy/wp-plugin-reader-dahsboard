<?php
$form = tr_form('option');
echo $form->open();
echo $form->text('Inventory Updated At');
echo $form->close('Submit');