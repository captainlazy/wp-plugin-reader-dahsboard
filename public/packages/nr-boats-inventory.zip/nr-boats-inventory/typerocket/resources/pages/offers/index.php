<?php

$table = tr_tables();
$table->setColumns('name', [
    'name' => [
        'sort' => true,
        'label' => 'Name',
        'actions' => ['edit', 'view', 'delete']
    ],
    'image_id' => [
        'label' => 'Image',
        'callback' => function ($text, $result) {
            return $result ? wp_get_attachment_image($text) : '';
        }
    ]
]);
try {
    $table->render();
} catch (Exception $e) {
}
