<?php
echo $form->open();
echo $form->column(
    [

        $form->image('Image Id')->setLabel('Image'),
        $form->text('Name')->setAttribute('style', 'max-width: 400px'),
        $form->text('Ad Link')->setLabel('Link')->setAttribute('style', 'max-width: 400px')

    ]
);
echo $form->submit('Update');
echo $form->close();
