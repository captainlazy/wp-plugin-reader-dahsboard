<h3><?php echo esc_html($offer->name); ?></h3>
