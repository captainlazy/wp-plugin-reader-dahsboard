<?php
/*
|--------------------------------------------------------------------------
| TypeRocket Routes
|--------------------------------------------------------------------------
|
| Manage your web routes here.
|
*/

tr_route()->get()->match('boatInventory/updateInventory')->do('update@Updater');
tr_route()->get()->match('boatInventory/forceUpdateInventory')->do('forceUpdate@Updater');
tr_route()->get()->match('boatInventory/forceUpdateAll')->do('forceUpdateAll@Updater');
tr_route()->get()->match('/boatInventory/deleteXmlFiles')->do('delete@Updater');

tr_route()->post()->match('nr/v1/boats')->do('find@Inventory')->name('findInventory');
