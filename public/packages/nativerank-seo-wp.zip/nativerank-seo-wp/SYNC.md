## Sync Payload

```ts

export interface Payload {
    domain: string, // stripped url of the site
    ip: string, // public IP address of the server
    blog_count: number, // if multi-site ? number of websites
    wp_version: string, // WordPress 5.4.2
    admin_url: string,
    home_url: string,

    config: {
        "digital_solution_subscription": 0 | 1,
        "digital_solution_smtp": 0 | 1,
        "digital_solution_development_mode": 0 | 1,
        "digital_solution_suspended": 0 | 1,
        "wp_debug": 0 | 1,
        "blog_public": 0 | 1
    }

    forms: {
        "id": number,
        "title": string,
        "is_active": 0 | 1,
        "notifications": {} //Check https://docs.gravityforms.com/form-object/ for reference
    }[]

    /*
    * list of plugins and themes that require updates
    */
    package_updates: {
        plugins: {
            'path/to/plugin_file.php': {
                name: string,
                version: number | string,
                new_version: number | string,
                upgradable: boolean
            }[]
        },
        themes: {
            'path/to/theme_file.php': {
                name: string,
                version: number | string,
                new_version: number | string,
                upgradable: boolean
            }[]
        }
    }
    /*
    * list of all plugins and themes
    */
    packages: {
        plugins: {
            'path/to/plugin_file.php': {
                name: string,
                version: string,
                plugin_url: string,
                author: string,
                author_url: string,
                network: boolean,
                active: boolean
            }[]
        },
        themes: {
            'path/to/theme_file.php': {
                name: string,
                version: string,
                author: string,
                author_url: string,
                screenshot: string,
                parent: boolean,
                active: boolean
            }[]
        }
    }

}


```
