<?php

namespace Nativerank;

class Nativerank_seo_1055_scripts {
	private function add_admin_scripts() {

		wp_enqueue_style( 'font-awesome', 'https://use.fontawesome.com/releases/v5.8.1/css/all.css', array(), null );
		wp_enqueue_script( 'vue-app', Nativerank_SEO_1055::plugin_url( 'dist/js/app.bundle.js' ), array(), WP_DEBUG ? null : Nativerank_SEO_1055_VERSION, true );
	}

	public function getAdminScripts() {
		$this->add_admin_scripts();
	}
}
