<?php

namespace Nativerank\Styles;
require "lessc.inc.php";

class Less
{
    protected $lessFilePath;
    protected $cssFilePath;

    function __construct()
    {
        $this->lessFilePath = get_stylesheet_directory() . "/less/src/custom.less";
        $this->cssFilePath = get_stylesheet_directory() . "/css/custom.css";
    }

    private function fix_site_url()
    {
        $file_contents = file_get_contents($this->lessFilePath);
        $file_contents = preg_replace('/@url[ :]+[ \'"]+(https|http):(\/\/[\w_-]+(?:(?:\.[\w_-]+)+))([\w.,@?^=%&:\/~+#-]*[\w@?^=%&\/~+#-])?[ \'"]+;/', "", $file_contents);
        file_put_contents($this->lessFilePath, $file_contents);
    }

    public function compileLess()
    {
        $this->fix_site_url();
        $less = new \lessc;
        $less->setFormatter("compressed");
        $less->setVariables(array(
            "url" => "'" . get_site_url() . "'"
        ));
        try {
            $result = $less->checkedCompile($this->lessFilePath, $this->cssFilePath);
        } catch (\Exception $e) {
            echo "fatal error: " . $e->getMessage();
        }
    }
}
