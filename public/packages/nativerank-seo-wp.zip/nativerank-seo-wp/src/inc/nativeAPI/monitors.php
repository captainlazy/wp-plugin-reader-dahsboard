<?php

namespace Nativerank\NativeAPI;


class  Monitor
{

    protected $site;
    protected $nativeAPIKey = '0bd348bb-5397-4220-84eb-201496e5cdb7';
    protected $monitorsType = ['Website', 'DomainExpiry', 'SSL'];
    protected $log;

    function __construct()
    {
        $this->site = str_replace('www.', '', parse_url(get_site_url(), PHP_URL_HOST));
    }


    public function updateMonitor($status)
    {
        foreach ($this->monitorsType as $monitor) {
            $response = $this->getMonitorID($monitor);

            if (!$response) {
                $this->log .= str_repeat('*', 65) . $response;
                continue;
            }

            if (!empty(json_decode($response)->error_code)) {
                $this->log .= $this->logError($monitor, $response);
                continue;
            }

            if (is_numeric($response)) {
                // If received a monitor ID, suspend the monitor using monitor ID
                $status = str_repeat('*', 65) . PHP_EOL . $monitor . ' Monitor - ' . $this->updateMonitorAPI($status, $response) . PHP_EOL;
                $this->log .= $status;
                continue;
            }

            $this->log .= str_repeat('*', 70) . 'Unknown error : ' . $response;
        }

        return $this->log;
    }


    private function getMonitorID($module)
    {
        $response = wp_remote_get("http://nativeapi.com/site24x7/monitors/retrieveByName/$module/" . $this->site . "?api=" . $this->nativeAPIKey);

        if (json_decode($response['body'])->data && json_decode($response['body'])->data->monitor_id) {
            return json_decode($response['body'])->data->monitor_id;
        }
        return $response['body'];
    }


    private function updateMonitorAPI($status, $monitorID)
    {
        $response = wp_remote_request("http://nativeapi.com/site24x7/monitors/$status/$monitorID?api=" . $this->nativeAPIKey, [
            'method' => 'PUT'
        ]);

        if (json_decode($response['body'])->data && json_decode($response['body'])->message) {
            return json_decode($response['body'])->message;
        }

        return $response['body'];
    }

    private function logError($monitor, $response)
    {
        return str_repeat('*', 65) . ' ' . PHP_EOL . $monitor . ' Monitor - ' . json_decode($response)->message . PHP_EOL;
    }

}
