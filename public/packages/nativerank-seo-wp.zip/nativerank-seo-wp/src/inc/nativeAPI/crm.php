<?php

namespace Nativerank\NativeAPI;

class CRM
{
    protected $siteUrl;
    protected $nativeAPIKey = '0bd348bb-5397-4220-84eb-201496e5cdb7';
    protected $crmTerms = [
        'activate' => 'Active',
        'suspend' => 'Suspended'
    ];
    protected $log;

    function __construct()
    {
        $this->siteUrl = $this->stripUrl(get_site_url());
    }

    private function stripUrl($url)
    {
        $url = parse_url(trim(strtolower($url)));
        if (!isset($url['host'])) {
            $url = $url['path'];
            $re = '/^(?:www\.)?(.*?)($|\/)/mi';
            preg_match_all($re, $url, $matches, PREG_SET_ORDER, 0);
            $url = $matches[0][1];
        } else {
            $url = str_replace('www.', '', $url['host']);
        }

        return $url;
    }

    public function updateField($fieldKey, $fieldValue)
    {
        $recordIDs = $this->getRecordsID();
        foreach ($recordIDs as $recordID) {
            $this->log .= str_repeat('*', 65) . ' ' . PHP_EOL . 'CRM - ' . $this->updateFieldAPI($recordID, $fieldKey, isset($this->crmTerms[$fieldValue]) ? $this->crmTerms[$fieldValue] : $fieldValue) . PHP_EOL;
        }
        return $this->log;
    }

    private function updateFieldAPI($record_id, $fieldKey, $fieldValue)
    {

        $data = (object)array($fieldKey => $fieldValue);

        $response = wp_remote_request("https://nativeapi.com/crm/update/accounts/$record_id?api=" . $this->nativeAPIKey, [
            'headers' => array('Content-Type' => 'application/json; charset=utf-8'),
            'method' => 'PUT',
            'data_format' => 'body',
            'body' => '{"data":[' . json_encode($data) . ']}'
        ]);

        $response = json_decode($response['body']);

        if ($response->data[0]->message) {
            return $response->data[0]->message;
        }
        return $response;
    }

    private function getRecordsID()
    {
        $response = wp_remote_get('https://nativeapi.com/crm/search/Accounts/' . urlencode($this->siteUrl) . '?api=' . $this->nativeAPIKey);
        $data = json_decode($response['body'])->data;

        if (count($data) === 1) {
            return $data[0]->id;
        }
        if (count($data) > 1) {
            $recordsfound = $this->findRecordWithWebsite($data);
            $recordsIDs = [];

            foreach ($recordsfound as $record) {
                $recordsIDs[] = (int)$record->id;
            }
            return $recordsIDs;

        }

        return json_encode($data);
    }

    //    Find records by matching website
    private function findRecordWithWebsite($records)
    {
        $recordsFound = array();
        foreach ($records as $record) {
            if (!isset($record->Website)) {
                continue;
            }

            if ($this->stripUrl($record->Website) == $this->siteUrl) {
                $recordsFound[] = $record;
            }
        }
        return $recordsFound;
    }
}
