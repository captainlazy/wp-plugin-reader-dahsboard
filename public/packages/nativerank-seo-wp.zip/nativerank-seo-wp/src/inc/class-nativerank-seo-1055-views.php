<?php

namespace Nativerank;

class Nativerank_seo_1055_views {
	private function redirect_plugin_assets() {
		$logo = ( ! empty( get_theme_mods()['config'] ) && isset( get_theme_mods()['config']->logo ) ) ? json_decode( get_theme_mods()['config'] )->logo->image : '';
		query_posts( array(
			'post_type'      => 'page',
			'post_status'    => 'publish',
			'posts_per_page' => - 1
		) );
		$allPages = [];
		if ( have_posts() ) : while ( have_posts() ) : the_post();
			array_push( $allPages, get_the_permalink() );
		endwhile; endif;
		wp_reset_query();
		$site_structure = new  Admin\site_structure();
		echo '<script>
    $nr_siteUrl = "' . site_url( '/' ) . '";
    $nr_logo = "' . $logo . '"
    $nrOverviewData = ' . $site_structure->getThePages() . ';
    $nr_allPages=' . json_encode( $allPages ) . ';
     $nr_pluginDirectory = "' . Nativerank_SEO_1055::plugin_url( '/' ) . '";</script>';
	}

	public function menu_page() {
		$this->redirect_plugin_assets();
		echo '<style>:root{--card-padding:24px;--card-height:390px;--card-skeleton:linear-gradient(lightgrey var(--card-height), transparent 0);--avatar-size:32px;--avatar-position:180px 80px;--avatar-skeleton:radial-gradient(circle 16px at center, white 99%, transparent 0);--title-height:16px;--title-width:60px;--title-position:90px 30px;--title-skeleton:linear-gradient(white var(--title-height), transparent 0);--desc-line-height:16px;--desc-line-skeleton:linear-gradient(white var(--desc-line-height), transparent 0);--desc-line-1-width:60px;--desc-line-1-position:165px 30px;--desc-line-2-width:60px;--desc-line-2-position:240px 30px;--footer-height:140px;--footer-position:0 70px;--footer-skeleton:linear-gradient(white var(--footer-height), transparent 0);--blur-width:200px;--blur-size:var(--blur-width) calc(var(--card-height) - var(--footer-height))}[v-cloak]{width:380px;height:var(--card-height);position:relative;margin:auto!important;transform:translatey(200px)}[v-cloak]:empty::after{content:"";display:block;width:100%;height:100%;border-radius:6px;box-shadow:0 10px 45px rgba(0,0,0,.1);background-image:linear-gradient(90deg,rgba(211,211,211,0) 0,rgba(211,211,211,.8) 50%,rgba(211,211,211,0) 100%),var(--title-skeleton),var(--desc-line-skeleton),var(--desc-line-skeleton),var(--avatar-skeleton),var(--footer-skeleton),var(--card-skeleton);background-size:var(--blur-size),var(--title-width) var(--title-height),var(--desc-line-1-width) var(--desc-line-height),var(--desc-line-2-width) var(--desc-line-height),var(--avatar-size) var(--avatar-size),100% var(--footer-height),100% 100%;background-position:-150% 0,var(--title-position),var(--desc-line-1-position),var(--desc-line-2-position),var(--avatar-position),var(--footer-position),0 0;background-repeat:no-repeat;animation:loading 1.5s infinite}@keyframes loading{to{background-position:350% 0,var(--title-position),var(--desc-line-1-position),var(--desc-line-2-position),var(--avatar-position),var(--footer-position),0 0}}#update-nag, .update-nag{display:none!important;}</style>';
		echo "<div class='nr_app_container'><div id='app' v-cloak></div></div>";

	}

	public function create_menu() {
		$Nativerank_SEO_1055 = new Nativerank_SEO_1055();

		add_menu_page( 'Native Rank SEO', '<b style="color:#f44336">NATIVE</b><b style="color:#1D8BF1">RANK</b>', 'manage_options', $Nativerank_SEO_1055->getPluginName(), array(
			$this,
			'menu_page'
		), Nativerank_SEO_1055::plugin_url( 'assets/img/logo.png' ), 0 );

	}


}
