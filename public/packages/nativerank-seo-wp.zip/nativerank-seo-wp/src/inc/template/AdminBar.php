<?php

namespace Nativerank\Template;

class AdminBar
{
    public $templateName;

    public function __construct()
    {

    }


    public function getTemplateName()
    {
        $template = FALSE;

        if (strpos(basename(get_page_template()), 'nr-') !== FALSE)
            $template = get_post_meta(get_the_ID(), 'nr_page_type', true);

        $this->templateName = $template;

        return $this->templateName;
    }

    public function addPageId($wp_admin_bar)
    {
        $args = array(
            'id' => 'Nativerank_SEO_1055_page_id',
            'title' => is_admin() ? 'NO PAGE ID' : '<span style="font-size:10px">PAGE ID</span> ' . '<b style="background:#2084C0!important;padding:0 4px">' . get_the_ID() . '</b>',
            'meta' => array('class' => 'nr_page_indicator')
        );
        $wp_admin_bar->add_node($args);
    }


    public function templateControl($wp_admin_bar)
    {

        $args = array(
            'id' => 'Nativerank_SEO_1055_template',
            'title' => $this->templateName ? '<span style="font-size:10px">TEMPLATE</span> ' . '<b style="background:#2084C0!important;padding:0 4px">' . $this->templateName . '</b>' : 'NO TEMPLATE',
            'meta' => array('class' => 'nr_page_indicator')
        );
        $wp_admin_bar->add_node($args);


        if ($this->templateName) {
            // add a child item to our parent item
            $args = array(
                'id' => 'Nativerank_SEO_1055_template-purge-single-cache',
                'title' => '<div class="nr_purge" style="cursor:pointer;" data-template="' . $this->templateName . '">Purge <b style="background:#2084C0!important;padding:0 4px">' . $this->templateName . '</b> Cache</span>',
                'parent' => 'Nativerank_SEO_1055_template',
            );
            $wp_admin_bar->add_node($args);

            $args = array(
                'id' => 'Nativerank_SEO_1055_template-purge-all-cache',
                'title' => '<div class="nr_purge" style="cursor:pointer;" data-template="all">Purge <b style="background:#a62700!important;padding:0 4px;color:#fff;">All</b> Caches</div>',
                'parent' => 'Nativerank_SEO_1055_template',
            );
            $wp_admin_bar->add_node($args);
        }
    }

    public function assets()
    {
        wp_enqueue_style('nr_notify_css', 'https://cdn.jsdelivr.net/npm/toastify-js/src/toastify.min.css');
        wp_enqueue_script('nr_notify_js', 'https://cdn.jsdelivr.net/npm/toastify-js');

        wp_localize_script('nr_notify_js', 'nr_ajax',
            array('ajax_url' => admin_url('admin-ajax.php')));

        wp_add_inline_script('nr_notify_js', '
     try {
	     document.addEventListener("DOMContentLoaded", function(){

		var clearCache = function (data) {

			var formData = new FormData()

			formData.append(\'action\', \'purge_template_cache\')
			formData.append(\'data[template]\', data.template)
			formData.append(\'data[function]\', data.function)

			fetch(nr_ajax.ajax_url, {
				method: \'POST\',
				headers: {
					\'Content-Type\': \'application/x-www-form-urlencoded; charset=utf-8\'
				},
				body: new URLSearchParams(formData),

			}).then(
				response => {
					if (!response.ok) {

						throw response
					}
					return response.json();
				}
			).then(
				json => {
					notifyClient(json.message, \'success\')
				}
			)
				.catch(e => {
					console.log(e)
					e.json().then(errorMessage => {
						errorMessage.data && notifyClient(errorMessage.data, \'error\')
					})
				})

		}

		var notifyClient = function (message, className) {

			var bgColor = {
				\'success\': \'linear-gradient(to right, #00b09b, #96c93d)\',
				\'error\': \'linear-gradient(to right, #ff0000, #ff9900)\'
			}
			Toastify({
				text: message,
				gravity: "bottom",
				backgroundColor: bgColor[className],
				close: true
			}).showToast()

		}

		document.querySelectorAll(\'.nr_purge\').forEach(function (el) {
			el.addEventListener(\'click\', function (event) {
				clearCache({ template: el.getAttribute(\'data-template\'), function: \'purge\' })
			})
		})

	})
} catch (e) {
	console.error({ nativerank_plugin: e })
}

  ');

    }


    public function handleRequest()
    {
        $data = $_POST['data'];
        $template = $data['template'];
        $function = $data["function"];


        if ($function == 'purge') {
            $cachePath = get_home_path() . "cache/views";

            if (!is_writable($cachePath))
                wp_send_json_error('Cache Directory is not writable.', 400);

            switch ($template) {
                case 'all':
                    $allFiles = glob("$cachePath/*.php");
                    $multiple = count($allFiles) < 2 ? "" : "s";
                    array_map('unlink', $allFiles);
                    wp_send_json(['files' => $allFiles, 'status' => 200, 'message' => count($allFiles) . " template cache$multiple purged!"], 200);
                    break;
                default:
                    if (!file_exists("$cachePath/$template.php")) {
                        wp_send_json_error("$template does not exist.", 400);
                        break;
                    }
                    $status = unlink("$cachePath/$template.php");
                    if ($status)
                        wp_send_json(['status' => 200, 'message' => "$template cache purged!"], 200);
                    else
                        wp_send_json_error("Unknown Error", 400);
                    break;
            }

            wp_die();
        }

        wp_send_json_error('Function not found.', 400);
        wp_die();
    }


    public function boot()
    {
        add_action('wp', array($this, 'getTemplateName'));

        //Add Page ID to admin bar
        add_action('admin_bar_menu', array($this, 'addPageId'), 90000);

        //Add Template Control to admin bar
        add_action('admin_bar_menu', array($this, 'templateControl'), 90000);

        add_action('wp_enqueue_scripts', array($this, 'assets'));

    }

    public function http()
    {
        //register http request end points
        add_action('wp_ajax_purge_template_cache', array($this, 'handleRequest'));
    }


}
