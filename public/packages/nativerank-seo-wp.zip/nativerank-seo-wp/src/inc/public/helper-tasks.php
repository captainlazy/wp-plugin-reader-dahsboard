<?php

namespace Nativerank\HelperTasks;


class Tasks {
	protected $EmojiScripts;
	protected $RemoveComments;
	protected $StructuredData;
	protected $tasks = [

	];

	public function __construct() {
		require 'remove-emoji-scripts.php';
		$this->EmojiScripts = new EmojiScripts\EmojiScripts();

		require 'remove-comments.php';
		$this->RemoveComments = new RemoveComments\RemoveComments();

		require 'structured-data.php';
		$this->StructuredData = new StructuredData\structuredData();

		$this->tasks = [
			[ 'object' => $this->EmojiScripts, 'method' => 'remove_all_scripts' ],
			[ 'object' => $this->RemoveComments, 'method' => 'remove_all_comments' ],
			[ 'object' => $this->StructuredData, 'method' => 'get_structured_data' ],
			[ 'object' => $this, 'method' => 'remove_glutenberg_css' ],
			[ 'object' => $this, 'method' => 'remove_jquery_migrate' ],
			[ 'object' => $this, 'method' => 'add_nr_h1_shortcode' ],
			[ 'object' => $this, 'method' => 'override_mce_options' ],
			[ 'object' => $this, 'method' => 'disable_embed' ],
			[ 'object' => $this, 'method' => 'remove_feeds' ],
			[ 'object' => $this, 'method' => 'remove_xmlrpc' ],
			[ 'object' => $this, 'method' => 'acf_custom_fields_fix' ],
			[ 'object' => $this, 'method' => 'optimize_image_tag_for_uk_image' ],
		];
	}

	private function remove_glutenberg_css() {
		add_action( 'wp_enqueue_scripts', function () {
			wp_dequeue_style( 'wp-block-library' );
		}, 100 );
	}

	private function add_nr_h1_shortcode() {
		add_shortcode( 'nrh1', function () {
			$key_name = get_post_custom_values( $key = 'NR - H1' );
			$string   = $key_name[0];
			if ( empty( $string ) ) {
				return trim( get_the_title() );
			}
			$pattern     = '/([\w+\- \'\,\&]*)(:)([\w+\- \,\&]*)/i';
			$replacement = '<span>$1$2</span><span>$3</span>';

			return preg_replace( $pattern, $replacement, $string );
		} );
	}

	private function remove_jquery_migrate() {
		add_action( 'wp_default_scripts', function ( $scripts ) {
			if ( ! is_admin() && isset( $scripts->registered['jquery'] ) ) {
				$script = $scripts->registered['jquery'];
				if ( $script->deps ) {
					$script->deps = array_diff( $script->deps, array( 'jquery-migrate' ) );
				}
			}
		} );
	}

	private function override_mce_options() {
		add_filter( 'tiny_mce_before_init', function ( $init ) {
			$opts                            = '*[*]';
			$init['valid_elements']          = $opts;
			$init['extended_valid_elements'] = $opts;
			$init['wpautop']                 = false;
			// Don't remove line breaks
			$init['remove_linebreaks'] = false;
			// Convert newline characters to BR tagSelect
			$init['convert_newlines_to_brs'] = true;
			// Do not remove redundant BR tagSelect
			$init['remove_redundant_brs']     = false;
			$init['indent']                   = true;
			$init['schema']                   = 'html5';
			$init['allow_unsafe_link_target'] = true;

			return $init;
		} );
	}

	private function disable_embed() {
		add_action( 'init', function () {

			// Remove the REST API endpoint.
			remove_action( 'rest_api_init', 'wp_oembed_register_route' );

			// Turn off oEmbed auto discovery.
			add_filter( 'embed_oembed_discover', '__return_false' );

			// Don't filter oEmbed results.
			remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );

			// Remove oEmbed discovery links.
			remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );

			// Remove oEmbed-specific JavaScript from the front-end and back-end.
			remove_action( 'wp_head', 'wp_oembed_add_host_js' );
			add_filter( 'tiny_mce_plugins', function ( $plugins ) {
				return array_diff( $plugins, array( 'wpembed' ) );
			} );

			// Remove all embeds rewrite rules.
			add_filter( 'rewrite_rules_array', function ( $rules ) {
				foreach ( $rules as $rule => $rewrite ) {
					if ( false !== strpos( $rewrite, 'embed=true' ) ) {
						unset( $rules[ $rule ] );
					}
				}

				return $rules;
			} );

			// Remove filter of the oEmbed result before any HTTP requests are made.
			remove_filter( 'pre_oembed_result', 'wp_filter_pre_oembed_result', 10 );
		}, 9999 );

		add_action( 'wp_footer', function () {
			wp_dequeue_script( 'wp-embed' );
		} );
	}

	public function items_disable_feed() {
		wp_die( __( 'No feed available, please visit the <a href="' . esc_url( home_url( '/' ) ) . '">homepage</a>!' ) );
	}

	private function remove_feeds() {
		add_action( 'do_feed', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_rdf', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_rss', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_rss2', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_atom', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_rss2_comments', array( $this, 'items_disable_feed' ), 1 );
		add_action( 'do_feed_atom_comments', array( $this, 'items_disable_feed' ), 1 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );
		remove_action( 'wp_head', 'feed_links', 2 );
	}

	public function remove_xmlrpc() {
		remove_action( 'wp_head', 'wlwmanifest_link' );
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links', 10 );
	}

	private function acf_custom_fields_fix() {
		if ( has_filter( 'acf/settings/remove_wp_meta_box' ) ) {
			add_filter( 'acf/settings/remove_wp_meta_box', '__return_false' );
		}
	}

	private function optimize_image_tag_for_uk_image() {

		add_filter( 'post_thumbnail_html', function ( $html, $post_id, $post_thumbnail_id, $size, $attr ) {
			if ( array_key_exists( 'uk-img', $attr ) ) {
				$html = str_replace( 'src', 'data-src', $html );
				if ( isset( $attr['sizes'] ) ) {
					$html = str_replace( 'size', 'data-size', $html );
				}
			}

			return $html;
		}, 99, 5 );


		add_filter( 'wp_get_attachment_image_attributes', function ( $attributes ) {

			if ( array_key_exists( 'uk-img', $attributes ) ) {
				if ( isset( $attributes['src'] ) ) {
					$attributes['data-src'] = $attributes['src'];
					unset( $attributes['src'] );
				}
				if ( isset( $attributes['srcset'] ) ) {
					$attributes['data-srcset'] = $attributes['srcset'];
					unset( $attributes['srcset'] );
				}
				if ( isset( $attributes['sizes'] ) ) {
					$attributes['data-sizes'] = $attributes['sizes'];
					unset( $attributes['sizes'] );
				}
			}

			return $attributes;
		}, 99 );
	}

	public function run_tasks() {
		foreach ( $this->tasks as $task ) {
            if (!isset($task['method'])) {
                continue;
            }


            $run_task = apply_filters("nr_1055_seo_task_${task['method']}", true);
            if ($run_task) {
                $isClassMethod = isset($task['object']);
                $taskToRun = $isClassMethod ? [$task['object'], $task['method']] : $task['method'];
                if ($isClassMethod ? method_exists($task['object'], $task['method']) : function_exists($taskToRun)) {
                    call_user_func($taskToRun);
                }
            }
        }

	}
}
