<?php

namespace Nativerank\HelperTasks\RemoveComments;

class RemoveComments
{
    private function init_filters()
    {

        add_action('widgets_init', array($this, 'disable_rc_widget'));
        add_filter('wp_headers', array($this, 'filter_wp_headers'));
        add_filter('xmlrpc_enabled', '__return_false');

        add_action('template_redirect', array($this, 'filter_query'), 9);


        add_action('template_redirect', array($this, 'filter_admin_bar'));
        add_action('admin_init', array($this, 'filter_admin_bar'));


        add_action('wp_loaded', array($this, 'init_wploaded_filters'));
    }


    public function init_wploaded_filters()
    {

        add_filter('comments_array', array($this, 'filter_existing_comments'), 20, 2);
        add_filter('comments_open', array($this, 'filter_comment_status'), 20, 2);
        add_filter('pings_open', array($this, 'filter_comment_status'), 20, 2);


        // Filters for the admin only
        if (is_admin()) {

            add_action('admin_menu', array($this, 'filter_admin_menu'), 9999);    // do this as late as possible
            add_action('admin_print_styles-index.php', array($this, 'admin_css'));
            add_action('admin_print_styles-profile.php', array($this, 'admin_css'));
            add_action('wp_dashboard_setup', array($this, 'filter_dashboard'));
            add_filter('pre_option_default_pingback_flag', '__return_zero');
        } // Filters for front end only
        else {
            add_action('template_redirect', array($this, 'check_comment_template'));
            add_filter('feed_links_show_comments_feed', '__return_false');
        }
    }

    public function filter_comment_status($open, $post_id)
    {
        $post = get_post($post_id);
        return false;
    }

    public function filter_existing_comments($comments, $post_id)
    {
        $post = get_post($post_id);
        return array();
    }

    /*
     * Replace the theme's comment template with a blank one.
     * To prevent this, define DISABLE_COMMENTS_REMOVE_COMMENTS_TEMPLATE
     * and set it to True
     */
    public function check_comment_template()
    {
        if (!defined('DISABLE_COMMENTS_REMOVE_COMMENTS_TEMPLATE') || DISABLE_COMMENTS_REMOVE_COMMENTS_TEMPLATE == true) {
            // Kill the comments template.
            add_filter('comments_template', array($this, 'dummy_comments_template'), 20);
        }
        // Remove comment-reply script for themes that include it indiscriminately
        wp_deregister_script('comment-reply');
        // feed_links_extra inserts a comments RSS link
        remove_action('wp_head', 'feed_links_extra', 3);
    }

    public function dummy_comments_template()
    {
        return dirname(__FILE__) . '/includes/comments-template.php';
    }


    /*
     * Remove the X-Pingback HTTP header
     */
    public function filter_wp_headers($headers)
    {
        unset($headers['X-Pingback']);
        return $headers;
    }

    /*
     * Issue a 403 for all comment feed requests.
     */
    public function filter_query()
    {
        if (is_comment_feed()) {
            wp_die(__('Comments are closed.'), '', array('response' => 403));
        }
    }

    /*
     * Remove comment links from the admin bar.
     */
    public function filter_admin_bar()
    {
        if (is_admin_bar_showing()) {
            // Remove comments links from admin bar
            remove_action('admin_bar_menu', 'wp_admin_bar_comments_menu', 60);
            if (is_multisite()) {
                add_action('admin_bar_menu', array($this, 'remove_network_comment_links'), 500);
            }
        }
    }

    /*
     * Remove comment links from the admin bar in a multisite network.
     */
    public function remove_network_comment_links($wp_admin_bar)
    {
        if ($this->networkactive && is_user_logged_in()) {
            foreach ((array)$wp_admin_bar->user->blogs as $blog) {
                $wp_admin_bar->remove_menu('blog-' . $blog->userblog_id . '-c');
            }
        } else {
            // We have no way to know whether the plugin is active on other sites, so only remove this one
            $wp_admin_bar->remove_menu('blog-' . get_current_blog_id() . '-c');
        }
    }


    public function filter_admin_menu()
    {
        global $pagenow;

        if ($pagenow == 'comment.php' || $pagenow == 'edit-comments.php')
            wp_die(__('Comments are closed.'), '', array('response' => 403));

        remove_menu_page('edit-comments.php');

        if (!$this->discussion_settings_allowed()) {
            if ($pagenow == 'options-discussion.php')
                wp_die(__('Comments are closed.'), '', array('response' => 403));

            remove_submenu_page('options-general.php', 'options-discussion.php');
        }
    }

    public function filter_dashboard()
    {
        remove_meta_box('dashboard_recent_comments', 'dashboard', 'normal');
    }

    private function discussion_settings_allowed()
    {
        if (defined('DISABLE_COMMENTS_ALLOW_DISCUSSION_SETTINGS') && DISABLE_COMMENTS_ALLOW_DISCUSSION_SETTINGS == true) {
            return true;
        }
    }

    public function admin_css()
    {
        echo '<style>
			#dashboard_right_now .comment-count,
			#dashboard_right_now .comment-mod-count,
			#latest-comments,
			#welcome-panel .welcome-comments,
			.user-comment-shortcuts-wrap {
				display: none !important;
			}
		</style>';
    }


    public function disable_rc_widget()
    {
        unregister_widget('WP_Widget_Recent_Comments');
        // The widget has added a style action when it was constructed - which will
        // still fire even if we now unregister the widget... so filter that out
        add_filter('show_recent_comments_widget_style', '__return_false');
    }

    public function remove_all_comments()
    {
        $this->init_filters();
    }
}
