<?php

namespace Nativerank\FormHandle;

class EmailSetup {

	protected $nrSMTPSettings;
	protected $NRSubscription;
	protected $NREnableSMTP;
	protected $pluginlog;

	function __construct() {
		$this->pluginlog = Nativerank_SEO_1055_PLUGIN_PATH . 'error.log';

		$this->NRSubscription = intval( trim( get_option( 'nativerank_seo_1055_subscriptionID' ) ) );
		$this->NREnableSMTP   = intval( trim( get_option( 'nativerank_seo_1055_emailSMTPID' ) ) );

		$this->optimizedLeadSettings();

		if ( $this->NRSubscription === 1 && $this->NREnableSMTP === 1 ) {
			$this->nrSMTPSettings = (object) array(
				"host"         => "smtp.sendgrid.net",
				"port"         => "587",
				"username"     => "apikey",
				"password"     => "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",
				"encryption"   => "tls",
				"auth_mode"    => null,
				"from_name"    => "Native Rank Digital Solution",
				"from_address" => "platform@nativerank.com"
			);

			$this->setupSMTP();
		}
	}

	public function smptpEmailSettings( $phpmailer ) {
		$SMTP = $this->nrSMTPSettings;
		$phpmailer->isSMTP();
		$phpmailer->SMTPOptions = array(
			'ssl' => array(
				'verify_peer'       => false,
				'verify_peer_name'  => false,
				'allow_self_signed' => true
			)
		);
		$phpmailer->Host        = $SMTP->host;
		$phpmailer->SMTPAuth    = true;
		$phpmailer->Port        = $SMTP->port;
		$phpmailer->Username    = $SMTP->username;
		$phpmailer->Password    = $SMTP->password;
		$phpmailer->SMTPSecure  = $SMTP->encryption;
		$phpmailer->From        = $SMTP->from_address;
		$phpmailer->FromName    = $SMTP->from_name;
	}


	private function optimizedLeadSettings() {
		add_filter( "gform_email_background_color_label", function ( $color, $field, $entry ) {
			return "#F4D4D2";
		}, 10, 3 );

		add_filter( 'gform_pre_send_email', function ( $email, $message_format, $notification ) {
			if ( ! isset( $notification['nr_1055_seo_ignore_notification'] ) || ! $notification['nr_1055_seo_ignore_notification'] ) {
				$email['abort_email'] = true;
			}

			return $email;
		}, 10, 3 );

		add_filter( 'gform_notification_ui_settings', function ( $ui_settings, $notification, $form ) {

			if ( intval( rgar( $notification, 'nr_1055_seo_ignore_notification' ) ) === 1 ) {
				$val = 'checked';
			} else {
				$val = '';
			}

			$ui_settings['nr_1055_seo_ignore_notification'] = '
            <tr valign="top">
			<th scope="row">
				<label for="nr_1055_seo_ignore_notification">Native Rank</label>
			</th>
			<td>
				<input type="checkbox" name="nr_1055_seo_ignore_notification" id="nr_1055_seo_ignore_notification" ' . $val . ' value="1">
				<label for="nr_1055_seo_ignore_notification" class="inline" > Disable Native Rank Lead Optimization </label>
			</td>
		</tr>';

			return $ui_settings;
		}, 10, 3 );


		add_filter( 'gform_pre_notification_save', function ( $notification, $form ) {
			$notification['nr_1055_seo_ignore_notification'] = intval( rgpost( 'nr_1055_seo_ignore_notification' ) );

			return $notification;
		}, 10, 2 );

	}

	private function setupSMTP() {

		add_action( 'phpmailer_init', array( $this, 'smptpEmailSettings' ) );


		add_action( 'wp_mail_failed', array( $this, 'logError' ), 10, 1 );
	}

	public function logError( $wp_error ) {
		if ( ! is_string( $wp_error ) ) {
			$wp_error = json_encode( $wp_error );
		}

		$date    = date( 'l jS \of F Y h:i:s A' );
		$message = "[$date] " . $wp_error . PHP_EOL;

		error_log( $message, 3, $this->pluginlog );
	}

}
