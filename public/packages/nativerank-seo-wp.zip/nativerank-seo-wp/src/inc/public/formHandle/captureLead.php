<?php

namespace Nativerank\FormHandle;


class CaptureLead {
	protected $lead;
	protected $entry;
	protected $form;
	protected $pluginlog;
	protected $NRSubscription;
	protected $NREnableSMTP;

	private static $spamTestingEmail = 'nrspamtesting@gmail.com';


	function __construct() {

		$this->NRSubscription = intval( trim( get_option( 'nativerank_seo_1055_subscriptionID' ) ) );
		$this->NREnableSMTP   = intval( trim( get_option( 'nativerank_seo_1055_emailSMTPID' ) ) );

		$this->pluginlog = Nativerank_SEO_1055_PLUGIN_PATH . 'error.log';
		$this->lead      = (object) [];
		if ( class_exists( 'GFCommon' ) ) {
			$this->capture();
		}
	}


	public function handleLead( $entry, $form ) {
		$this->lead = (object) array( 'lead' => $entry, 'formManifest' => $form );

		return $this->sendLeadToAPI( $this->lead );
	}

	private function sendLeadToAPI( $lead ) {


		$domain = get_site_url();
		$domain = str_replace( 'www.', '', parse_url( $domain, PHP_URL_HOST ) );

		$curl = curl_init();

		curl_setopt( $curl, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $curl, CURLOPT_SSL_VERIFYPEER, 0 );

		curl_setopt_array( $curl, array(
			CURLOPT_URL            => "https://platform.nativerank.com/_/items/form_submissions",
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING       => "",
			CURLOPT_MAXREDIRS      => 10,
			CURLOPT_TIMEOUT        => 30,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => "POST",
			CURLOPT_POSTFIELDS     => "integration=gravity_forms&identifier=$domain&data=" . json_encode( $lead->lead ) . "&meta=" . json_encode( $lead->formManifest ) . "&ip_address=" . $lead->lead["ip"],
			CURLOPT_HTTPHEADER     => array(
				"Accept: */*",
				"Authorization: Bearer LctQzJ5SB9yn93xdYVXEzmJMZGs4ubJx",
				"Cache-Control: no-cache",
				"Connection: keep-alive",
				"Content-Type: application/x-www-form-urlencoded",
				"Host: platform.nativerank.com",
				"accept-encoding: gzip, deflate",
				"cache-control: no-cache",
			),
		) );

		$response = curl_exec( $curl );
		$err      = curl_error( $curl );
		curl_close( $curl );

		if ( $err ) {
			$this->logError( $err );
		}

		return true;
	}

	public function logError( $wp_error ) {
		if ( ! is_string( $wp_error ) ) {
			$wp_error = json_encode( $wp_error );
		}

		$date    = date( 'l jS \of F Y h:i:s A' );
		$message = "[$date] " . $wp_error . PHP_EOL;
		wp_mail( 'websupport@nativerank.com', 'Lead Capture Error on ' . get_site_url(), $message );
		error_log( $message, 3, $this->pluginlog );
	}

	public function sendNotification( $entry, $form ) {
		$rawForm = $this->getRawFormForSpamTesting( $form, $entry );
		$rawBody = implode( PHP_EOL, $rawForm['fields'] );

		ob_start();
		foreach ( $form['fields'] as $field ) {
			if ( strtoupper( $field->label ) !== 'UNTITLED' ) {
				?>


                <tr>
                    <td align="center" style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:15px;font-weight:600;line-height:1;text-align:center;text-transform:uppercase;color:#2395F3;">
							<?= $field['label'] ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:18px;font-weight:600;line-height:1;text-align:center;color:#494949;">                <?= $field->get_value_entry_detail( \RGFormsModel::get_lead_field_value( $entry, $field ), $currency = '', $use_text = true, $format = 'html' ); ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <p style="border-top:dashed 1px lightgrey;font-size:1;margin:0px auto;width:100%;"></p>
                        <!--[if mso | IE]>
						<table
								align="center" border="0" cellpadding="0" cellspacing="0"
								style="border-top:dashed 1px lightgrey;font-size:1;margin:0px auto;width:548px;"
								role="presentation" width="548px"
						>
							<tr>
								<td style="height:0;line-height:0;">
									&nbsp;
								</td>
							</tr>
						</table>
						<![endif]-->
                    </td>
                </tr>


				<?php

			}

		}

		$body = ob_get_clean();
		include 'sendNotification.php';
		new SendNotification( $rawForm, $entry, $rawBody, true );
		new SendNotification( $form, $entry, $body );
	}

	private function getRawFormForSpamTesting( $form, $entry ) {
		$rawForm                  = $form;
		$rawForm['notifications'] = array_map( function ( $notification ) {
			unset( $notification['nr_1055_seo_ignore_notification'] );
			$notification['to'] = self::$spamTestingEmail;

			return $notification;
		}, $rawForm['notifications'] );
		$rawForm['fields']        = array_map( function ( $field ) use ( $entry ) {
			if ( strtoupper( $field->label ) !== 'UNTITLED' ) {
				$field = $field->get_value_entry_detail( \RGFormsModel::get_lead_field_value( $entry, $field ), $currency = '', $use_text = true, $format = 'text', 'email' );
			}

			return $field;
		}, $rawForm['fields'] );

		return $rawForm;
	}

	private function capture() {
		add_action( 'gform_post_submission', array( $this, 'handleLead' ), 10, 2 );
		add_action( 'gform_post_submission', array( $this, 'sendNotification' ), 10, 2 );
	}

}
