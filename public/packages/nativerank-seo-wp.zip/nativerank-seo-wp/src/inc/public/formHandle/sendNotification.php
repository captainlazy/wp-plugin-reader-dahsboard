<?php

namespace Nativerank\FormHandle;

class SendNotification {

	protected $emailHTL;
	protected $form;
	protected $entry;
	/**
	 * @var bool
	 */
	private $skipTemplate;

	public function __construct( $form, $entry, $emailHTML, $skipTemplate = false ) {
		$this->form         = $form;
		$this->entry        = $entry;
		$this->emailHTL     = $emailHTML;
		$this->skipTemplate = $skipTemplate;
		$this->sendNotifications();
	}

	private function prepareEmail() {
		ob_start();
		?>
		<?= include 'emailTemplate.php' ?>
		<?php
		return ob_get_clean();
	}

	private function sendNotifications() {
		$email = [];
		foreach ( $this->form['notifications'] as $notification ) {

			if ( ! $notification['isActive'] ) {
				continue;
			}

			$name             = $this->getEntrantName();
			$email['subject'] = $this->replace_variables( $notification['subject'] . $name );

			if ( ! isset( $notification['nr_1055_seo_ignore_notification'] ) || $notification['nr_1055_seo_ignore_notification'] === 0 ) {
				$email['to']        = $this->replace_variables( $notification['to'] );
				$email['message']   = $this->skipTemplate ? $this->emailHTL : $this->prepareEmail();
				$email['headers']   = array( 'Content-Type: text/html; charset=UTF-8' );
				$email['headers'][] = "Cc: " . $this->replace_variables( isset( $notification['cc'] ) ? $notification['cc'] : '' );
				$email['headers'][] = "Bcc: " . $this->replace_variables( isset( $notification['bcc'] ) ? $notification['bcc'] : '' );
				$email['headers'][] = "Reply-To: " . $this->replace_variables( isset( $notification['replyTo'] ) ? $notification['replyTo'] : '' );
				add_filter( 'wp_mail_content_type', function () {
					return "text/html";
				} );

				wp_mail( $email['to'], $email['subject'], $email['message'], $email['headers'] );
			}
		}
	}

	private function getEntrantName() {
		$name_fields = \GFAPI::get_fields_by_type( $this->form, 'name' );

		$name = '';

		if ( count( $name_fields ) > 0 ) {
			$name_fields = array_shift( $name_fields );
			$name_fields = $name_fields->inputs ?? [];
			$name_fields = array_filter( $name_fields, function ( $name_input ) {
				return isset( $name_input['label'] ) && ( $name_input['label'] === 'First' || 'Last' );
			} );


			$name = ' - ';
			foreach ( $name_fields as $name_input ) {
				$name .= sprintf( "{%s:%d} ", $name_input['label'] ?? '', $name_input['id'] ?? 0 );
			}
		}

		return $name;

	}

	private function replace_variables( $text ) {
		return \GFCommon::replace_variables( $text, $this->form, $this->entry, false, false, false, "html" );
	}


}
