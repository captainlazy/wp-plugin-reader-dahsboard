<?php

namespace Nativerank\Tracking;

class Track
{
    protected $visits;
    protected $lastVisit;
    protected $source;
    protected $medium;
    protected $lastPage;

    public function __construct()
    {
        $this->visits = 0;
        $this->source = '';
        $this->medium = 'direct';
        $this->lastPage = '';

        $this->setDefaults();


        if (isset($_SERVER['HTTP_REFERER'])) {
            $this->source = parse_url($_SERVER['HTTP_REFERER'], PHP_URL_HOST);
            if ($this->source == parse_url($this->getAddress(), PHP_URL_HOST)) {
                $this->source = '';
                $this->lastPage = str_replace('http://', '', str_replace('https://', '', $_SERVER['HTTP_REFERER']));
            }
        }

        if (isset($_GET['gclid'])) {
            $this->medium = 'paid';
        }

    }

    private function getAddress()
    {
        $protocol = $_SERVER['HTTPS'] == 'on' ? 'https' : 'http';
        return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    }


    private function setDefaults()
    {
        // Set No of visits
        if (isset($_COOKIE['_nr_nov'])) {
            $cookie = explode('.', $_COOKIE['_nr_nov']);
            $this->visits = (int)$cookie[0];
            $this->lastVisit = $cookie[1];
        }

        //Set Analytics data
        if (isset($_COOKIE['_nr_secure_td'])) {
            $cookie = explode(';', $_COOKIE['_nr_secure_td']);
            $this->source = $cookie[0];
            $this->medium = $cookie[1];
            $this->lastPage = $cookie[2];
        }


    }

    private function setVisits()
    {

        // Consider a new visit if returned after 30 minutes
        if ($this->visits == 0 || time() - $this->lastVisit > 1800) {
            setcookie(
                '_nr_nov',
                ++$this->visits . '.' . time(),
                time() + (10 * 365 * 24 * 60 * 60),
                '/'
            );
        }
    }

    private function source()
    {
        if (isset($_GET['utm_source'])) {
            $this->source = $_GET['utm_source'];
            return;
        }

    }

    private function medium()
    {

        if (isset($_GET['utm_medium'])) {
            $this->medium = $_GET['utm_medium'];
            return;
        }

        if ($this->medium != 'direct')
            return;

        if (strpos($this->source, 'google') != false || strpos($this->source, 'bing') !== false) {
            $this->medium = 'organic';
            return;
        }

        if (!empty($this->source) && $this->medium == 'direct') {
            $this->medium = 'referral';
        }
    }

    private function store()
    {

        setcookie(
            '_nr_secure_td',
            $this->source . ';' . $this->medium . ';' . $this->lastPage,
            time() + (10 * 365 * 24 * 60 * 60),
            '/'
        );
    }

    public function getStats($visit = true)
    {
        if ($visit) {
            $this->setVisits();
        }

        $this->source();
        $this->medium();
        $this->store();
        return [
            '# Visits' => (int)$this->visits,
            'source' => $this->source,
            'medium' => $this->medium,
            'Last Page Visited' => $this->lastPage
        ];
    }

    public function boot()
    {
        $this->getStats();
    }

    public function formField($form)
    {
        $stats = '';
        foreach ($this->getStats(false) as $stat => $value) {
            $stats .= $stat . ': ' . $value . ' | ';
        }
        $props = array(
            'id' => 999,
            'label' => 'Tracking',
            'type' => 'hidden',
            'defaultValue' => $stats
        );
        $field = \GF_Fields::create($props);
        array_push($form['fields'], $field);
        return $form;
    }

    public function forms()
    {
        add_filter('gform_pre_render', array($this, 'formField'));
        add_filter('gform_pre_validation_1', array($this, 'formField'));
        add_filter('gform_pre_submission_filter_1', array($this, 'formField'));
        add_filter('gform_admin_pre_render_1', array($this, 'formField'));
    }
}
