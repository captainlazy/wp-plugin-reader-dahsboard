<?php

namespace Nativerank\frontend;


class Nativerank_seo_1055_scripts
{
    protected $tagManager;
    protected $bingVerification;
    protected $structuredData;

    function __construct()
    {
        $this->tagManager = trim(get_option('nativerank_seo_1055_gtmID'));
        $this->bingVerification = trim(get_option('nativerank_seo_1055_bingID'));
        $this->structuredData = stripslashes(trim(get_option('nativerank_seo_1055_structuredDataID')));
        $this->developmentMode = stripslashes(trim(get_option('nativerank_seo_1055_developmentModeID')));

    }

    private function prepare_site_structure()
    {
        $structuredData = json_decode($this->structuredData);
        if (!empty($structuredData->businessType) && $structuredData->businessName) {
            $data = array(
                "@context" => "http://schema.org",
                "@type" => $structuredData->businessType,
                "name" => $structuredData->businessName,
                "@id" => get_site_url() . "/#$structuredData->businessType",
                "url" => get_site_url(),
                "logo" => [$structuredData->businessLogo],
                "image" => [$structuredData->businessImage],
                "description" => $structuredData->businessDescription,
                "telephone" => '+1' . $structuredData->businessPhone,
            );
        } else {
            return;
        }

        if (!empty($structuredData->businessCity)) {
            $data['address'] = (object)[
                "@type" => "PostalAddress",
                "addressLocality" => $structuredData->businessCity,
                "addressRegion" => $structuredData->businessState,
                "postalCode" => $structuredData->businessZip
            ];

            if (!empty($structuredData->businessAddress)) {
                $data['address']->streetAddress = $structuredData->businessAddress;
            }
            if (!empty($structuredData->businessAreaServed)) {
                $data['address']->areaServed = $structuredData->businessAreaServed;
            }

        }

        if (!empty($structuredData->businessMapsUrl)) {
            $data['hasMap'] = $structuredData->businessMapsUrl;
        }

        if (!empty($structuredData->businessPriceRange)) {
            $data['priceRange'] = $structuredData->businessPriceRange;
        }

        if (!empty($structuredData->businessLat) && !empty($structuredData->businessLng)) {
            $data['geo'] = (object)[
                "@type" => "GeoCoordinates",
                "latitude" => $structuredData->businessLat,
                "longitude" => $structuredData->businessLng
            ];
        }
        if (!empty($structuredData->businessServicesOffered)) {
            $data['makesOffer'] = (object)[
                "@type" => "Offer",
                "itemOffered" => $structuredData->businessServicesOffered
            ];
        }

        if (!empty($structuredData->businessPhone)) {
            $data['contactPoint'] = (object)[
                "@type" => "ContactPoint",
                "telephone" => "+1" . $structuredData->businessPhone,
                "contactType" => "Customer Service"
            ];
        }

        if (!empty($structuredData->businessHours)) {
            foreach ($structuredData->businessHours as $timeSlot) {
                $data['openingHoursSpecification'][] = (object)[
                    "@type" => "OpeningHoursSpecification",
                    "dayOfWeek" => $timeSlot->days,
                    "opens" => $timeSlot->startTime,
                    "closes" => $timeSlot->endTime
                ];
            }
        }


        if (!empty($structuredData->businessRatingValue) && !empty($structuredData->businessReviewCount)) {
            $data['aggregateRating'] = (object)[
                "@type" => "AggregateRating",
                "bestRating" => "5",
                "worstRating" => "1",
                "ratingValue" => $structuredData->businessRatingValue,
                "reviewCount" => $structuredData->businessReviewCount
            ];
        }

        return wp_json_encode($data);


    }

    private function tag_manager()
    {
        if (!empty($this->tagManager) && $this->tagManager != 'null') {
            ob_start();
            ?>
			<!-- Google Tag Manager -->
			<script>(function (w, d, s, l, i) {
					w[l] = w[l] || []
					w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' })
					var f = d.getElementsByTagName(s)[0], j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : ''
					j.async = true
					j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl
					f.parentNode.insertBefore(j, f)
				})(window, document, 'script', 'dataLayer', '<?= $this->tagManager ?>')</script>
			<!-- End Google Tag Manager -->
            <?php
            $output = ob_get_clean();
        } else {
            $output = false;
        }
        return $output;
    }

    public function tag_manager_noscript()
    {
        if (!empty($this->tagManager) && $this->tagManager != 'null') {
            ob_start();
            ?>
			<!-- Google Tag Manager (noscript) -->
			<noscript>
				<iframe src="https://www.googletagmanager.com/ns.html?id=<?= $this->tagManager ?>" height="0" width="0"
				        style="display:none;visibility:hidden"></iframe>
			</noscript>
			<!-- End Google Tag Manager (noscript) -->
            <?php
            $output = ob_get_clean();
        } else {
            $output = false;
        }
        echo $output;
    }

    private function bing_verification()
    {
        if ($this->bingVerification != '' && $this->bingVerification != 'undefined') {
            ob_start();
            ?>
			<meta name="msvalidate.01" content="<?= $this->bingVerification ?>">
            <?php
            $output = ob_get_clean();
        } else {
            $output = false;
        }
        return $output;
    }

    private function structured_data()
    {
        if ($this->structuredData != '' && $this->structuredData != 'undefined') {
            ob_start();
            ?>
			<script type="application/ld+json"><?php if (strpos($this->structuredData, '@context')) {
                    echo $this->structuredData;
                } else {
                    echo $this->prepare_site_structure();
                } ?></script>
            <?php
            $output = ob_get_clean();
        } else {
            $output = false;
        }
        return $output;
    }

    private function load_custom_less()
    {

        if ($this->developmentMode == '1' || $this->developmentMode == 1 || $this->developmentMode == true) {
            ob_start();
            ?>
			<!--DEVELOPMENT MODE ENABLED-->
			<script>console.log('%c NATIVERANK', 'background: #222; color: #f44336;font-weight:800;letter-spacing:2px;', 'Development mode is enabled')</script>
			<link rel="stylesheet/less" type="text/css"
			      href="<?= get_site_url() ?>/wp-content/themes/yootheme_child/less/src/custom.less"/>
            <?php if (is_user_logged_in()) {
                echo "<script>less = {logLevel: 2,env: 'development',dumpLineNumbers: 'comments'}</script>";
            } ?>
			<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/3.5.0/less.min.js"></script>
            <?php if (is_user_logged_in()) {
                echo "<script>less.watch()</script>";
            } ?>

            <?php
            $output = ob_get_clean();
        } else {
            $output = false;
        }
        return $output;
    }

    public function loadScripts()
    {

     
        echo PHP_EOL . PHP_EOL . "<!-- OPTIMIZED USING NATIVERANK SEO PLUGIN  |  https://nativerank.com -->" . PHP_EOL . PHP_EOL;

        if ($this->load_custom_less()) {
            echo $this->load_custom_less();
        }

        if ($this->tag_manager()) {
            echo $this->tag_manager();
            \add_action('nativerank_seo_1055_gtm_noscript', array($this, 'tag_manager_noscript'));
        }
        if ($this->bing_verification()) {
            echo $this->bing_verification();
        }

        if ($this->structured_data()) {
            echo $this->structured_data();
        }
        echo PHP_EOL . "<!-- / NATIVERANK -->" . PHP_EOL . PHP_EOL;
    }
}
