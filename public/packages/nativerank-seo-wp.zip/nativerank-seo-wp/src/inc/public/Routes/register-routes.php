<?php

// register routes here by creating a new instance of Route and passing the URI to match

use Nativerank\frontend\Routes\Route;

new Route('sitemap');


