<?php


namespace Nativerank\frontend\Routes;


class Route {
	protected $uri;
	protected $controller;
	protected $method;

	public function __construct( $uri, $controller = false, $method = 'index' ) {
		$this->uri        = $uri;
		$this->controller = $controller ?: ucwords( $uri ) . 'Controller';
		$this->method     = $method;
		add_action( 'init', [ $this, 'addRoute' ] );
	}

	public function addRoute() {
		add_rewrite_rule( "{$this->uri}/?$", "index.php?nr_wp_controller={$this->controller}&nr_wp_method={$this->method}", "top" );
	}


}
