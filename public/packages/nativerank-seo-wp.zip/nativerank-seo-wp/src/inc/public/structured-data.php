<?php

namespace Nativerank\HelperTasks\StructuredData;

class structuredData {

	public function print_schemas() {
		if ( ! empty( $this->site_navigation_schema() ) ) {
			echo $this->site_navigation_schema();
		}
	}

	private function site_navigation_schema() {
		$output        = false;
		$menuLocations = get_nav_menu_locations();
		if ( ! empty( $menuLocations['navbar'] ) ):
			$menuID     = $menuLocations['navbar'];
			$primaryNav = get_transient( Nativerank_SEO_1055_NAV_TRANSIENT );

			if ( ( is_user_logged_in() && current_user_can( 'administrator' ) ) || $primaryNav === false ) {
				$primaryNav = wp_get_nav_menu_items( $menuID );
				set_transient( Nativerank_SEO_1055_NAV_TRANSIENT, $primaryNav );
			}

			$nodes = '';
			foreach ( $primaryNav as $navItem ) {
				if ( $primaryNav[0]->title != $navItem->title ) {
					$nodes .= ",";
				}
				$nodes .= '{"@type": "SiteNavigationElement","name": "' . wp_strip_all_tags( $navItem->title ) . '"';
				$nodes .= ',"url": "' . $navItem->url . '"}';

			}

			ob_start();
			echo '<script type="application/ld+json">
				{
					"@context": "http://schema.org",
					"@graph": [
						' . $nodes . '
					]
				}
			</script>' . PHP_EOL;
			$output = ob_get_clean();
		endif;

		return $output;
	}

	public function get_structured_data() {
		add_action( 'wp_head', array( $this, 'print_schemas' ) );
	}

}
