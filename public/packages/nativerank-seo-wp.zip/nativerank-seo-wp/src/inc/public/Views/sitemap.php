<?php

use Nativerank\frontend\Sitemap;

get_header();

// the plugin core

echo (new Sitemap())->create();


?>

	<style>
		li {
			margin-top: 6px;
		}
	</style>


<?php
get_footer();
