<?php


namespace Nativerank\frontend\Controllers;


class SitemapController extends Controller
{
    const NR_SEO_1055_CONTROLLER_DESCRIPTION = 'Use the sitemap to find your way around our website.';
    protected $resource = 'sitemap';

    public function index()
    {
        $viewPath = Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/public/Views/{$this->resource}.php";
        if (file_exists($viewPath)) {
            include $viewPath;
        }
    }
}