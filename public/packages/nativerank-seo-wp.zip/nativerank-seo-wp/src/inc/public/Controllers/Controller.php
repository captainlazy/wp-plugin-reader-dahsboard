<?php


namespace Nativerank\frontend\Controllers;


class Controller
{
    protected $resource = 'default';
    const NR_SEO_1055_CONTROLLER_DESCRIPTION = '';

    public function getResource()
    {
        return $this->resource;
    }
}