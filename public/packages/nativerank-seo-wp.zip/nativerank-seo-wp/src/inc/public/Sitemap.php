<?php


namespace Nativerank\frontend;


class Sitemap
{

    public function addShortcode()
    {
        add_shortcode('nr_1055_sitemap', [$this, 'create']);
    }

    public function create()
    {
        // ==============================================================================
        // General Variables
        $checkOptions = get_option('wpseo_xml');
        $goHtm = '';

        //Hard Coded Styles
        $goHtm .= '<!-- NR HTML Sitemap Plugin Start -->
<div class="uk-panel uk-padding">
<div id="nr_1055_sitemap" class="uk-container uk-child-width-1-1" uk-grid>';

        if (!isset($checkOptions['post_types-page-not_in_sitemap'])) {
            $checkOptions['post_types-page-not_in_sitemap'] = false;
        }

        // ==============================================================================
        // Pages
        $pageCheck = get_pages();
        if ((!empty($pageCheck)) && $checkOptions['post_types-page-not_in_sitemap'] !== true) {
            $pageTitle = get_post_type_object('page');
            $pageTitle = $pageTitle->label;
            $goHtm .= '<div id="sitemap_pages" class=""><h3>' . $pageTitle . '</h3>
		<ul class="uk-list uk-list-large sitemapParent uk-column-1-2@s uk-column-1-4@m">';
            $pageInc = '';
            $getPages = get_all_page_ids();
            foreach ($getPages as $pageID) {
                if ((get_post_meta($pageID, '_yoast_wpseo_meta-robots-noindex', true) === '1' && get_post_meta($pageID, '_yoast_wpseo_sitemap-include', true) !== 'always') || (get_post_meta($pageID, '_yoast_wpseo_sitemap-include', true) === 'never') || (get_post_meta($pageID, '_yoast_wpseo_redirect', true) !== '')) {
                    continue;
                }
                if ($pageInc == '') {
                    $pageInc = $pageID;
                    continue;
                }
                $pageInc .= ', ' . $pageID;
            }
            $goHtm .= wp_list_pages(array('include' => $pageInc, 'title_li' => '', 'sort_column' => 'post_title', 'sort_order' => 'ASC', 'echo' => false));

            $goHtm .= '</ul></div>';
        }


// ==============================================================================
// Posts
        $postsTest = get_posts();

        if (!isset($checkOptions['post_types-post-not_in_sitemap'])) {
            $checkOptions['post_types-post-not_in_sitemap'] = false;
        }

        if ((!empty($postsTest)) && $checkOptions['post_types-post-not_in_sitemap'] !== true) {
            $postTitle = get_post_type_object('post');
            $postTitle = $postTitle->label;
            if (get_option('show_on_front') == 'page') {
                $postsURL = get_permalink(get_option('page_for_posts'));
                $postTitle = get_the_title(get_option('page_for_posts'));
            } else {
                $postsURL = get_bloginfo('url');
            }
            $goHtm .= '<div id="sitemap_posts" class=""><h3>';
            if ($postsURL !== '') {
                $goHtm .= '<a href="' . $postsURL . '">' . $postTitle . '</a>';
            } else {
                $goHtm .= $postTitle;
            }
            $goHtm .= '</h3><ul class="uk-list uk-list-large">';
            //Categories
            $cateEx = '';
            $getCate = get_option('wpseo_taxonomy_meta');
            if (!empty($getCate['category'])) {
                foreach ($getCate['category'] as $cateID => $item) {
                    if (($item['wpseo_noindex'] == 'noindex') || ($item['wpseo_sitemap_include'] == 'never')) {
                        if ($cateEx == '') {
                            $cateEx = $cateID;
                        } else {
                            $cateEx .= ', ' . $cateID;
                        }
                    }
                }
            }
            $cats = get_categories('exclude=' . $cateEx);
            foreach ($cats as $cat) {
                $goHtm .= "<li style='margin-top:10px;'><h4><a href='" . esc_url(get_term_link($cat)) . "'>" . $cat->cat_name . "</a></h4>";
                $goHtm .= "<ul class='uk-list uk-list-large uk-column-1-2@s uk-column-1-4@m'>";
                query_posts('posts_per_page=-1&cat=' . $cat->cat_ID);
                while (have_posts()) {
                    the_post();
                    if ((get_post_meta(get_the_ID(), '_yoast_wpseo_meta-robots-noindex', true) === '1' && get_post_meta(get_the_ID(), '_yoast_wpseo_sitemap-include', true) !== 'always') || (get_post_meta(get_the_ID(), '_yoast_wpseo_sitemap-include', true) === 'never') || (get_post_meta(get_the_ID(), '_yoast_wpseo_redirect', true) !== '')) {
                        continue;
                    }

                    $category = get_the_category();
                    // Only display a post link once, even if it's in multiple categories
                    if ($category[0]->cat_ID == $cat->cat_ID) {
                        $goHtm .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
                    }
                }
                wp_reset_query();
                $goHtm .= "</ul>";
                $goHtm .= "</li>";
            }
            $goHtm .= '</ul></div>';
        }

// ==============================================================================
// Custom Post Types

        $custom_post_types = get_post_types(array('public' => true, '_builtin' => false));
        // add to this filter to hide custom post types from the sitemap
        $custom_post_types = apply_filters('nr_1055_sitemap_custom_post_type_filter', $custom_post_types);

        foreach ($custom_post_types as $post_type) {
            $postsTest = get_posts('post_type=' . $post_type);
            if (!empty($postsTest)) {
                $checkSitemap = 'post_types-' . $post_type . '-not_in_sitemap';

                if (!isset($checkOptions[$checkSitemap])) {
                    $checkOptions[$checkSitemap] = false;
                }

                if ($checkOptions[$checkSitemap] === true) {
                    continue;
                }
                $postType = get_post_type_object($post_type);
                $postTypeLink = get_post_type_archive_link($postType->name);
                $goHtm .= '<div id="sitemap_' . str_replace(' ', '', strtolower($postType->labels->name)) . '">';
                if (!empty($postTypeLink)) {
                    $goHtm .= '<h3><a href="' . $postTypeLink . '">' . $postType->labels->name . '</a></h3>';
                } else {
                    $goHtm .= '<h3>' . $postType->labels->name . '</h3>';
                }
                $goHtm .= '<ul class="uk-list uk-list-large uk-column-1-2@s uk-column-1-4@m">';
                query_posts('post_type=' . $post_type . '&posts_per_page=-1&orderby=title&order=ASC');
                while (have_posts()) {
                    the_post();
                    if ((get_post_meta(get_the_ID(), '_yoast_wpseo_meta-robots-noindex', true) === '1' && get_post_meta(get_the_ID(), '_yoast_wpseo_sitemap-include', true) !== 'always') || (get_post_meta(get_the_ID(), '_yoast_wpseo_sitemap-include', true) === 'never') || (get_post_meta(get_the_ID(), '_yoast_wpseo_redirect', true) !== '')) {
                        continue;
                    }
                    $goHtm .= '<li><a href="' . get_permalink() . '">' . get_the_title() . '</a></li>';
                }
                wp_reset_query();
                $goHtm .= '</ul></div>';
            }
        }

        $goHtm .= '</div></div><!-- NR HTML Sitemap Plugin END -->';

        return $goHtm;
    }

}
