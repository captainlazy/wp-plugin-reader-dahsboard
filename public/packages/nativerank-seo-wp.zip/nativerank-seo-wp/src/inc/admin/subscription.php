<?php

namespace Nativerank\Admin;


use Nativerank\NativeAPI\CRM;
use Nativerank\NativeAPI\Monitor;

class Subscription {
	protected $secretKeyPublic;

	/**
	 * @var CRM
	 */
	private $CRM;

	function __construct() {
		$this->secretKeyPublic = '$2y$10$.a0Y94M3eVsvRSedqT72WeOQQWRD0XxuUXIPuZbJyngE0yU.pcL3a';
		add_action( 'wp_ajax_action_nativerank_subscription', array( $this, 'checkSubscription' ) );
	}

	private function deactivateSEO() {
		$defaults = array(
			'depth'        => 0,
			'show_date'    => '',
			'date_format'  => get_option( 'date_format' ),
			'child_of'     => 0,
			'exclude'      => '',
			'title'        => __( 'Pages' ),
			'echo'         => 1,
			'authors'      => '',
			'sort_column'  => 'menu_order, post_title',
			'link_before'  => '',
			'link_after'   => '',
			'item_spacing' => 'preserve',
			'walker'       => '',
		);

		$r                 = wp_parse_args( '', $defaults );
		$r['hierarchical'] = 0;
		$pages             = get_pages( $r );


		foreach ( $pages as $page ) {
			$args = array(
				'ID'         => $page->ID,
				'post_name'  => sanitize_title( $page->post_title ),
				'meta_input' => array(
					'_yoast_wpseo_title'    => '%%title%% | %%sitedesc%% | %%sitename%%',
					'_yoast_wpseo_metadesc' => '%%title%% | %%excerpt%%'
				)
			);

			if ( $page->post_parent ) {
				$args['meta_input']['_yoast_wpseo_title'] = '%%title%% | %%parent_title%% | %%sitedesc%% | %%sitename%%';
			}

			if ( strtolower( sanitize_title( $page->post_title ) === sanitize_title( 'Home' ) ) ) {
				$args['meta_input']['NR - H1'] = get_bloginfo( 'name' );
			} else {
				$args['meta_input']['NR - H1'] = $page->post_title;
			}

			wp_update_post( $args );
		}
	}


	private function compareKey( $secretKeyPrivate ) {
		return password_verify( $secretKeyPrivate, $this->secretKeyPublic );
	}

	private function createBackup() {
		$Exporeter = new \Nativerank\Admin\exporter;

		return $Exporeter->exportPages();
	}


	public function checkSubscription() {
		$mode = $_POST['function_name'];

		switch ( $mode ):
			case 'set':
				$secretKeyPrivate = $_POST['option_value'];
				if ( $this->compareKey( $secretKeyPrivate ) ) {
					update_option( 'nativerank_seo_1055_subscriptionID', 1, true );
					$response['result']  = 1;
					$response['message'] = 'activated';
				} else {
					update_option( 'nativerank_seo_1055_subscriptionID', 0, true );
					$response['result']  = 0;
					$response['message'] = 'Status Inactive : Please enter the correct API key to activate subscription.';
					if ( empty( $this->createBackup() ) ) {
						$response['message'] .= PHP_EOL . 'UNABLE TO BACKUP THE DATABASE. PLEASE BACK UP THE SITE MANUALLY';
					} else {
						$response['backup'] = $this->createBackup();
						$this->deactivateSEO();
					}

				}
				break;
			case 'get':
				$result = get_option( 'nativerank_seo_1055_subscriptionID', 'No subscription found' );
				if ( $result == "No subscription found" ) {
					$response['message'] = $result;
				} else {
					$response['message'] = 'success';
					$response['result']  = $result;
				}
				break;
			case 'suspensionset':
				$secretKeyPrivate = $_POST['option_value'];
				if ( $this->compareKey( $secretKeyPrivate ) ) {
					update_option( 'nativerank_seo_1055_siteSuspendedID', 0, true );
					$response['result']  = 0;
					$monitorMessage      = $this->updateMonitors( 'activate' );
					$crmMessage          = $this->updateCRM( 'activate' );
					$response['message'] = 'Suspension Removed | ' . $monitorMessage . $crmMessage;
				} else {
					update_option( 'nativerank_seo_1055_siteSuspendedID', 1, true );
					$response['result']  = 1;
					$monitorMessage      = $this->updateMonitors( 'suspend' );
					$crmMessage          = $this->updateCRM( 'suspend' );
					$response['message'] = 'Site Suspended | ' . $monitorMessage . $crmMessage;
				}
				break;
			case 'suspensionget':
				$result = get_option( 'nativerank_seo_1055_siteSuspendedID', 'not found' );
				if ( $result == "not found" ) {
					update_option( 'nativerank_seo_1055_siteSuspendedID', 0 );
					$response['message'] = 'added_setting';
					$response['result']  = 0;
				} else {
					$response['message'] = 'success';
					$response['result']  = $result;
				}
				break;
			default:
				$response['error'] = 'Function Not Found';
				break;
		endswitch;
		echo json_encode( $response );
		wp_die();
	}

	private function updateMonitors( $status ) {
		require plugin_dir_path( __FILE__ ) . "../nativeAPI/monitors.php";

		$this->monitors = new Monitor();

		return $this->monitors->updateMonitor( $status );
	}


	private function updateCRM( $status ) {
		require plugin_dir_path( __FILE__ ) . "../nativeAPI/crm.php";

		$this->CRM = new CRM();

		return $this->CRM->updateField( 'Website_Monitoring', $status );
	}
}
