<?php

namespace Nativerank\Admin;

use WP_Error;

class Importer {
	private $contentOnlyKeys = [
		'content',
		'url'
	];
	/**
	 * @var array|false|int|string|null
	 */
	private $currentSiteUrlWithoutScheme = '';

	function __construct() {
		add_action( 'wp_ajax_action_update_seo', array( $this, 'processCSV' ) );
	}

	/**
	 * @param $mode
	 */
	private function optimizeImport( $mode ) {
		if ( $mode == true ) {
			wp_defer_term_counting( true );
			wp_defer_comment_counting( true );
		} else {
			wp_defer_term_counting( false );
			wp_defer_comment_counting( false );
		}
	}

	/**
	 * @param $page
	 *
	 * @return int
	 */
	private function getPageIdByPath( $page ) {
		if ( empty( $page ) ) {
			return 0;
		}

		$page = get_page_by_path( $page );
		$page = $page->ID;

		return empty( $page ) ? 0 : $page;
	}

	/**
	 * @param $args
	 * @param $content
	 * @param $page_type
	 * @param $template
	 *
	 * @return mixed
	 */
	private function conditionallyAddArguments( $args, $content, $page_type, $template ) {
		if ( ! empty( $content ) ) {
			$args['post_content'] = $content;
		}

		if ( ! empty( $page_type ) ) {
			$args['meta_input']['nr_page_type'] = strtolower( $page_type );
		}

		if ( ( ! empty( $template ) && array_key_exists( $template, wp_get_theme()->get_page_templates() ) ) || strtolower( $template ) == 'default' ) {
			$args['meta_input']['_wp_page_template'] = strtolower( $template );
			$args['page_template']                   = strtolower( $template );
		}

		return $args;
	}

	/**
	 * @param $id
	 * @param $label
	 * @param $h1
	 * @param $title_tag
	 * @param $meta_description
	 * @param $parent_page
	 * @param $slug
	 * @param $content
	 * @param $template
	 * @param $page_type
	 *
	 * @return int|\WP_Error
	 */
	private function updatePage( $id, $label, $h1, $title_tag, $meta_description, $parent_page, $slug, $content, $template, $page_type ) {
		$args = array(
			'ID'          => $id,
			'post_title'  => $label,
			'post_name'   => $slug,
			'post_parent' => $this->getPageIdByPath( $parent_page ),
			'meta_input'  => array(
				'NR - H1'               => $h1,
				'_yoast_wpseo_title'    => $title_tag,
				'_yoast_wpseo_metadesc' => $meta_description
			)
		);

		$args = $this->conditionallyAddArguments( $args, $content, $page_type, $template );

		$result = wp_update_post( $args, true );

		if ( $result instanceof WP_Error ) {
			$result->add_data( $args );
		}

		return $result;
	}

	/**
	 * @param $id
	 * @param $label
	 * @param $h1
	 * @param $title_tag
	 * @param $meta_description
	 * @param $parent_page
	 * @param $slug
	 * @param $content
	 * @param $template
	 * @param $page_type
	 *
	 * @return int|\WP_Error
	 */
	private function processPage( $id, $label, $h1, $title_tag, $meta_description, $parent_page, $slug, $content, $template, $page_type ) {
		if ( false !== get_post_status( $id ) ) {
			return $this->updatePage( $id, $label, $h1, $title_tag, $meta_description, $parent_page, $slug, $content, $template, $page_type );
		}

		if ( strtolower( $label ) == 'home' ) {
			update_option( 'show_on_front', 'page' );
			update_option( 'page_on_front', $id );
		}

		$args = array(
			'import_id'      => $id,
			'menu_order'     => $id,
			'post_title'     => $label,
			'post_parent'    => $this->getPageIdByPath( $parent_page ),
			'post_name'      => $slug,
			'post_type'      => 'page',
			'comment_status' => 'closed',
			'ping_status'    => 'closed',
			'post_status'    => 'publish',
			'meta_input'     => array(
				'NR - H1'               => $h1,
				'_yoast_wpseo_title'    => $title_tag,
				'_yoast_wpseo_metadesc' => $meta_description
			)
		);

		$args = $this->conditionallyAddArguments( $args, $content, $page_type, $template );

		$result = wp_insert_post( $args, true );

		if ( $result instanceof WP_Error ) {
			$result->add_data( $args );
		}

		return $result;
	}

	/**
	 *
	 */
	public function processCSV() {

		$result = [];

		$csv = $_POST['csv'];

		$csv = json_decode( stripslashes( $csv ) );

		$this->optimizeImport( true );

		$productionDomain = '';

		$isDevSite = $this->isDevSite();

		foreach ( $csv as $page ) {
			$content = $this->hasContent( $page ) ? $page->content : null;

			if ( $this->isContentOnly( $page ) ) {
				$result[] = $this->updateContent( $page->url, $content );
				continue;
			}

			if ( $isDevSite ) {
				if ( empty( $productionDomain ) ) {
					if ( property_exists( $page, 'DOMAIN NAME' ) ) {
						$productionDomain = $page->{'DOMAIN NAME'};
						if ( ( strpos( $productionDomain, "http" ) !== 0 ) && ( strpos( $productionDomain, "/" ) !== 0 ) ) {
							$productionDomain = "http://${productionDomain}";
						}
					}
				} else {
					$content = $this->replaceContentLinksWithCurrentSiteUrl( $productionDomain, $content );
				}
			}

			$result[] = $this->processPage( $page->id, $page->label, $page->h1, $page->title_tag, $page->meta_description, $page->parent_page, $page->slug, $content, $page->template, $page->page_type );
		}
		$this->optimizeImport( false );

		echo json_encode( $result );
		wp_die();
	}

	/**
	 * @param object $page
	 *
	 * @return bool
	 */
	private function hasContent( $page ) {
		return isset( $_POST['content'] ) && ! empty( $page->content ) && ! strpos( $page->content, 'N/A' );
	}

	/**
	 * @param $page
	 *
	 * @return bool
	 */
	private function isContentOnly( $page ) {
		return empty( array_diff( array_keys( get_object_vars( $page ) ), $this->contentOnlyKeys ) );
	}

	/**
	 * @param string $url
	 * @param null $content
	 *
	 * @return int|\WP_Error
	 */
	private function updateContent( string $url, $content = null ) {
		$url = trailingslashit( $url );

		if ( ( strpos( $url, "http" ) !== 0 ) && ( strpos( $url, "/" ) !== 0 ) ) {
			$url = "http://${url}";
		}


		$path = parse_url( $url, PHP_URL_PATH );
		$path = empty( $path ) ? $url : $path;
		$id   = $path === "/" ? get_option( 'page_on_front' ) : $this->getPageIdByPath( $path );

		if ( $this->isDevSite() ) {
			$content = $this->replaceContentLinksWithCurrentSiteUrl( $url, $content );
		}

		if ( empty( $id ) ) {
			return new \WP_Error( 'invalid_post', __( 'Invalid post ID.' ), $url );
		}

		if ( empty( $content ) ) {
			return new \WP_Error( 'empty_content', __( 'Content is empty.' ), $url );
		}

		return wp_update_post( [ 'ID' => $id, 'post_content' => $content ], true );
	}

	/**
	 * @return bool
	 */
	private function isDevSite(): bool {
		if ( empty( $this->currentSiteUrlWithoutScheme ) ) {
			$this->initializeCurrentSiteUrlWithoutScheme();
		}

		return is_int( strpos( $this->currentSiteUrlWithoutScheme, 'nativerank.dev' ) );
	}

	private function initializeCurrentSiteUrlWithoutScheme() {
		$siteUrl                           = get_site_url();
		$this->currentSiteUrlWithoutScheme = parse_url( $siteUrl, PHP_URL_HOST ) . parse_url( $siteUrl, PHP_URL_PATH );
	}

	/**
	 * @param string $url
	 * @param null $content
	 *
	 * @return string
	 */
	private function replaceContentLinksWithCurrentSiteUrl( string $url, $content = null ): string {
		$content = (string) $content;
		$host    = parse_url( $url, PHP_URL_HOST );

		if ( empty( $this->currentSiteUrlWithoutScheme ) ) {
			$this->initializeCurrentSiteUrlWithoutScheme();
		}

		return str_replace( $host, $this->currentSiteUrlWithoutScheme, $content );

	}

}
