<?php


namespace Nativerank\Admin;

use Nativerank\Admin\Utility\Title;

require 'Title.php';

class ImageCloner
{

	public function __construct()
	{
		$this->registerRoutes();
	}

	public function getAllPages()
	{

		$metaKey    = $_POST['metaKey'];
		$metaValues = $_POST['metaValues'];


		if (empty($metaKey) || empty($metaValues)) {
			wp_send_json_error(['message' => 'Meta Key and Meta Value are both required'], 400);
		}

		$metaValues = json_decode(wp_unslash($metaValues));
		$cacheKey   = $metaKey;
		$cacheKey   .= Nativerank_SEO_1055_VERSION;
		$cacheKey   .= implode(".", $metaValues);
		$cacheKey   = substr($cacheKey, 0, 171);

		$cache = get_transient("nr_pages_all_$cacheKey");
		if ($cache) {
			echo json_encode($cache);
			wp_die();
		}
		$metaValues = '("' . implode('","', $metaValues) . '")';
		global $wpdb;
		$query = "
        SELECT DISTINCT p.ID,p.post_title,p.post_parent FROM {$wpdb->postmeta} pm
        LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE 
        p.post_status=%s
        AND p.post_type = %s
        AND pm.meta_key= %s
        AND pm.meta_value IN {$metaValues}";

		$pages = $wpdb->get_results($wpdb->prepare($query, 'publish', 'page', $metaKey));


		foreach ($pages as $page) {
			if (!empty($page->post_parent)) {
				$page->post_title = get_the_title($page->post_parent) . " - " . $page->post_title;
				$page->post_title = (new Title($page->post_title))->prop;
			}
		}

		$pages = array_map(function ($page) {
			return ['value' => $page->ID, 'text' => $page->post_title];
		}, $pages);

		set_transient("nr_pages_all_$cacheKey", $pages, MINUTE_IN_SECONDS);
		echo json_encode($pages);
		wp_die();
	}


	public function updateFeaturedImage()
	{
		$posts = json_decode(wp_unslash($_POST['nr__post_title']), true);

		$postIDs = array_map(function ($post) {
			return $post['value'];
		}, $posts);


		$images = array_map(function ($post) {
			return ['image' => get_post_thumbnail_id($post['value']), 'post_title' => $post['text']];
		}, $posts);

		$countPages = 0;
		$errorPages = 0;

		$args = array(
			'post_type' => 'page',
			'posts_per_page' => -1,
			'post__not_in' => $postIDs,
			'post_status' => 'publish',
		);


		$the_query = new \WP_Query($args);


		if ($the_query->have_posts()) {
			while ($the_query->have_posts()) {
				$the_query->the_post();
				$post_title = get_the_title(get_the_ID());
				if (!empty(wp_get_post_parent_id(get_the_ID()))) {
					$post_title = get_the_title(wp_get_post_parent_id(get_the_ID())) . " - " . $post_title;
				}

				$imageData = array_values(array_filter($images, function ($image) use ($post_title) {
					$image_post_title = (new Title($image['post_title']))->prop;
					$post_title       = (new Title($post_title))->prop;
					$re               = preg_quote($image_post_title);

					$re = '/' . ((strpos($image_post_title, " - ") > -1) ? "" : " - ") . $re . '$/i';
					return preg_match($re, $post_title);
				}));
				if (!empty($imageData)) {

					$imageId = $imageData[0]['image'];
					$result  = set_post_thumbnail(get_the_ID(), $imageId);
					if ($result !== false)
						$countPages++;
					else
						$errorPages++;
				}

			}
		}

		echo wp_send_json(['Successful' => $countPages . " Pages", 'Failed' => $errorPages . " Pages"], 200);

		wp_die();

		/* Restore original Post Data */
		wp_reset_postdata();
	}

	public function updateBodyImages()
	{
		$posts = json_decode(wp_unslash($_POST['nr__post_title']), true);

		$postIDs = array_map(function ($post) {
			return (int)$post['value'];
		}, $posts);

		$images = array_map(function ($post) {
			return ['images' => get_field('body_images', $post['value']), 'post_title' => $post['text']];
		}, $posts);

		$args = array(
			'post_type' => 'page',
			'posts_per_page' => -1,
			'post__not_in' => $postIDs,
			'post_status' => 'publish',
		);

		$the_query = new \WP_Query($args);

		$countPages = 0;
		$errorPages = 0;

		if ($the_query->have_posts()) {
			while ($the_query->have_posts()) {
				$the_query->the_post();

				$post_title = get_the_title(get_the_ID());

				if (!empty(wp_get_post_parent_id(get_the_ID()))) {
					$post_title = get_the_title(wp_get_post_parent_id(get_the_ID())) . " - " . $post_title;
				}
				$imageData = array_values(array_filter($images, function ($image) use ($post_title) {
					$image_post_title = (new Title($image['post_title']))->prop;
					$post_title       = (new Title($post_title))->prop;
					$re               = preg_quote($image_post_title);

					$re = '/' . ((strpos($image_post_title, " - ") > -1) ? "" : " - ") . $re . '$/i';
					return preg_match($re, $post_title);
				}));
				if (!empty($imageData)) {
					// Delete all existing rows
					$existingImages = get_field('body_images');
					if (!empty($existingImages)) {
						$count = count($existingImages);
						for ($index = 0; $index <= $count; $index++) {
							delete_row('body_images', $index);
						}
						delete_row('body_images', 1);
					}
					//....

					foreach ($imageData[0]['images'] as $image) {
						$result = add_row('body_images', array('images' => $image['images']['id']));
						if ($result)
							$countPages++;
						else
							$errorPages++;
					}
				}
			}
		}

		echo wp_send_json(['Successful' => $countPages . " Images", 'Failed' => $errorPages . " Images"], 200);

		wp_die();

		/* Restore original Post Data */
		wp_reset_postdata();
	}

	private function registerRoutes()
	{
		add_action('wp_ajax_action_cloner_get_all_filtered_pages', array($this, 'getAllPages'));
		add_action('wp_ajax_action_cloner_update_featured_image', array($this, 'updateFeaturedImage'));
		add_action('wp_ajax_action_cloner_update_body_images', array($this, 'updateBodyImages'));
	}

}
