<?php

namespace Nativerank\Admin;

class Globals
{

    protected $filePath;

    public function __construct()
    {
        $this->filePath = get_stylesheet_directory() . '/data.json';
    }

    public function boot()
    {
        $this->registerRoutes();
    }

    public function getGlobals()
    {
        if (file_exists($this->filePath)) {
            echo json_encode(json_decode(file_get_contents($this->filePath)));
            wp_die();
        }

        wp_send_json_error('data.json file not found.', 400);
        wp_die();
    }

    public function setGlobals()
    {
        $globals = $_POST['globals'];
        if (file_exists($this->filePath)) {
            $log = file_put_contents($this->filePath, stripcslashes($globals));

            if ($log == FALSE) {
                wp_send_json_error('Unable to edit data.json', 503);
                wp_die();
            }

            echo wp_send_json(['filesize' => $log], 200);
            wp_die();
        }

        wp_send_json_error('data.json file not found.', 400);
        wp_die();
    }

    private function registerRoutes()
    {
        add_action('wp_ajax_action_get_globals', array($this, 'getGlobals'));
        add_action('wp_ajax_action_set_globals', array($this, 'setGlobals'));

    }
}
