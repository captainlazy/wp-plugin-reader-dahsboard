<?php

namespace Nativerank\Admin;

class Utility
{
	public function __construct()
	{
		$this->registerRoutes();
	}


	public function getAllMetaKeys()
	{
		$cache = get_transient('nr_pages_meta_keys');
		if ($cache) {
			echo json_encode($cache);
			wp_die();
		}

		global $wpdb;
		$post_type = 'page';
		$query     = "
        SELECT DISTINCT($wpdb->postmeta.meta_key) 
        FROM $wpdb->posts 
        LEFT JOIN $wpdb->postmeta 
        ON $wpdb->posts.ID = $wpdb->postmeta.post_id 
        WHERE $wpdb->posts.post_type = '%s' 
        AND $wpdb->postmeta.meta_key != '' 
        AND $wpdb->postmeta.meta_key NOT RegExp '(^[_0-9].+$)' 
        AND $wpdb->postmeta.meta_key NOT RegExp '(^[0-9]+$)'
    ";
		$meta_keys = $wpdb->get_col($wpdb->prepare($query, $post_type));
		set_transient('nr_pages_meta_keys', $meta_keys, MINUTE_IN_SECONDS); # create 1 Day Expiration
		echo json_encode($meta_keys);
		wp_die();
	}

	public function getAllMetaValues()
	{
		$metaKey = $_POST['metaKey'];
		if (empty($metaKey)) {
			echo null;
			wp_die();
		}

		$cache = get_transient('nr_pages_all_meta_values');
		if ($cache) {
			echo json_encode($cache);
			wp_die();
		}
		global $wpdb;
		$metaValues = $wpdb->get_col($wpdb->prepare("
        SELECT DISTINCT pm.meta_value FROM {$wpdb->postmeta} pm
        LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = %s 
        AND p.post_type = %s
    ", $metaKey, 'page'));
		set_transient('nr_pages_all_meta_values', $metaValues, MINUTE_IN_SECONDS); # create 1 Day Expiration
		echo json_encode($metaValues);
		wp_die();
	}


	public function getAllPages()
	{
		$metaKey   = $_POST['metaKey'];
		$metaValue = $_POST['metaValue'];

		if (empty($metaKey) || empty($metaValue)) {
			echo null;
			wp_die();
		}

		$cache = get_transient("nr_pages_all_$metaKey-$metaValue");
		if ($cache) {
			echo json_encode($cache);
			wp_die();
		}
		global $wpdb;
		$pages = $wpdb->get_col($wpdb->prepare("
        SELECT DISTINCT p.post_title FROM {$wpdb->postmeta} pm
        LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = %s
        AND pm.meta_value = %s
        AND p.post_type = %s
    ", $metaKey, $metaValue, 'page'));


		set_transient("nr_pages_all_$metaKey-$metaValue", $pages, MINUTE_IN_SECONDS);
		echo json_encode($pages);
		wp_die();
	}

	public function updateFeaturedImage()
	{
		$imageId        = (int)$_POST['image'];
		$nr__post_title = $_POST['nr__post_title'];
		$metaQuery      = json_decode(stripcslashes($_POST['filter']), true);


		$args = array(
			'post_type' => 'page',
			'posts_per_page' => -1,
			'nr__post_title' => $nr__post_title,
			'post_status' => 'publish',
			'meta_query' => $metaQuery
		);


		$the_query = new \WP_Query($args);

		$countPages = 0;
		$errorPages = 0;

		if ($the_query->have_posts()) {
			while ($the_query->have_posts()) {
				$the_query->the_post();
				$result = set_post_thumbnail(get_the_ID(), $imageId);
				if ($result)
					$countPages++;
				else
					$errorPages++;
			}
		}

		echo wp_send_json(['Successful' => $countPages . " Pages", 'Failed' => $errorPages . " Pages"], 200);

		wp_die();

		/* Restore original Post Data */
		wp_reset_postdata();
	}

	public function updateBodyImages()
	{
		$imageIds       = json_decode(stripcslashes($_POST['images']), true);
		$nr__post_title = $_POST['nr__post_title'];
		$metaQuery      = json_decode(stripcslashes($_POST['filter']), true);

		$args = array(
			'post_type' => 'page',
			'posts_per_page' => -1,
			'nr__post_title' => $nr__post_title,
			'post_status' => 'publish',
			'meta_query' => $metaQuery
		);


		$the_query = new \WP_Query($args);

		$countPages = 0;
		$errorPages = 0;

		if ($the_query->have_posts()) {
			while ($the_query->have_posts()) {
				$the_query->the_post();

				// Delete all existing rows
				$images = get_field('body_images');
				if (!empty($images)) {
					$count = count($images);
					for ($index = 0; $index <= $count; $index++) {
						delete_row('body_images', $index);
					}
					delete_row('body_images', 1);
				}
				//....

				foreach ($imageIds as $imageId) {
					$result = add_row('body_images', array('images' => $imageId));
					if ($result)
						$countPages++;
					else
						$errorPages++;
				}
			}
		}

		echo wp_send_json(['Successful' => $countPages . " Images", 'Failed' => $errorPages . " Images"], 200);

		wp_die();

		/* Restore original Post Data */
		wp_reset_postdata();
	}

	private function registerRoutes()
	{
		add_filter('posts_where', function ($where, $wp_query) {
			global $wpdb;
			if ($nr__post_title = $wp_query->get('nr__post_title')) {
				$where .= ' AND ' . $wpdb->posts . '.post_title = \'' . esc_sql($nr__post_title) . '\'';
			}
			return $where;
		}, 10, 2);


		add_action('wp_ajax_action_get_all_meta_keys', array($this, 'getAllMetaKeys'));
		add_action('wp_ajax_action_get_all_meta_values', array($this, 'getAllMetaValues'));
		add_action('wp_ajax_action_get_all_filtered_pages', array($this, 'getAllPages'));
		add_action('wp_ajax_action_update_featured_image', array($this, 'updateFeaturedImage'));
		add_action('wp_ajax_action_update_body_images', array($this, 'updateBodyImages'));

	}

}
