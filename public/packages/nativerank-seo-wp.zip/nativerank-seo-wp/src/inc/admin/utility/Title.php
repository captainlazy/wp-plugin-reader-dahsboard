<?php


namespace Nativerank\Admin\Utility;


class Title
{

    /**
     * @var string
     */
    public $prop;


    /**
     * Title constructor.
     * @param $title string | null
     */
    public function __construct($title = null)
    {
        if (empty($title)) {

            if (empty($this->prop)) {
                return new \ErrorException('Title is required');
            }
            return $this->prop;
        }

        $this->prop = $title;

        $this->removeCharacters();

    }

    private function removeCharacters()
    {

        $value = utf8_encode($this->prop);
        $value = html_entity_decode($value, ENT_QUOTES, "UTF-8");
        $value = trim($value);
        $value = preg_replace('/[^(\x20-\x7F)]+$/', '', $value);
        $value = preg_replace('/[^(\x20-\x7F)]+/', ' ', $value);
        $this->prop = $value;
        return $value;
    }


}
