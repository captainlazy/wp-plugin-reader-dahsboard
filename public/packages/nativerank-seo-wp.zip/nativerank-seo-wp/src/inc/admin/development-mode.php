<?php

namespace Nativerank\Admin;

class Development_mode
{
	protected $developmentMode;
	protected $setupHasRun;
	protected $cssFilePath;

	function __construct()
	{
		$this->cssFilePath     = get_stylesheet_directory() . "/css/custom.css";
		$this->developmentMode = trim(get_option('nativerank_seo_1055_developmentModeID'));
		$this->setupHasRun     = trim(get_option('nativerank_seo_1055_setupHasRun'));
		if ($this->developmentMode != '0' || $this->developmentMode != 0 || $this->developmentMode != false) {
			add_option('nativerank_seo_1055_developmentModeID', 1);
			update_option('blog_public', 0);
		}
	}

	public function check_development_mode()
	{
		if ($this->developmentMode == '0' || $this->developmentMode == 0 || $this->developmentMode == false) {
			update_option('blog_public', 1);
			$this->compile_less();
		} else {
			update_option('blog_public', 0);
			$this->remove_old_css_file();
			return false;
		}
	}

	private function remove_old_css_file()
	{
		unlink($this->cssFilePath);
	}

	private function compile_less()
	{
		require plugin_dir_path(__FILE__) . "../styles/class-nativerank-seo-1055-less.php";
		$Less = new \Nativerank\Styles\Less;
		$Less->compileLess();
	}
}
