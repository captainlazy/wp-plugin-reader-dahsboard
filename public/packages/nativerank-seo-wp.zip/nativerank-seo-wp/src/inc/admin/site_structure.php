<?php
/**
 * Created by PhpStorm.
 * User: sahilkhanna
 * Date: 2019-03-13
 * Time: 23:29
 */

namespace Nativerank\Admin;

class site_structure
{
    public function getImages()
    {
        $pageId = $_POST['pageId'];
        $thumbnailUrl = get_the_post_thumbnail_url($pageId, 'thumbnail');
        if ($thumbnailUrl) {
            echo json_encode(array('url' => $thumbnailUrl));
        } else {
            echo json_encode(array('url' => "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAyAAAAMgAgMAAACmHu77AAAADFBMVEWzs7Pf39/ExMTU1NRdkO0cAAAEDUlEQVR4Xu3cIW4bURAG4PVWBVFUmCMEBpb7CAX12qqsyLDQ0PBdwkcJ9yXMC3OMgtdmUlVa0/7bb6jRB573/fNGM2wWUiAgICABBQICAhJZICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIKdhpsZrDqQNc/UYA5mG2bqLgezmIWMM5DjM1zUFcrgBOadA1jcgD2EQEBAQEBAQkIf5324XCAgICAjI6/iyCMipunHZkFbduGjIvrpx2ZBjNbGyIZcKH9mQallnQ6ZqWWdD9h2yiofsOmSMh3wZesVDjvWIkA051CPCPwEBWVfz5z+FgID41/JBdEVxaaxr/IdlBavTeM2Nuu1d1G3DfS5kXd/DqYvS20F9gms8p0KmOiKHPsyY3zLtLa6nVMju91dkO/R6SX9W+FqTspGQv6c178MhNa35lA25DG/VoiFLmUWZlgLZLwVyXApkvRRIy4fUBWVs0ZA666vnaEhdUD5tTsmQCiOfN5sf6ZDLr37jtmVDtm9tum/ZkKm6W99jIXXWe1JsyZDju0GO50hIscp1Coa0P94WLomQOutj/JRpzdGlQ/p7z8dwSF1QsiF11s/ZkAojm2hIdUtX4ZAKI9mQOuuP6ZAKI/mQHkayIRVGsiF11u/CIRVGwiEVRsIhFUbCIRVGsiEVRsIhFUbyIRVGCmLDAAgICAgICEjAMj3rDSMWTuavALWU1ZpcG5hBQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH4CAfTad3uoxsIAAAAASUVORK5CYII="));
        }
        wp_die();
    }

    public function updateImages()
    {
        $pageId = $_POST['pageId'];
        $imageID = $_POST['imageId'];
        $setFeaturedImage = set_post_thumbnail($pageId, $imageID);
        if (!$setFeaturedImage) {
            echo 'failed';
            wp_die();
        }
        $thumbnailUrl = get_the_post_thumbnail_url($pageId, 'post-thumbnail');
        echo json_encode(array('url' => $thumbnailUrl));
        wp_die();
    }

    public function updateMetaField()
    {
        $pageId = $_POST['pageId'];
        $key = $_POST['key'];
        $value = $_POST['value'];

        update_post_meta($pageId, $key, $value);
        echo wp_send_json(array('message' => 'Successful'), 200);
        wp_die();
    }

    public function getAllPages($mode = false)
    {
        $defaults = array(
            'depth' => 0,
            'show_date' => '',
            'date_format' => get_option('date_format'),
            'child_of' => 0,
            'exclude' => '',
            'title' => __('Pages'),
            'echo' => 1,
            'authors' => '',
            'sort_column' => 'menu_order, post_title',
            'link_before' => '',
            'link_after' => '',
            'item_spacing' => 'preserve',
            'walker' => '',
        );

        $r = wp_parse_args('', $defaults);
        $r['hierarchical'] = 0;
        $pages = get_pages($r);

        $allPages = [];
        $findTopPage = [];

        $pages = json_decode(json_encode($pages), true);
        foreach ($pages as $pageKey => $page) {

            unset($pages[$pageKey]['ping_status']);

            unset($pages[$pageKey]['comment_status']);
            unset($pages[$pageKey]['post_password']);
            unset($pages[$pageKey]['pinged']);
            unset($pages[$pageKey]['to_ping']);
            unset($pages[$pageKey]['post_content']); //for now
            unset($pages[$pageKey]['post_content_filtered']);
            unset($pages[$pageKey]['post_type']);
            unset($pages[$pageKey]['post_mime_type']);
            unset($pages[$pageKey]['comment_count']);

            //unset($pages[$pageKey]['filter']);
            unset($pages[$pageKey]['post_excerpt']);
            $posttitle = $page['post_title'];

            $posttitle = preg_replace('~\x{00a0}~siu', ' ', $posttitle);
            $posttitle = str_replace("\\u00a0\"", "\"", $posttitle);
            $posttitle = trim(str_replace("\\u00a0", " ", $posttitle));
            unset($pages[$pageKey]['post_title']);
            $pages[$pageKey]['name'] = $posttitle;

            $pages[$pageKey]['title_tag'] = get_post_meta($page['ID'], '_yoast_wpseo_title', true);
            $pages[$pageKey]['meta_description'] = get_post_meta($page['ID'], '_yoast_wpseo_metadesc', true);
            $pages[$pageKey]['nr_page_type'] = get_post_meta($page['ID'], 'nr_page_type', true);
            $pages[$pageKey]['template'] = get_post_meta($page['ID'], '_wp_page_template', true);


            $pages[$pageKey]['permalink'] = get_the_permalink($page['ID']);

            $pages[$pageKey]['postDate'] = $page['post_date_gmt'];
            unset($pages[$pageKey]['post_date_gmt']);
            $pages[$pageKey]['lastModified'] = $page['post_modified_gmt'];
            unset($pages[$pageKey]['post_modified_gmt']);


            if ($page['post_parent'] == 0) {
                $allPages[$page['ID']] = $pages[$pageKey];
                unset($pages[$pageKey]);
            }


        }

        foreach ($pages as $pageKey => $page) {
            if (isset($allPages[$page['post_parent']])) {
                $findTopPage[$page['ID']] = $page['post_parent'];
                $allPages[$page['post_parent']]['children'][$page['ID']] = $page;
                unset($pages[$pageKey]);
            }
        }


        foreach ($pages as $pageKey => $page) {
            if (is_array($allPages[$findTopPage[$page['post_parent']]]['children'][$page['post_parent']])) {
                $page['topParent'] = $findTopPage[$page['post_parent']];
                $allPages[$findTopPage[$page['post_parent']]]['children'][$page['post_parent']]['children'][$page['ID']] = $page;
            }

        }


        $allPages = json_encode(array_values($allPages));
        $allPages = str_replace('post_title', 'name', $allPages);
        $allPages = str_replace('ID', 'id', $allPages);
        $allPages = str_replace('post_parent', 'parent', $allPages);

        if ($mode == true) {
            return $allPages;
        }
        echo $allPages;
        wp_die();
    }

    public function apiGetAllPages()
    {
        add_action('wp_ajax_action_get_all_pages_api', array($this, 'getAllPages'));
        add_action('wp_ajax_action_get_image_api', array($this, 'getImages'));
        add_action('wp_ajax_action_set_image_api', array($this, 'updateImages'));
        add_action('wp_ajax_action_update_meta_field', array($this, 'updateMetaField'));

    }

    public function getThePages()
    {
        return $this->getAllPages(true);
    }

}
