<?php


namespace Nativerank\Admin;


class Sync {


	/**
	 * The NRank API server.
	 *https://track-digital.test/
	 * @var string (URL)
	 */
	protected $server_root = 'https://track.nativerank.com';

	/**
	 * Path to the REST API on the server.
	 *
	 * @var string (URL)
	 */
	protected $rest_api = '/api/nativerank-websites/save-info';


	/**
	 * Stores the API key used for authentication.
	 *
	 * @var string
	 */
	protected $api_key = '9d7b6288b9f20b419db69bb32671f582';


	/**
	 * Holds the last last time the site synced with the API
	 *
	 * @var array|false
	 */
	protected $last_sync = false;


	/**
	 * Cron Job Hook
	 *
	 * @var string
	 */
	const CRON_JOB_HOOK = 'nativerank_seo_wp_api_sync_job';

	/**
	 * @var array
	 */
	private $runtime_data = [];

	public function __construct() {

		$this->last_sync = get_option( 'nativerank_seo_wp_last_sync', false );


		if ( $this->last_sync === false ) {
			$this->last_sync['time'] = time();

			$this->boot();
		}

		if ( ! wp_next_scheduled( self::CRON_JOB_HOOK ) ) {
			$this->register_cron_job();
		}


		add_filter( self::CRON_JOB_HOOK, [ $this, 'boot' ] );
	}

	public function update_sync_options() {
		update_option( 'nativerank_seo_wp_last_sync', $this->last_sync );
	}

	public function register_cron_job() {
		wp_schedule_event( strtotime( "tomorrow midnight" ), 'daily', self::CRON_JOB_HOOK );
	}

	public function boot() {
		$bootable = apply_filters( 'nativerank_seo_wp_api__bootable', true );


		if ( $bootable !== true ) {
			return false;
		}

		$this->get_packages();
		$this->get_package_updates_infos();

		$this->api_sync();

	}

	/**
	 * Returns a list of all plugins and themes installed the WordPress site
	 *
	 * @return array Array that contains 2 sub-arrays: 'plugins' and 'themes'.
	 */
	public function get_packages() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$packages = array(
			'plugins' => array(),
			'themes'  => array(),

		);

		$plugins = get_plugins();
		$themes  = wp_get_themes();


		// Extract and collect details we need.
		foreach ( $plugins as $slug => $data ) {

			if ( is_multisite() ) {
				$active = is_plugin_active_for_network( $slug ) || is_plugin_active( $slug );
			} else {
				$active = is_plugin_active( $slug );
			}

			$packages['plugins'][ $slug ] = array(
				'name'       => $data['Name'],
				'version'    => $data['Version'],
				'plugin_url' => $data['PluginURI'],
				'author'     => $data['Author'],
				'author_url' => $data['AuthorURI'],
				'network'    => $data['Network'],
				'active'     => $active,
			);
		}

		foreach ( $themes as $slug => $theme ) {

			if ( is_multisite() ) {
				$active = $theme->is_allowed() || get_stylesheet() == $slug; //network enabled or on main site
			} else {
				// If the theme is available on main site it's "active".
				$active = get_stylesheet() == $slug;
			}

			$parent                      = $theme->parent() ? $theme->get_template() : false;
			$packages['themes'][ $slug ] = array(
				'name'       => $theme->display( 'Name', false ),
				'version'    => $theme->display( 'Version', false ),
				'author'     => $theme->display( 'Author', false ),
				'author_url' => $theme->display( 'AuthorURI', false ),
				'screenshot' => $theme->get_screenshot(),
				'parent'     => $parent,
				'active'     => $active,
			);
		}

		return $packages;
	}

	/**
	 * Returns a list of all config data
	 *
	 * @return array
	 */
	private function config_data() {
		return [
			'digital_solution_subscription'     => (int) get_option( 'nativerank_seo_1055_subscriptionID', 0 ),
			'digital_solution_smtp'             => (int) get_option( 'nativerank_seo_1055_emailSMTPID', 0 ),
			'digital_solution_development_mode' => (int) get_option( 'nativerank_seo_1055_developmentModeID', 0 ),
			'digital_solution_suspended'        => (int) get_option( 'nativerank_seo_1055_siteSuspendedID', 0 ),
			'wp_debug'                          => (int) defined( 'WP_DEBUG' ) && true === WP_DEBUG,
			'blog_public'                       => (int) get_option( 'blog_public', 0 )
		];
	}

	/**
	 * Returns a list of all gravity forms' data.
	 *
	 * @return array Array that contains each form in a subarray  [ 'title', 'is', 'is_active', 'notifications' = [] ].
	 */
	private function gravity_form_data() {
		$res = [];

		if ( class_exists( 'GFCommon' ) ) {
			$forms = \GFAPI::get_forms();
			foreach ( $forms as $form ) {
				$res[] = [
					'id'            => $form['id'],
					'title'         => $form['title'],
					'is_active'     => (int) $form['is_active'],
					'notifications' => $form['notifications']
				];
			}
		}

		return $res;
	}

	/**
	 * Generates the stats data about the site and installed products
	 *
	 * @param bool $encoded Whether to json encode the fields that are arrays
	 *
	 * @return array
	 *
	 * Payload: json
	 * {
	 * domain: string, // stripped url of the site
	 * blog_count : number, // if multi-site ? number of websites
	 * wp_version : string, // WordPress 5.4.2
	 * admin_url : string,
	 * home_url : string,
	 * 'package_updates' : {plugins: [], themes: []} // list of plugins and themes that require updates
	 * 'packages' => {plugins: [], themes: []} // list of all plugins and themes
	 * }
	 */
	public function build_api_data( $encoded = false ) {
		global $wp_version;


		if ( ! function_exists( 'is_plugin_active' ) ) {
			include_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$theme      = wp_get_theme();
		$ms_allowed = $theme->get_allowed();


		// Get WP/BP version string to help with support.
		$wp_ver = '';
		if ( is_multisite() ) {
			$wp_ver     = "WordPress Multisite $wp_version";
			$blog_count = get_blog_count();
		} else {
			$wp_ver     = "WordPress $wp_version";
			$blog_count = 1;
		}
		if ( defined( 'BP_VERSION' ) ) {
			$wp_ver .= ', BuddyPress ' . BP_VERSION;
		}

		// Get a list of pending WP updates of non-WPMUDEV themes/plugins.
		$package_updates = $this->get_package_updates_infos();

		$packages = $this->get_packages();

		$config = $this->config_data();
		$forms  = $this->gravity_form_data();

		$ip = file_get_contents( 'http://ipecho.net/plain' );

		$domain = $this->stripUrl( network_site_url() );
		$domain = $domain === $ip ? $this->stripUrl( WP_NR_SITEURL ) : $domain;
		$domain = empty( $domain ) ? $ip : $domain;

		$data = array(
			'domain'          => $domain,
			'ip'              => $ip,
			'blog_count'      => $blog_count,
			'wp_version'      => $wp_ver,
			'admin_url'       => network_admin_url(),
			'home_url'        => network_site_url(),
			'package_updates' => $package_updates,
			'packages'        => $packages,
			'config'          => $config,
			'forms'           => $forms,
			'api_token'       => $this->api_key
		);

		$data = array_merge( $data, $this->runtime_data );

		if ( $encoded ) {
			$data['package_updates'] = json_encode( $data['package_updates'] );
			$data['packages']        = json_encode( $data['packages'] );
			$data['config']          = json_encode( $data['config'] );
			$data['forms']           = json_encode( $data['forms'] );
		}

		return $data;
	}


	// TODO
	private function get_post_smtp_errors() {

		$args = array(
			'posts_per_page'   => - 1,
			'orderby'          => 'date',
			'order'            => 'DESC',
			'post_type'        => 'post_excerpt',
			'post_status'      => 'private',
			'suppress_filters' => true,
			'date_query'       => array(
				array(
					'column' => 'post_date_gmt',
					'after'  => '30 days ago',
				)
			)
		);


	}


	/**
	 * Returns a list of all plugins and themes on the WordPress site that have
	 * an pending update.
	 *
	 * @return array Array that contains 2 sub-arrays: 'plugins' and 'themes'.
	 */
	public function get_package_updates_infos() {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		$core_updates = array(
			'plugins' => array(),
			'themes'  => array(),
		);


		// Get the available updates list.
		$plugin_data = get_site_transient( 'update_plugins' );
		$theme_data  = get_site_transient( 'update_themes' );


		// Extract and collect details we need.
		if ( isset( $plugin_data->response ) && is_array( $plugin_data->response ) ) {
			foreach ( $plugin_data->response as $slug => $infos ) {
				$item                             = get_plugin_data( WP_PLUGIN_DIR . '/' . $slug );
				$core_updates['plugins'][ $slug ] = array(
					'name'        => $item['Name'],
					'version'     => $item['Version'],
					'new_version' => $infos->new_version,
					'upgradable'  => ! empty( $infos->package ),
				);
			}
		}

		if ( isset( $theme_data->response ) && is_array( $theme_data->response ) ) {
			foreach ( $theme_data->response as $slug => $infos ) {
				$item                            = wp_get_theme( $slug );
				$core_updates['themes'][ $slug ] = array(
					'name'        => $item->Name,
					'version'     => $item->Version,
					'new_version' => $infos['new_version'],
					'upgradable'  => ! empty( $infos['package'] ),
				);
			}
		}

		return $core_updates;
	}


	/**
	 * Contacts the API to sync the latest data from this site.
	 *
	 * In case the API call fails the function returns boolean false
	 *
	 *
	 * @return array|bool
	 */
	public function api_sync() {
		$res = false;


		if ( defined( 'WP_INSTALLING' ) ) {
			return false;
		}

		$stats_data = $hash_data = $this->build_api_data( true );
		$data_hash  = md5( json_encode( $hash_data ) ); //get a hash of the data to see if it changed
		unset( $hash_data );

		if ( isset( $this->last_sync['hash'] ) && $data_hash === $this->last_sync['hash'] ) {
			return true;
		}

		$this->last_sync['hash'] = $data_hash;

		$response                          = wp_remote_post( $this->server_root . $this->rest_api, [ 'body' => $stats_data ] );
		$this->last_sync['log']            = [];
		$this->last_sync['log']['message'] = wp_remote_retrieve_response_message( $response );
		$this->last_sync['log']['code']    = wp_remote_retrieve_response_code( $response );
		if ( 200 === wp_remote_retrieve_response_code( $response ) ) {
			$data = json_decode( wp_remote_retrieve_body( $response ), true );

			$res = $data;
		}
		$this->update_sync_options();

		return $res;
	}

	public function add_runtime_data( $data = [] ) {
		$this->runtime_data = array_merge( $this->runtime_data, $data );

		return $this;
	}

	private function stripUrl( $url ) {
		$url = parse_url( trim( strtolower( $url ) ) );
		if ( ! isset( $url['host'] ) ) {
			$url = $url['path'];
			$re  = '/^(?:www\.)?(.*?)($|\/)/mi';
			preg_match_all( $re, $url, $matches, PREG_SET_ORDER, 0 );
			$url = $matches[0][1];
		} else {
			$url = str_replace( 'www.', '', $url['host'] );
		}

		return $url;
	}

}



