<?php

namespace Nativerank\Admin;

class exporter
{

    function __construct()
    {
        add_action('wp_ajax_action_nativerank_seo_export', array($this, 'apiExportPages'));
    }

    private function processAllPages()
    {

        $out = array();
        $defaults = array(
            'depth' => 0,
            'show_date' => '',
            'date_format' => get_option('date_format'),
            'child_of' => 0,
            'exclude' => '',
            'title' => __('Pages'),
            'echo' => 1,
            'authors' => '',
            'sort_column' => 'menu_order, post_title',
            'link_before' => '',
            'link_after' => '',
            'item_spacing' => 'preserve',
            'walker' => '',
        );

        $r = wp_parse_args('', $defaults);
        $r['hierarchical'] = 0;
        $pages = get_pages($r);

        $titles = array('id', 'label', 'h1', 'title_tag', 'meta_description', 'parent_page', 'slug', 'content', 'template', 'page_type');
        array_push($out, $titles);

        foreach ($pages as $page) {

            $row = array(
                $page->ID,
                $page->post_title,
                get_post_meta($page->ID, 'NR - H1', true),
                get_post_meta($page->ID, '_yoast_wpseo_title', true),
                get_post_meta($page->ID, '_yoast_wpseo_metadesc', true),
                get_page_uri($page->post_parent) ? get_page_uri($page->post_parent) : 0,
                $page->post_name,
                wp_slash($page->post_content),
                get_page_template_slug($page->ID),
                get_post_meta($page->ID, 'nr_page_type', true)
            );
            array_push($out, $row);
        }
        return $out;
    }

    public function exportPages()
    {
        return $this->processAllPages();
    }

    public function apiExportPages()
    {
        echo json_encode($this->processAllPages());
        wp_die();
    }
}
