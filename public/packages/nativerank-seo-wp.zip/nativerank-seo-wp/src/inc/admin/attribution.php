<?php


namespace Nativerank\Admin;


class Attribution {

	public function __construct() {
		add_filter( 'nr_1055_template_data', [ $this, 'addAttribution' ] );
	}

	public function addAttribution( $data = [] ) {
		$attribution = get_option( 'nativerank_seo_1055_attributionID' );

		if ( is_string( $attribution ) && ! empty( $attribution ) ) {
			$data['attribution'] = json_decode( stripslashes( trim( $attribution ) ) );
		}

		return $data;
	}

}