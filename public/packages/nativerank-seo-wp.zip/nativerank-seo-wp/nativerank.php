<?php
/*
  Plugin Name: Native Rank
  Plugin URI: https://www.nativerank.com
  description: Use the NativeRank SEO plugin to improve your SEO strategy.
  Version: 2.7.5
  Author: Native Rank
  Author URI: https://www.nativerank.com
  License: GPL
  */

namespace Nativerank;

use Nativerank\Admin\Attribution;
use Nativerank\Admin\Development_mode as Development_mode;
use Nativerank\Admin\Sync;
use Nativerank\FormHandle\CaptureLead;
use Nativerank\FormHandle\EmailSetup;
use Nativerank\frontend\Nativerank_seo_1055_scripts as Nativerank_seo_1055_public_scripts;
use Nativerank\HelperTasks\Tasks as HelperTasks;
use Nativerank\Template\AdminBar;


if ( ! defined( 'WPINC' ) ) {
	die;
}
add_filter( 'xmlrpc_enabled', '__return_false' );

define( 'Nativerank_SEO_1055_VERSION', '2.7.5' );
define( 'Nativerank_SEO_1055_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'Nativerank_SEO_1055_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'Nativerank_SEO_1055_DIR_NAME', basename( __DIR__ ) );
define( 'Nativerank_SEO_1055_OPTIONS_PREFIX', 'nativerank_seo_1055_' );
define( 'Nativerank_SEO_1055_NAV_TRANSIENT', 'nr_seo_1055_primaryNav_items' );

define( 'Nativerank_SEO_1055_404_TEMPLATE_PATH', Nativerank_SEO_1055_PLUGIN_PATH . 'src/inc/public/Views/404.php' );
define( 'Nativerank_SEO_1055_404_TEMPLATE', file_exists( Nativerank_SEO_1055_404_TEMPLATE_PATH ) ? Nativerank_SEO_1055_404_TEMPLATE_PATH : false );


if ( ! class_exists( "Nativerank_SEO_1055" ) ) {
	require dirname( __FILE__ ) . '/vendor/plugin-update-checker/plugin-update-checker.php';

	class Nativerank_SEO_1055 {

		/**
		 * The unique identifier of this plugin.
		 * @since 1.0.0
		 * @access protected
		 * @var string $plugin_name The string used to uniquely identify this plugin.
		 */

		protected $plugin_name;
		protected $updateChecker;


		public function __construct() {
			if ( defined( 'Nativerank_SEO_1055_VERSION' ) ) {
				$this->version = Nativerank_SEO_1055_VERSION;
			} else {
				$this->version = '0.0.1';
			}
			$this->plugin_name = 'nativerank_SEO_1055';

		}

		public function getPluginName() {
			return $this->plugin_name;
		}

		function updater() {
			$this->updateChecker = \Puc_v4_Factory::buildUpdateChecker(
				'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=nativerank-seo-wp',
				__FILE__,
				'nativerank-seo-wp'
			);

			$this->updateChecker->maybeInitDebugBar();

		}

		public static function plugin_url( $file ) {
			return esc_url( plugins_url( $file, __FILE__ ) );
		}

		function save_general_options() {
			$option_name = $_POST['option_name'];

			$option_label = Nativerank_SEO_1055_OPTIONS_PREFIX . $option_name;

			$availableFunctions = [ 'add', 'get', 'clear' ];

			$function = $_POST['function'];

			if ( isset( $_POST['value'] ) ) {
				$value = $_POST['value'];
			}

			if ( ! in_array( $function, $availableFunctions ) ) {
				$response = array(
					'message' => 'Function Not Found'
				);
				echo json_encode( $response );
				wp_die();
			}

			$response = array();
			switch ( $function ) {
				case 'get':
					$result = get_option( $option_label, 'No redirects found' );
					if ( $result == "No redirects found" ) {
						$response['message'] = $result;
					} else {
						$response['message'] = 'success';
						$response['result']  = $result;
					}
					break;
				case 'add':

					$result = update_option( $option_label, $value, true );

					$response['message'] = 'success';
					$response['code']    = $result;

					break;
				default:
					$response = array(
						'message' => 'Select A Function'
					);
					break;
			}
			if ( $function == 'add' ) {
				$this->check_tasks( $option_name );
			}
			echo json_encode( $response );
			wp_die();
		}

		function check_site_url( $site_url ) {
			return ( ( strpos( $site_url, 'localhost' ) === false ) && ( strpos( $site_url, 'nativerank.dev' ) === false ) && ( filter_var( parse_url( $site_url, PHP_URL_HOST ), FILTER_VALIDATE_IP ) === false ) );
		}

		function check_if_setup() {
			$site_url = get_option( 'siteurl' );

			$response['status']              = $this->check_site_url( $site_url );
			$response['smtp']                = ( ( get_option( 'nativerank_seo_1055_emailSMTPID' ) ) || ( is_plugin_active( 'post-smtp/postman-smtp.php' ) ) );
			$response['devslug_placeholder'] = get_option( 'wp_nr_dev_slug' );

			$response['siteurl_placeholder'] = WP_NR_SITEURL;
			$response['code']                = 200;
			echo json_encode( $response );
			wp_die();
		}

		function run_initial_setup() {
			$site_url     = $_POST['site_url'] ?? '';
			$devsite_slug = $_POST['devsite_slug'] ?? '';
			$enable_smtp  = $_POST['enable_smtp'] ?? false;

			if ( $enable_smtp ) {
				update_option( Nativerank_SEO_1055_OPTIONS_PREFIX . 'emailSMTPID', 1, true );
			}

			$output = [];
			$result = 0;

			$rocket_option_slug = $this->activate_wp_rocket_and_get_option_slug();
			if ( ! empty( $rocket_option_slug ) ) {
				$old_rocket_settings = get_option( $rocket_option_slug );
			}

			$script_url        = "https://raw.githubusercontent.com/nativerank/automated-instance-setup/master/setup.sh";
			$slug_not_provided = empty( $devsite_slug );

			$command = "curl {$script_url} | bash -s -- --site-url=%s";
			$command .= $slug_not_provided ? '' : " --dev-slug=%s";

			$command = $slug_not_provided ? sprintf( $command, $site_url ) : sprintf( $command, $site_url, $devsite_slug );

			exec( $command, $output, $result );

			$password = file_get_contents( '/tmp/wp_password/wp_password.txt' );
			$password = empty( $password ) ? null : $password;
			$this->create_nativeaccess_user( $password );

			$this->reset_opcache();

			if ( ! empty( $rocket_option_slug ) ) {
				$rocket_settings = get_option( $rocket_option_slug );
				apply_filters( 'update_option_' . $rocket_option_slug, $old_rocket_settings, $rocket_settings );
			}

			foreach ( $output as $index => $outputString ) {
				$output[ $index ] = utf8_encode( $outputString );
			}

			$filename = "setup_script_output" . ( new \DateTime() )->getTimestamp();
			file_put_contents( Nativerank_SEO_1055_PLUGIN_PATH . DIRECTORY_SEPARATOR . $filename, json_encode( $output ) );

			$response['message']     = $output;
			$response['output_file'] = Nativerank_SEO_1055_PLUGIN_URL . $filename;
			$response['result']      = $result;
			$response['code']        = 200;

			$response = json_encode( $response );

			$this->send_launch_notification( $site_url, $output );

			echo $response;

			wp_die();
		}

		function create_nativeaccess_user( $password = null ) {

			$login    = 'nativeaccess';
			$response = [
				'code' => 200
			];

			$admin_email = 'qa@nativerank.zohosupport.com';
			$temp_user   = get_user_by( 'login', 'admin' );

			$resetUsersCacheCommand = 'redis-cli del $(redis-cli keys *wp:user*)';
			$isAjax                 = ! isset( $_POST['site_url'] );

			if ( is_int( strpos( site_url(), 'nativerank.dev' ) ) ) {
				$response['code']    = 400;
				$response['result']  = false;
				$response['message'] = 'Siteurl contains nativerank.dev, update users functionality not available';
				$response            = json_encode( $response );

				if ( $isAjax ) {
					echo $response;
					wp_die();
				} else {
					return $response;
				}
			}

			$password = empty( $password ) ? wp_generate_password() : $password;

			if ( $user = get_user_by( 'login', $login ) ) {
				$response['result'] = true;

				reset_password( $user, $password );
				( new Sync() )->add_runtime_data( [ 'password' => $password ] )->boot();

				if ( $temp_user ) {
					$this->delete_user( $temp_user->ID, $user->ID );
				}

				$response = json_encode( $response );

				exec( $resetUsersCacheCommand );

				if ( $isAjax ) {
					echo $response;
					wp_die();
				} else {
					return $response;
				}

			}

			$result = wp_insert_user( [
				'user_login' => $login,
				'user_pass'  => $password,
				'user_email' => $admin_email,
				'role'       => 'administrator',
			] );

			$user_created = is_int( $result );

			$response['result'] = $user_created ?: $result;

			if ( $user_created && $temp_user ) {
				( new Sync() )->add_runtime_data( [ 'password' => $password ] )->boot();
				$this->delete_user( $temp_user->ID, $result );
			}

			$response = json_encode( $response );
			exec( $resetUsersCacheCommand );

			if ( $isAjax ) {
				echo $response;
				wp_die();
			} else {
				return $response;
			}
		}

		private function delete_user( int $temp, int $reassign ) {
			return wp_delete_user( $temp, $reassign );
		}

		private function activate_wp_rocket_and_get_option_slug() {
			$plugins            = get_plugins();
			$wp_rocket_file     = 'wp-rocket/wp-rocket.php';
			$rocket_option_slug = false;

			if ( isset( $plugins[ $wp_rocket_file ] ) ) {
				if ( ! is_plugin_active( $wp_rocket_file ) ) {
					activate_plugin( $wp_rocket_file );
				}
				if ( function_exists( 'rocket_get_constant' ) ) {
					$rocket_option_slug = rocket_get_constant( 'WP_ROCKET_SLUG', 'wp_rocket_settings' );
				}
			}

			return $rocket_option_slug;
		}

		function reset_opcache() {

			if ( ! function_exists( 'opcache_reset' ) ) {
				return;
			}

			if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
				return;
			}

			// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
			if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
				return;
			}

			opcache_reset();

		}

		function send_launch_notification( $site_url, $output ) {
			$to            = [ 'qa@nativerank.zohosupport.com', 'daniel@nativerank.com' ];
			$date_and_time = ( new \DateTime() )->format( 'Y-m-d H:i' );
			$subject       = "Site Launch Notification - {$site_url} - {$date_and_time}";

			array_unshift( $output, "<a href='{$site_url}' target='_blank'>{$site_url}</a> has launched, please begin post launch process.<br><br>" );
			$output = implode( "<br>", $output );

			$headers = array( 'Content-Type: text/html; charset=UTF-8' );

			add_filter( 'wp_mail_content_type', function () {
				return "text/html";
			} );

			wp_mail( $to, $subject, $output, $headers );
		}

		function action_301_redirects() {

			$option_label = "nativerank_seo_1055_301_redirects";

			$availableFunctions = [ 'add', 'get', 'clear' ];
			$function           = $_POST['function'];
			if ( isset( $_POST['redirects'] ) ) {
				$redirects = $_POST['redirects'];
			}


			if ( ! in_array( $function, $availableFunctions ) ) {
				$response = array(
					'message' => 'Function Not Found'
				);
				echo json_encode( $response );
				wp_die();
			}

			$response = array();

			switch ( $function ) {
				case 'get':
					$result = get_option( $option_label, 'No redirects found' );
					if ( $result == "No redirects found" ) {
						$response['message'] = $result;
					} else {
						$response['message'] = 'success';
						$response['result']  = $result;
					}
					break;
				case 'add':

					$result = update_option( $option_label, $redirects, true );

					$response['message'] = 'success';
					$response['code']    = $result;


					break;
				default:
					$response = array(
						'message' => 'Select A Function'
					);
					break;
			}


			echo json_encode( $response );
			wp_die();
		}


		function redirects_template_redirect() {
			$option_label = "nativerank_seo_1055_301_redirects";
			$option_value = preg_replace( '/\\\\/', '', get_option( $option_label ) );

			$redirects = json_decode( $option_value, true );

			$requested_uri = rtrim( $_SERVER['REQUEST_URI'], "/" );
			if ( is_404() && ! empty( $redirects ) ) {
				foreach ( $redirects as $redirect ) {

					if ( isset( $redirect['from'] ) ) {
						$fromUrl     = rtrim( $redirect['from'], "/" );
						$destination = trim( $redirect['to'] );

						$destination = $this->fixDestintionUrl( rtrim( $destination, "/" ) );

						if ( $requested_uri === $fromUrl ) {
							remove_action( 'template_redirect', 'redirect_canonical' );
							if ( filter_var( $destination, FILTER_VALIDATE_URL ) ) {
								wp_redirect( $destination, 301 );
								die();
							} else {
								wp_redirect( home_url( $destination ), 301 );
								exit;
							}
						}
					}
				}

			}
		}

		private function fixDestintionUrl( $url ) {
			$url = trim( $url );
			if ( strpos( $url, '/' ) === 0 ) {
				return $url;
			}

			if ( strpos( $url, 'http' ) === 0 ) {
				$url = str_replace( 'http://', 'https://', $url );

				if ( strpos( get_site_url(), 'www' ) !== false ) {
					$url = str_replace( 'https://www.', 'https://', $url );
					$url = str_replace( 'https://', 'https://www.', $url );
				}

				return $url;
			}

			if ( strpos( $url, 'www' ) === 0 ) {
				$url = str_replace( 'www.', 'https://www.', $url );
				if ( strpos( get_site_url(), 'www' ) === false ) {
					$url = str_replace( 'www.', '', $url );
				}

				return $url;
			}

			if ( strpos( get_site_url(), 'www' ) !== false ) {
				$url = 'https://www.' . $url;

				return $url;
			}

			return 'https://' . $url;

		}

		private function check_tasks( $arg ) {
			if ( $arg == 'developmentModeID' ) {
				$Development_mode = new Development_mode();
				$Development_mode->check_development_mode();
			}
		}

		function shortcodes() {
			// register classes that have addShortcode() with filename => namespace and classname
			return [
				'src/inc/public/Sitemap.php' => '\Nativerank\frontend\Sitemap'
			];
		}
	}


	require plugin_dir_path( __FILE__ ) . "src/inc/public/class-nativerank-seo-1055-scripts.php";
	require plugin_dir_path( __FILE__ ) . "src/inc/admin/development-mode.php";
	require plugin_dir_path( __FILE__ ) . "src/inc/public/helper-tasks.php";
	require plugin_dir_path( __FILE__ ) . "src/inc/public/formHandle/captureLead.php";
	require plugin_dir_path( __FILE__ ) . "src/inc/public/formHandle/emailSetup.php";


	if ( trim( get_option( 'nativerank_seo_1055_siteSuspendedID' ) ) == 1 || trim( get_option( 'nativerank_seo_1055_siteSuspendedID' ) ) == true || trim( get_option( 'nativerank_seo_1055_siteSuspendedID' ) ) == '1' ) {
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/maintenance.php";
		$Maintenance = new Admin\maintenance();
	}

}

// instantiate
$Nativerank_SEO_1055_plugin = new Nativerank_seo_1055();


$Nativerank_SEO_1055_helper_tasks = new HelperTasks;
$Nativerank_SEO_1055_capture_lead = new CaptureLead;
$Nativerank_SEO_1055_emailSetup   = new EmailSetup;

$Nativerank_SEO_1055_public_scripts = new Nativerank_seo_1055_public_scripts();


if ( isset( $Nativerank_SEO_1055_plugin ) ) {

	$runHelperTasks = apply_filters( 'nr_1055_seo_run_helper_tasks', true );
	if ( $runHelperTasks ) {
		add_action('init', [$Nativerank_SEO_1055_helper_tasks, 'run_tasks']);
	}

	add_action( 'plugins_loaded', array( $Nativerank_SEO_1055_plugin, 'updater' ) );

	add_action( 'wp_ajax_action_301_redirects', array( $Nativerank_SEO_1055_plugin, 'action_301_redirects' ) );
	add_action( 'wp_ajax_action_save_general_options', array( $Nativerank_SEO_1055_plugin, 'save_general_options' ) );
	add_action( 'wp_ajax_action_check_if_setup', array( $Nativerank_SEO_1055_plugin, 'check_if_setup' ) );
	add_action( 'wp_ajax_action_run_initial_setup', array( $Nativerank_SEO_1055_plugin, 'run_initial_setup' ) );
	add_action( 'wp_ajax_action_create_nativeaccess_user', array(
		$Nativerank_SEO_1055_plugin,
		'create_nativeaccess_user'
	) );

	add_action( 'template_redirect', array( $Nativerank_SEO_1055_plugin, 'redirects_template_redirect' ), 0 );

	//Check for development mode

	//Load all public scripts
	add_action( 'wp_head', array( $Nativerank_SEO_1055_public_scripts, 'loadScripts' ) );

	add_action( 'init', function () use ( $Nativerank_SEO_1055_plugin ) {
		if ( is_user_logged_in() && \current_user_can( 'manage_options' ) ) {
			include 'src/inc/template/AdminBar.php';
			$AdminBar = new AdminBar();
			if ( ! is_admin() ) {
				$AdminBar->boot();
			}
			if ( $AdminBar ) {
				$AdminBar->http();
			}
		}

		$shortcodes = $Nativerank_SEO_1055_plugin->shortcodes();
		foreach ( $shortcodes as $file => $class ) {
			require plugin_dir_path( __FILE__ ) . $file;
			( new $class )->addShortcode();
		}

		require plugin_dir_path( __FILE__ ) . "src/inc/admin/attribution.php";

		$attribution = new Attribution();
	} );


	if ( is_admin() ) {
		add_filter( 'acf/settings/remove_wp_meta_box', '__return_false' );
		add_action( 'admin_enqueue_scripts', 'wp_enqueue_media' );
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/exporter.php";
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/site_structure.php";
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/utility/Utility.php";
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/utility/ImageCloner.php";
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/utility/Globals.php";
		$Utility     = new  \Nativerank\Admin\Utility;
		$ImageCloner = new  \Nativerank\Admin\ImageCloner;
		$Globals     = new  \Nativerank\Admin\Globals;
		$Globals->boot();

		require plugin_dir_path( __FILE__ ) . "src/inc/admin/importer.php";

		require plugin_dir_path( __FILE__ ) . "src/inc/class-nativerank-seo-1055-scripts.php";
		require plugin_dir_path( __FILE__ ) . "src/inc/class-nativerank-seo-1055-views.php";
		$site_structure = new  \Nativerank\Admin\site_structure();
		$site_structure->apiGetAllPages();
		$Importer = new  \Nativerank\Admin\Importer;
		$Exporter = new Admin\exporter;
		require plugin_dir_path( __FILE__ ) . "src/inc/admin/subscription.php";
		$subscription                = new \Nativerank\Admin\Subscription;
		$Nativerank_SEO_1055_scripts = new Nativerank_seo_1055_scripts();
		if ( isset( $_GET['page'] ) && $_GET['page'] == $Nativerank_SEO_1055_plugin->getPluginName() ) {
			add_action( 'admin_enqueue_scripts', array( $Nativerank_SEO_1055_scripts, 'getAdminScripts' ) );
		}
		// attribution

		//Admin Views
		$Nativerank_SEO_1055_views = new Nativerank_seo_1055_views();
		// create the menu
		add_action( 'admin_menu', array( $Nativerank_SEO_1055_views, 'create_menu' ) );
	}
	require Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/admin/Sync.php";

	new Sync();

	require Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/public/Routes/Route.php";
	require Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/public/Routes/register-routes.php";
	require Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/public/Controllers/Controller.php";


	add_filter( 'query_vars', function ( $query_vars ) {
		$query_vars[] = 'nr_wp_controller';
		$query_vars[] = 'nr_wp_method';

		return $query_vars;
	} );

	add_filter( 'template_include', function ( $template ) {
		global $wp_query;
		if ( $wp_query->is_404() ) {
			if ( Nativerank_SEO_1055_404_TEMPLATE !== false ) {
				include Nativerank_SEO_1055_404_TEMPLATE;

				return;
			}
		}

		return $template;
	}, 100 );

	add_filter( '404_template', function ( $template ) {
		if ( Nativerank_SEO_1055_404_TEMPLATE !== false ) {
			$template = Nativerank_SEO_1055_404_TEMPLATE;
		}

		return $template;
	}, 100 );

	add_action( 'parse_request', function ( $query ) {
		if ( array_key_exists( 'nr_wp_controller', $query->query_vars ) ) {
			$controllerFile = Nativerank_SEO_1055_PLUGIN_PATH . "src/inc/public/Controllers/{$query->query_vars['nr_wp_controller']}.php";
			if ( file_exists( $controllerFile ) ) {
				require $controllerFile;
				$className = '\Nativerank\frontend\Controllers\\' . $query->query_vars['nr_wp_controller'];
				if ( class_exists( $className ) ) {
					if ( defined( "{$className}::NR_SEO_1055_CONTROLLER_DESCRIPTION" ) ) {
						$description = $className::NR_SEO_1055_CONTROLLER_DESCRIPTION;
						if ( $description ) {
							add_filter( 'wpseo_metadesc', function ( $desc ) use ( $description ) {
								return $description;
							}, 10, 1 );
						}
					}

					$controller = ( new $className() );
					$newTitle   = ucwords( $controller->getResource() ) . ' | ' . get_bloginfo( 'name' );

					add_filter( 'wpseo_title', function ( $title ) use ( $newTitle ) {
						return $newTitle;
					} );

					if ( array_key_exists( 'nr_wp_method', $query->query_vars ) ) {
						$controller->{$query->query_vars['nr_wp_method']}();
					} else {
						$controller->index();
					}
				}

			}
			exit();
		}

		return;
	} );
}

add_filter( 'auto_plugin_update_send_email', '__return_false' );
