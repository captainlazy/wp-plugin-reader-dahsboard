=== Native Rank SEO ===
Contributors: nativerankweb
Tags: SEO, website, speed, optimization, XML sitemap, Google Search Console, Content analysis, Readability, Local SEO, Native Rank, Ranking
Requires at least: 4.9
Tested up to: 5.1
Stable tag: 4.3
Requires PHP: 5.2.4
License: GPL
License URI: https://www.gnu.org/licenses/gpl.html

Use the NativeRank SEO plugin to improve your SEO strategy.

== Description ==
1. License
All products are licensed under the GNU General Public License (GPL). Automatic updates are only available to customers with an active subscription. The number of websites which receive automatic updates is limited by the subscription type.



== Installation ==


== Frequently Asked Questions ==

= A question that someone might have =

== Screenshots ==

== Changelog ==


= 1.9.4 =
__FEATURES__
* Added sync features

= 1.9.4 =
__FEATURES__
* Featured Image bug fixed
* Added notification on image update

= 1.9 =
__FEATURES__
* Added Image Cloner
* Improvements

= 1.8.1 =
__FEATURES__
* Added Sitemap functionality

= 1.6.0 =
__FEATURES__
* Form Analytics

= 1.5.2 =
__FEATURES__
* Ability to edit data.json globals from the plugin

__FIX__
* Fixed the issue where cache purging was not working if jQuery was not loaded

= 1.5.0 =

__FEATURES__
* Added ability to clear template cache
* Shows Page id in Overview tab
* Shows Title Tags & Meta Descriptions in Overview tab
* Ability to edit template and page type from overview tab.
* Added Utility tab where images can be uploaded in bulk.

__FIXEs__
* Fixed the issue where Notifications were getting sent twice if SMTP is turned off



= 1.4.32 =

__FIXEs__
* Fixed edit page url from overview tab


= 1.4.31 =

__FIXEs__
* Fixed subscription issue where nothing was exporting

= 1.4.3 =

__FIXEs__
* Fixed nr_page_type not being printed
* Fixed content formatting by adding slashes to characters that need escaping


= 1.4.2 =

__FIXEs__
* Fixed 301 destination url adding www in the begining

__FEATURES__
* Show current page id and page template in admin bar.


= 1.3.13 =

__FIXEs__
* Fixed Structured data not saving if business type was not selected
* Fixed the issue where URL was not redirecting if destination URL did not have http:// at the beginning
* Fixed NRH1 not displaying when Digital Solution is turned off on some sites.

__FEATURES__
* Suspend monitor in Site24x7 when site is suspended
* Delete monitors in Site24x7 when Digital Solutions API is disabled
* Update the website monitoring field in CRM

= 1.3.13 =
*Fixed Vendor

= 1.3.1 =
*Bug Fixes

= 1.3.0 =
*New Structured Data Tool
*Ability to export site SEO
*Improved development mode

= 1.2.2 =
*Fixed bugs

= 1.2.1 =
*Toggling Development will also toggle No Index / No Follow

= 1.2.0 =
*Added Overview
*Ability to add featured images from the plugin
*Added SEO Tab with import ability
*Fixed Bugs

= 1.1.12 =
*Fixed Navbar error in structured data

= 1.1.1 =
*Added helper tasks

= 1.1.0 =
*Add GTM, Bing Tag & Structured Data right from the plugin
*Control Site Development mode from the plugin

= 1.0.3 =
* Minor Fixes

= 1.0.2 =
* Fixed an issue tht caused the 301s from working

= 1.0.1 =
* Automatic Updates

= 1.0.0 =
* 301 Redirection Added

== Upgrade Notice ==

= 1.0 =
* Redirect old pages to new URLs
