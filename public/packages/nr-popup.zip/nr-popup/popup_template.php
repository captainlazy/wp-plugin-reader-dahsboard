<?php if ( isset( $image ) && ! empty( $image ) ): ?>
    <div id="nr_1055_seo_popup" class="uk-modal">
        <div class="uk-modal-dialog popup-modal uk-background-muted uk-width-large uk-margin-auto-vertical">
            <div class="uk-margin-auto uk-text-center uk-padding-small">
                <button class="uk-modal-close-outside" type="button" uk-close></button>
                <div>
                    <img uk-img height="auto" max-width="100%" data-src="<?= $image ?>">
                </div>
            </div>
        </div>
    </div>

    <script defer>
        UIkit.util.ready(() => {
            showNotice();
        });

        function showNotice() {
            if (document.cookie.indexOf("nr_1055_seo_popup_shown=1") > -1) {
                return;
            } else {
                var exp = new Date();
                exp.setDate(exp.getDate() + 1);
                document.cookie = "nr_1055_seo_popup_shown=1; expires=" + exp + "; path=/";
                UIkit.modal("#nr_1055_seo_popup").show();
            }
        }
    </script>

<?php endif;
