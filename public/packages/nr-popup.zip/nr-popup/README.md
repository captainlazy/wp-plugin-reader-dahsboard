# nr-popup

Adds a popup to the NR Template engine.

Access in .hbs files with `{{ popup }}`