<?php

/*
Plugin Name: NR Popup
Description: Adds a popup to the NR Template engine
Version: 0.0.1
Author: mitchierichie
Author URI: https://nativerank.com/
*/

define( 'NR_POPUP_DIR_NAME', basename( __DIR__ ) );
define( 'NR_POPUP_PLUGIN_MAIN_FILE', __FILE__ );

define( 'NR_1055_SEO_POPUP_TEMPLATE_PATH', __DIR__ . "/popup_template.php" );
define( 'NR_1055_SEO_POPUP_SHORTCODE', 'nr_1055_seo_popup' );

if ( function_exists( 'acf_add_options_page' ) ) {
	acf_add_options_page( array(
		'page_title' => 'NR Popup',
		'menu_title' => 'NR Popup',
		'menu_slug'  => 'nr-popup'
	) );
}

if ( function_exists( 'acf_add_local_field_group' ) ) {
	acf_add_local_field_group( array(
		'key'                   => 'group_5fd7e89336bb8',
		'title'                 => 'NR Popup',
		'fields'                => array(
			array(
				'key'               => 'field_5fd7e8b22ce88',
				'label'             => 'Image',
				'name'              => 'nr_1055_seo_popup_image',
				'type'              => 'image',
				'instructions'      => '',
				'required'          => 1,
				'conditional_logic' => 0,
				'wrapper'           => array(
					'width' => '',
					'class' => '',
					'id'    => '',
				),
				'return_format'     => 'url',
				'preview_size'      => 'medium',
				'library'           => 'all',
				'min_width'         => '',
				'min_height'        => '',
				'min_size'          => '',
				'max_width'         => '',
				'max_height'        => '',
				'max_size'          => '',
				'mime_types'        => '',
			),
			array(
				'key'               => 'field_5fd7e93f2ca06',
				'label'             => 'Status',
				'name'              => 'nr_1055_seo_popup_status',
				'type'              => 'true_false',
				'instructions'      => '',
				'required'          => 0,
				'conditional_logic' => 0,
				'wrapper'           => array(
					'width' => '',
					'class' => '',
					'id'    => '',
				),
				'message'           => '',
				'default_value'     => 0,
				'ui'                => 1,
				'ui_on_text'        => 'Active',
				'ui_off_text'       => 'Inactive',
			),
		),
		'location'              => array(
			array(
				array(
					'param'    => 'options_page',
					'operator' => '==',
					'value'    => 'nr-popup',
				),
			),
		),
		'menu_order'            => 0,
		'position'              => 'normal',
		'style'                 => 'default',
		'label_placement'       => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen'        => '',
		'active'                => true,
		'description'           => '',
	) );
}

if ( ! function_exists( 'nr_1055_seo_popup_callback' ) ) {
	function nr_1055_seo_popup_callback( $atts = [], $content = null, $tag = '' ) {
		$image = get_field( 'nr_1055_seo_popup_image', 'option' );
		if ( $image ) {
			$status = get_field( 'nr_1055_seo_popup_status', 'option' );
			if ( $status ) {
				ob_start();
				include NR_1055_SEO_POPUP_TEMPLATE_PATH;

				return ob_get_clean();
			}
		}

		return $content;
	}
}

if ( function_exists( 'nr_1055_seo_popup_callback' ) ) {
	add_shortcode( NR_1055_SEO_POPUP_SHORTCODE, 'nr_1055_seo_popup_callback' );
}

add_action( 'init', function () {
	add_filter( 'nr_1055_template_data', function ( $data ) {
		$data['popup'] = do_shortcode( '[' . NR_1055_SEO_POPUP_SHORTCODE . ']' );

		return $data;
	} );
} );

add_action( 'plugins_loaded', function () {
	Puc_v4_Factory::buildUpdateChecker(
		'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_POPUP_DIR_NAME,
		NR_POPUP_PLUGIN_MAIN_FILE,
		NR_POPUP_DIR_NAME
	);
} );

