<?php


namespace nativerank\BioTEMediaArchive\Helpers;


class PermalinkStructure
{

    public function __construct()
    {

        add_action('init', [$this, 'custom_rewrite']);
        add_filter('post_type_link', [$this, 'custom_permalinks'], 10, 2);

    }

    function custom_rewrite()
    {

        add_permastruct('media', '/%customname%/', false);
    }

    function custom_permalinks($permalink, $post)
    {
        return str_replace('%customname%/', 'news-media/' . $post->post_name, $permalink);
    }

}
