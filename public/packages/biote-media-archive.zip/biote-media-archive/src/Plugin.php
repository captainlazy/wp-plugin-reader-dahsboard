<?php


namespace nativerank\BioTEMediaArchive;


use PostTypes\PostType;

class Plugin
{
    /**
     * The plugin context object.
     *
     * @var Context
     */
    private $context;

    /**
     * Main instance of the plugin.
     *
     * @var Plugin|null
     */
    private static $instance = null;

    /**
     * Sets the plugin main file.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     */
    public function __construct($main_file)
    {
        $this->context = new Context($main_file);
    }

    /**
     * Retrieves the plugin context object.
     *
     * @return Context Plugin context.
     */
    public function context()
    {
        return $this->context;
    }

    /**
     * Registers the plugin with WordPress.
     */
    public function register()
    {

        //Register Post Type `media`
        $media = (new PostType([
            'name' => 'media',
            'singular' => 'Media Article',
            'plural' => 'Media Articles',
            'slug' => 'media',
        ]))
            ->options([
                'has_archive' => true,
                'supports' => ['title', 'thumbnail', 'editor', 'excerpt', 'revisions'],
                'show_in_rest' => true
            ])
            ->icon('dashicons-book-alt')
            ->register();

        //Register Post Type `research`
        $media = (new PostType([
            'name' => 'research',
            'singular' => 'Research Article',
            'plural' => 'Research Articles',
            'slug' => 'research',
        ]))
            ->options([
                'has_archive' => true,
                'supports' => ['title', 'editor', 'excerpt', 'revisions'],
                'show_in_rest' => true
            ])
            ->icon('dashicons-book-alt')
            ->register();


    }


    /**
     * Retrieves the main instance of the plugin.
     *
     *
     * @return Plugin NR WP GALLERY instance.
     */
    public static function instance()
    {
        return static::$instance;
    }

    /**
     * Loads the plugin main instance and initializes it.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     * @return bool True if the plugin main instance could be loaded, false otherwise.
     */
    public static function load($main_file)
    {
        if (null !== static::$instance) {
            return false;
        }

        static::$instance = new static($main_file);

        // register plugin after plugin is activated
        static::$instance->register();
        return true;
    }

}
