<?php

/*
Plugin Name: Biote Media Archive
Plugin URI: https://nativernak.com
Description: A brief description of the Plugin.
Version: 0.0.2
Author: Native Rank
Author URI: https://natierank.com
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define most essential constants.
define('NATIVERANK_BIOTE_MEDIA_ARCHIVE_VERSION', '0.0.2');
define('NATIVERANK_BIOTE_MEDIA_ARCHIVE_PLUGIN_MAIN_FILE', __FILE__);
define('NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM', '7.2');
define('NATIVERANK_BIOTE_MEDIA_ARCHIVE_DIR_NAME', basename(__DIR__));

require_once __DIR__ . '/vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook(__FILE__, function () {
    if (version_compare(PHP_VERSION, NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM, '<')) {
        wp_die(
        /* translators: %s: version number */
            esc_html(sprintf(__('NR WP GALLERY requires PHP version %s', 'nr-biote-media-archive'), NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM)),
            esc_html__('Error Activating', 'nr-biote-media-archive')
        );
    }

    flush_rewrite_rules(true);

    do_action('nr_biote_media_archive_activation');

});

/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook(__FILE__, function ($network_wide) {
    if (version_compare(PHP_VERSION, NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM, '<')) {
        return;
    }

    do_action('nr_biote_media_archive_deactivation', $network_wide);
});

/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_biote_media_archive_opcache_reset()
{
    if (version_compare(PHP_VERSION, NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM, '<')) {
        return;
    }

    if (!function_exists('opcache_reset')) {
        return;
    }

    if (!empty(ini_get('opcache.restrict_api')) && strpos(__FILE__, ini_get('opcache.restrict_api')) !== 0) {
        return;
    }

    // `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
    if (defined('WPCOM_IS_VIP_ENV') && WPCOM_IS_VIP_ENV) {
        return;
    }

    opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action('plugins_loaded', function () {
    $updateChecker = Puc_v4_Factory::buildUpdateChecker(
        'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NATIVERANK_BIOTE_MEDIA_ARCHIVE_DIR_NAME,
        NATIVERANK_BIOTE_MEDIA_ARCHIVE_PLUGIN_MAIN_FILE,
        NATIVERANK_BIOTE_MEDIA_ARCHIVE_DIR_NAME
    );
});

add_action('upgrader_process_complete', 'nr_biote_media_archive_opcache_reset');

if (version_compare(PHP_VERSION, NATIVERANK_BIOTE_MEDIA_ARCHIVE_PHP_MINIMUM, '>=')) {

    \nativerank\BioTEMediaArchive\Plugin::load(NATIVERANK_BIOTE_MEDIA_ARCHIVE_PLUGIN_MAIN_FILE);

}
