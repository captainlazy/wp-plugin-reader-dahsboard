<?php


namespace Nativerank\Teams;


/**
 * Class Context
 * @package Nativerank\Teams
 */
class Context {

}
