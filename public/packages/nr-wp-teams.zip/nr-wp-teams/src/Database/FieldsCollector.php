<?php


namespace Nativerank\Teams\Database;


use App\Models\Member;
use App\Models\MemberCustomField;
use TypeRocket\Utility\Sanitize;
use function _\remove;

class FieldsCollector {

	private $fields = [];
	private $schema = [];
	private $cast = [];

	public function __construct() {
		$this->register();
	}

	private function register() {
		$this->fields = ( new MemberCustomField() )->get();

		if ( empty( $this->fields ) ) {
			return;
		}

		$this->fields = $this->fields->toArray();

		$this->removeDuplicateColumns();
		$this->prepareSchema();

		add_filter( 'nr_1055_teams_add_member_custom_fields', [ $this, 'getSchema' ] );
	}

	private function prepareSchema() {
		foreach ( $this->fields as $field ) {
			$name = Sanitize::underscore( $field['name'] );
			switch ( $field['type'] ) {
				case 'search':
				case 'file':
				case 'image':
					$this->schema[] = "{$name} BIGINT(20) DEFAULT NULL";
					break;
				case 'checkbox':
				case 'toggle':
					$this->schema[] = "{$name} BOOL";
					break;
				default:
					$this->schema[] = "{$name} TEXT DEFAULT NULL";
					break;
			}
		}
	}

	private function removeDuplicateColumns() {
		$firstMember = ( new Member() )->first();
		if ( empty( $firstMember ) ) {
			return;
		}

		$fields       = array_keys( $firstMember->getFormFields() );
		$customFields = $this->fields;
		remove( $customFields, function ( $field ) use ( $fields ) {
			return in_array( Sanitize::underscore( $field['name'] ), $fields );
		} );

		$this->fields = $customFields;
	}

	public function getSchema() {
		return $this->schema;
	}

}