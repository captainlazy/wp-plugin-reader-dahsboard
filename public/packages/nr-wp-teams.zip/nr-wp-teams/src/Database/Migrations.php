<?php


namespace Nativerank\Teams\Database;


use wpdb;

/**
 * Class Migrations
 * @package Nativerank\Teams\Database
 */
class Migrations {

	/**
	 * @var wpdb
	 */
	protected $db;

	/**
	 * @var string
	 */
	protected $charset_collate;

	/**
	 * @var string
	 */
	protected $db_prefix;

	/**
	 * Migrations constructor.
	 */
	public function __construct() {
		global $wpdb;

		$this->db              = $wpdb;
		$this->charset_collate = $wpdb->get_charset_collate();
		$this->db_prefix       = $wpdb->prefix;

		$this->register_all_DBs();
	}


	/**
	 * Register Tables
	 * @return array[] each set of arrays will contain [TableSchema function, TableName]
	 */
	private function register() {
		return [
			[ 'memberSchema', 'members' ],
			[ 'memberCustomFieldsSchema', 'members' ],
			[ 'memberCustomFieldsModelSchema', 'membercustomfields' ],
		];

	}

	/**
	 * @return string[]
	 */
	private function memberSchema() {
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'name VARCHAR(60) DEFAULT NULL',
			'title TEXT DEFAULT NULL',
			'photo BIGINT(20) DEFAULT NULL',
			'position BIGINT(20)',
			'bio TEXT DEFAULT NULL',
			'tags TEXT DEFAULT NULL',
			'status BOOL DEFAULT TRUE',
			'modified INT(11)',
			'created INT(11) DEFAULT \'00000000000\' NOT NULL',
			'UNIQUE KEY id (id)'
		];
	}

	/**
	 * @return string[]
	 */
	private function memberCustomFieldsModelSchema() {
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'name VARCHAR(60) NOT NULL',
			'type TEXT NOT NULL',
			'label TEXT',
			'modified INT(11)',
			'created INT(11) DEFAULT \'00000000000\' NOT NULL',
			'UNIQUE KEY id (id)'
		];
	}

	private function memberCustomFieldsSchema() {
		return apply_filters( 'nr_1055_teams_add_member_custom_fields', [] );
	}

	/**
	 *
	 * @param string[]|string $queries Optional. The query to run. Can be multiple queries
	 *                                 in an array, or a string of queries separated by
	 *                                 semicolons. Default empty string.
	 */
	private function dbDelta( $queries ) {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $queries );
	}

	// Register all DBs
	private function register_all_DBs() {
		foreach ( $this->register() as $db ) {
			$table_name = $this->db_prefix . $db[1];
			$tableCols  = $this->{$db[0]}();
			if ( empty( $tableCols ) ) {
				continue;
			}
			$tableCols = implode( ",\n", $tableCols );
			$sql       = sprintf( "CREATE TABLE `%s` ( %s ) %s;", $table_name, $tableCols, $this->charset_collate );
			$this->dbDelta( $sql );
		}

	}

}
