<?php


namespace Nativerank\Teams\Resources;


class MemberCustomField {
	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;


	public function __construct( $name = 'MemberCustomField' ) {
		$this->resource = tr_resource_pages( 'Teams Custom Field', 'Teams Custom Fields', [
			'position'   => 2,
			'capability' => 'edit_posts'
		], 'MemberCustomField' );

		return $this->resource;
	}
}