<?php


namespace Nativerank\Teams\Resources;


use App\Models\Member as MemberModel;

/**
 * Class Example
 * @package Nativerank\Teams\Resources
 */
class Member {

	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;


	public function __construct( $name = 'Member' ) {
		$this->resource = tr_resource_pages( 'Member', 'Teams', [
			'position'   => 2,
			'capability' => 'edit_posts'
		], 'Member' )->setIcon( 'users' );

		return $this->resource;
	}

	public static function all() {
		$members = ( new MemberModel() )->where( 'status', 1 )->get();
		$members = $members ? $members->toArray() : [];
		usort( $members, function ( $a, $b ) {
			if ( $a['position'] === $b['position'] ) {
				return 0;
			}

			return $a['position'] < $b['position'] ? - 1 : 1;
		} );

		return apply_filters( 'nr_1055_teams_filter_members', $members );
	}

	public static function tags() {
		$members = ( new MemberModel() )->select( 'tags' )->get();
		$members = $members ? $members->toArray() : [];
		$tags    = [];
		foreach ( $members as $member ) {
			if ( $member['tags'] ) {
				$tags = array_merge( $tags, $member['tags'] );
			}
		}
		$tags = array_unique( $tags );

		return apply_filters( 'nr_1055_teams_filter_tags', $tags );
	}


}
