<?php


namespace Nativerank\Teams;


use Nativerank\Teams\Core\Custom_Resource;
use Nativerank\Teams\Core\Shortcodes\TeamsPage;
use Nativerank\Teams\Resources\Member;
use Nativerank\Teams\Resources\MemberCustomField;
use Puc_v4_Factory;
use TypeRocket\Register\PostType;
use TypeRocket\Register\Resourceful;
use TypeRocket\Register\Taxonomy;


/**
 * Class Plugin
 * @package Nativerank\Teams
 */
class Plugin {

	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 */
	public function __construct( $main_file ) {
		$this->context = new Context( $main_file );
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context() {
		return $this->context;
	}

	/**
	 * Registers the plugin with WordPress.
	 */
	public function register() {

		// Register CTP & CTT
		$this->customPostTypes();

		// Register Custom Resources
		$this->resources();

		$this->shortcodes();

		do_action( 'nr_teams_init' );
	}

	/**
	 * Register Custom Post Types and Taxonomies
	 * @return PostType[]|Taxonomy[]
	 */
	public function customPostTypes() {
		return [
//            Custom_Post_Type::make('Example')
		];
	}

	/**
	 * @return Resourceful[]
	 */
	public function resources() {
		return [
			( new Member() ),
			( new MemberCustomField() )
		];
	}

	/**
	 * @return Shortcode[]
	 */
	public function shortcodes() {
		return [
			new TeamsPage(),
		];
	}

	public function add_hooks() {
		add_action( 'nr_1055_teams_all_members', function () {
			return Member::all();
		} );

		add_action( 'nr_1055_teams_all_tags', function () {
			return Member::tags();
		} );
	}

	public function update_checker() {
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_TEAMS_DIR_NAME,
			NR_TEAMS_PLUGIN_MAIN_FILE,
			NR_TEAMS_DIR_NAME
		);
	}


	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR Teams instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load( $main_file ) {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static( $main_file );

		// register plugin after typerocket is loaded
		add_action( 'typerocket_loaded', [ static::$instance, 'register' ] );
		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ] );

		add_action( 'plugins_loaded', [ static::$instance, 'add_hooks' ] );

		return true;
	}

}
