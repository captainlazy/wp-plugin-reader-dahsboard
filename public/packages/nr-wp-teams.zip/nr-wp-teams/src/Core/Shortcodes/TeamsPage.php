<?php


namespace Nativerank\Teams\Core\Shortcodes;


use Nativerank\Teams\Core\Util\Shortcode;
use Nativerank\Teams\Resources\Member;

class TeamsPage extends Shortcode {

	protected $name = 'nr_teams_page';

	public function callback() {
		$members = Member::all();
		$tags    = Member::tags();

		$view = tr_view( 'members.index', [ 'members' => $members, 'tags' => $tags ] );

		ob_start();

		$view::load();

		return ob_get_clean();
	}

}