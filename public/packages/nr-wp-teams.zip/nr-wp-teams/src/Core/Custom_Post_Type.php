<?php

namespace Nativerank\Teams\Core;


use Nativerank\Teams\Core\Util\CPT;

/**
 * Class Custom_Post_Type
 */
class Custom_Post_Type extends CPT
{


}
