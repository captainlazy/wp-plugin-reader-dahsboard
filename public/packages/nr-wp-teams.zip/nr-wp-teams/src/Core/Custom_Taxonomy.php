<?php

namespace Nativerank\Teams\Core;


use Nativerank\Teams\Core\Util\CTT;

/**
 * Class Custom_Taxonomy
 */
class Custom_Taxonomy extends CTT
{


}
