# nr-wp-plugin-boilerplate
Boilerplate Wordpress plugin in [Typerocket framework](https://typerocket.com/docs/v4)

To initialize a plugin, navigate to your Wordpress plugins directory in the command line.

Clone this repository:

```bash
git clone REPO-URL PLUGIN-FOLDER-NAME
```

Once the repo is cloned, `cd` into the folder and run this command:

```bash
php nr-plugin-init.php [PLUGIN-NAME]
```
The PLUGIN-NAME argument is in square brackets because it is optional, if you leave it off, it will prompt you for a name. 

Once the script is done, if there are no problems, your plugin is ready to develop, and should be safe to activate on your Wordpress installation.

_Note:_

All plugins created by this tool will prefix the provided name with NR, no need to include this name prefix when running the initialize script.
