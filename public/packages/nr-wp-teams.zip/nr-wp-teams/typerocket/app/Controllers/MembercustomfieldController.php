<?php

namespace App\Controllers;

use App\Models\Member;
use App\Models\MemberCustomField;
use TypeRocket\Controllers\Controller;
use TypeRocket\Utility\Sanitize;

class MembercustomfieldController extends Controller {

	protected $modelClass = MemberCustomField::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
		return tr_view( 'member_custom_fields.index' );
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add() {
		$form = tr_form( 'membercustomfield', 'create' );

		return tr_view( 'member_custom_fields.add', [ 'form' => $form ] );
		//NOTE: Save the data we pass over from the view using the create() method.
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @return mixed
	 */
	public function create() {
		$field = new $this->modelClass;
		if ( empty( $request ) ) {
			$request = $this->request->getFields();
		}

		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Field Name is Required!', 'warning' );
		}

		if ( empty( $request['type'] ) ) {
			return $this->response->flashNext( 'ERROR: Field Type is Required!', 'warning' );
		}


		$existing_field = $this->checkForExistingField( $request['name'] );

		if ( $existing_field ) {
			return $this->response->flashNext( 'ERROR: Field Name Already in Use!', 'warning' );
		}

		$field = $this->updateFields( $field, $request );
		$field->save();

		$this->refreshDatabase();

		return $this->response->flashNext( 'Member field added!' )->setRedirect( tr_redirect()->toPage( 'membercustomfield', 'index' )->url );
	}

	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit( $id ) {
		$form = tr_form( 'membercustomfield', 'update', $id );

		return tr_view( 'member_custom_fields.edit', [ 'form' => $form ] );

	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param MemberCustomField $field
	 *
	 * @return mixed
	 */
	public function update( $id, MemberCustomField $field ) {
		$request = $this->request->getFields();

		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Field Name is Required!', 'warning' );
		}

		$existing_field = $this->checkForExistingField( $request['name'], $field->id );

		if ( $existing_field ) {
			return $this->response->flashNext( 'ERROR: Field Name Already in Use!', 'warning' );
		}

		// Update modified time
		$request['modified'] = ( new \DateTime() )->getTimestamp();

		$field = $this->updateFields( $field, $request );

		$field->save();

		$this->refreshDatabase();

		$this->response->flashNext( 'Member field updated!' );

		return tr_redirect()->toPage( 'membercustomfield', 'edit', $id );
	}

	/**
	 * @param MemberCustomField $field
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return MemberCustomField
	 */
	public function updateFields( MemberCustomField $field, $request = [] ) {

		foreach ( $request as $fieldLabel => $fieldValue ) {
			$field->{$fieldLabel} = $fieldValue;
		}

		return $field;
	}

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show( $id ) {
		// TODO: Implement show() method.
	}

	/**
	 * The delete page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function delete( $id ) {
		$form = tr_form( 'membercustomfield', 'destroy', $id );

		return tr_view( 'member_custom_fields.delete', [ 'form' => $form ] );
	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function destroy( $id ) {
		$field  = new $this->modelClass;
		$delete = $this->request->getFields( 'delete_custom_field' );

		if ( $delete == '1' ) {
			$field->findOrDie( $id );

			$this->dropColumn( $field->name );

			$field->delete();

			$this->response->flashNext( 'Field deleted!', 'warning' );

			return tr_redirect()->toPage( 'membercustomfield', 'index' );
		} else {
			$this->response->flashNext( 'Unable to delete Field!', 'error' );

			return tr_redirect()->toPage( 'membercustomfield', 'delete', $id );
		}
	}

	/**
	 * @param $name
	 */
	private function dropColumn( $name ) {
		global $wpdb;

		$table = $wpdb->prefix . 'members';
		$name  = Sanitize::underscore( $name );

		$sql = "ALTER TABLE {$table} DROP {$name}";

		$wpdb->get_results( $sql );
	}

	private function checkForExistingField( $name, $id = false ) {
		$existing_field = ( new $this->modelClass )->where( 'name', $name );
		if ( $id !== false && is_int( $id ) ) {
			$existing_field = $existing_field->where( 'id', '!=', $id );
		}
		$existing_field = (int) $existing_field->findAll()->count();
		if ( ! $existing_field && $id === false ) {
			$firstMember = ( new Member() )->first();
			if ( $firstMember ) {
				$formFields     = $firstMember->getFormFields();
				$fieldNames     = array_keys( $formFields );
				$existing_field = in_array( Sanitize::underscore( $name ), $fieldNames );
			}
		}

		return $existing_field;
	}

	private function refreshDatabase() {
		// create schema
		( new \Nativerank\Teams\Database\FieldsCollector() );

		//update DB Tables
		( new \Nativerank\Teams\Database\Migrations() );
	}

}