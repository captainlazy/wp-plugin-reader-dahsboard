<?php

namespace App\Controllers;

use App\Models\Member;
use App\Models\MemberCustomField;
use TypeRocket\Controllers\Controller;
use TypeRocket\Utility\Sanitize;


class MemberController extends Controller {

	protected $modelClass = Member::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
		return tr_view( 'members.index' );
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add() {
		$form = tr_form( 'member', 'create' );

		return tr_view( 'members.add', [ 'form' => $form ] );
		//NOTE: Save the data we pass over from the view using the create() method.
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function create( $request = [] ) {
		$member = new Member;
		if ( empty( $request ) ) {
			$request = $this->request->getFields();
		}
		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Member Name is Required!', 'warning' );
		}

		$existing_member = (int) ( new Member() )->where( 'name', $request['name'] )->findAll()->count();
		if ( $existing_member ) {
			return $this->response->flashNext( 'ERROR: Member Already Exists!', 'warning' );
		}

		$member = $this->updateFields( $member, $request );
		$member->save();

		return $this->response->flashNext( 'Member added!' )->setRedirect( tr_redirect()->toPage( 'member', 'index' )->url );

	}

	/**
	 * @param Member $member
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return Member
	 */
	public function updateFields( Member $member, $request = [] ) {

		$request = $this->checkForEmptyMultiSelectFields( $request );

		foreach ( $request as $fieldLabel => $fieldValue ) {
			$member->{$fieldLabel} = $fieldValue;
		}

		return $member;
	}


	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit( $id ) {
		$form = tr_form( 'member', 'update', $id );

		return tr_view( 'members.edit', [ 'form' => $form ] );
	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param Member $member
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function update( $id, Member $member ) {
		$request = $this->request->getFields();

		// Update modified time
		$request['modified'] = ( new \DateTime() )->getTimestamp();

		$member = $this->updateFields( $member, $request );

		$member->save();
		$this->response->flashNext( 'Member updated!' );

		return tr_redirect()->toPage( 'member', 'edit', $id );
	}

	private function checkForEmptyMultiSelectFields( $request = [] ) {
		if ( ! isset( $request['tags'] ) ) {
			$request['tags'] = [];
		}

		$fields = ( new MemberCustomField() )->get();
		foreach ( $fields as $field ) {
			if ( $field->type === 'select-multiple' ) {
				$name = Sanitize::underscore( $field->name );
				if ( ! isset( $request[ $name ] ) ) {
					$request[ $name ] = [];
				}
			}
		}

		return $request;
	}

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show( $id ) {
		// TODO: Implement show() method.
	}

	/**
	 * The delete page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function delete( $id ) {
		$form = tr_form( 'member', 'destroy', $id );

		return tr_view( 'members.delete', [ 'form' => $form ] );
	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function destroy( $id ) {
		$member = new Member();
		$delete = $this->request->getFields( 'delete_member' );

		if ( $delete == '1' ) {
			$member->findOrDie( $id );
			$member->delete();
			$this->response->flashNext( 'Member deleted!', 'warning' );

			return tr_redirect()->toPage( 'member', 'index' );
		} else {
			$this->response->flashNext( 'Unable to delete Member!', 'error' );

			return tr_redirect()->toPage( 'member', 'delete', $id );
		}
	}

	/**
	 *
	 */
	public function updateOrder() {
		$members = $this->request->getDataPost()['members'];
		if ( empty( $members ) ) {
			return;
		}
		$members = json_decode( $members );
		foreach ( $members as $order => $id ) {
			if ( is_int( $id ) ) {
				$member = ( new Member() )->find( $id );
				if ( $member && is_int( $order ) ) {
					$member->position = $order;
					$member->save();
				}
			}
		}

		return $this->response->flashNow( 'Members order updated!', 'success' );
	}


}
