<?php

namespace App\Models;

use TypeRocket\Models\Model;
use TypeRocket\Utility\Sanitize;

class Member extends Model {
	protected $resource = 'members';

	protected $cast = [
		'id'       => 'int',
		'tags'     => 'array',
		'modified' => 'int',
		'created'  => 'int',
	];

	protected $format = [
	];

	public function __construct() {
		$this->addCustomCast();
		
		parent::__construct();
	}

	private function addCustomCast() {
		$fields = ( new MemberCustomField() )->get();

		if ( empty( $fields ) ) {
			return;
		}

		$fields = $fields->toArray();

		foreach ( $fields as $field ) {
			$name = Sanitize::underscore( $field['name'] );
			switch ( $field['type'] ) {
				case 'links':
				case 'items':
				case 'gallery':
				case 'select-multiple':
					$this->cast[ $name ] = 'array';
					break;
				case 'search':
				case 'file':
				case 'image':
					$this->cast[ $name ] = 'int';
					break;
			}
		}
	}
}
