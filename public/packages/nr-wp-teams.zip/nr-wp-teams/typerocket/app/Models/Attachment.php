<?php
namespace App\Models;

use TypeRocket\Models\WPAttachment;

class Attachment extends WPAttachment
{
}