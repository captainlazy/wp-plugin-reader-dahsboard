<?php

namespace App\Models;

use TypeRocket\Models\Model;

class MemberCustomField extends Model {
	protected $resource = 'membercustomfields';
}