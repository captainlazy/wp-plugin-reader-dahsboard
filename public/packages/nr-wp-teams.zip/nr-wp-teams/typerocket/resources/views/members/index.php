<?php

foreach ( $members as $member ) {
	echo '<p>';
	echo $member['name'] . '<br>';
	echo $member['title'];
	echo '</p>';
}