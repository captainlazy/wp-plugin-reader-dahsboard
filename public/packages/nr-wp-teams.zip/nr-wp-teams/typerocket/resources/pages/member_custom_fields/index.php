<?php

$table = tr_tables()->setOrder( 'name', 'asc' );
$table->setSearchColumns( [
	'name'       => 'Name',
	'field_type' => 'Field Type',
] );
$table->setColumns( 'name', [
	'name'     => [
		'sort'        => true,
		'label'       => 'Name',
		'delete_ajax' => false,
		'actions'     => [ 'edit', 'delete' ]
	],
	'type'     => [
		'sort'  => true,
		'label' => 'Type'
	],
	'modified' => [
		'sort'     => true,
		'label'    => 'Last Modified',
		'callback' => function ( $timestamp ) {
			return '<div title ="' . ( new DateTime( "@$timestamp" ) )->format( 'F j, Y, g:i a' ) . '">' . ( new DateTime( "@$timestamp" ) )->format( 'M j, g:i a' ) . '</div>';
		}
	],

] );
$table->render();

echo "<style>.tr-list-table tbody td{vertical-align: middle}</style>";
