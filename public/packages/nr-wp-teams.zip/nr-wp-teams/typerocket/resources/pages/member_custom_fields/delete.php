<?php
echo $form->open();
echo $form->checkbox( 'Delete Custom Field' )->setText( "I'm sure I want to delete this field" );
echo $form->submit( 'Delete' );
echo $form->close();
