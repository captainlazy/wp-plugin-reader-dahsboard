<?php

$tabs = tr_tabs();

$form->useAjax();
echo $form->open();


$tabs->addTab( 'Custom Field', function () use ( $form ) {
	echo $form->row(
		$form->column(
			$form->text( 'Name' )->required(),
			$form->text( 'Label' )->setHelp( 'Optional, will replace name in the form front-end' ),
			$form->hidden( 'Created' )->setLabel( 'Custom Field Added' )->setAttribute( 'readonly', 'readonly' )->setDefault( ( new DateTime() )->getTimestamp() )
		),
		$form->column(
			$form->select( 'Type' )->setOptions( NR_TEAMS_FIELD_TYPES ),
			$form->hidden( 'Modified' )->setLabel( 'Custom Field Modified' )->setAttribute( 'readonly', 'readonly' )->setDefault( ( new DateTime() )->getTimestamp() )
		)
	);
} );

$tabs->setSidebar( function () use ( $form ) {
	echo $form->submit( 'Add Custom Field' );
} );

$tabs->render( 'box' );


echo $form->close();