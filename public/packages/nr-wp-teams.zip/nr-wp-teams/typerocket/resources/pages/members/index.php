<?php

$table = tr_tables()->setOrder( 'position', 'ASC' )->setLimit( 1000 );
$table->setSearchColumns( [
	'name'  => 'Name',
	'title' => 'Title',
	'id'    => 'ID'
] );
$table->setColumns(
	'id', [
	'id'       => [
		'sort'  => true,
		'label' => 'ID'
	],
	'name'     => [
		'sort'        => true,
		'label'       => 'Name',
		'delete_ajax' => false,
		'actions'     => [ 'edit', 'delete' ]
	],
	'title'    => [
		'sort'  => true,
		'label' => 'Title'
	],
	'modified' => [
		'sort'     => true,
		'label'    => 'Last Modified',
		'callback' => function ( $timestamp ) {
			return '<div class="modified_column" title ="' . ( new DateTime( "@$timestamp" ) )->format( 'F j, Y, g:i a' ) . '">' . ( new DateTime( "@$timestamp" ) )->format( 'M j, g:i a' )
			       . '</div>';
		}
	],

] );
$table->render();

echo "<style>.tr-list-table tbody td{vertical-align: middle}</style>";

$send_form = tr_form()->useAjax()->useUrl( 'PUT', 'update_members_order' );
echo $send_form->open( [ 'id' => 'members_order_form' ] );
echo $send_form->close();
?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/themes/base/jquery-ui.min.css"
      integrity="sha256-sEGfrwMkIjbgTBwGLVK38BG/XwIiNC/EAG9Rzsfda6A=" crossorigin="anonymous"/>
<script src="https://ik.imagekit.io/busgktl78f/jquery-ui.min_qZKdVskoD.js" crossorigin="anonymous"></script>
<style>
    .disable-click {
        pointer-events: none;
    }

    tr.manage-column:first-child .sort-to-top {
        display: none;
        pointer-events: none;
    }
</style>

<script>
    jQuery(document).ready(function ($) {
        $(".alignleft.actions").last().after("<div class='alignleft'><a id='sort-button' title='Change the order of team members on the front end' class='button button-primary'>Change Order</a></div>")
        let sort_button = $("#sort-button")
        let column_sort_buttons = $("thead .manage-column a, tfoot .manage-column a, .row-actions")
        let table_links = $("table .manage-column a")

        let teamMembersSortable = $("tbody.the-list")
        let memberOrderForm = $("#members_order_form")
        let sorting = false;
        sort_button.click(function () {
            if (sorting === false) {
                column_sort_buttons.hide()
                table_links.addClass('disable-click')

                sorting = true;
                sort_button.hide()

                teamMembersSortable.sortable({
                    axis: "y",
                    cursor: "grab",
                    handle: ".sort-handle",

                })

                sort_button.after("<a id='save-sort' style='margin-left: 5px' class='button button-primary'>Save</a>")
                let save_sort = $("#save-sort")

                save_sort.after('<svg id="stop-sort" style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="currentColor" d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z" /></svg>')

                $(".modified_column").append('<span style="position: absolute; right: 90px;cursor: grab!important;" class="sort-handle"><svg style="width:24px;" viewBox="0 0 24 24"><path fill="currentColor" d="M13,11H18L16.5,9.5L17.92,8.08L21.84,12L17.92,15.92L16.5,14.5L18,13H13V18L14.5,16.5L15.92,17.92L12,21.84L8.08,17.92L9.5,16.5L11,18V13H6L7.5,14.5L6.08,15.92L2.16,12L6.08,8.08L7.5,9.5L6,11H11V6L9.5,7.5L8.08,6.08L12,2.16L15.92,6.08L14.5,7.5L13,6V11Z" /></svg></span>')
                $(".modified_column").append('<span style = "position: absolute; right: 50px;" class="sort-to-top"><svg style="width:24px;height:24px" viewBox="0 0 24 24"><path fill="currentColor" d="M8,11H11V21H13V11H16L12,7L8,11M4,3V5H20V3H4Z" /></svg></span>')

                $(".sort-to-top").click(function () {
                    let row = $(this).parent().parent().parent()
                    $(row).insertBefore($("tbody.the-list tr.manage-column:eq(0)"))
                })

                $("#stop-sort").click(function () {
                    location.reload();
                })

                save_sort.click(function () {
                    $("#stop-sort").remove()
                    $(".sort-handle").remove()
                    save_sort.remove()

                    let list = teamMembersSortable.sortable("toArray")

                    list = lodash.map(list, item => lodash.toInteger(lodash.last(item.split("-"))))
                    list = JSON.stringify(list)

                    memberOrderForm.append(`<input type="hidden" name="members" value="${list}">`)
                    memberOrderForm.submit()

                    teamMembersSortable.sortable("destroy")
                    column_sort_buttons.show()
                    table_links.removeClass('disable-click')

                    sorting = false
                    sort_button.show()
                })
            }
        })
    })
</script>