<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<?php

use App\Models\Member;
use App\Models\MemberCustomField;
use TypeRocket\Utility\Sanitize;
use function _\map;
use function _\remove;


$members = ( new Member() )->select( 'tags' )->get();
$members = $members ? $members->toArray() : [];

$tags = [];
foreach ( $members as $member ) {
	if ( $member['tags'] ) {
		$tags = array_merge( $tags, $member['tags'] );
	}
}
$tags = array_unique( $tags );

$tabs = tr_tabs();

$form->useAjax()->setDebugStatus( false );
echo $form->open();

$firstMember    = ( new Member() )->first();
$existingFields = [];
if ( $firstMember ) {
	$existingFields = array_keys( $firstMember->getFormFields() );
}

$customFields       = [];
$customFieldObjects = ( new MemberCustomField() )->get();

if ( $customFieldObjects ) {
	$customFields = $customFieldObjects->toArray();
	if ( ! empty( $firstMember ) ) {
		remove( $customFields, function ( $field ) use ( $existingFields ) {
			return ! in_array( Sanitize::underscore( $field['name'] ), $existingFields );
		} );
	}

	$customFields = map( $customFields, function ( $field ) use ( $form ) {
		$type_function = $field['type'];
		$name          = $field['name'];
		switch ( $field['type'] ) {
			case 'select-multiple':
				$type_function = 'select';
				break;
		}
		$fieldObject = $form->$type_function( $name );
		if ( is_callable( [ $fieldObject, 'setLabel' ] ) && isset( $field['label'] ) ) {
			$fieldObject->setLabel( $field['label'] );
		}

		switch ( $field['type'] ) {
			case 'select-multiple':
				$fieldObject->multiple()->setAttribute( 'class', 'multiple-select' );
				$name             = Sanitize::underscore( $name );
				$membersWithField = ( new Member() )->select( $name )->get();
				$values           = [];
				foreach ( $membersWithField as $member ) {
					if ( $member->$name ) {
						$values = array_merge( $values, $member->$name );
					}
				}
				$values = array_unique( $values );
				foreach ( $values as $index => $value ) {
					$fieldObject->setOption( $value, $value );
				}
				break;
		}

		return $fieldObject;
	} );

}

$tagSelect = $form->select( 'Tags' )->multiple()->setAttribute( 'class', 'multiple-select' );
foreach ( $tags as $index => $tag ) {
	$tagSelect->setOption( $tag, $tag );
}
$tabs->addTab( 'Member Info', function () use ( $form, $tagSelect, $customFields ) {
	echo $form->row(
		$form->column(
			$form->text( 'Name' )->required(),
			$form->text( 'Title' ),
			$form->image( 'Photo' ),
			$form->text( 'Position' )->setLabel( 'Order' )->setType( 'number' )->setAttribute( 'value', 0 ),
			$tagSelect
		),
		$form->column(
			$form->hidden( 'Created' )->setLabel( 'Member Added' )->setAttribute( 'readonly', 'readonly' )->setDefault( ( new DateTime() )->getTimestamp() ),
			$form->hidden( 'Modified' )->setLabel( 'Member Modified' )->setAttribute( 'readonly', 'readonly' )->setDefault( ( new DateTime() )->getTimestamp() ),
			$form->editor( 'Bio' )
		)
	);
	if ( ! empty( $customFields ) ) {
		echo $form->row(
			$form->column( $customFields )
		);
	}
} );

$tabs->setSidebar( function () use ( $form ) {
	echo $form->submit( 'Add Member' );
	echo $form->toggle( 'Status' )->setDefault( true );
} );
?>
<script>
    (function ($) {
        $(document).ready(function () {
            $('.multiple-select').select2({
                tags: true,
                placeholder: 'Select or add a new tag'
            });
        });
    })(jQuery)
</script>
<?php

$tabs->render( 'box' );


echo $form->close();
