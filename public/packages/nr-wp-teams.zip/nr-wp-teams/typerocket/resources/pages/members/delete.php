<?php
echo $form->open();
echo $form->checkbox('Delete Member')->setText("I'm sure I want to delete this member");
echo $form->submit('Delete');
echo $form->close();
