let mix = require('laravel-mix');


mix.ts('src/main.ts', 'public/js/marine-manager-analytics-public.js')
