<?php

/**
 * Fired during plugin activation
 *
 * @link       https://nativerank.com
 * @since      1.0.0
 *
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 * @author     Sahil Khanna <sahil.khanna@nativerank.com>
 */
class Marine_Manager_Analytics_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
