<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://nativerank.com
 * @since      1.0.0
 *
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 */

/**
 *
 * @since      1.0.0
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 * @author     Sahil Khanna <sahil.khanna@nativerank.com>
 */
class Marine_Manager_Analytics_updater {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function check_for_updates() {

		require MARINE_MANAGER_ANALYTICS_DIR_PATH . 'third-party/plugin-update-checker/plugin-update-checker.php';

		Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . MARINE_MANAGER_ANALYTICS_DIR_NAME,
			MARINE_MANAGER_ANALYTICS_MAIN_FILE,
			MARINE_MANAGER_ANALYTICS_DIR_NAME
		);
	}


}
