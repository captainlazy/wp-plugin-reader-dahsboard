<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://nativerank.com
 * @since      1.0.0
 *
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Marine_Manager_Analytics
 * @subpackage Marine_Manager_Analytics/includes
 * @author     Sahil Khanna <sahil.khanna@nativerank.com>
 */
class Marine_Manager_Analytics_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'marine-manager-analytics',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
