<?php

use Illuminate\Support\Str;
use Nativerank\Resources\Core\BaseResource\BaseResource;
use Nativerank\Resources\Core\Resource\Field\BaseFieldsCreator;

if ( ! function_exists( 'nr_1055_get_resources' ) ) {
	function nr_1055_get_resources( $resource, $arguments = [] ) {
		return BaseResource::indexQuery( $resource, $arguments );
	}
}


if ( ! function_exists( 'nr_1055_add_resource_fields' ) ) {
	function nr_1055_add_resource_fields() {
		$defaultFields = [
			'Text'   => [
				'component' => 'input',
				'type'      => 'text',
			],
			'Number' => [
				'component' => 'input',
				'type'      => 'number',
			],
			'Email'  => [
				'component' => 'input',
				'type'      => 'email',
			],
			'Date'   => [
				'component' => 'input',
				'type'      => 'date',
			],
			'Editor' => [
				'component' => 'editor',
			],
			'Image'  => [
				'component' => 'image',
			],
		];

		foreach ( $defaultFields as $name => $field ) {
			$slug          = Str::snake( Str::studly( $name ) );
			$fieldPostType = 'nr_resource_field';
			$arguments     = [
				'post_type'   => $fieldPostType,
				'post_status' => 'publish',
				'post_title'  => $name,
				'post_name'   => $slug,
				'meta_input'  => [
					'_nr_resource_field' => $field,
				],
			];
			$post          = get_page_by_path( $slug, OBJECT, $fieldPostType );
			if ( $post instanceof \WP_Post ) {
				$arguments['ID'] = $post->ID;
				wp_update_post( $arguments );
				continue;
			}

			wp_insert_post( $arguments );
		}
	}
}

if ( ! function_exists( 'nr_1055_value_is_json' ) ) {

	function nr_1055_value_is_json( $value ) {
		json_decode( $value );

		return ( json_last_error() == JSON_ERROR_NONE );
	}
}