<?php


namespace Nativerank\Resources\Providers;


use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Nativerank\Resources\Core\BaseResource\BaseResourceContract;
use Nativerank\Resources\Core\Controllers\ResourceController;
use Nativerank\Resources\Core\Hooks\Hooks;
use Nativerank\Resources\Core\Resource\Field;
use Nativerank\Resources\Core\Resource\Resource;
use Nativerank\Resources\Core\Resource\ResourceField;
use Nativerank\Resources\Core\Resource\ResourceType;
use Nativerank\Resources\Core\Route\Route;
use Nativerank\Resources\Core\Util\Scheduler;
use Nativerank\Resources\Core\Util\Shortcode;
use Nativerank\Resources\Hooks\NRTemplateHooks;
use Nativerank\Resources\Plugin;
use WP_Error;
use WP_Post;
use WP_Post_Type;

class ResourceProvider {

	public const FIELD_PREFIX = "_nr_resource_";


	/**
	 * @var Shortcode[]
	 */
	private $shortcodes = [];

	/**
	 * @var Hooks[]
	 */
	private $hooks = [];

	/**
	 * @var array
	 */
	private $classes = [];

	/**
	 * @var WP_Post[]
	 */
	private $posts = [];

	/**
	 * @var array
	 */
	protected $vueConfig = [];

	/**
	 * @var Plugin
	 */
	private $plugin;
	private array $postTypes;
	private ResourceType $resourcePostType;
	private array $resources;

	public function __construct( Plugin $plugin ) {
		$this->plugin           = $plugin;
		$this->resourcePostType = new ResourceType();
	}

	public function register() {
		$this->posts();

		add_action( 'init', [ $this, 'registerPostTypes' ] );

		$this->initializeVueApp();
		FieldProvider::registerRoutes();

		$this->adminPage();

//		 register shortcodes
		$this->shortcodes();

//		 register hooks
		if ( ! wp_doing_ajax() ) {
			$this->hooks();
		}

//		 Register any special classes
		$this->classes();

	}

	/**
	 * @return Collection
	 */
	protected function baseResources(): Collection {
		$postTypes = [
			$this->resourcePostType,
			new Field(),
		];

		return collect( $postTypes );
	}

	private function adminPage() {
		add_action( 'admin_menu', function () {
			add_filter( 'acf/settings/remove_wp_meta_box', '__return_false' );
			add_menu_page(
				__( 'NR Resources', 'resources-text-domain' ),
				__( 'NR Resources', 'resources-text-domain' ),
				'edit_posts',
				NR_RESOURCES_PLUGIN_NAME_KEBAB,
				[ $this, 'menu_page_callback' ],
				'dashicons-admin-generic',
				1
			);
		} );

		if ( is_admin() && $this->is_plugin_page() ) {
			$vueConfigAction = NR_RESOURCES_GET_VUE_CONFIG_ACTION;

			add_action( 'admin_enqueue_scripts', function () use ( $vueConfigAction ) {
				wp_enqueue_script(
					NR_RESOURCES_PLUGIN_NAME_KEBAB,
					NR_RESOURCES_PLUGIN_URI . "/dist/js/main.js",
					[],
					WP_DEBUG ? null : NR_RESOURCES_VERSION,
					true
				);
				wp_enqueue_script( 'lodash' );
				wp_enqueue_style(
					NR_RESOURCES_PLUGIN_NAME_KEBAB,
					NR_RESOURCES_PLUGIN_URI . "/dist/css/main.css",
					[],
					WP_DEBUG ? null : NR_RESOURCES_VERSION
				);

				// jQuery
				wp_enqueue_script( 'jquery' );

				// This will enqueue the Media Uploader script
				wp_enqueue_media();

				wp_add_inline_script( NR_RESOURCES_PLUGIN_NAME_KEBAB, "window.nr_resources_vue_config_action='{$vueConfigAction}'", 'before' );
			} );
		}
	}

	protected function initializeVueApp() {
		$this->configureVueApp();

		Route::ajax( NR_RESOURCES_GET_VUE_CONFIG_ACTION, $this, 'getAppConfig' );

		$this->registerRoutes();
	}


	protected function configureVueApp() {
		$this->vueConfig = [
			'plugin_uri'     => NR_RESOURCES_PLUGIN_URI,
			'rest_namespace' => NR_RESOURCES_REST_NAMESPACE,
			'resources'      => $this->resources(),
			'nr_site_url'    => get_site_url(),
			'is_admin'       => current_user_can( 'manage_options' ),
		];
	}

	public function getAppConfig() {
		wp_send_json( $this->vueConfig );
	}

	private function is_plugin_page(): bool {
		return isset( $_GET['page'] ) && $_GET['page'] == NR_RESOURCES_PLUGIN_NAME_KEBAB;
	}

	public function menu_page_callback() {
		?>
        <div class="resources_app_container">
            <div id="nr_resources_app">
                <nr-resources-app>
                </nr-resources-app>
            </div>
        </div>
		<?php
	}

	/**
	 * Register shortcodes
	 * @return Shortcode[]
	 */
	public function shortcodes(): array {
		$this->shortcodes = [];

		return $this->shortcodes;
	}

	public function registerPostTypes() {
		$postTypes = $this->baseResources();
		$postTypes->each( function ( $resource ) {
			/* @var BaseResourceContract $resource */
			static::registerPostType( $resource );
		} );

		collect( $this->posts )->each( function ( $post ) {
			/* @var WP_Post $post */
			static::initializePostType( $post );
		} );
	}

	public static function initializePostType( WP_Post $post ) {
		$resource = new Resource( $post );
		static::registerPostType( $resource );
		update_post_meta( $post->ID, '_nr_resource_plural', $resource->getPlural() );
		update_post_meta( $post->ID, '_nr_resource_type', $resource->type() );
	}

	/**
	 * @param BaseResourceContract $resource
	 *
	 * @return WP_Error|WP_Post_Type
	 */
	protected static function registerPostType( $resource ) {
		return register_post_type( $resource->type(), $resource->arguments() );
	}

	private static function prepareFields( $fields ): array {

		return collect( $fields )->flatMap( function ( $field ) {
			return ( new ResourceField( $field['field'], $field['label'], $field['column'] ) )->arguments();
		} )->toArray();
	}

	public static function addResource() {
		$postType = ( new ResourceType() )->type();
		$label    = $_POST['label'] ?? '';
		$slug     = empty( $_POST['slug'] ?? false ) ? BaseResource::generateSlug( $label ) : $_POST['slug'];

		$fields = $_POST['fields'] ?? null;


		static::checkForExistingResource( $postType, $slug );

		$arguments = [
			'post_type'   => $postType,
			'post_title'  => $label,
			'post_name'   => $slug,
			'post_status' => 'publish',
		];

		if ( is_array( $fields ) ) {
			$arguments['meta_input'] = static::prepareFields( $fields );
		}


		$resource = wp_insert_post( $arguments, true );

		if ( $resource instanceof WP_Error ) {
			wp_send_json_error( [
				'error' => $resource,
			], 400 );
		}

		$post     = get_post( $resource );
		$resource = new Resource( $post );
		$result   = static::registerPostType( $resource );
		update_post_meta( $post->ID, '_nr_resource_plural', $resource->getPlural() );
		update_post_meta( $post->ID, '_nr_resource_type', $resource->type() );

		$resource = collect( static::mapResources( [ $post ] ) )->first();

		wp_send_json( [
			'resource' => $resource,
		], $resource && $result instanceof WP_Post_Type ? 200 : 400 );
	}

	protected static function checkForExistingResource( $postType, $slug ) {
		global $wpdb;
		$query   = 'SELECT count(id) AS existing_posts FROM wp_posts WHERE post_status=%s AND post_type=%s AND post_name=%s';
		$results = $wpdb->get_results( $wpdb->prepare( $query, 'publish', $postType, $slug ) );
		$count   = collect( $results )->first()->existing_posts;
		if ( (int) $count ) {
			wp_send_json_error( [
				'error' => "Resource with slug {$slug} already exists!",
			], 400 );
		}
	}

	/**
	 * @return WP_Post[]
	 */
	private function posts(): array {
		$this->posts = get_posts( [
			'post_type'   => $this->resourcePostType->type(),
			'post_status' => 'publish',
		] );

		return $this->posts;
	}

	private function registerRoutes() {
		$resourceController = new ResourceController();
		Route::ajax( 'register_resource', static::class, 'addResource', true );
		Route::ajax( 'resource_index', $resourceController, 'index' );
		Route::ajax( 'resource_detail', $resourceController, 'detail' );
		Route::ajax( 'create_resource', $resourceController, 'create' );
		Route::ajax( 'update_resource', $resourceController, 'update' );
		Route::ajax( 'delete_resource', $resourceController, 'delete' );
	}

	public static function mapResources( $posts = [] ): array {


		$resources = collect();
		$fields    = static::queryAllFields();
		$fields    = static::mapFields( $fields );

		foreach ( $posts as $post ) {

			$resource = static::mapResourceWithFields( $post, $fields );

			if ( ! empty( $routes = $resource->pull( 'routes' ) ) ) {
				foreach ( $routes as $route ) {
					$type = $route['type'] ?? 'ajax';
					Route::$type( $route['action'] ?? '', $route['controller'] ?? '', $route['method'] ?? null );
				}
			}

			$resources->push( $resource );
		}

		return $resources->toArray();
	}

	private static function convertResourcePostToResource( WP_Post $resource ): Collection {
		return collect( $resource->to_array() )
			->only( ResourceController::$postSelects );
	}

	private static function mapResourceWithFields( WP_Post $resource, Collection $fields ): Collection {
		$resource       = static::convertResourcePostToResource( $resource );
		$resourceFields = static::getResourceFieldsByResourceID( $fields, $resource->get( 'ID' ) );

		$title = $resource->pull( 'post_title' );
		$slug  = $resource->pull( 'post_name' );
		$id    = $resource->get( 'ID' );

		return $resource
			->merge( [
				'fields'        => $resourceFields,
				'key'           => 'ID',
				'label'         => Str::singular( $title ),
				'singularLabel' => Str::singular( $title ),
				'plural'        => get_post_meta( $id, '_nr_resource_plural', true ),
				'resource'      => $slug,
				'type'          => get_post_meta( $id, '_nr_resource_type', true ),
				'uriKey'        => Str::plural( Str::kebab( $title ) ),
			] );
	}

	private static function getResourceFieldsByResourceID( Collection $fields, int $id ): Collection {
		return $fields->where( 'id', $id )->map( function ( $field ) {
			return collect( $field )
				->only(
					'label',
					'column',
					'component',
					'type',
					'views',
				)->all();
		} );
	}

	/**
	 * Register special classes
	 * @return object[]
	 */
	private function classes(): array {
		$this->classes = [
			( new Scheduler() ),
		];

		return $this->classes;
	}

	protected static function queryAllFields(): Collection {
		global $wpdb;

		$fieldIdsQuery = "SELECT 
       resource_field_ids.post_id AS id, 
       resource_field_meta.meta_value as field_meta,    
       resource_fields.meta_value as field_value
FROM wp_postmeta AS resource_field_ids
INNER JOIN wp_postmeta AS resource_field_meta ON resource_field_ids.meta_value = resource_field_meta.post_id
INNER JOIN wp_postmeta AS resource_fields ON (resource_fields.post_id = resource_field_ids.post_id AND REPLACE(resource_fields.meta_key, %s, '') = REPLACE(resource_field_ids.meta_key, %s, '')) 
WHERE resource_field_ids.meta_key LIKE %s
          AND resource_field_meta.meta_key = %s
          AND resource_fields.meta_key LIKE %s";

		return collect(
			$wpdb->get_results(
				$wpdb->prepare(
					$fieldIdsQuery,
					'_nr_resource_column_',
					'_nr_resource_field_id_',
					'_nr_resource_field_id_%',
					'_nr_resource_field',
					'_nr_resource_column_%',
				),
				ARRAY_A
			) );
	}

	protected static function mapFields( Collection $fields ): Collection {
		return $fields
			->map( function ( $field ) {
				$field      = collect( $field );
				$fieldValue = maybe_unserialize( $field->pull( 'field_value' ) );
				$fieldMeta  = maybe_unserialize( $field->pull( 'field_meta' ) );
				$field      = $field->merge( $fieldValue )->merge( $fieldMeta );


				return $field->toArray();
			} )
			->sortBy( function ( $field ) {
				return ( $field['column'] ?? false ) !== 'ID';
			} )
			->values();
	}

	/**
	 * @return Hooks[]
	 */
	public function hooks(): array {
		$this->hooks = [
			( new NRTemplateHooks() )->register( $this->resources ),
		];

		return $this->hooks;
	}

	private function resources(): array {
		$this->resources = static::mapResources( $this->posts );

		return $this->resources;
	}

}
