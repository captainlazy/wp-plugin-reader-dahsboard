<?php


namespace Nativerank\Resources\Providers;


use Nativerank\Resources\Core\Route\Route;

class FieldProvider {

	const POST_TYPE = "nr_resource_field";

	public function all() {
		wp_send_json( collect( get_posts( [
			'post_type'   => self::POST_TYPE,
			'post_status' => 'publish',
			'numberposts' => - 1,
			'orderby'     => 'post_title',
		] ) )->toArray() );
	}

	public static function registerRoutes() {
		Route::ajax( 'available_fields', new self(), 'all' );
	}

}
