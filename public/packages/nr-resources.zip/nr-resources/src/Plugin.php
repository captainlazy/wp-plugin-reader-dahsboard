<?php


namespace Nativerank\Resources;

use Nativerank\Resources\Providers\ResourceProvider;
use Puc_v4_Factory;

/**
 * Class Plugin
 * @package Nativerank\Resource
 */
class Plugin {

	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;


	private $updateChecker;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 */
	public function __construct( $main_file ) {
		$this->context = new Context( $main_file );
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context() {
		return $this->context;
	}

	/**
	 * Registers the plugin with WordPress.
	 */
	public function register() {

		( new ResourceProvider( static::$instance ) )->register();

		do_action( 'nr_resource_init' );
	}

	public function update_checker() {
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_RESOURCES_DIR_NAME,
			NR_RESOURCES_PLUGIN_MAIN_FILE,
			NR_RESOURCES_DIR_NAME
		);
	}

	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR BP PLUGIN NAME instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return Plugin|null
	 */
	public static function load( $main_file ): ?Plugin {

		if ( null !== static::$instance ) {
			return static::$instance;
		}

		if ( static::$instance === null ) {
			static::$instance = new static( $main_file );
		}


		// register plugin and update checker once plugins are loaded
		add_action( 'plugins_loaded', [ static::$instance, 'register' ], 11 );
		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ], 12 );

		return static::$instance;
	}

}
