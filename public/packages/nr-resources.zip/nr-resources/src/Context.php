<?php


namespace Nativerank\Resources;


/**
 * Class Context
 * @package Nativerank\Resource
 */
class Context {

}
