<?php


namespace Nativerank\Resources\Core\Util;


class Scheduler {

	protected static $contextPrefix = 'nr_resources_';
	protected $events = [];
	protected $time_between_events = 180;
	protected $interval = 'daily';

	public function __construct() {
		add_filter( 'cron_schedules', [ $this, 'add_intervals' ] );
		$this->add_actions();
		$this->add_cron_events();
	}

	private function add_actions() {
		foreach ( $this->events as $event ) {
			$callback = [ $this, $event ];
			$hook     = static::$contextPrefix . $event;
			if ( is_callable( $callback ) ) {
				add_action( $hook, $callback );
			}
		}
	}

	public function add_intervals( $schedules ) {

		return $schedules;
	}

	private function add_cron_events() {
		foreach ( $this->events as $index => $event ) {
			$hook = static::$contextPrefix . $event;
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time() + ( $this->time_between_events * $index ), $this->interval, $hook );
			}
		}
	}

}