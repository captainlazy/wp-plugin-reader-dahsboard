<?php


namespace Nativerank\Resources\Core\Route;


class Route {

	/**
	 * @param string|array $action
	 * @param string|callable $controller
	 * @param string|null $method
	 * @param bool $static
	 *
	 * @return array|mixed|string
	 */
	public static function ajax( $action, $controller, $method = null, $static = false ) {
		if ( empty( $method ) && is_string( $action ) ) {
			$method = $action;
		}

		if ( is_array( $action ) ) {
			$action_array = $action;
			$action       = array_shift( $action_array );
			if ( empty( $method ) ) {
				$method = $action;
			}

			$resource = empty( $action_array ) ? false : array_shift( $action_array );
			$action   = $resource === false ? $action : "{$action}_{$resource}";
		}

		$controller = is_object( $controller ) || $static ? $controller : new $controller();
		add_action( "wp_ajax_{$action}", [ $controller, $method ] );

		return $action;
	}

	/**
	 * @param string|array $uri
	 * @param string $controller
	 * @param string|null $method
	 * @param string[] $http_methods
	 */
	public static function rest( $uri, $controller, $method = null, $http_methods = [ 'POST' ] ) {
		if ( is_array( $uri ) ) {
			$action = array_shift( $uri );

			if ( empty( $method ) ) {
				$method = $action;
			}

			$resource = empty( $uri ) ? false : array_shift( $uri );

			$uri = $resource === false ? $action : "{$action}_{$resource}";
		}

		add_action( 'rest_api_init', function () use ( $uri, $controller, $method, $http_methods ) {
			register_rest_route( NR_RESOURCES_REST_NAMESPACE, $uri, [
				'methods'  => $http_methods,
				'callback' => [
					$controller,
					$method,
				],
			] );
		} );
	}


}
