<?php


namespace Nativerank\Resources\Core\Controllers;

use WP_Post;

class Controller {

	/**
	 * @var WP_Post|null
	 */
	protected ?WP_Post $post = null;

	/**
	 * @var string
	 */
	protected string $postType;

	protected $request = [];

	protected string $primaryKey = 'ID';

	/**
	 * @var bool
	 */
	protected $ajax;

	/**
	 */
	protected function removeRequestParams() {
		unset( $this->request['action'] );
	}

	protected function getPost(): ?WP_Post {
		return $this->post;
	}

	protected function queryPost() {
		$this->post = get_post( $this->getId(), OBJECT );
	}


	/**
	 * @return false|mixed
	 */
	protected function getId() {
		return $this->request[ $this->primaryKey ] ?? false;
	}

	protected function sendResponse( array $response, $code = null ) {
		$response = collect( $response );

		if ( $this->ajax ) {
			wp_send_json( $response->all(), $code );
			wp_die();
		}

		return $response->toArray();
	}
}