<?php


namespace Nativerank\Resources\Core\Controllers;


use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Nativerank\Resources\Core\Util\Helper;

class ResourceController extends Controller {

	public static string $rowFieldNamePrefix = '_nr_resource_value_';
	protected $request = [];

	protected $resource;

	public static array $postSelects = [
		'ID',
		'ancestors',
		'menu_order',
		'post_author',
		'post_category',
		'post_content',
		'post_content_filtered',
		'post_date',
		'post_date_gmt',
		'post_modified',
		'post_modified_gmt',
		'post_excerpt',
		'post_mime_type',
		'post_name',
		'post_title',
		'post_parent',
		'tags_input',
	];


	// TODO: refactor entire class to query resource post type, not laravel models
	private int $page = 1;
	private int $perPage = 10;
	private array $arguments;


	/**
	 * @param string|null $resource
	 * @param array $request
	 *
	 * @return array|string|void
	 */
	public function index( $request = [], $resource = null ) {

		$this->initialize( $request, $resource, $_GET );

		if ( ! $this->checkResourceAndPostType() ) {
			return;
		}

		$fields = collect( $this->request['fields'] ?? [] );
		$total  = $this->countPosts();

		$this->initializeArguments();

		$rows = $this->queryResourceRows( $fields );

		return $this->sendResponse( [
			'data'      => $rows,
			'total'     => $total,
			'page'      => $this->page,
			'last_page' => Helper::calculateLastPage( $total, $this->perPage ),
			'html'      => paginate_links( [
				'total'   => Helper::calculateLastPage( $total, $this->perPage ),
				'current' => $this->page,
			] ),
		] );

	}

	private function initializeArguments() {
		$this->arguments = [
			'post_type'   => $this->postType,
			'post_status' => 'publish',
			'paged'       => $this->page,
			'numberposts' => $this->perPage,
		];

		if ( isset( $this->request['queryArguments'] ) ) {
			$this->arguments = array_merge( $this->arguments, $this->request['queryArguments'] );
		}
	}

	/**
	 * @param null $resource
	 * @param array $request
	 *
	 * @return array|void
	 */
	public function create( $request = [], $resource = null ) {
		$this->initialize( $resource, $request, $_POST );

		if ( ! $this->checkResourceAndPostType() ) {
			return;
		}

		$result = $this->updatePost();
		$saved  = is_array( $result );

		return $this->sendResponse( [
			'model'  => $saved ? $result : false,
			'errors' => $saved ? [] : $result,
		], $saved ? 200 : 400 );
	}

	public function update( $request = [], $resource = null ) {
		try {

			$this->initialize( $resource, $request, $_POST );

			if ( ! $this->checkResourceAndPostType() ) {
				return;
			}


			$id = $this->getId();

			if ( $id === false ) {
				return $this->missingId();
			}

			$result = $this->updatePost();
			$saved  = is_array( $result );

			return $this->sendResponse( [
				'model'  => $saved ? $result : false,
				'errors' => $saved ? [] : $result,
			], $saved ? 200 : 400 );

		} catch ( \Exception $e ) {
			dd( $e );
		}

	}

	public function delete( $request = [], $resource = null ) {

		$this->initialize( $resource, $request, $_POST );

		if ( ! $this->checkResourceAndPostType() ) {
			return;
		}

		$id = $this->getId();

		if ( $id === false ) {
			return $this->missingId();
		}

		$resourcePost = collect( get_posts( [
			'post_type'   => 'nr_resource',
			'post_status' => 'publish',
			'post_name'   => $this->resource,
		] ) )->first();
		$resourcePost = $resourcePost instanceof \WP_Post ? $resourcePost->ID : $resourcePost;
		$softDelete   = (bool) get_post_meta( $resourcePost, '_nr_resource_soft_deletion', true );
		$deleted      = $softDelete ? wp_update_post( [
			'ID'          => $id,
			'post_status' => 'draft',
		], true ) : wp_delete_post( $id );

		if ( $deleted instanceof \WP_Error ) {
			return $this->sendResponse( [
				'error' => $deleted,
			], 400 );
		}

		$deleted = empty( $deleted ) ? false : $deleted;

		return $this->sendResponse( [
			'deleted' => $deleted,
			'data'    => $id,
		], $deleted ? 200 : 400 );
	}

	protected function initialize( $request = [], $resource = null, $global = [] ) {
		$this->resource = $resource;
		$this->initializeIsAjax();
		$this->request = $this->ajax ? $global : $request;

		$this->assignResource();
		$this->initializePostType();
		$this->removeRequestParams();
		$this->initializePage();
		$this->initializePerPage();

	}

	/**
	 */
	protected function removeRequestParams() {
		unset( $this->request['action'], $this->request['resource'], $this->request['type'] );
	}

	/**
	 */
	protected function initializeIsAjax() {
		$this->ajax = wp_doing_ajax();
	}

	protected function checkResourceAndPostType(): bool {
		if ( ! $this->resource || ! $this->postType ) {
			if ( $this->ajax ) {
				$this->missingResource();
			}

			return false;
		}

		return true;
	}

	protected function missingResource() {
		status_header( 400 );
		wp_die( 'Resource is required!' );
	}

	protected function missingId() {
		$response = [
			'message' => "Primary key {$this->primaryKey} is required!",
			'data'    => $this->request,
		];

		if ( $this->ajax ) {
			return $this->sendResponse( $response, 400 );
		}

		return $response;

	}

	protected function assignResource() {
		$this->resource = $this->ajax ? stripslashes( $this->request['resource'] ) : $this->resource;
	}

	protected function queryResourceRows( Collection $fields ): Collection {
		$rows = collect( get_posts( $this->arguments ) );

		$rows->transform( function ( $row ) use ( $fields ) {
			/* @var \WP_Post $row */
			$fields = $this->mapFieldValuesToFields( $row->ID, $fields );

			return $this->mapResourceRow( $row, $fields );
		} );

		return $rows;
	}

	protected function mapFieldValuesToFields( int $id, Collection $fields ): Collection {
		$fieldValues = $this->queryFieldValues( $id, $fields );

		return $fields
			->filter( function ( $field ) {
				return $field && isset( $field['column'] );
			} )
			->map( function ( $field ) use ( $id, $fieldValues ) {
				$isPrimaryKey   = $field['column'] === $this->primaryKey;
				$fieldValues    = $fieldValues->filter( function ( $fieldValue ) use ( $field ) {
					return $fieldValue['field_name'] === $this->convertResourceColumnToRowFieldName( (string) $field['column'] );
				} )->pluck( 'field_value' );
				$field['value'] = $isPrimaryKey ? collect( $id ) : $fieldValues;

				if ( $field['value']->count() === 1 ) {
					$field['value'] = $field['value']->first();
				} else {
					$field['value'] = $field['value']->all();
				}

				return collect( $field )
					->only(
						'column',
						'value',
						'label',
					)
					->all();
			} )
			->filter()
			->sortBy( function ( $field ) {
				return ( $field['column'] !== $this->primaryKey );
			} )
			->values();
	}

	protected function queryFieldValues( int $id, Collection $fields ): Collection {
		global $wpdb;

		$fieldNames = $fields
			->pluck( 'column' )
			->map( function ( $column ) {
				return $this->convertResourceColumnToRowFieldName( (string) $column );
			} )
			->filter()
			->reject( 'ID' );

		if ( $fieldNames->isEmpty() ) {
			return collect();
		}

		$lastFieldNameKey = array_key_last( $fieldNames->all() );
		$fieldValuesQuery = "SELECT post_id AS id, meta_key AS field_name, meta_value AS field_value FROM wp_postmeta WHERE post_id = {$id} AND meta_key IN (";
		$fieldNames->each( function ( $fieldName, $index ) use ( $fieldNames, $lastFieldNameKey, &$fieldValuesQuery ) {
			global $wpdb;
			$fieldValuesQuery .= '%s';
			if ( $index !== $lastFieldNameKey ) {
				$fieldValuesQuery .= ',';
			}
			$fieldValuesQuery = $wpdb->prepare( $fieldValuesQuery, $fieldName );
		} );
		$fieldValuesQuery .= ')';

		return collect( $wpdb->get_results( $fieldValuesQuery, ARRAY_A ) );
	}

	protected function convertResourceColumnToRowFieldName( string $column ): string {
		return Str::start( $column, static::$rowFieldNamePrefix );
	}

	protected function initializePostType() {
		$this->postType = $this->ajax ? stripslashes( $this->request['type'] ) : $this->request['type'];
	}

	protected function getPostType() {
		return $this->postType;
	}

	protected function countPosts(): int {
		$count = 0;
		if ( $this->postType ) {
			$count = wp_count_posts( $this->postType )->publish ?? 0;
		}

		return (int) ( $count );
	}

	protected function initializePage() {

		if ( ! $this->ajax && get_query_var( 'paged' ) ) {
			$this->page = get_query_var( 'paged' );
		}

		$this->page = $this->getNumericValue( 'page', $this->page );
	}

	protected function initializePerPage() {

		$this->perPage = $this->getNumericValue( 'perPage', $this->perPage );

	}

	protected function getNumericValue( string $key, $default = 1 ): int {

		return is_numeric( $this->request[ $key ] ?? false ) ? $this->request[ $key ] : $default;
	}

	protected function updatePost() {
		$postColumns = collect( $this->request['fields'] ?? [] )->only(
			'post_title',
			'post_content',
			'post_excerpt',
		);
		$metaInput   = collect( $this->request['fields'] ?? [] )
			->flatMap( function ( $value, $key ) {
				$key   = $this->convertResourceColumnToRowFieldName( (string) $key );
				$value = wp_unslash( $value );

				return [ $key => $value ];
			} )
			->except(
				'ID',
				'post_title',
				'post_content',
				'post_excerpt',
			);
		$arguments   = array_merge( [
			'post_type'   => $this->postType,
			'post_status' => 'publish',
			'meta_input'  => $metaInput->all(),
		], $postColumns->all() );
		$id          = $this->getId();

		$result = ( $id ? wp_update_post( array_merge( $arguments, [ 'ID' => $id ] ), true ) : wp_insert_post( $arguments, true ) );

		if ( is_integer( $result ) ) {
			$this->post = get_post( $result );

			$metaInput = $metaInput
				->transform( function ( $field, $key ) {
					$key = Str::replaceFirst( static::$rowFieldNamePrefix, '', $key );

					return [
						'column' => $key,
						'value'  => $key === $this->primaryKey ? (int) $field : $field,
					];
				} )
				->sortBy( function ( $field ) {
					return ( $field['column'] !== $this->primaryKey );
				} )
				->values();

			return $this->mapResourceRow( $this->post, $metaInput );
		}

		return $result;
	}

	protected function mapResourceRow( \WP_Post $row, Collection $fields ): array {
		$row           = collect( $row->to_array() )->only( static::$postSelects )->toArray();
		$row['fields'] = $fields->toArray();

		return $row;
	}

}
