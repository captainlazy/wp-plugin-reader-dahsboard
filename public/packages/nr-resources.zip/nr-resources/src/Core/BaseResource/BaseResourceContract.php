<?php


namespace Nativerank\Resources\Core\BaseResource;

interface BaseResourceContract {
	public function type(): string;

	public function arguments(): array;

}
