<?php


namespace Nativerank\Resources\Core\BaseResource;

use Illuminate\Support\Str;
use Nativerank\Resources\Core\Controllers\ResourceController;
use Nativerank\Resources\Providers\ResourceProvider;

class BaseResource implements BaseResourceContract {

	protected string $type;
	protected array $arguments;
	protected array $labels;

	protected static array $defaults = [
		'supports'            => array(
			'title',
			'editor',
			'excerpt',
			'page-attributes',
			'custom-fields',
		),
		'show_ui'             => true,
		'show_in_menu'        => false,
		'show_in_admin_bar'   => false,
		'show_in_nav_menus'   => false,
		'can_export'          => true,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => false,
		'capability_type'     => 'post',
	];

	public static function generateSlug( $label ): string {
		return Str::snake( Str::pluralStudly( $label ) );
	}

	public static function prepareForDataHook( $resource ): array {
		return [
			$resource['uriKey'] => static::indexQuery( $resource ),
		];
	}

	public static function prepareHelpers(): array {
		return [
			'nr_resource' => function () {
				$arguments      = func_get_args();
				$resource       = $arguments[0];
				$queryArguments = [];
				$pagination     = $arguments[1] === "pagination";
				if ( ! $pagination && isset( $arguments[1]['hash'] ) ) {
					$queryArguments = $arguments[1]['hash'];
				}

				$result = nr_1055_get_resources( $resource, $queryArguments );

				if ( $pagination ) {
					unset( $result['data'] );
				} else {
					return collect( $result['data'] )->map( function ( $row ) {
						$row['fields'] = collect( $row['fields'] )->keyBy( 'column' )->all();

						return $row;
					} )->all();
				}


				return $result;
			},
		];
	}

	public static function indexQuery( $resource, $arguments = [] ) {
		$resource = get_page_by_path( $resource, OBJECT, 'nr_resource' );

		if ( is_null( $resource ) ) {
			throw new \Error( $resource . ' is not a valid resource slug' );
		}

		$resource = collect( ResourceProvider::mapResources( [ $resource ] ) )->first();

		$arguments = collect( $arguments )
			->transform( function ( $argument, $key ) {
				if ( is_string( $argument ) ) {
					if ( nr_1055_value_is_json( $argument ) ) {
						return @json_decode( $argument, true );
					}
				}

				return $argument;
			} )
			->filter()
			->all();

		if ( $resource ) {

			return ( new ResourceController() )->index(
				[
					'type'           => $resource['type'],
					'fields'         => $resource['fields'],
					'queryArguments' => $arguments,
				],
				$resource['resource'],
			);
		}

		return null;
	}

	public function type(): string {
		return $this->type;
	}

	public function arguments(): array {
		return $this->arguments;
	}
}