<?php


namespace Nativerank\Resources\Core\Hooks;


abstract class Hooks {

	public function __construct() {
	}

	/**
	 * @param mixed $resources
	 *
	 * @return $this
	 */
	public abstract function register( $resources );
}