<?php


namespace Nativerank\Resources\Core\Resource;


use Illuminate\Support\Str;
use Nativerank\Resources\Core\BaseResource\BaseResource;

class ResourceField extends BaseResource {

	const POST_TYPE = "nr_resource_field";
	const FIELD_PREFIX = "_nr_resource_";

	/**
	 * @var string|int nr_resource_field post type ID
	 */
	private $field_id;

	/**
	 * @var string Field Column ID
	 */
	private string $column;

	/**
	 * @var string Label for front-end
	 */
	private string $label;

	/**
	 * @var array Views, field is visible
	 */
	private array $views = [ "index", "create", "update" ];

	public function __construct( $fieldID, $fieldName, $fieldColumn = '' ) {
		$this->field_id = $fieldID;
		$this->label    = $fieldName;

		if ( empty( $fieldColumn ) ) {
			$fieldColumn = Str::snake( Str::studly( $fieldName ) );
		}

		$this->column = $fieldColumn;

	}


	/**
	 * @return string meta key to store the nr_resource_field post ID
	 *  e.g. "_nr_resource_field_id_{column_name}"
	 */
	private function meta_key_field_id(): string {
		return self::FIELD_PREFIX . "field_id_" . $this->column;
	}

	/**
	 * @return string meta key to store the nr_resource_field meta/options
	 *  e.g. "_nr_resource_column_{column_name}"
	 */
	private function meta_key_field(): string {
		return self::FIELD_PREFIX . "column_" . $this->column;
	}

	private function meta_value_field(): array {
		return [
			'column' => $this->column,
			'label'  => $this->label,
			'views'  => $this->views,
		];
	}

	public function type(): string {
		return self::POST_TYPE;
	}

	public function arguments(): array {
		return [
			$this->meta_key_field_id() => $this->field_id,
			$this->meta_key_field()    => $this->meta_value_field(),
		];
	}
}
