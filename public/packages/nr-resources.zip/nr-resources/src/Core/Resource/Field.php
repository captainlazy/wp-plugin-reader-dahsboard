<?php


namespace Nativerank\Resources\Core\Resource;

use Nativerank\Resources\Core\BaseResource\BaseResource;

class Field extends BaseResource {

	public function type(): string {
		$this->type = 'nr_resource_field';

		return $this->type;
	}

	public function arguments(): array {

		$this->arguments = array_merge( static::$defaults, array(
			'label'        => 'NR Resource Fields',
			'description'  => 'Resource Field Types',
			'labels'       => $this->labels(),
			'hierarchical' => true,
			'menu_icon'    => 'dashicons-cog',
		) );

		return $this->arguments;
	}

	protected function labels() {
		$this->labels = array(
			'name'                  => 'Resource Fields',
			'singular_name'         => 'Resource Field',
			'menu_name'             => 'Resource Fields',
			'name_admin_bar'        => 'Resource Fields',
			'archives'              => 'Resource Field Archives',
			'attributes'            => 'Resource Field Attributes',
			'all_items'             => 'All Resource Fields',
			'add_new_item'          => 'Add New Resource Field',
			'add_new'               => 'Add New Resource Field',
			'new_item'              => 'New Resource Field',
			'edit_item'             => 'Edit Resource Field',
			'update_item'           => 'Update Resource Field',
			'view_item'             => 'View Resource Field',
			'view_items'            => 'View Resource Fields',
			'search_items'          => 'Search Resource Fields',
			'not_found'             => 'Not found',
			'not_found_in_trash'    => 'Not found in Trash',
			'featured_image'        => 'Featured Image',
			'set_featured_image'    => 'Set featured image',
			'remove_featured_image' => 'Remove featured image',
			'use_featured_image'    => 'Use as featured image',
			'insert_into_item'      => 'Insert into item',
			'uploaded_to_this_item' => 'Uploaded to this item',
			'items_list'            => 'Resource Fields list',
			'items_list_navigation' => 'Resource Fields list navigation',
			'filter_items_list'     => 'Filter items list',
		);

		return $this->labels;
	}
}