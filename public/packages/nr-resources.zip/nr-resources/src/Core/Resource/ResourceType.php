<?php


namespace Nativerank\Resources\Core\Resource;


use Nativerank\Resources\Core\BaseResource\BaseResource;

class ResourceType extends BaseResource {

	public function type(): string {
		$this->type = 'nr_resource';

		return $this->type;
	}

	public function arguments(): array {
		$this->arguments = array_merge( static::$defaults, array(
			'label'       => 'NR Resources',
			'description' => 'Resources',
			'labels'      => $this->labels(),
			'menu_icon'   => 'dashicons-cog',
		) );

		return $this->arguments;
	}

	protected function labels() {
		$this->labels = array(
			'name'                  => 'Resources',
			'singular_name'         => 'Resource',
			'menu_name'             => 'Resources',
			'name_admin_bar'        => 'Resources',
			'archives'              => 'Resource Archives',
			'attributes'            => 'Resource Attributes',
			'all_items'             => 'All Resources',
			'add_new_item'          => 'Add New Resource',
			'add_new'               => 'Add New Resource',
			'new_item'              => 'New Resource',
			'edit_item'             => 'Edit Resource',
			'update_item'           => 'Update Resource',
			'view_item'             => 'View Resource',
			'view_items'            => 'View Resources',
			'search_items'          => 'Search Resources',
			'not_found'             => 'Not found',
			'not_found_in_trash'    => 'Not found in Trash',
			'featured_image'        => 'Featured Image',
			'set_featured_image'    => 'Set featured image',
			'remove_featured_image' => 'Remove featured image',
			'use_featured_image'    => 'Use as featured image',
			'insert_into_item'      => 'Insert into item',
			'uploaded_to_this_item' => 'Uploaded to this item',
			'items_list'            => 'Resources list',
			'items_list_navigation' => 'Resources list navigation',
			'filter_items_list'     => 'Filter items list',
		);

		return $this->labels;
	}
}