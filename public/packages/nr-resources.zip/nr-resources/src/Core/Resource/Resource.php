<?php


namespace Nativerank\Resources\Core\Resource;

use Illuminate\Support\Str;
use Nativerank\Resources\Core\BaseResource\BaseResource;

class Resource extends BaseResource {

	private string $label;
	private string $plural;
	private string $slug;

	public function __construct( \WP_Post $resource ) {
		$label        = $resource->post_title;
		$this->label  = $label;
		$this->type   = Str::snake( Str::studly( $label ) );
		$this->slug   = static::generateSlug( $label );
		$this->plural = Str::plural( $this->label );
	}

	public function arguments(): array {
		$this->arguments = array_merge( static::$defaults, array(
			'label'               => $this->label,
			'description'         => $this->label,
			'labels'              => $this->labels(),
			'menu_icon'           => 'dashicons-cog',
			'public'              => true,
			'hierarchical'        => true,
			'has_archive'         => true,
			'publicly_queryable'  => true,
			'exclude_from_search' => false,
		) );

		return $this->arguments;
	}

	protected function labels() {
		$this->labels = array(
			"name"                  => $this->plural,
			"singular_name"         => "{$this->label}",
			"menu_name"             => $this->plural,
			"name_admin_bar"        => $this->plural,
			"archives"              => "{$this->label} Archives",
			"attributes"            => "{$this->label} Attributes",
			"all_items"             => "All Resources",
			"add_new_item"          => "Add New {$this->label}",
			"add_new"               => "Add New {$this->label}",
			"new_item"              => "New {$this->label}",
			"edit_item"             => "Edit {$this->label}",
			"update_item"           => "Update {$this->label}",
			"view_item"             => "View {$this->label}",
			"view_items"            => "View Resources",
			"search_items"          => "Search Resources",
			"not_found"             => "Not found",
			"not_found_in_trash"    => "Not found in Trash",
			"featured_image"        => "Featured Image",
			"set_featured_image"    => "Set featured image",
			"remove_featured_image" => "Remove featured image",
			"use_featured_image"    => "Use as featured image",
			"insert_into_item"      => "Insert into item",
			"uploaded_to_this_item" => "Uploaded to this item",
			"items_list"            => "{$this->plural} list",
			"items_list_navigation" => "{$this->plural} list navigation",
			"filter_items_list"     => "Filter items list",
		);

		return $this->labels;
	}

	public function getPlural(): string {
		return $this->plural;
	}

}