<?php


namespace Nativerank\Resources\Hooks;


use Nativerank\Resources\Core\BaseResource\BaseResource;
use Nativerank\Resources\Core\Hooks\Hooks;
use Nativerank\Resources\Core\Util\Helper;

class NRTemplateHooks extends Hooks {

	private $helpers = [];
	private $data = [];

	/*
	* Use this file to modify NRTemplate
	* with the hooks
	* nr_1055_template_helpers
	* nr_1055_template_data
	* nr_1055_template_partials
	* nr_1055_template_files_FILENAME
	*
	* Some of these hooks are already being used below
	* See other comments for built-in shortcuts to use them
	*
	*/

	/**
	 * @param array $resources
	 *
	 * @return $this|NRTemplateHooks
	 */
	public function register( $resources = [] ): NRTemplateHooks {
		foreach ( $resources as $resource ) {
//			$this->data( BaseResource::prepareForDataHook( $resource ) );
			$this->helpers( BaseResource::prepareHelpers( $resource ) );
		}

		add_filter( 'nr_1055_template_helpers', [ $this, 'registerHelpers' ], 11 );

//		add_filter( 'nr_1055_template_data', [ $this, 'registerData' ] );

		return $this;
	}

	public function data( $data = [] ) {
		// You can add data here
		// just set a key => value pair
		// in $this->data, the key will be
		// the name of your data variable
		// the variable will then return your value in NR Templates

		$this->data = array_merge( $this->data, [
			// for example,
			// 'galleryImages' => SOME VALUE;
		], $data );

		return $this->data;
	}

	public function helpers( $helpers = [] ) {

		// add helpers to NRTemplate, in the $newHelpers array
		// as 'name' => function() {} pairs
		$this->helpers = array_merge( $this->helpers, [
			// or register static functions from \Nativerank\NrPluginName\Core\Util\Helper
			// by name (key only, no value), like this
			'strip_url',
		], $helpers );

		$this->helpers = Helper::getHelpers( $this->helpers );

		return $this->helpers;

	}

	/* *
	 * Heads up:
	 * You can edit the below functions, but you probably won't need to
	*/

	/**
	 * @param array $helpers
	 *
	 * @return array
	 */
	public function registerHelpers( array $helpers ) {
		foreach ( $this->helpers( [] ) as $name => $callback ) {
			$helpers[ $name ] = $callback;
		}

		return $helpers;
	}

	public function registerData( $data ) {
		foreach ( $this->data() as $key => $datum ) {
			$data[ $key ] = $datum;
		}

		return $data;
	}


	/*
	 * STOP EDITING
	 * These filters are set in place to allow you to add/overwrite
	 * helpers, partials and templates in NRTemplate
	 *
	 * Helpers can be added up at the top of the file inside $newHelpers
	 *
	 * To add templates and/or partials,
	 * Just place files in the /templates
	 * and /templates/partials directories inside this plugin's root directory
	 * Then you can use them for nr_page_type
	 * or use the partials in your templates
	 *
	 * !!! WARNING !!!
	 * If you name a template or partial the same as one in your theme, it will override it
	 *
	 * There is also a directory inside partials, named after the plugin,
	 * nr-plugin-name/, putting partials in there will add plugin scope
	 * to help avoid name conflicts
	 *
	 * */

	public function collect_files() {
		if ( ! empty( NR_NR_PLUGIN_NAME_TEMPLATES_DIR ) ) {
			if ( ! file_exists( NR_NR_PLUGIN_NAME_TEMPLATES_DIR ) ) {
				mkdir( NR_NR_PLUGIN_NAME_TEMPLATES_DIR, 0775, true );
			}
			if ( $handle = opendir( NR_NR_PLUGIN_NAME_TEMPLATES_DIR ) ) {
				while ( false !== ( $entry = readdir( $handle ) ) ) {
					$fileInfo = pathinfo( $entry );
					if ( array_key_exists( 'extension', $fileInfo ) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs' ) {
						add_filter( 'nr_1055_template_files_' . $fileInfo['filename'], [ $this, 'template' ], 20 );
					}
				}
				closedir( $handle );
			}
			if ( ! empty( NR_NR_PLUGIN_NAME_PARTIALS_DIR ) ) {
				if ( ! file_exists( NR_NR_PLUGIN_NAME_PARTIALS_DIR ) ) {
					mkdir( NR_NR_PLUGIN_NAME_PARTIALS_DIR, 0775, true );
				}
				if ( ! file_exists( NR_NR_PLUGIN_NAME_PARTIALS_DIR . "nr-plugin-name/" ) ) {
					mkdir( NR_NR_PLUGIN_NAME_PARTIALS_DIR . "nr-plugin-name/", 0775, true );
				}
				add_filter( 'nr_1055_template_partials', [ $this, 'partials' ], 20 );
			}
		}

	}

	public function partials( $partials ) {
		$dirs = array_filter( glob( NR_NR_PLUGIN_NAME_PARTIALS_DIR . '*/' ), 'is_dir' );

		foreach ( $dirs as $path ) {

			if ( $handle = opendir( $path ) ) {
				while ( false !== ( $entry = readdir( $handle ) ) ) {

					$fileInfo = pathinfo( $entry );
					if ( array_key_exists( 'extension', $fileInfo ) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs' ) {
						if ( strpos( $path, NR_NR_PLUGIN_NAME_PARTIALS_DIR ) > - 1 ) {
							$sub = rtrim( str_replace( NR_NR_PLUGIN_NAME_PARTIALS_DIR, '', $path ), '/' );
						} else {
							$sub = rtrim( preg_replace( '/.*\/partials\/(.*)/', '$1', $path ), '/' );
						}

						$fileName              = empty( $sub ) ? $fileInfo['filename'] : $sub . '.' . $fileInfo['filename'];
						$partials[ $fileName ] = file_get_contents( $path . $entry );
					}
				}

				closedir( $handle );
			}
		}

		return $partials;
	}

	public function template( $templateString, $fileName ) {
		$replacement = NR_NR_PLUGIN_NAME_TEMPLATES_DIR . $fileName . '.hbs';
		if ( file_exists( $replacement ) ) {
			return file_get_contents( $replacement );
		}

		return $templateString;
	}
}
