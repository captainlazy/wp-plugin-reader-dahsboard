<?php

/*
Plugin Name: NR Resources
Plugin URI: https://nativerank.com
Description: Native Rank Wordpress Resources
Version: 0.2.2
Author: mitch
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_RESOURCES_VERSION', '0.2.2' );
define( 'NR_RESOURCES_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_RESOURCES_PHP_MINIMUM', '7.4.0' );
define( 'NR_RESOURCES_DIR_NAME', basename( __DIR__ ) );
define( 'NR_RESOURCES_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_RESOURCES_PLUGIN_URI', plugins_url( NR_RESOURCES_DIR_NAME ) );

define( 'NR_RESOURCES_GET_VUE_CONFIG_ACTION', 'nr_resources_get_vue_config' );

define( 'NR_RESOURCES_PLUGIN_NAME_KEBAB', 'nr-resources' );
define( 'NR_RESOURCES_REST_NAMESPACE', NR_RESOURCES_PLUGIN_NAME_KEBAB . '/v1' );

define( 'NR_RESOURCES_TEMPLATES_DIR', NR_RESOURCES_PLUGIN_PATH . 'templates/' );
define( 'NR_RESOURCES_PARTIALS_DIR', NR_RESOURCES_TEMPLATES_DIR . 'partials/' );

if ( class_exists( '\Nativerank\Resources\Plugin' ) ) {
	die();
}

require_once plugin_dir_path( __FILE__ ) . "functions.php";

require_once plugin_dir_path( __FILE__ ) . 'vendor/autoload_packages.php';


/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_RESOURCES_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR Resources requires PHP version %s', 'nr-resources' ), NR_RESOURCES_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-resources' )
		);
	}

	flush_rewrite_rules();
	do_action( 'nr_resources_activation' );

} );

/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_RESOURCES_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_resources_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_resources_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_RESOURCES_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_resources_opcache_reset' );

if ( version_compare( PHP_VERSION, NR_RESOURCES_PHP_MINIMUM, '>=' ) ) {
	add_action( 'plugins_loaded', function () {
		$instance = \Nativerank\Resources\Plugin::load( NR_RESOURCES_PLUGIN_MAIN_FILE );

		require NR_RESOURCES_PLUGIN_PATH . 'routes.php';
	} );

	add_action( 'nr_resources_activation', 'nr_1055_add_resource_fields' );
}

