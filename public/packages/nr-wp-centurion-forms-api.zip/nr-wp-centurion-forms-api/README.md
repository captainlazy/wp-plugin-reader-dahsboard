# nr-wp-centurion-forms-api

Handles form entries from front-end of Gridsome build, sends them to Aimbase CRM and stores them in the Wordpress CMS database.