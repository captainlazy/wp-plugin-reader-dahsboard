<?php

/*
Plugin Name: NR Centurion Forms API
Plugin URI: https://nativerank.com
Description: Receives form entry requests from the site front-end, adds them to the client CRM and Gravity Forms database
Version: 0.8.1
Author: Native Rank
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_CENTURION_FORMS_API_VERSION', '0.8.1' );
define( 'NR_CENTURION_FORMS_API_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_CENTURION_FORMS_API_PHP_MINIMUM', '5.6.0' );
define( 'NR_CENTURION_FORMS_API_DIR_NAME', basename( __DIR__ ) );
define( 'NR_CENTURION_FORMS_API_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_CENTURION_FORMS_API_PLUGIN_URI', plugins_url( NR_CENTURION_FORMS_API_DIR_NAME ) );

define( 'NR_CENTURION_FORMS_API_TEMPLATES_DIR', NR_CENTURION_FORMS_API_PLUGIN_PATH . 'templates/' );
define( 'NR_CENTURION_FORMS_API_PARTIALS_DIR', NR_CENTURION_FORMS_API_TEMPLATES_DIR . 'partials/' );
define( 'NR_CENTURION_FORMS_API_REST_NAMESPACE', 'centurion-forms-api/v1' );

if ( class_exists( '\Nativerank\CenturionFormsAPI\Plugin' ) ) {
	die();
}

require 'vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_CENTURION_FORMS_API_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR BP PLUGIN NAME requires PHP version %s', 'nr-centurion-forms-api' ), NR_CENTURION_FORMS_API_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-centurion-forms-api' )
		);
	}

	//Create DB Tables
	( new \Nativerank\CenturionFormsAPI\Database\Migrations() );

	do_action( 'nr_centurion_forms_api_activation' );

} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_CENTURION_FORMS_API_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_centurion_forms_api_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_centurion_forms_api_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_CENTURION_FORMS_API_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_centurion_forms_api_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_CENTURION_FORMS_API_PHP_MINIMUM, '>=' ) ) {

	\Nativerank\CenturionFormsAPI\Plugin::load( NR_CENTURION_FORMS_API_PLUGIN_MAIN_FILE );

}

add_action( 'init', function () {
	if ( file_exists( NR_CENTURION_FORMS_API_PLUGIN_PATH . 'nr-template-hooks.php' ) ) {
		include NR_CENTURION_FORMS_API_PLUGIN_PATH . 'nr-template-hooks.php';
	}
} );


if ( is_admin() ) {
	if ( isset( $_GET['page'] ) && $_GET['page'] == 'nr-wp-centurion-forms-api' ) {
		add_action( 'admin_enqueue_scripts', function () {
			global $wpdb;
			$prefix     = $wpdb->prefix;
			$table_name = 'form_entries';
			$order_by   = 'entry_id';
			$sort_order = 'DESC';
			$sql        = "SELECT * from ${prefix}${table_name} ORDER BY ${order_by} ${sort_order}";

			$entries = $wpdb->get_results( $sql, ARRAY_A );

			foreach ( $entries as $index => $entry ) {
				$entry["entry_data"]     = json_decode( stripslashes( $entry["entry_data"] ) );
				$entry["response"]       = json_decode( stripslashes( $entry["response"] ) );
				$entry["raw_entry_data"] = json_decode( stripslashes( $entry["raw_entry_data"] ) );
				$entries[ $index ]       = $entry;
			}

			$entries = json_encode( $entries );

			wp_enqueue_script(
				'nr_centurion_forms_app',
				NR_CENTURION_FORMS_API_PLUGIN_URI . "/dist/js/app.js",
				[],
				WP_DEBUG ? null : NR_CENTURION_FORMS_API_VERSION,
				true
			);
			wp_enqueue_script(
				'nr_centurion_forms_app_chunk_vendors',
				NR_CENTURION_FORMS_API_PLUGIN_URI . "/dist/js/chunk-vendors.js",
				[],
				WP_DEBUG ? null : NR_CENTURION_FORMS_API_VERSION,
				true
			);

			$rest_url = get_rest_url();

			wp_add_inline_script( 'nr_centurion_forms_app', "window.nr_centurion_form_entries=${entries}", 'before' );
			wp_add_inline_script( 'nr_centurion_forms_app', "window.nr_centurion_rest_url='${rest_url}'", 'before' );

			wp_enqueue_style( 'nr_centurion_forms_app_styles',
				NR_CENTURION_FORMS_API_PLUGIN_URI . "/dist/css/app.css",
				[],
				WP_DEBUG ? null : NR_CENTURION_FORMS_API_VERSION
			);

			wp_enqueue_style( 'nr_centurion_forms_mdi_icons',
				"https://cdn.jsdelivr.net/npm/@mdi/font@latest/css/materialdesignicons.min.css"
			);

			wp_enqueue_style( 'nr_centurion_forms_app_chunk_vendors_styles',
				NR_CENTURION_FORMS_API_PLUGIN_URI . "/dist/css/chunk-vendors.css",
				[],
				WP_DEBUG ? null : NR_CENTURION_FORMS_API_VERSION
			);
		} );
	}
}

add_action( 'admin_menu', function () {
	add_filter( 'acf/settings/remove_wp_meta_box', '__return_false' );
	add_menu_page(
		__( 'Forms', 'centurion-forms-text-domain' ),
		__( 'Forms', 'centurion-forms-text-domain' ),
		'edit_posts',
		'nr-wp-centurion-forms-api',
		function () {
			?>

            <style>
                :root {
                    --card-padding: 24px;
                    --card-height: 390px;
                    --card-skeleton: linear-gradient(lightgrey var(--card-height), transparent 0);
                    --avatar-size: 32px;
                    --avatar-position: 180px 80px;
                    --avatar-skeleton: radial-gradient(circle 16px at center, white 99%, transparent 0);
                    --title-height: 16px;
                    --title-width: 60px;
                    --title-position: 90px 30px;
                    --title-skeleton: linear-gradient(white var(--title-height), transparent 0);
                    --desc-line-height: 16px;
                    --desc-line-skeleton: linear-gradient(white var(--desc-line-height), transparent 0);
                    --desc-line-1-width: 60px;
                    --desc-line-1-position: 165px 30px;
                    --desc-line-2-width: 60px;
                    --desc-line-2-position: 240px 30px;
                    --footer-height: 140px;
                    --footer-position: 0 70px;
                    --footer-skeleton: linear-gradient(white var(--footer-height), transparent 0);
                    --blur-width: 200px;
                    --blur-size: var(--blur-width) calc(var(--card-height) - var(--footer-height))
                }

                [v-cloak] {
                    width: 380px;
                    height: var(--card-height);
                    position: relative;
                    margin: auto !important;
                    transform: translatey(200px)
                }

                [v-cloak]:empty::after {
                    content: "";
                    display: block;
                    width: 100%;
                    height: 100%;
                    border-radius: 6px;
                    box-shadow: 0 10px 45px rgba(0, 0, 0, .1);
                    background-image: linear-gradient(90deg, rgba(211, 211, 211, 0) 0, rgba(211, 211, 211, .8) 50%, rgba(211, 211, 211, 0) 100%), var(--title-skeleton), var(--desc-line-skeleton), var(--desc-line-skeleton), var(--avatar-skeleton), var(--footer-skeleton), var(--card-skeleton);
                    background-size: var(--blur-size), var(--title-width) var(--title-height), var(--desc-line-1-width) var(--desc-line-height), var(--desc-line-2-width) var(--desc-line-height), var(--avatar-size) var(--avatar-size), 100% var(--footer-height), 100% 100%;
                    background-position: -150% 0, var(--title-position), var(--desc-line-1-position), var(--desc-line-2-position), var(--avatar-position), var(--footer-position), 0 0;
                    background-repeat: no-repeat;
                    animation: loading 1.5s infinite
                }

                @keyframes loading {
                    to {
                        background-position: 350% 0, var(--title-position), var(--desc-line-1-position), var(--desc-line-2-position), var(--avatar-position), var(--footer-position), 0 0
                    }
                }

                #update-nag, .update-nag {
                    display: none !important;
                }
            </style>
            <div class="nr_app_container">
                <div id="nr_centurion_forms_app" v-cloak></div>
            </div>

			<?php
		},
		'dashicons-buddicons-pm',
		1
	);
} );
