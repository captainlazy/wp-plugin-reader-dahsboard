<?php

namespace Nativerank\CenturionFormsAPI;

class CenturionAdminCSS
{
    public function __construct()
    {
        add_action('admin_head', [$this, 'css']);
    }

    public function css()
    {
        echo '<style>
        #adminmenu > li:nth-child(6) {
                background:#414042;
                border-left:6px solid #c28a2a;

        } 
        #adminmenu > li:nth-child(6) .wp-menu-image:before{
        }
        </style>';
    }
}
