<?php

namespace Nativerank\CenturionFormsAPI\EmailLeads;

use Nativerank\CenturionFormsAPI\RESTControllers\LeadController;
use function _\union;

class SendNotification {

	protected $emailHTML;
	protected $form;
	protected $entry;
	protected $nr_emails = [
		'mitchell@nativerank.com',
		'sahil@nativerank.com',
	];
	protected $to = [
		'Become a Dealer'                  => [
			'mgibbs@centurion-supreme.com',
			'AMauzy@centurion-supreme.com'
		],
		'Share Your Story'                 => [
			'zkuykendall@centurion-supreme.com',
		],
		'Contact A Dealer - International' => [
			'AMauzy@centurion-supreme.com',
			'TNurmi@correctcraft.com',
			'WFurze@correctcraft.com',
		],
		'default'                          => [
			'mgibbs@centurion-supreme.com',
			'AMauzy@centurion-supreme.com',
			'zkuykendall@centurion-supreme.com',
			'PJones@centurion-supreme.com',
		]
	];

	const NR_CENTURION_FORMS_API_NOTIFY_NR = 'nr_1055_centurion_forms_api_notify_nr';

	public function __construct( $entry, $emailHTML ) {
		$this->form      = $entry['leadTypeName'];
		$this->entry     = $entry;
		$this->emailHTML = $emailHTML;
		$this->send();

	}

	private function prepareEmail() {
		ob_start();
		?>
		<?= include 'emailTemplate.php' ?>
		<?php
		return ob_get_clean();
	}

	private function send() {
		$email = [];


		$email['to'] = $this->to['default'];
		foreach ( $this->to as $form_name => $email_addresses ) {
			if ( strtolower( $form_name ) === strtolower( $this->form ) ) {
				$email['to'] = $email_addresses;
			}
		}

		if ( isset( $this->entry['additional_emails_vue_app'] ) ) {
			$email['to'] = in_array( $this->form, LeadController::$AIMBASE_FORMS ) ? $this->entry['additional_emails_vue_app'] : union( $email['to'], $this->entry['additional_emails_vue_app'] );
		}

		if ( get_option( self::NR_CENTURION_FORMS_API_NOTIFY_NR ) ) {
			$email['to'] = array_merge( $email['to'], $this->nr_emails );
		}

		$email['subject']   = "New Entry: {$this->form}";
		$email['message']   = $this->prepareEmail();
		$email['headers']   = array( 'Content-Type: text/html; charset=UTF-8' );
		$email['headers'][] = "Reply-To: " . $this->entry['emailAddress'];
		add_filter( 'wp_mail_content_type', function () {
			return "text/html";
		} );

		wp_mail( $email['to'], $email['subject'], $email['message'], $email['headers'] );
	}


}
