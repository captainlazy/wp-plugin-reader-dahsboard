<?php

namespace Nativerank\CenturionFormsAPI\EmailLeads;

use function _\startCase;

class CaptureLead {
	protected $lead;
	protected $entry;
	protected $form;
	protected $pluginlog;


	function __construct() {
		$this->pluginlog = NR_CENTURION_FORMS_API_PLUGIN_PATH . 'error.log';
		$this->lead      = (object) [];
		$this->capture();
	}


	public function handleLead( $entry ) {
		$this->lead = (object) array( 'lead' => $entry );
	}

	public function sendNotification( $entry ) {
		ob_start();
		foreach ( $entry as $field => $value ) {
			if ( strtoupper( $field ) !== 'UNTITLED' && strtoupper( $field ) !== 'ADDITIONAL_EMAILS_VUE_APP' ) {
				?>

                <tr>
                    <td align="center" style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:15px;font-weight:600;line-height:1;text-align:center;color:#2395F3;">
							<?= startCase( $this->removePrefixes( $field ) ) ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <div style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:18px;font-weight:600;line-height:1;text-align:center;color:#494949;">
							<?= is_array($value) ? implode('<br>', $value) : $value ?>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="font-size:0px;padding:10px 25px;word-break:break-word;">
                        <p style="border-top:dashed 1px lightgrey;font-size:1;margin:0px auto;width:100%;"></p>
                        <!--[if mso | IE]>
						<table
								align="center" border="0" cellpadding="0" cellspacing="0"
								style="border-top:dashed 1px lightgrey;font-size:1;margin:0px auto;width:548px;"
								role="presentation" width="548px">
							<tr>
								<td style="height:0;line-height:0;">
									&nbsp;
								</td>
							</tr>
						</table>
						<![endif]-->
                    </td>
                </tr>


				<?php

			}

		}

		$body = ob_get_clean();
		new SendNotification( $entry, $body );
	}

	private function removePrefixes( $string ) {
		return str_replace( [ 'customData.', 'Products.0.' ], '', $string );

	}


	private function capture() {
		add_action( 'nr_1055_centurion_forms_api_new_email_lead', array( $this, 'handleLead' ), 10, 1 );
		add_action( 'nr_1055_centurion_forms_api_new_email_lead', array( $this, 'sendNotification' ), 10, 1 );
	}

}
