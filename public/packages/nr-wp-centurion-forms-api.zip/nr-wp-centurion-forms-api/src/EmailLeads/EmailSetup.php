<?php

namespace Nativerank\CenturionFormsAPI\EmailLeads;

class EmailSetup {

	protected $nrSMTPSettings;
	protected $pluginlog;

	function __construct() {
		$this->pluginlog = NR_CENTURION_FORMS_API_PLUGIN_PATH . 'error.log';

		$this->nrSMTPSettings = (object) array(
			"host"         => "smtp.sendgrid.net",
			"port"         => "587",
			"username"     => "apikey",
			"password"     => "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",
			"encryption"   => "tls",
			"auth_mode"    => null,
			"from_name"    => "Native Rank Digital Solution",
			"from_address" => "platform@nativerank.com"
		);

		$this->setupSMTP();
	}

	public function smptpEmailSettings( $phpmailer ) {
		$SMTP = $this->nrSMTPSettings;
		$phpmailer->isSMTP();
		$phpmailer->SMTPOptions = array(
			'ssl' => array(
				'verify_peer'       => false,
				'verify_peer_name'  => false,
				'allow_self_signed' => true
			)
		);
		$phpmailer->Host        = $SMTP->host;
		$phpmailer->SMTPAuth    = true;
		$phpmailer->Port        = $SMTP->port;
		$phpmailer->Username    = $SMTP->username;
		$phpmailer->Password    = $SMTP->password;
		$phpmailer->SMTPSecure  = $SMTP->encryption;
		$phpmailer->From        = $SMTP->from_address;
		$phpmailer->FromName    = $SMTP->from_name;
	}

	private function setupSMTP() {

		add_action( 'phpmailer_init', array( $this, 'smptpEmailSettings' ) );

		add_action( 'wp_mail_failed', array( $this, 'logError' ), 10, 1 );
	}

	public function logError( $wp_error ) {
		if ( ! is_string( $wp_error ) ) {
			$wp_error = json_encode( $wp_error );
		}

		$date    = date( 'l jS \of F Y h:i:s A' );
		$message = "[$date] " . $wp_error . PHP_EOL;

		error_log( $message, 3, $this->pluginlog );
	}

}
