<?php

namespace Nativerank\CenturionFormsAPI\Aimbase {

	class ApiException extends \Exception {
		protected $message = 'Unknown exception';     // Exception message
		private $string;                            // Unknown
		protected $code = 0;                       // User-defined exception code
		protected $file;                              // Source filename of exception
		protected $line;                              // Source line of exception
		private $trace;                             // Unknown

		public function __construct( $response ) {
			$message = "Unknown Aimbase API Exception";

			if ( $response['data'] ) {
				if ( is_string( $response['data'] ) ) {
					$message = $response['data'];
				} else {
					$message = $response['data']['Message'];
				}
			}
			parent::__construct( $message, $response['status'] );
		}

		public function __toString() {
			return get_class( $this ) . " {$this->code}: '{$this->message}' in {$this->file}({$this->line})\n" . "{$this->getTraceAsString()}";
		}
	}
}
