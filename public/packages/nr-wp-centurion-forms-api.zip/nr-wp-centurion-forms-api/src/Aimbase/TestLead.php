<?php


namespace Nativerank\CenturionFormsAPI\Aimbase;


use DateTime;
use DateTimeZone;

class TestLead {


	public function __construct() {

		register_rest_route( NR_CENTURION_FORMS_API_REST_NAMESPACE, '/test_lead/', array(
			'methods'  => 'POST',
			'callback' => [ $this, 'test' ]
		) );
	}

	public function test() {
		return ( new Lead( [
			'brands'                      => "CTRN",
			'leadSourceName'              => "Organic",
			'leadTypeName'                => "Build a Boat",
			'leadCategoryName'            => "centurionboats.com",
			'firstName'                   => "Sahil",
			'lastName'                    => "Khanna",
			'postalCode'                  => "80204",
			'countryCode'                 => "US",
			'emailAddress'                => "sahil.khanna@nativerank.com",
			'address1'                    => "1150 Auraria Pkwy.",
			'city'                        => "Denver",
			'state'                       => "CO",
			'receiveEmailCampaigns'       => false,
			'comment'                     => "This is a test comment.",
			'serializedCustomData'        => '[{"FieldName":"scheme","FieldValue":"Core"},{"FieldName":"Hull Main Front","FieldValue":"Centurion Gelcoat Pink Ribbon"},{"FieldName":"Tower Scheme","FieldValue":"Battle Advance"},{"FieldName":"Two Tone Accent","FieldValue":"Centurion Gelcoat Canadian Blue MF"}]',
			'isCommunicationOptIn'        => true,
			'communicationOptInIpAddress' => '127.0.0.1',
			'communicationOptInDate'      => ( new DateTime( null, new DateTimeZone( 'UTC' ) ) )->format( DateTime::ATOM ),
			'referrer'                    => 'https://www.centurionboats.com/test-ride/?utm_source=Email'
		] ) )->toJson();
	}

}

