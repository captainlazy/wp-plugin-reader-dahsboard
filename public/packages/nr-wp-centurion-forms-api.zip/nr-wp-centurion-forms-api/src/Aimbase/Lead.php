<?php

namespace Nativerank\CenturionFormsAPI\Aimbase;

use DateTime;
use DeviceDetector\DeviceDetector;
use Nativerank\CenturionFormsAPI\RESTControllers\LeadController;
use function _\map;
use function dot;

class Lead {

	////////////////////////////////////////////////////////////
	// Configuration
	////////////////////////////////////////////////////////////
	public static $REQUIRED_ATTRIBS = [
		// 'internalAttribName' => 'JsonPropertyName'
		'brands'               => 'Brands',
		'leadSourceName'       => 'LeadSourceName',
		'leadTypeName'         => 'LeadTypeName',
		'leadCategoryName'     => 'LeadCategoryName',
		'firstName'            => 'FirstName',
		'lastName'             => 'LastName',
		'postalCode'           => 'PostalCode',
		'countryCode'          => 'CountryCode',
		'emailAddress'         => 'Email',
		'isCommunicationOptIn' => 'IsCommunicationOptIn'
	];

	public static $CONSTANT_REQUIRED_ATTRIBS = [
		'brands'           => 'CTRN',
		'leadCategoryName' => 'centurionboats.com',
		'countryCode'      => 'US',
		'postalCode'       => '00000',
		'products'         => [
			[
				'ProductCode'      => 'Vi22',
				'ProductModelYear' => '2020'
			]
		],
	];

	public static $OPTIONAL_ATTRIBS = [
		// 'internalAttribName' => 'JsonPropertyName'
		'leadEventName'               => 'LeadEventName',
		'leadCampaignName'            => 'LeadCampaignName',
		'address1'                    => 'Address1',
		'address2'                    => 'Address2',
		'city'                        => 'City',
		'state'                       => 'State',
		'district'                    => 'District',
		'homePhone'                   => 'HomePhone',
		'mobilePhone'                 => 'MobilePhone',
		'workPhone'                   => 'WorkPhone',
		'receiveEmailCampaigns'       => 'ReceiveEmailCampaigns',
		'receiveSmsCampaigns'         => 'ReceiveSmsCampaigns',
		'receiveNewsletter'           => 'ReceiveNewsletter',
		'products'                    => 'Products',
		'dealerId'                    => 'DealerId',
		'dealerNumber'                => 'DealerNumber',
		'comment'                     => 'Comment',
		'exactTargetOptInListIds'     => 'ExactTargetOptInListIds',
		'exactTargetCustomAttributes' => 'ExactTargetCustomAttributes',
		'customData'                  => 'Customs',
		'userUid'                     => 'UserUid',
		'sessionUid'                  => 'SessionUid',
		'communicationOptInIpAddress' => 'CommunicationOptInIpAddress',
		'communicationOptInDate'      => 'CommunicationOptInDate',
		'communicationOptInSource'    => 'CommunicationOptInSource',
		'listCodes'                   => 'ListCodes',
	];

	public static $VALID_VALUES = [
		'brands' => [
			"CTRN",
			"SUPR"
		],

		'leadTypeName' => [
			"Request Brochure Mail",
			"Request Brochure Download",
			"Contact a Dealer",
			"Find a Dealer",
			"Request Quote",
			"Schedule a Test Drive",
			"Build a Boat",
			"Trade In",
			"Request Factory Tour",
			"General Contact",
			"Best Christmas Ever"
		],

		'leadCategoryName' => [
			"centurionboats.com",
			"supremetowboats.com",
			"supremechristmas.com",
			"centurionchristmas.com"
		]
	];

	public static $KEY_SWITCHES = [
		'form_name' => 'leadTypeName',
		'ip'        => 'communicationOptInIpAddress',
		'referrer'  => 'communicationOptInSource',
	];

	////////////////////////////////////////////////////////////
	// Members
	////////////////////////////////////////////////////////////
	public $attribs;


	////////////////////////////////////////////////////////////
	// Construction
	////////////////////////////////////////////////////////////

	/*
	 * Construct an AvalaLead object.
	 *
	 * The $attribs param is a key/value hash of the following
	 * properties:
	 *
	 *   'brands'                       // required
	 *   'leadSourceName'               // required
	 *   'leadTypeName'                 // required
	 *   'leadCategoryName'             // required
	 *   'firstName'                    // required
	 *   'lastName'                     // required
	 *   'address1'
	 *   'address2'
	 *   'city'
	 *   'state'
	 *   'countryCode'                  // required
	 *   'district'
	 *   'postalCode'                   // required
	 *   'emailAddress'                 // required
	 *   'homePhone'
	 *   'mobilePhone'
	 *   'workPhone'
	 *   'receiveEmailCampaigns'        // optional boolean
	 *   'receiveSmsCampaigns'          // optional boolean
	 *   'receiveNewsletter'            // optional boolean
	 *   'productCode'
	 *   'productIdList'                // optional comma-separated list of product IDs
	 *   'dealerId'
	 *   'dealerNumber'                 // optional OEM dealer identifier
	 *   'comment'
	 *   'exactTargetOptInListIds'
	 *   'exactTargetCustomAttributes'
	 *   'userUid'
	 *   'sessionUid'
	 *   'customData'                   // optional hash of key/value pairs
	 */
	public function __construct( array $attribs ) {
		$this->attribs = $attribs;

		$this->getUserAgentInfo();

		$this->switchKeys();
		$this->formatAttributesByKey();

		if ( in_array( $this->attribs['leadTypeName'], LeadController::$AIMBASE_FORMS ) ) {
			$this->checkForDotNotationAndConvertToArray();

			if ( isset( $this->attribs['serializedCustomData'] ) ) {
				$this->attribs['customData'] = array_merge( $this->attribs['customData'] ?? [], json_decode( $this->attribs['serializedCustomData'], true ) );
			}

			$this->removeEmptyValues( 'customData' );

			$this->removeEmptyValues( 'products' );

			$this->attribs = array_merge( self::$CONSTANT_REQUIRED_ATTRIBS, $this->attribs );

			if ( ! isset( $this->attribs['leadSourceName'] ) || empty( $this->attribs['leadSourceName'] ) ) {
				$this->attribs['leadSourceName'] = 'Organic';
			}

			$this->attribs['isCommunicationOptIn'] = ( $this->attribs['isCommunicationOptIn'] ?? 0 ) == 1;

			if ( ! isset( $this->attribs['communicationOptInDate'] ) ) {
				$this->attribs['communicationOptInDate'] = ( new DateTime() )->format( 'Y-m-d' );
			}

			$this->validate();
		}


	}



	////////////////////////////////////////////////////////////
	// Instance Methods
	////////////////////////////////////////////////////////////

	/*
	 * Throws Exception if the object's properties are not valid.
	 */
	public function validate() {

		// Verify that all required attributes are set
		foreach ( self::$REQUIRED_ATTRIBS as $requiredAttrib => $discard ) {
			$val = @$this->attribs[ $requiredAttrib ];
			// Required attribute not set, or an empty value other than a boolean false? That's an error.
			if ( ! isset( $val ) || ( empty( $val ) && ( $val !== false ) ) ) {
				throw new \Exception( "Missing required attribute '$requiredAttrib'" );
			}
		}

		// For each attribute that has a set of valid values,
		// validate the current values against those.
		foreach ( self::$VALID_VALUES as $attribName => $supportedValues ) {
			$val = $this->attribs[ $attribName ];
			if ( ! in_array( $val, $supportedValues ) ) {
				throw new \Exception( "Attribute '$attribName' has invalid value '$val'" );
			}
		}
	}

	private function getUserAgentInfo() {
		if ( isset( $this->attribs['user_agent'] ) ) {
			$userAgent = $this->attribs['user_agent'];

			$dd = new DeviceDetector( $userAgent );

			$dd->parse();

			$userAgentInfo['UA - Browser']          = $dd->getClient( 'name' );
			$userAgentInfo['UA - Operating System'] = $dd->getOs( 'name' );
			$userAgentInfo['UA - Device']           = $dd->getDeviceName();

			foreach ( $userAgentInfo as $userAgentKey => $userAgentValue ) {
				$this->attribs["customData.{$userAgentKey}"] = $userAgentValue;
			}
		}
	}

	private function formatAttributesByKey() {
		foreach ( $this->attribs as $attribKey => $attrib ) {
			switch ( $attribKey ) {
				case 'communicationOptInSource':
					$this->attribs[ $attribKey ] = substr( parse_url( $attrib, PHP_URL_PATH ), 0, 40 );
					break;
			}
		}

	}

	private function switchKeys() {
		foreach ( $this->attribs as $attribKey => $attrib ) {
			if ( isset( self::$KEY_SWITCHES[ $attribKey ] ) ) {
				$key_switch = self::$KEY_SWITCHES[ $attribKey ];
				if ( is_array( $key_switch ) ) {
					foreach ( $key_switch as $new_key ) {
						$this->attribs[ $new_key ] = $attrib;
					}
					unset( $this->attribs[ $attribKey ] );
					continue;
				}
				$this->attribs[ $key_switch ] = $attrib;
				unset( $this->attribs[ $attribKey ] );
			}
		}

	}

	private function checkForDotNotationAndConvertToArray() {
		$dot        = dot( $this->attribs );
		$removeKeys = [];
		foreach ( $this->attribs as $attribKey => $attrib ) {
			if ( strpos( $attribKey, '.' ) > 0 ) {
				$removeKeys[] = $attribKey;

				$dot->set( $attribKey, $attrib );
			}
		}
		$this->attribs = $dot->all();

		foreach ( $removeKeys as $remove_key ) {
			if ( isset( $params[ $remove_key ] ) ) {
				unset( $params[ $remove_key ] );
			}
		}

		return $this;
	}

	private function removeEmptyValues( $attribKey ) {
		if ( isset( $this->attribs[ $attribKey ] ) ) {
			foreach ( $this->attribs[ $attribKey ] as $key => $value ) {
				if ( is_array( $value ) ) {
					foreach ( $value as $nestedKey => $nestedValue ) {
						if ( empty( $nestedValue ) ) {
							if ( $nestedKey === 'FieldValue' ) {
								unset( $this->attribs[ $attribKey ][ $key ] );
							} else {
								unset( $this->attribs[ $attribKey ][ $key ][ $nestedKey ] );
							}
						}
					}
				}
				if ( empty( $this->attribs[ $attribKey ][ $key ] ) ) {
					unset( $this->attribs[ $attribKey ][ $key ] );
				}
			}
			if ( empty( $this->attribs[ $attribKey ] ) ) {
				unset( $this->attribs[ $attribKey ] );
			}
		}
	}

	public
	function getAttribs() {
		return $this->attribs;
	}

	public function asHash() {
		$hash = [];

		// Gather all required attributes.
		foreach ( self::$REQUIRED_ATTRIBS as $internalAttribName => $jsonAttribName ) {
			$hash[ $jsonAttribName ] = $this->attribs[ $internalAttribName ];
		}

		// Gather all optional attributes if they are set.
		foreach ( self::$OPTIONAL_ATTRIBS as $internalAttribName => $jsonAttribName ) {
			$value = @$this->attribs[ $internalAttribName ];
			if ( isset( $value ) && ! empty( $value ) ) {

				// Special case for the customData attribute
				if ( $internalAttribName == 'customData' ) {
					// Reformat it to an array of hashes
					$value = map( $value, function ( $fieldValue, $fieldName ) {
						return is_array( $fieldValue ) && isset( $fieldValue['FieldName'] ) ? $fieldValue : [
							'FieldName'  => $fieldName,
							'FieldValue' => $fieldValue
						];
					} );
				}

				$hash[ $jsonAttribName ] = $value;
			}
		}

		return $hash;
	}

	/**
	 * @return false|string
	 */
	public function toJson() {
		return json_encode( $this->asHash() );
	}
}
