<?php

namespace Nativerank\CenturionFormsAPI\Aimbase;

use Nativerank\CenturionFormsAPI\Notification\Email\LeadFailed;
use function _\head;

require_once 'ApiException.php';

class ApiClient {

	////////////////////////////////////////////////////////////
	// Configuration
	////////////////////////////////////////////////////////////
	const DEBUG_LOGGING_ENABLED = 'error_log';  // echo | error_log | none

	const LOGIN_URL = "/api/security/login";
	const CREATE_LEAD_URL = "/marketing/api/lead?manufacturer=<manufacturerCode>";
	const DEALER_SEARCH_URL = "/marketing/api/LocatedDealerSearch?manufacturer=<manufacturerCode>";
	const RESULTS_PAGE_SIZE = 10;


	////////////////////////////////////////////////////////////
	// Members
	////////////////////////////////////////////////////////////
	private $token = null;
	private $baseUrl = null;
	private $manufacturerCode = null;


	////////////////////////////////////////////////////////////
	// Construction
	////////////////////////////////////////////////////////////
	public function __construct( $baseUrl, $manufacturerCode ) {
		$this->baseUrl          = $baseUrl;
		$this->manufacturerCode = $manufacturerCode;
	}


	////////////////////////////////////////////////////////////
	// Public API Methods
	////////////////////////////////////////////////////////////
	public function login( $username, $password ) {
		$response = $this->post(
			$this->baseUrl . self::LOGIN_URL,
			[
				"Username" => $username,
				"Password" => $password
			]
		);

		// NOTE: API returns the token in the form of username:token:garbage. I
		//       think the ":garbage" suffix is a bug on their end since
		//       their docs don't include it. The auth header wants username:token
		//       so we will just split by ':' and rejoin just the first two
		//       pieces. That should be safe against now or future changes to
		//       fix the garbage.
		$this->token = join( ':', array_slice( explode( ':', $response['data'] ), 0, 2 ) );
	}


	/**
	 * @param Lead $lead
	 *
	 * @return array
	 * @throws ApiException
	 */
	public function createLead( Lead $lead ) {
		$url = str_replace(
			'<manufacturerCode>',
			$this->manufacturerCode,
			$this->baseUrl . self::CREATE_LEAD_URL
		);

		return $this->post( $url, [ $lead->asHash() ] );
	}

	public function searchForDealers( $searchTerms ) {
		$brandCode   = $searchTerms['brandCode'];
		$countryCode = $searchTerms['countryCode'];
		$postalCode  = $searchTerms['postalCode'];
		$state       = $searchTerms['state'];

		$url = str_replace(
			'<manufacturerCode>',
			$this->manufacturerCode,
			$this->baseUrl . self::DEALER_SEARCH_URL
		);

		$terms = [
			"ManufacturerCode"        => $this->manufacturerCode,
			"BrandCode"               => $brandCode,
			"CountryCode"             => $countryCode,
			"IncludeAllInDealerGroup" => true
		];
		if ( $postalCode ) {
			$terms['PostalCode'] = $postalCode;
		}
		if ( $state ) {
			$terms['State'] = $state;
		}

		$searchParams = [
			"Skip"  => "0",
			"Take"  => "" . self::RESULTS_PAGE_SIZE,
			"Terms" => $terms
		];

		$response = $this->post( $url, $searchParams );
		$dealers  = array_slice( $response['data'], 0, 15 ); // Max 15 results

		// TODO: Make a Dealer model object?
		return $dealers;
	}


	////////////////////////////////////////////////////////////
	// Internal Helpers
	////////////////////////////////////////////////////////////
	protected function log( $str ) {
		switch ( self::DEBUG_LOGGING_ENABLED ) {
			case 'echo':
				echo $str . "\n";
				break;

			case 'error_log':
				error_log( $str );
				break;
		}
	}

	/**
	 * @param $url
	 * @param $requestData
	 *
	 * @return array
	 * @throws ApiException
	 */
	protected function post( $url, $requestData ) {
		$postBody = json_encode( $requestData );

		$headers = [
			"Accept: application/json",
			"Content-Type: application/json",
			"Content-Length: " . strlen( $postBody )
		];

		if ( isset( $this->token ) ) {
			array_unshift( $headers, "Authenticate: Avala-Api {$this->token}" );
		}

		$curl = curl_init();
		curl_setopt_array(
			$curl,
			[
				CURLOPT_RETURNTRANSFER => 1,
				CURLOPT_POST           => 1,
				CURLOPT_URL            => $url,
				CURLOPT_HTTPHEADER     => $headers,
				CURLOPT_POSTFIELDS     => $postBody
			]
		);
		$body   = curl_exec( $curl );
		$status = curl_getinfo( $curl, CURLINFO_HTTP_CODE );
		curl_close( $curl );

		$responseData = json_decode( $body, true );
		if ( ! isset( $responseData ) ) {
			$responseData = $body;
		}

		$response = [
			"data"   => $responseData,
			"status" => $status
		];

		if ( ( $response['status'] >= 200 ) && ( $response['status'] < 400 ) ) {
			// Treat 200s and 300s as success. If we see that we get
			// redirects in the 300 level, we'll split it out and handle
			// those with CURLOPT_FOLLOWLOCATION=true and CURLOPT_CUSTOMREQUEST="POST"

			// If this is a lead submission request, check for success message in response
			if ( isset( $response['data']['LeadResponseRecords'] ) ) {
				$record = head( $response['data']['LeadResponseRecords'] );
				if ( ! isset( $record['Status'] ) || $record['Status'] !== 'Success' ) {
					( new LeadFailed( print_r( $response, true ) ) )->send();
				}
			}

			return $response;
		} else {
			// If we don't get any error message out of the
			// API failure, try to create a default one based
			// on status code.
			if ( empty( $response['data'] ) ) {
				switch ( $response['status'] ) {
					case 401:
						$response['data'] = "Unauthorized";
						break;

					case 500:
						$response['data'] = "Unknown Server Error";
						break;

					case 502:
					case 503:
					case 504:
						$response['data'] = "Server Unavailable";
						break;
				}
			}

			$this->log( "AIMBASE API ERROR:" );
			$this->log( "------------------" );
			$this->log( print_r( $response, true ) );
			$this->log( "\n" );

			$response['entry'] = $requestData;

			( new LeadFailed( print_r( $response, true ) ) )->send();

			throw new ApiException( $response );
		}
	}
}

