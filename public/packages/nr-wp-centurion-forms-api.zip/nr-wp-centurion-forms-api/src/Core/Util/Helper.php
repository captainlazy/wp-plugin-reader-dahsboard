<?php

namespace Nativerank\CenturionFormsAPI\Core\Util;

use Closure;

class Helper {
	static function strip_url( $url ) {
		if ( empty( $url ) ) {
			return '';
		}

		$url = parse_url( trim( strtolower( $url ) ) );
		if ( ! isset( $url['host'] ) ) {
			$url = $url['path'];
			$re  = '/^(?:www\.)?(.*?)($|\/)/mi';
			preg_match_all( $re, $url, $matches, PREG_SET_ORDER, 0 );
			$url = $matches[0][1];
		} else {
			$url = str_replace( 'www.', '', $url['host'] );
		}

		return $url;
	}


	/**
	 * Removes an item from the array and returns its value.
	 *
	 * @param array $arr The input array
	 * @param String $key The key pointing to the desired value
	 *
	 * @return String|array|object|null The value mapped to $key or null if none
	 */
	static function array_remove_key( array &$arr, $key ) {
		if ( array_key_exists( $key, $arr ) ) {
			$val = $arr[ $key ];
			unset( $arr[ $key ] );

			return $val;
		}

		return null;
	}

	static function getHelpers( $helpers ) {
		$HelperClassMethods = get_class_methods( self::class );
		foreach ( $HelperClassMethods as $method ) {
			$key = array_search( $method, $helpers );
			if ( $key !== false ) {
				if ( function_exists( self::class . "::{$method}" ) ) {
					$helpers[ $method ] = Closure::fromCallable( self::class . "::{$method}" );
				}
				unset( $helpers[ $key ] );
			}
		}

		return $helpers;
	}

	/**
	 * Stolen from Typerocket v4
	 * Sanitize Underscore
	 *
	 * Remove all special characters and replace spaces and dashes with underscores
	 * allowing only a single underscore after trimming whitespace form string and
	 * lower casing
	 *
	 * ` --"2_ _e''X  AM!pl'e-"-1_@` -> _2_ex_ample_1_
	 *
	 * @param string $name
	 * @param bool $keep_dots
	 *
	 * @return mixed|string
	 */
	public static function sanitize_underscore( $name, $keep_dots = false ) {
		if ( is_string( $name ) ) {

			if ( $keep_dots ) {
				$name = preg_replace( '/[\.]+/', '.', $name );
				$name = preg_replace( "/[^A-Za-z0-9\.\\s\\-\\_?]/", '', strtolower( trim( $name ) ) );
			} else {
				$name = preg_replace( '/[\.]+/', '_', $name );
				$name = preg_replace( "/[^A-Za-z0-9\\s\\-\\_?]/", '', strtolower( trim( $name ) ) );
			}


			$name = preg_replace( '/[-\\s]+/', '_', $name );
			$name = preg_replace( '/_+/', '_', $name );
		}

		return $name;
	}

}
