<?php


namespace Nativerank\CenturionFormsAPI\LeadDatabase;

use Nativerank\CenturionFormsAPI\Database\Migrations;

class EntryCreator {

	private $leadJson;
	private $response;
	private $formName;
	private $entryId = null;

	/**
	 * EntryCreator constructor.
	 *
	 * @param string $leadJson
	 * @param $response
	 * @param string $formName
	 * @param int|null $entryId
	 */
	public function __construct( string $leadJson, $response, string $formName, int $entryId = null ) {
		$this->leadJson = $leadJson;
		$this->response = $response;
		$this->formName = $formName;
		$this->entryId  = $entryId;
	}

	/**
	 * @return int|null
	 */
	public function store() {
		global $wpdb;

		$table = $wpdb->prefix . Migrations::TABLE_NAME;

		$timestamp = ( new \DateTime() )->getTimestamp();

		$data = [
			'form_name'  => esc_sql( $this->formName ),
			'entry_data' => esc_sql( $this->leadJson ),
			'created'    => $timestamp
		];

		if(!empty($this->response)) {
			$data['response']   = esc_sql( $this->response );
		}

		if ( $this->entryId !== null ) {
			$data['entry_id'] = $this->entryId;
			$result = $wpdb->update( $table, $data, [ 'entry_id' => $this->entryId ] );

			if($result != false) {
				return $this->entryId;
			}
		}

		$data['raw_entry_data'] = esc_sql( $this->leadJson );
		$wpdb->insert( $table, $data );

		return $wpdb->insert_id;
	}

}