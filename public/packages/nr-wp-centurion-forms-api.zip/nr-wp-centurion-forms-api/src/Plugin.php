<?php


namespace Nativerank\CenturionFormsAPI;

use Nativerank\CenturionFormsAPI\Aimbase\TestLead;
use Nativerank\CenturionFormsAPI\Core\Util\Scheduler;
use Nativerank\CenturionFormsAPI\EmailLeads\CaptureLead;
use Nativerank\CenturionFormsAPI\EmailLeads\EmailSetup;
use Nativerank\CenturionFormsAPI\EmailLeads\SendNotification;
use Nativerank\CenturionFormsAPI\RESTControllers\LeadController;
use Nativerank\CenturionFormsAPI\CenturionAdminCSS;
use Puc_v4_Factory;

/**
 * Class Plugin
 * @package Nativerank\CenturionFormsAPI
 */
class Plugin {

	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 */
	public function __construct( $main_file ) {
		$this->context = new Context( $main_file );
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context() {
		return $this->context;
	}

	/**
	 * Registers the plugin with WordPress.
	 */
	public function register() {

		// Register CTP & CTT
		$this->customPostTypes();

		// Register any other classes
		$this->classes();

		add_action( 'wp_ajax_action_update_forms_api_notify_nr_setting', array( $this, 'update_notify_nr_setting' ) );
		add_action( 'wp_ajax_action_get_forms_api_notify_nr_setting', array( $this, 'get_notify_nr_setting' ) );

		do_action( 'nr_centurion_forms_api_init' );
	}

	public function get_notify_nr_setting() {
		$notifyNR            = get_option( SendNotification::NR_CENTURION_FORMS_API_NOTIFY_NR );
		$response['message'] = 'success';
		$response['code']    = $notifyNR;

		echo json_encode( $response );
		wp_die();
	}

	public function update_notify_nr_setting() {
		$value               = $_POST['value'];
		$result              = update_option( SendNotification::NR_CENTURION_FORMS_API_NOTIFY_NR, $value );
		$response['message'] = 'success';
		$response['code']    = $result;

		echo json_encode( $response );
		wp_die();
	}

	public function update_checker() {
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_CENTURION_FORMS_API_DIR_NAME,
			NR_CENTURION_FORMS_API_PLUGIN_MAIN_FILE,
			NR_CENTURION_FORMS_API_DIR_NAME
		);
	}

	/**
	 * Register Custom Post Types and Taxonomies
	 */
	public function customPostTypes() {
		// TODO: rework nr-wp-plugin-boilerplate's CPT and CTT classes to make creating CPT and CTT easier, but without typerocket
	}

	/**
	 * @return array
	 */
	public function classes() {
		return [
			( new Scheduler() ),
			( new CaptureLead() ),
			( new EmailSetup() ),
			( new CenturionAdminCSS() ),
		];
	}

	public function rest_routes() {
		return [
			( new LeadController() ),
			( new TestLead() ),
		];
	}

	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR BP PLUGIN NAME instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load( $main_file ) {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static( $main_file );

		// register plugin after plugin is activated
		add_action( 'init', [ static::$instance, 'register' ], 100 );
		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ] );
		add_action( 'rest_api_init', [ static::$instance, 'rest_routes' ] );

		return true;
	}

}
