<?php

namespace Nativerank\CenturionFormsAPI\Notification\Email;

class LeadFailed extends Email {

	protected $to = [ 'websupport@nativerank.com', ];
	protected $subject = 'Centurion Boats - Lead Delivery Failed';

}