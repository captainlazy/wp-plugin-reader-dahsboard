<?php


namespace Nativerank\CenturionFormsAPI\Notification\Email;


class Email {

	protected $to;
	protected $message;
	protected $subject = 'Centurion Boats - ';


	public function __construct( $message ) {
		$this->message = $message;
	}

	public function send() {
		date_default_timezone_set( 'America/Denver' );
		$date      = date( 'm/d/Y', time() );
		$headers   = array();
		$headers[] = 'From: Nativerank Bot for Centurion <me@example.net>';
		$headers[] = 'Reply-To: Sahil Khanna <sahil.khanna@nativerank.com>';
		$headers[] = 'Content-Type: text/html; charset=UTF-8';


		$sent = wp_mail( $this->to, $this->subject . $date, $this->message, $headers );


		$status  = ( $sent ? 200 : 404 );
		$message = ( $sent ? 'Email sent' : 'Email failed to send!' );

		return [ 'status' => $status, 'message' => $message ];

	}

}