<?php


namespace Nativerank\CenturionFormsAPI\RESTControllers;

use Nativerank\CenturionFormsAPI\Aimbase\ApiClient;
use Nativerank\CenturionFormsAPI\Aimbase\Lead;
use Nativerank\CenturionFormsAPI\LeadDatabase\EntryCreator;
use Nativerank\CenturionFormsAPI\Notification\Email\LeadFailed;

class LeadController {

	private const BASE_URL = "https://correctcraft.aimbase.com";
	private const MANUFACTURER_CODE = "FLN";
	private const USERNAME = "nativerank";
	private const PASSWORD = "skA6Y@yLDZ2Z;r\h";

	private $databaseEntryId = null;


	public static $REQUIRED_ATTRIBS = [
		'form_name',
		'firstName',
		'lastName',
		'emailAddress',
	];

	public static $AIMBASE_FORMS = [
		"Request Brochure Mail",
		"Request Brochure Download",
		"Contact a Dealer",
		"Find a Dealer",
		"Request Quote",
		"Schedule a Test Drive",
		"Build a Boat",
		"Trade In",
		"Request Factory Tour",
		"Best Christmas Ever"
	];

	public function __construct() {
		register_rest_route( NR_CENTURION_FORMS_API_REST_NAMESPACE, '/update_lead', array(
			'methods'  => 'POST',
			'callback' => [ $this, 'update' ]
		) );

		register_rest_route( NR_CENTURION_FORMS_API_REST_NAMESPACE, '/new_lead/', array(
			'methods'  => 'POST',
			'callback' => [ $this, 'process_new' ]
		) );

	}

	public function update( \WP_REST_Request $request ) {

		$params = $request->get_params();

		$params = is_string( $params['data'] ) ? json_decode( $params['data'], true ) : $params['data'];

		$params['form_name'] = $params['form_name'] ?? ( $request->get_params()['form_name'] ?? false );

		if ( isset( $params['entry_id'] ) ) {
			$this->databaseEntryId = $params['entry_id'];
			unset( $params['entry_id'] );
		}

		$this->save( $params, $params['response'] ?? null, $params['form_name'] ?? 'No form name' );

		$lead = $params;

		try {
			$lead = new Lead( $params );

			$result = $this->save( $lead, $params['response'] ?? null, $params['form_name'] ?? 'No form name' );

			$response = [
				'message' => ( $result === false || $result === null ) ? 'Failed to update entry!' : 'Entry updated!',
			];

			$status = ( $result == false || $result === null ) ? 400 : 200;

			return new \WP_Rest_Response( $response, $status );

		} catch ( \Exception $error ) {
			$errorString = $error->getCode() . " " . $error->getMessage() . "\n";
			$errorString .= $this->line_breaks_and_return_print_r( $params );

			$this->log( $errorString );

			( new LeadFailed( $errorString ) )->send();

			$response = new \WP_REST_Response( "Oops!\nForms API Error: " . $error->getCode() . " " . $error->getMessage() . "\n", 400 );

			$this->save( $lead, $response, $params['form_name'] ?? 'No form name' );

			return $response;
		}

	}

	public function process_new( \WP_REST_Request $request ) {

		$params = $request->get_params();

		$params = is_string( $params['data'] ) ? json_decode( $params['data'], true ) : $params['data'];

		$params['form_name'] = $params['form_name'] ?? ( $request->get_params()['form_name'] ?? false );

		if ( isset( $params['entry_id'] ) ) {
			$this->databaseEntryId = $params['entry_id'];
		}

		$this->save( $params, 'Initial entry addition', $params['form_name'] ?? 'No form name' );

		$valid = $this->validate( $params );
		if ( $valid !== true ) {
			return $valid;
		}

		return $this->send( $params );

	}

	/**
	 * @param $params
	 *
	 * @return bool|\WP_REST_Response
	 */
	private function validate( $params ) {
		foreach ( self::$REQUIRED_ATTRIBS as $requiredAttribute ) {
			$providedParam = @$params[ $requiredAttribute ];
			if ( ! isset( $providedParam ) || ( empty( $providedParam ) && ( $providedParam !== false ) ) ) {
				$message = "Request is missing {$requiredAttribute}, ";
				$message .= 'form name: ' . ( $params['form_name'] ?? 'No form name' );
				$message .= $this->line_breaks_and_return_print_r( $params );

				$this->log( $message );

				( new LeadFailed( $message ) )->send();

				$this->save( $params, $message, $params['form_name'] ?? 'No form name' );

				return new \WP_REST_Response( $message, 200 );
			}
		}

		return true;
	}


	private function send( $params ) {
		$lead = $params;
		try {
			$client = new ApiClient( self::BASE_URL, self::MANUFACTURER_CODE );
			$client->login( self::USERNAME, self::PASSWORD );
			$lead = ( new Lead( $params ) );

			if ( in_array( $params['form_name'], self::$AIMBASE_FORMS ) ) {
				if ( ! empty( $params['additional_emails_vue_app'] ?? [] ) ) {
					$this->email( $lead );
				}
				$response = $client->createLead( $lead );
			} else {
				$response = $this->email( $lead );
			}

			$response = new \WP_REST_Response( $response['data'] ?? '', 200 );

			$this->save( $lead, $response, $params['form_name'] ?? 'No form name' );

		} catch ( \Exception $error ) {
			$errorString = $error->getCode() . " " . $error->getMessage() . "\n";
			$errorString .= $this->line_breaks_and_return_print_r( $params );
			$this->log( $errorString );

			( new LeadFailed( $errorString ) )->send();

			$response = new \WP_REST_Response( "Oops!\nForms API Error: " . $error->getCode() . " " . $error->getMessage() . "\n", 200 );

			$this->save( $lead, $response, $params['form_name'] ?? 'No form name' );
		}

		return $response;
	}

	private function email( Lead $lead ) {
		$leadToEmail = $lead->getAttribs();

		if ( isset( $leadToEmail['user_agent'] ) ) {
			unset( $leadToEmail['user_agent'] );
		}

		do_action( 'nr_1055_centurion_forms_api_new_email_lead', $leadToEmail );
		$response['data']   = 'Lead sent via email';
		$response['status'] = 200;

		return $response;
	}

	/**
	 * @param $lead
	 * @param $response
	 * @param $formName
	 *
	 * @return bool|int|\Nativerank\CenturionFormsAPI\LeadDatabase\int|null
	 */
	private function save( $lead, $response, $formName ) {
		$response = $response === null ? $response : json_encode( $response );

		if ( $lead instanceof Lead ) {
			$lead = $lead->toJson();
		}

		if ( is_array( $lead ) ) {
			$lead = json_encode( $lead );
		}

		if ( $lead === false ) {
			$errorMessage = 'json_encode() returned false, ';
			$errorMessage .= $formName ?? 'no form name, ';
			$errorMessage .= 'database entry ID:' . ( $this->databaseEntryId ?? '' );
			$errorMessage .= $this->line_breaks_and_return_print_r( json_decode( $lead, true ) );

			$this->log( $errorMessage );

			( new LeadFailed( $errorMessage ) )->send();

			return false;
		}

		$entryCreator          = new EntryCreator( $lead, $response, $formName, $this->databaseEntryId );
		$this->databaseEntryId = $entryCreator->store();

		if ( $this->databaseEntryId === null ) {
			$errorMessage = "DB INSERT returned null on {$lead}";
			$errorMessage .= $formName ?? 'no form name, ';
			$errorMessage .= 'database entry ID:' . $this->databaseEntryId ?? '';
			$errorMessage .= $this->line_breaks_and_return_print_r( json_decode( $lead, true ) );

			$this->log( $errorMessage );

			( new LeadFailed( $errorMessage ) )->send();

			return false;
		}


		return $this->databaseEntryId;
	}

	/**
	 * @param array $array
	 *
	 * @return string
	 */
	private function line_breaks_and_return_print_r( array $array ) {
		return "\n\n<br><br>" . print_r( $array, true );
	}

	////////////////////////////////////////////////////////////
	// Internal Helpers
	////////////////////////////////////////////////////////////
	protected function log( $str ) {
		error_log( "FORMS API ERROR: {$str}" );
	}

}