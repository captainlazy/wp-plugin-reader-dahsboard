<?php

/*
Plugin Name: NR Marine Manager
Plugin URI: https://nativerank.com
Description: Publish Marine Manager inventory to Wordpress
Version: 0.1.5
Author: Native Rank
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_MARINE_MANAGER_VERSION', '0.1.5' );
define( 'NR_MARINE_MANAGER_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_MARINE_MANAGER_PHP_MINIMUM', '5.6.0' );
define( 'NR_MARINE_MANAGER_DIR_NAME', basename( __DIR__ ) );
define( 'NR_MARINE_MANAGER_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_MARINE_MANAGER_PLUGIN_URI', plugins_url( NR_MARINE_MANAGER_DIR_NAME ) );
define( 'NR_MARINE_MANAGER_REST_NAMESPACE', 'marine-manager/v1' );
define( 'NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION', 'nr_1055_marine_manager_incoming_inventory' );
define( 'NR_MARINE_MANAGER_DEALER_OPTION', 'nr_1055_marine_manager_dealer' );
define( 'NR_MARINE_MANAGER_LOG_PATH', NR_MARINE_MANAGER_PLUGIN_PATH . 'error.log' );
define( 'NR_MARINE_MANAGER_DOMAIN', 'https://marinemanagerpro.com' );


define( 'NR_MARINE_MANAGER_TEMPLATES_DIR', NR_MARINE_MANAGER_PLUGIN_PATH . 'templates/' );
define( 'NR_MARINE_MANAGER_PARTIALS_DIR', NR_MARINE_MANAGER_TEMPLATES_DIR . 'partials/' );

if ( class_exists( '\Nativerank\MarineManager\Plugin' ) ) {
	die();
}

require 'vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_MARINE_MANAGER_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR BP PLUGIN NAME requires PHP version %s', 'nr-marine-manager' ), NR_MARINE_MANAGER_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-marine-manager' )
		);
	}

	//Create DB Tables
	( new \Nativerank\MarineManager\Database\Migrations() );

	add_role( 'marine_manager', 'Marine Manager', [
		'read'                    => true,
		'manage_marine_inventory' => true,
	] );

	do_action( 'nr_marine_manager_activation' );


} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_MARINE_MANAGER_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_marine_manager_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_marine_manager_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_MARINE_MANAGER_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_marine_manager_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_MARINE_MANAGER_PHP_MINIMUM, '>=' ) ) {

	\Nativerank\MarineManager\Plugin::load( NR_MARINE_MANAGER_PLUGIN_MAIN_FILE );

}


