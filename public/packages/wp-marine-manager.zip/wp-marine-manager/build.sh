#!/usr/bin/env bash

rm -rf vendor
rm composer-lock.json
composer install --no-interaction --no-dev --prefer-dist

cd app || exit
npm run build
