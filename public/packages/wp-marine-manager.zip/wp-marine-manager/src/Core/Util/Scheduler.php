<?php


namespace Nativerank\MarineManager\Core\Util;


use Nativerank\MarineManager\Importer;

class Scheduler {


	protected static $contextPrefix = 'nr_1055_marine_manager_';
	protected $events = [
		'create_boat_pages',
		'update_boat_pages',
	];
	protected $seconds_between_events = 180;
	protected $intervalInSeconds = 300;

	public function __construct() {
		add_filter( 'cron_schedules', [ $this, 'add_intervals' ] );
		$this->add_actions();
		$this->add_cron_events();
	}

	private function add_actions() {
		foreach ( $this->events as $event ) {
			$callback = [ $this, $event ];
			if ( is_callable( $callback ) ) {
				add_action( static::$contextPrefix . "{$event}_cron_hook", $callback );
			}
		}
	}

	public function add_intervals( $schedules ) {
		$schedules['every_five_minutes'] = array(
			'interval' => $this->intervalInSeconds,
			'display'  => esc_html__( 'Every 5 minutes' ),
		);

		return $schedules;
	}

	private function add_cron_events() {
		foreach ( $this->events as $index => $event ) {
			$hook = static::$contextPrefix . "{$event}_cron_hook";
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time() + ( $this->seconds_between_events * $index ), 'every_five_minutes', $hook );
			}
		}
	}

	public function create_boat_pages() {
		$pendingImports = $this->get_pending_imports();
		$pendingImports = collect( $pendingImports );
		$imports        = $pendingImports->filter( function ( $import ) {
			return isset( $import['update_type'] ) && $import['update_type'] === 'created';
		} );

		if ( $imports->isEmpty() ) {
			return;
		}

		$pendingImports = $pendingImports->reject( function ( $import ) {
			return ! isset( $import['update_type'] ) || $import['update_type'] === 'created';
		} );
		if ( $imports->count() > 20 ) {
			$pendingImports = $pendingImports->merge( $imports->splice( 20 ) );
		}

		( new Importer( $imports ) )->handle();

		update_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, $pendingImports->values()->all() );

	}

	public function update_boat_pages() {
		$pendingImports = $this->get_pending_imports();
		$pendingImports = collect( $pendingImports );

		$imports = $pendingImports->filter( function ( $import ) {
			return isset( $import['update_type'] ) && $import['update_type'] === 'updated';
		} );

		if ( $imports->isEmpty() ) {
			return;
		}

		$pendingImports = $pendingImports->reject( function ( $import ) {
			return ! isset( $import['update_type'] ) || $import['update_type'] === 'updated';
		} );

		if ( $imports->count() > 20 ) {
			$pendingImports = $pendingImports->merge( $imports->splice( 20 ) );
		}

		( new Importer( $imports ) )->handle();

		update_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, $pendingImports->values()->all() );
	}

	private function get_pending_imports() {
		return get_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, [] );
	}

}