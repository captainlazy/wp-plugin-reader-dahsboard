<?php


namespace Nativerank\MarineManager;


use Illuminate\Support\Collection;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use WP_REST_Request;

class IncomingUpdatesReceiver {

	/**
	 * @var Logger
	 */
	private $logger;

	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register' ] );
		$this->logger = new Logger( 'incoming_updates' );
		$this->logger->pushHandler( new StreamHandler( NR_MARINE_MANAGER_LOG_PATH ) );
	}

	public function register() {
		register_rest_route( NR_MARINE_MANAGER_REST_NAMESPACE, '/publish', array(
			'methods'  => 'POST',
			'callback' => [ $this, 'handle' ],
		) );
	}

	public function handle( WP_REST_Request $request ): \WP_REST_Response {
		try {
			$payload = $request->get_params();
			$payload = collect( $payload );

			if ( current_user_can( 'manage_marine_inventory' ) ) {
				$dealerId = $payload->get( 'dealer' );
				update_option( NR_MARINE_MANAGER_DEALER_OPTION, $dealerId );

				$incomingUpdates = $payload->get( 'updates', [] );
				$inventory       = get_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, [] );
				$inventory       = collect( $inventory )->values();
				$incomingUpdates = collect( $incomingUpdates )->values();
				$deletes         = $this->filterDeletes( $incomingUpdates );
				$incomingUpdates = $this->removeDeletes( $incomingUpdates );

				$success = $this->processDeletes( $deletes );

				if ( $incomingUpdates->isEmpty() ) {
					// DO NOTHING
				} else {
					$inventory = $inventory->merge( $incomingUpdates )->values();
					$inventory = $inventory->sortBy( 'updated_at' )->values();

					if ( $inventory->count() < 20 ) {
						$success = $success && ( new Importer( $inventory ) )->handle();
						update_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, [] );
					} else {
						$success = $success && ( new Importer( $inventory->splice( 20 ) ) )->handle();
						$success = $success && update_option( NR_MARINE_MANAGER_INVENTORY_UPDATES_OPTION, $inventory->toArray() );
					}
				}

				if ( ! $success ) {
					$this->logger->error( 'Inventory update failed', [
						'incoming'  => $incomingUpdates->toArray(),
						'deletes'   => $deletes->toArray(),
						'inventory' => $inventory->toArray(),
					] );
				}

				return new \WP_REST_Response( [ 'success' => $success ] );
			} else {
				throw new \Exception( 'User cannot manage marine inventory', 400 );
			}
		} catch ( \Throwable $exception ) {
			$this->logger->error( $exception->getMessage() );

			return new \WP_REST_Response( [
				'success' => false,
				'error'   => $exception->getMessage(),
			], 400 );
		}

	}

	/**
	 * @param Collection $inventory
	 *
	 * @return Collection
	 */
	private function filterDeletes( Collection $inventory ): Collection {
		return $inventory->filter( function ( $item ) {
			if ( is_object( $item ) ) {
				return $item->update_type === 'deleted';
			}
			if ( is_array( $item ) && isset( $item['update_type'] ) ) {
				return $item['update_type'] === 'deleted';
			}

			return false;
		} )
		                 ->values()
		                 ->pluck( 'id' )
		                 ->filter( function ( $id ) {
			                 return is_int( $id );
		                 } )
		                 ->values();
	}

	private function removeDeletes( Collection $updates ): Collection {
		return $updates->reject( function ( $item ) {
			if ( is_object( $item ) ) {
				return $item->update_type === 'deleted';
			}
			if ( is_array( $item ) && isset( $item['update_type'] ) ) {
				return $item['update_type'] === 'deleted';
			}

			return true;
		} );
	}

	private function processDeletes( Collection $deletes ): bool {
		if ( $deletes->isNotEmpty() ) {
			global $wpdb;

			$getPostIdsQuery = 'SELECT post_id FROM wp_postmeta WHERE meta_key="mmid" AND meta_value IN (';
			$getPostIdsQuery .= $deletes->implode( ', ' );
			$getPostIdsQuery .= ')';
			$deletePostIds   = $wpdb->get_results( $getPostIdsQuery, ARRAY_N );
			$deletePostIds   = collect( $deletePostIds )->map( function ( $result ) {
				return is_array( $result ) ? (int) array_shift( $result ) : false;
			} )->filter()->values();
			if ( $deletePostIds->isNotEmpty() ) {
				$deletePostIds                = $deletePostIds->implode( ', ' );
				$deletePostsQuery             = "DELETE FROM wp_posts WHERE ID IN ({$deletePostIds})";
				$deletePostMetaQuery          = "DELETE FROM wp_postmeta WHERE post_id IN ({$deletePostIds})";
				$deleteTermRelationshipsQuery = "DELETE FROM wp_term_relationships WHERE object_id IN ({$deletePostIds})";
				$wpdb->query( $deletePostsQuery );
				$wpdb->query( $deletePostMetaQuery );
				$wpdb->query( $deleteTermRelationshipsQuery );

				return empty( $wpdb->get_results( "SELECT ID from wp_posts WHERE ID IN ({$deletePostIds})" ) );
			}
		}

		return true;
	}

}