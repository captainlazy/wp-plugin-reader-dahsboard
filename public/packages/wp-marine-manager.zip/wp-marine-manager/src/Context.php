<?php


namespace Nativerank\MarineManager;


/**
 * Class Context
 * @package Nativerank\MarineManager
 */
class Context {

}
