<?php


namespace Nativerank\MarineManager;


use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use WP_Query;

class Importer {

	/**
	 * @var Collection
	 */
	private $imports;

	private $metaKeys = [
		'id'                => 'mmid',
		'stock_number'      => 'boat_stocknumber',
		'color'             => 'boat_color',
		'usage'             => 'boat_usage',
		'trim'              => 'boat_trim',
		'trim_color'        => 'boat_trim_color',
		'price'             => 'boat_price',
		'price_formatted'   => 'boat_price_formatted',
		'vin'               => 'boat_vin',
		'currency'          => 'boat_price_currency',
		'year'              => 'boat_model_year',
		'miles'             => 'boat_miles',
		'location'          => 'boat_location',
		'manufacturer'      => 'boat_manufacturer',
		'manufacturer_name' => 'boat_manufacturer_name',
		'brand_slug'        => 'boat_manufacturer_identifier',
		'media'             => 'boat_media',
		'categories'        => 'boat_categories',
		'types'             => 'boat_types',
		'engine_make'       => 'boat_engine_make',
		'length'            => 'boat_length',
		'usage_metric'      => 'boat_usage_metric',
		'usage_value'       => 'boat_usage_value',
		'_yoast_wpseo_title',
		'_yoast_wpseo_metadesc',
		'boat_condition',
		'boat_model',
	];

	private static $boatIDKey = 'boat_id';

	private static $pageTypeMetaKey = 'nr_page_type';

	/**
	 * @var Logger
	 */
	private $logger;

	/**
	 * @var Collection
	 */
	private $brands;

	/**
	 * @var Collection
	 */
	private $results;

	private static $resultsEndpoint = 'api/wp-importer/results';
	/**
	 * @var string
	 */
	private $resultsURL;

	public function __construct( Collection $imports ) {
		$this->imports = $imports;
		$this->logger  = new Logger( 'importer' );
		$this->logger->pushHandler( new StreamHandler( NR_MARINE_MANAGER_LOG_PATH ) );
		$this->results = collect();
		$this->initializeResultsURL();
	}

	/**
	 * @return bool
	 */
	public function handle(): bool {
		try {
			$this->initializeBrands();

			return $this->import();
		} catch ( \Throwable $exception ) {
			$this->logger->error( $exception->getMessage() );

			return false;
		}
	}


	private function import() {
		$success = true;
		$this->imports->first( function ( $import ) use ( &$success ) {
			$url   = '';
			$brand = $this->brands->first( function ( $brand ) use ( $import ) {
				return $brand->identifier === $import['manufacturer']['slug'];
			} );
			if ( is_null( $brand ) ) {
				$brand = $this->createBrandPage( $import );
				if ( empty( $brand ) || $brand instanceof \WP_Error ) {
					return;
				}
			}
			$usage = $this->checkForExistingUsagePage( $brand->ID, $import['usage'] );
			if ( empty( $usage ) ) {
				$usage = $this->createUsagePage( $import, $brand->ID );
				if ( $usage instanceof \WP_Error ) {
					return;
				}
			}
			if ( is_array( $usage ) ) {
				$usage = array_shift( $usage );
			}

			$import['page_template'] = $this->findPageTemplate( $import );
			$meta                    = $this->pluckAndMapMeta( $import );
			$page                    = $this->checkForExistingBoatPage( $meta->get( 'mmid' ) );

			$defaults = $this->initializeDefaults(
				$usage->ID,
				$import,
				$meta->all()
			);
			if ( empty( $page ) ) {
				$result = $this->savePost( $defaults );
			} else {
				$result = $this->savePost( $defaults, $page );
			}
			if ( is_int( $result ) && $result ) {
				$siteUrl = get_site_url();
				$search  = parse_url( $siteUrl, PHP_URL_SCHEME ) . '://' . parse_url( $siteUrl, PHP_URL_HOST );
				if ( $port = parse_url( $siteUrl, PHP_URL_PORT ) ) {
					$search .= ':' . $port;
				}
				$url = str_replace( $search, '', get_permalink( $result ) );
			}
			if ( $result instanceof \WP_Error ) {
				$success = false;
				$this->logger->error( 'Error importing boat', [
					'import' => $import,
					'result' => $result,
				] );
			}
			$result = [
				'import_id' => $import['id'],
				'result'    => $result,
				'url'       => $url,
			];
			$this->results->push( $result );
		} );

		if ( function_exists( 'rocket_clean_files' ) ) {
			$this->flushArchiveCaches();
		}

		$resultsResponse          = $this->sendResultsToResultsURL();
		$resultsResponseIsWPError = $resultsResponse instanceof \WP_Error;
		if ( $resultsResponseIsWPError ) {
			$this->logger->error( 'Sending results to Marine Manager failed', [ 'error' => $resultsResponse ] );
		}
		$success = $success && ! $resultsResponseIsWPError && $this->resultsResponseWasSuccessful( $resultsResponse );

		return $success;
	}

	/**
	 * @param array $arguments
	 * @param null $page
	 *
	 * @return int|\WP_Error
	 */
	private function savePost( array $arguments = [], $page = null ) {
		if ( is_array( $page ) ) {
			$page = collect( $page )->first();
		}
		if ( is_int( $page ) ) {
			$arguments = array_merge( [ 'ID' => $page ], $arguments );

			return wp_update_post( $arguments, true );
		}

		return wp_insert_post( $arguments, true );
	}

	private function initializeDefaults( int $parent, array $import, array $meta = [] ): array {
		$pageTemplate = isset( $import['page_template'] ) ? $import['page_template'] : null;
		$title        = isset( $import['title'] ) ? $import['title'] : null;
		$content      = isset( $import['description'] ) ? $import['description'] : null;;

		$defaults = [
			'post_status'   => 'publish',
			'post_type'     => 'page',
			'post_title'    => $title,
			'post_parent'   => $parent,
			'post_content'  => $content,
			'page_template' => $pageTemplate,
			'meta_input'    => $meta,
		];

		if ( isset( $import['slug'] ) && Str::of( $import['slug'] )->isNotEmpty() ) {
			$defaults['post_name'] = $import['slug'];
		}

		return $defaults;
	}

	/**
	 * @param int $mmid
	 *
	 * @return array
	 */
	private function checkForExistingBoatPage( int $mmid ): array {
		return get_posts( [
			'post_type'  => 'page',
			'fields'     => 'ids',
			'meta_query' => [
				[
					'key'   => 'boat',
					'value' => 1,
				],
				[
					'key'   => 'mmid',
					'value' => $mmid,
				],
			],
		] );
	}

	private function pluckAndMapMeta( array $import ): Collection {
		$meta = collect( $import );

		$metaKeys   = collect( $this->metaKeys )->push( self::$boatIDKey, self::$pageTypeMetaKey );
		$templates  = $meta->pull( 'templates', [] );
		$attributes = collect( $meta->pull( 'attribute_values' ) );
		$attributes->each( function ( $attribute ) use ( &$meta, $metaKeys ) {
			if ( $metaKeys->contains( $attribute['attribute']['slug'] ) ) {
				$meta->put( $attribute['attribute']['slug'], $attribute['value'] );
			}
		} );
		$pageType = $this->findTemplateByFiletype( $templates, '.hbs' );
		if ( ! empty( $pageType ) ) {
			$meta->put( self::$pageTypeMetaKey, $this->convertHBSFilenameToPageType( $pageType ) );
		}

		foreach ( $this->metaKeys as $key => $switch ) {
			if ( $meta->has( $key ) ) {
				$value = $meta->pull( $key );
				if ( $key === 'vin' && ( Str::of( $value ) )->lower()->startsWith( 'xxx' ) ) {
					continue;
				}
				$meta->put( $switch, $value );
			}
		}

		$meta = $meta->only( $metaKeys->values() )
		             ->filter();

		$meta->put( 'boat', 1 );

		return $meta;
	}

	private function createUsagePage( array $import, int $parent ) {
		$usage        = isset( $import['usage'] ) ? $import['usage'] : 'New';
		$templates    = collect( $import )->pull( 'templates', [] );
		$pageTemplate = $this->findPageTemplate( $import, 'usage' );
		$meta         = [
			'usage'       => 1,
			'identifier'  => strtolower( $usage ),
			'unoptimized' => 1,
		];
		if ( isset( $import['usage_page_meta'] ) ) {
			$meta = array_merge( $meta, $import['usage_page_meta'] );
		}
		$pageType = $this->findTemplateByFiletype( $templates, '.hbs', 'usage' );
		if ( $pageType ) {
			$meta[ self::$pageTypeMetaKey ] = $this->convertHBSFilenameToPageType( $pageType );
		} else {
		}
		$arguments = [
			'post_status' => 'publish',
			'post_parent' => $parent,
			'post_type'   => 'page',
			'post_title'  => $usage,
			'meta_input'  => $meta,
		];
		if ( $pageTemplate ) {
			$arguments['page_template'] = $pageTemplate;
		}


		$result = wp_insert_post( $arguments, true );
		if ( $result instanceof \WP_Error ) {
			$this->logger->error( "Failed to save {$usage} {$parent} page", [
				'arguments' => $arguments,
				'result'    => $result,
			] );

			return $result;
		}

		return get_post( $result );
	}

	private function checkForExistingUsagePage( int $parent, string $usage ): array {
		return get_children( [
			'post_parent' => $parent,
			'meta_query'  => [
				[
					'key'   => 'usage',
					'value' => 1,
				],
				[
					'key'   => 'identifier',
					'value' => strtolower( $usage ),
				],
			],
		] );
	}

	private function createBrandPage( array $import ) {
		$resource     = 'App\\Models\\Manufacturer';
		$name         = isset( $import['manufacturer']['name'] ) ? $import['manufacturer']['name'] : $import['manufacturer']['slug'];
		$name         = (string) Str::of( $name )->finish( ' Boats' );
		$slug         = $import['manufacturer']['slug'] ?? '';
		$templates    = collect( $import )->pull( 'templates', [] );
		$pageTemplate = $this->findPageTemplate( $import, $resource );
		$pageType     = $this->findTemplateByFiletype( $templates, '.hbs', $resource );
		if ( empty( $slug ) ) {
			return false;
		}
		$meta = [
			'brand'       => 1,
			'identifier'  => $slug,
			'unoptimized' => 1,
		];
		if ( isset( $import['manufacturer']['logo'] ) && ! empty( $import['manufacturer']['logo'] ) ) {
			$meta['brand_logo_url'] = $import['manufacturer']['logo'];
		}
		if ( $pageType ) {
			$meta[ self::$pageTypeMetaKey ] = $this->convertHBSFilenameToPageType( $pageType );
		}
		$arguments = [
			'post_status' => 'publish',
			'post_type'   => 'page',
			'post_title'  => $name,
			'meta_input'  => $meta,
		];
		if ( $pageTemplate ) {
			$arguments['page_template'] = $pageTemplate;
		}
		$result = wp_insert_post( $arguments, true );
		if ( $result instanceof \WP_Error ) {
			$this->logger->error( "Failed to save {$name} brand page", $import );

			return $result;
		}
		$result             = get_post( $result );
		$result->identifier = $slug;
		$this->brands->push( $result );

		return $result;
	}

	private function initializeBrands() {
		global $wpdb;

		$brands       = $wpdb->get_results( $wpdb->prepare(
			"SELECT posts.ID, pmBR.meta_value as brand, pmID.meta_value as identifier FROM $wpdb->posts as posts 
    LEFT JOIN $wpdb->postmeta as pmBR ON (posts.ID = pmBR.post_id)
	LEFT JOIN $wpdb->postmeta as pmID ON (posts.ID = pmID.post_id)
WHERE posts.post_type = %s AND posts.post_status = %s AND pmBR.meta_key = %s AND pmID.meta_key = %s", 'page', 'publish', 'brand', 'identifier' ) );
		$this->brands = collect( $brands );
	}

	/**
	 * @param array $templates
	 * @param string $filetype
	 * @param string $resource
	 *
	 * @return string|null
	 */
	private function findTemplateByFiletype( array $templates = [], string $filetype = '.php', $resource = 'App\\Models\\Boat' ): string {
		$filetype  = Str::lower( $filetype );
		$templates = collect( $templates )->filter( function ( $template ) use ( $resource ) {
			$template = Collection::wrap( $template );

			return $template->get( 'related_type', false ) === $resource;
		} )->values();
		$name      = null;
		$templates->first( function ( $template ) use ( &$name, $filetype ) {
			$template = Collection::wrap( $template );
			if ( Str::endsWith( Str::lower( $template->get( 'name' ) ), $filetype ) ) {
				$name = $template->get( 'name' );

				return true;
			}

			return false;
		} );

		return $name;
	}

	/**
	 * @param array $import
	 * @param string $resource
	 *
	 * @return string|null
	 */
	private function findPageTemplate( array $import, $resource = 'App\\Models\\Boat' ) {
		return isset( $import['templates'] ) ? $this->findTemplateByFiletype( $import['templates'], '.php', $resource ) : null;
	}

	/**
	 * @param string $filename
	 *
	 * @return string
	 */
	private function convertHBSFilenameToPageType( string $filename ): string {
		return (string) Str::of( $filename )->replaceMatches( '/.hbs$/i', '' );
	}

	/**
	 * @return array|\WP_Error
	 */
	private function sendResultsToResultsURL() {
		return wp_remote_post( $this->resultsURL, [
			'body' => [
				'results' => $this->results->all(),
			],
		] );
	}

	private function initializeResultsURL() {
		$this->resultsURL = (string) ( Str::of( NR_MARINE_MANAGER_DOMAIN )->finish( '/' ) . Str::of( static::$resultsEndpoint )->trim( '/' ) );
	}

	/**
	 * @param array $resultsResponse
	 *
	 * @return bool
	 */
	private function resultsResponseWasSuccessful( array $resultsResponse ): bool {
		return isset( $resultsResponse['response']['code'] ) && $resultsResponse['response']['code'] === 200;
	}

	private function flushArchiveCaches() {
		$query = new WP_Query( [
			'post_type'   => 'page',
			'post_status' => 'publish',
			'fields'      => 'ids',
			'meta_query'  => [
				'key'     => 'nr_page_type',
				'compare' => 'LIKE',
				'value'   => 'inventory_archive',
			],
		] );

		$urls = collect( $query->posts )
			->transform( function ( $id ) {
				return get_permalink( $id );
			} );

		rocket_clean_files( $urls->all() );
	}
}