<?php
/*
Plugin Name: NR WP GALLERY
Plugin URI: https://nativerank.com
Description: Simple plugin to manage gallery on your website
Version: 1.2.3
Author: Native Rank
Author URI: https://nativerank.com
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define most essential constants.
define('NR_WP_GALLERY_VERSION', '1.2.3');
define('NR_WP_GALLERY_PLUGIN_MAIN_FILE', __FILE__);
define('NR_WP_GALLERY_PHP_MINIMUM', '5.6.0');
define('NR_WP_GALLERY_DIR', __DIR__);
define('NR_WP_GALLERY_DIR_NAME', basename(__DIR__));
define('NR_WP_GALLERY_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('NR_WP_GALLERY_PLUGIN_URI', plugins_url(NR_WP_GALLERY_DIR_NAME));

define('NR_WP_GALLERY_TEMPLATES_DIR', NR_WP_GALLERY_PLUGIN_PATH . 'templates/');
define('NR_WP_GALLERY_PARTIALS_DIR', NR_WP_GALLERY_TEMPLATES_DIR . 'partials/');

if (class_exists('\Nativerank\WPGallery\Plugin')) {
    die();
}

require_once __DIR__ . '/vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook(__FILE__, function () {
    if (version_compare(PHP_VERSION, NR_WP_GALLERY_PHP_MINIMUM, '<')) {
        wp_die(
        /* translators: %s: version number */
            esc_html(sprintf(__('NR WP GALLERY requires PHP version %s', 'nr-wp-gallery'), NR_WP_GALLERY_PHP_MINIMUM)),
            esc_html__('Error Activating', 'nr-wp-gallery')
        );
    }

    flush_rewrite_rules(true);

    //Create DB Tables
    (new \Nativerank\WPGallery\Database\Migrations());


    do_action('nr_wp_gallery_activation');

});


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook(__FILE__, function ($network_wide) {
    if (version_compare(PHP_VERSION, NR_WP_GALLERY_PHP_MINIMUM, '<')) {
        return;
    }

    do_action('nr_wp_gallery_deactivation', $network_wide);
});


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_wp_gallery_opcache_reset()
{
    if (version_compare(PHP_VERSION, NR_WP_GALLERY_PHP_MINIMUM, '<')) {
        return;
    }

    if (!function_exists('opcache_reset')) {
        return;
    }

    if (!empty(ini_get('opcache.restrict_api')) && strpos(__FILE__, ini_get('opcache.restrict_api')) !== 0) {
        return;
    }

    // `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
    if (defined('WPCOM_IS_VIP_ENV') && WPCOM_IS_VIP_ENV) {
        return;
    }

    opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action('plugins_loaded', function () {
    $updateChecker = Puc_v4_Factory::buildUpdateChecker(
        'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_WP_GALLERY_DIR_NAME,
        NR_WP_GALLERY_PLUGIN_MAIN_FILE,
        NR_WP_GALLERY_DIR_NAME
    );
});


add_action('upgrader_process_complete', 'nr_wp_gallery_opcache_reset');

flush_rewrite_rules(true);

add_filter('query_vars', function ($vars) {
    $vars[] = 'nr_gallery_thumbnail';
    return $vars;
});

add_action('init', function () {
    add_rewrite_rule(
        '^nr-gallery/thumbnail/([\d]+)?',
        'index.php?nr_gallery_thumbnail=$matches[1]',
        'top'
    );
});

add_action('parse_request', function ($wp) {
    if (
    !empty($wp->query_vars['nr_gallery_thumbnail'])
    ) {
        wp_redirect(wp_get_attachment_image_url($wp->query_vars['nr_gallery_thumbnail']), 301);
        exit;
    }
});


if (version_compare(PHP_VERSION, NR_WP_GALLERY_PHP_MINIMUM, '>=')) {

    \Nativerank\WPGallery\Plugin::load(NR_WP_GALLERY_PLUGIN_MAIN_FILE);

}
