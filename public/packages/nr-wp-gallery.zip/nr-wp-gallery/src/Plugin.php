<?php


namespace Nativerank\WPGallery;

use Nativerank\WPGallery\Admin\MenuPages\Sub_Menu;
use Nativerank\WPGallery\Core\Controllers\Gallery;
use Nativerank\WPGallery\Database\Migrations;

/**
 * Class Plugin
 * @package Nativerank\WPGallery
 */
class Plugin
{

    /**
     * The plugin context object.
     *
     * @var Context
     */
    private $context;

    /**
     * Main instance of the plugin.
     *
     * @var Plugin|null
     */
    private static $instance = null;

    /**
     * Sets the plugin main file.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     */
    public function __construct($main_file)
    {
        $this->context = new Context($main_file);
    }

    /**
     * Retrieves the plugin context object.
     *
     * @return Context Plugin context.
     */
    public function context()
    {
        return $this->context;
    }

    /**
     * Registers the plugin with WordPress.
     */
    public function register()
    {


        add_filter('nr_1055_template_data', function ($data) {
            $data['galleries'] = json_decode(json_encode((new Gallery())->get_with_data()), true);
            return $data;
        });

        new Migrations();


        //Register Routes
        $this->routes();


        new Sub_Menu();

        // Register any other classes
        $this->classes();

        do_action('nr_wp_gallery_init');
    }


    public function routes()
    {
        $routes = include NR_WP_GALLERY_DIR . '/src/Core/Http/api.php';

        add_action('rest_api_init', function () use ($routes) {
            foreach ($routes as $k => $args) {

                register_rest_route(NR_WP_GALLERY_DIR_NAME . '/v1', '/' . ltrim($args['route'], '/'), array(
                    'methods' => $args['method'],
                    'callback' => $args['callback']
                ));
            }
        });

    }


    /**
     * Retrieves the main instance of the plugin.
     *
     *
     * @return Plugin NR WP GALLERY instance.
     */
    public static function instance()
    {
        return static::$instance;
    }

    /**
     * Loads the plugin main instance and initializes it.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     * @return bool True if the plugin main instance could be loaded, false otherwise.
     */
    public static function load($main_file)
    {
        if (null !== static::$instance) {
            return false;
        }

        static::$instance = new static($main_file);

        // register plugin after plugin is activated
        add_action('init', [static::$instance, 'register'], 100);

        return true;
    }

    /**
     * @return array
     */
    public function classes()
    {
        return [

        ];
    }

}
