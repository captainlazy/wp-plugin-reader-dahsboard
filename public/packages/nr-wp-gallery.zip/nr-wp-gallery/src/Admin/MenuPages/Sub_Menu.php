<?php

namespace Nativerank\WPGallery\Admin\MenuPages;

use Nativerank\WPGallery\Core\Controllers\Gallery;

class Sub_Menu
{

    /**
     * Important
     */
    const PRIORITY = 11;
    const PARENT_SLUG = 'nativerank_SEO_1055';
    const PAGE_TITLE = 'Gallery By Native Rank';
    const MENU_TITLE = 'Gallery';
    const MENU_SLUG = 'nr-gallery';
    const CAPABILITY = 'upload_files';

    /**
     * Autoload method
     * @return void
     */
    public function __construct()
    {

        if (isset($_GET['page']) && $_GET['page'] === 'nr-gallery') {

            wp_enqueue_script(
                'nr_gallery_app',
                NR_WP_GALLERY_PLUGIN_URI . '/dist/app.js',
                array(),
                filemtime(NR_WP_GALLERY_DIR . '/dist/app.js'),
                true
            );
            wp_localize_script('nr_gallery_app', 'nr_gallery_app_globals',
                array(
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'site_url' => get_site_url(),
                    'rest_url' => get_rest_url(null, NR_WP_GALLERY_DIR_NAME . '/v1'),
                    'galleries' => (new Gallery())->get_with_data(),
                    'galleries_only' => (new Gallery())->get(),
                )
            );
        }


        add_action('admin_menu', array(&$this, 'register_sub_menu'), self::PRIORITY);
    }

    /**
     * Register submenu
     * @return void
     */
    public function register_sub_menu()
    {
        add_submenu_page(
            self::PARENT_SLUG, self::PAGE_TITLE, self::MENU_TITLE, self::CAPABILITY, self::MENU_SLUG, array(&$this, 'submenu_page_callback')
        );
    }

    /**
     *
     * Render submenu
     * @return void
     */
    public function submenu_page_callback()
    {
        include(NR_WP_GALLERY_DIR . '/src/Admin/Views/gallery.php');
    }

}
