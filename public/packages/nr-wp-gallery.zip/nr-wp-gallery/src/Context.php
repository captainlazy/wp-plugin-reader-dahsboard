<?php


namespace Nativerank\WPGallery;


/**
 * Class Context
 * @package Nativerank\WPGallery
 */
class Context
{

}
