<?php

use Nativerank\WPGallery\Core\Controllers\Category;
use Nativerank\WPGallery\Core\Controllers\Gallery;
use Nativerank\WPGallery\Core\Controllers\Image;

return [
    [
        'route' => 'gallery',
        'method' => 'POST',
        'callback' => [new Gallery, 'add'],
    ],
    [
        'route' => 'gallery',
        'method' => 'GET',
        'callback' => [new Gallery, 'get'],
    ],
    [
        'route' => 'gallery_with_data',
        'method' => 'GET',
        'callback' => [new Gallery, 'get_with_data'],
    ],
    [
        'route' => 'category/(?P<gallery_id>\d+)',
        'method' => 'POST',
        'callback' => [new Category, 'add'],
    ],
    [
        'route' => 'category/(?P<category_id>\d+)',
        'method' => 'DELETE',
        'callback' => [new Category, 'delete'],
    ],
    [
        'route' => 'category',
        'method' => 'PUT',
        'callback' => [new Category, 'update'],
    ],
    [
        'route' => 'images/(?P<gallery_id>\d+)/(?P<category_id>\d+)',
        'method' => 'POST',
        'callback' => [new Image, 'add'],
    ]
];
