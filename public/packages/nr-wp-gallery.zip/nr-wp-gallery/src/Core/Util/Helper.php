<?php

namespace Nativerank\WPGallery\Core\Util;

class Helper
{
    static function strip_url($url)
    {
        if (empty($url)) {
            return '';
        }

        $url = parse_url(trim(strtolower($url)));
        if (!isset($url['host'])) {
            $url = $url['path'];
            $re = '/^(?:www\.)?(.*?)($|\/)/mi';
            preg_match_all($re, $url, $matches, PREG_SET_ORDER, 0);
            $url = $matches[0][1];
        } else {
            $url = str_replace('www.', '', $url['host']);
        }

        return $url;
    }


    /**
     * Removes an item from the array and returns its value.
     *
     * @param array $arr The input array
     * @param String $key The key pointing to the desired value
     *
     * @return String|array|object|null The value mapped to $key or null if none
     */
    static function array_remove_key(array &$arr, $key)
    {
        if (array_key_exists($key, $arr)) {
            $val = $arr[$key];
            unset($arr[$key]);

            return $val;
        }

        return null;
    }


}
