<?php


namespace Nativerank\WPGallery\Core\Controllers;

use Nativerank\WPGallery\Database\Migrations;

class Gallery
{

    public $galleries;

    public function __construct()
    {
        return $this;
    }


    public function add(\WP_REST_Request $request)
    {

        $name = $request->get_param('name');


        if (empty($name)) {
            return new \WP_Error('invalid_name', 'Gallery Name is required.', array('status' => 400));

        }

        if ($this->get_by_name($name) !== false) {
            return new \WP_Error('invalid_gallery_name', 'Gallery with provided name already exists', array('status' => 400));
        }

        global $wpdb;

        $result = $wpdb->insert($wpdb->prefix . Migrations::$GALLERIES_TABLE, array(
            'name' => $name
        ));

        if ($result === false) {
            return new \WP_Error('error_adding_gallery', 'Couldn\'t add Gallery. Unknown Error occurred.', array('status' => 404));
        }

        return new \WP_REST_Response(["message" => "Gallery Added", "code" => 200, 'data' => (new Gallery())->get_with_data()], '200');
    }

    public function get()
    {
        global $wpdb;
        $this->galleries = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . Migrations::$GALLERIES_TABLE);

        if (empty($this->galleries)) {

            $this->galleries = $this->default();
        }


        return $this->galleries;
    }


    private function default()
    {
        global $wpdb;

        $wpdb->insert($wpdb->prefix . Migrations::$GALLERIES_TABLE, array(
            'name' => 'Default',
        ));

        return [
            [
                'id' => "1",
                'name' => 'Default'
            ]
        ];


    }

    public function get_by_id($id)
    {
        global $wpdb;
        $this->galleries = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . Migrations::$GALLERIES_TABLE . " WHERE id = $id");

        if (empty($this->galleries)) {
            return false;
        }


        return $this->galleries;
    }

    public function get_by_name($name)
    {
        global $wpdb;
        $this->galleries = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . Migrations::$GALLERIES_TABLE . " WHERE name = $name");

        if (empty($this->galleries)) {
            return false;
        }

        return $this->galleries;
    }

    public function get_with_data()
    {
        global $wpdb;
        $gallery = $wpdb->prefix . Migrations::$GALLERIES_TABLE;
        $category = $wpdb->prefix . Migrations::$CATEGORIES_TABLE;

        $result = $wpdb->get_results("
            SELECT 
            g.id AS gallery_id, g.name AS gallery_name, c.id as category_id, meta, images
            FROM {$gallery} g
            INNER JOIN {$category} c ON (g.id = c.gallery_id)
            ");

        $response = [];

        foreach ($result as $row) {

            $row->gallery_id = intval($row->gallery_id);
            $row->category_id = intval($row->category_id);
            if (!isset($response[$row->gallery_id])) {
                $response[$row->gallery_id] = [
                    'id' => $row->gallery_id,
                    'name' => $row->gallery_name,
                    'categories' => []
                ];
            }
            $row->meta = json_decode($row->meta);
            $row->images = json_decode($row->images);
            if (!is_array($row->images)) {
                $row->images = [];
            }

            $response[$row->gallery_id]['categories'][] = $row;
        }

        return array_values($response);

    }

}
