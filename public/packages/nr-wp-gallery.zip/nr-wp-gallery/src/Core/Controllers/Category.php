<?php


namespace Nativerank\WPGallery\Core\Controllers;


use Nativerank\WPGallery\Database\Migrations;

class Category
{


    public function __construct()
    {

        return $this;
    }

    public function add(\WP_REST_Request $request)
    {
        $gallery_id = intval($request['gallery_id']);
        $meta = $request->get_param('meta');


        if (empty($gallery_id)) {
            return new \WP_Error('missing_gallery_id', 'Gallery ID is required', array('status' => 404));
        }

        if (empty($meta)) {
            return new \WP_Error('invalid_meta', 'Category meta data is required.', array('status' => 400));

        }

        if (empty((new Gallery())->get_by_id($gallery_id))) {
            return new \WP_Error('invalid_gallery_id', 'Gallery with provided ID does not exist', array('status' => 404));
        }

        global $wpdb;

        $result = $wpdb->insert($wpdb->prefix . Migrations::$CATEGORIES_TABLE, array(
            'meta' => $meta,
            'gallery_id' => $gallery_id
        ));

        if ($result === false) {
            return new \WP_Error('error_adding_category', 'Couldn\'t add Category. Unknown Error occurred.', array('status' => 404));
        }

        return new \WP_REST_Response(["message" => "Category Added", "code" => 200, 'data' => (new Gallery())->get_with_data()], '200');
    }

    public function update(\WP_REST_Request $request)
    {
        $meta = $request->get_param('meta');
        $category_id = $request->get_param('category_id');

        if (empty($category_id)) {
            return new \WP_Error('missing_category_id', 'Category ID is required', array('status' => 404));
        }

        global $wpdb;

        $result = $wpdb->update(
            $wpdb->prefix . Migrations::$CATEGORIES_TABLE,
            ['meta' => $meta,],
            ['id' => $category_id]
        );

        if (empty($result)) {
            return new \WP_Error('error_updating_category', 'Couldn\'t update Category. Unknown Error occurred.', array('status' => 404));
        }

        return new \WP_REST_Response(["message" => "Category Updated", "code" => 200, 'data' => (new Gallery())->get_with_data()], '200');

    }


    public function delete(\WP_REST_Request $request)
    {
        $category_id = $request->get_param('category_id');

        global $wpdb;
        $result = $wpdb->delete(
            $wpdb->prefix . Migrations::$CATEGORIES_TABLE,
            ['id' => $category_id]
        );
        if (empty($result)) {
            return new \WP_Error('error_deleting_category', 'Couldn\'t delete Category. Unknown Error occurred.', array('status' => 404));
        }

        return new \WP_REST_Response(["message" => "Category Deleted", "code" => 200, 'data' => (new Gallery())->get_with_data()], '200');


    }

}
