<?php


namespace Nativerank\WPGallery\Core\Controllers;


use Nativerank\WPGallery\Database\Migrations;

class Image
{
    public function __construct()
    {
    }

    public function add(\WP_REST_Request $request)
    {
        $category_id = $request['category_id'];
        $gallery_id = $request['gallery_id'];
        var_dump($category_id, $gallery_id);
        $images = $request->get_param('images');


        global $wpdb;

        $result = $wpdb->update($wpdb->prefix . Migrations::$CATEGORIES_TABLE, array(
            'images' => $images
        ), array('id' => $category_id, 'gallery_id' => $gallery_id));

        return new \WP_REST_Response(["message" => "Images Added", "code" => 200, 'data' => (new Gallery())->get_with_data()], '200');

    }
}
