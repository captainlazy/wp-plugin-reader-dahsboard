=== NR WP Gallery ===

Simple gallery plugin for your website

== Description ==

Use this plugin to manage images on your website.


== Installation ==
1. Install the plugin
2. Use `{{galleries}}` variable in your handlebars template


== Schema ==
```
[
    {
        "id": "1", //Gallery id
        "name": "Default", // Gallery Name
        "categories" : [
            {
                "category_id": 1
                "gallery_id" : 1,
                "meta" : {
                    "name": "Category Name",
                    "description" : "Description Name"
                },
                "images" : [1,21,12] //image IDs
            }
        ]
    }
]
```


== Changelog ==


= 1.2.3 =
* Fix "Done" button after deleting images

= 1.2 =
* Multiple Gallery Support
