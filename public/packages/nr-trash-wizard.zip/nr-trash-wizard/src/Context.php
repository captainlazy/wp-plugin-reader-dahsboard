<?php


namespace nativerank\Trash_Wizard;

/**
 * Class Context
 */
class Context {

}
