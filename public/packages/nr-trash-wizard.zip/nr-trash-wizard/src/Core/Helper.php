<?php


namespace nativerank\Trash_Wizard\Core;


class Helper {

	public static function call( $target ) {
		$callable = self::getCallable( $target );

		return call_user_func( $callable );
	}


	public static function getCallable( $target ) {
		$segments = explode( '@', $target );
		$method   = $segments[1];

		if ( is_null( $method ) ) {
			throw new InvalidArgumentException( 'Method not provided.' );
		}

		if ( ! class_exists( $segments[0] ) ) {
			throw new InvalidArgumentException( 'Invalid Class provided.' );
		}

		return [ new $segments[0](), $method ];
	}

	public static function convertToArray( $data ) {
		return json_decode( json_encode( $data ), true );
	}
}
