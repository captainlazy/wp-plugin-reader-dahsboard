<?php


namespace nativerank\Trash_Wizard\Admin;


class UIHelper {

	/**
	 * UIHelper constructor.
	 */
	public function __construct() {
		if ( apply_filters( NR_TRASH_WIZARD_PLUGIN_NAME . '_UIHelper_Bootable', true ) ) {
			$this->boot();
		}
	}

	private function boot() {

		if ( apply_filters( NR_TRASH_WIZARD_PLUGIN_NAME, '_Hide_Yoast', true ) ) {
			$this->hideYoastMetaBox();
		}

	}

	private function hideYoastMetaBox() {
		add_action( 'add_meta_boxes', function () {
			remove_meta_box( 'wpseo_meta', NR_TRASH_WIZARD_MAIN_POST_TYPE, 'normal' );
		}, 11 );
	}

}
