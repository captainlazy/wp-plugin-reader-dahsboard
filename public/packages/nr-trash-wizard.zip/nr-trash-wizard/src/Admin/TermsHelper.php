<?php


namespace nativerank\Trash_Wizard\Admin;


class TermsHelper {


	public function __construct() {
		$this->inject_zip_codes();
	}


	private function parseZipCodes( $value ) {

		$value = preg_replace( '/[\s\r\n\, ]+/', ',', trim( $value ) );

		return explode( ',', $value );

	}


	private function inject_zip_codes() {
		add_filter( 'get_object_terms', function ( $terms, $object_ids, $taxonomies, $args ) {
			if ( ! $terms
			     || is_wp_error( $terms )
			) {
				return $terms;
			}

			if ( 'region' !== $taxonomies[0] ) {
				return $terms;
			}

			foreach ( $terms as $term ) {
				$term->zip_codes = $this->parseZipCodes( get_field( 'zip_codes', $term ) );
			}

			return $terms;

		}, 11, 4 );
	}
}
