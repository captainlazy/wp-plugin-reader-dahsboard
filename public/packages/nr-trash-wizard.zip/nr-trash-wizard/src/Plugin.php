<?php


namespace nativerank\Trash_Wizard;


use nativerank\Trash_Wizard\Admin\TermsHelper;
use nativerank\Trash_Wizard\Admin\UIHelper;
use nativerank\Trash_Wizard\Core\Helper;
use PostTypes\PostType;
use PostTypes\Taxonomy;
use Puc_v4_Factory;

class Plugin {
	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	private static $routes = [];

	public $updateChecker;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 */
	public function __construct( $main_file ) {
		$this->context = new Context( $main_file );
		self::$routes  = include( NR_TRASH_WIZARD_PLUGIN_MAIN_DIR . '/routes.php' );
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context() {
		return $this->context;
	}


	/**
	 * Registers the plugin with WordPress.
	 */
	public function register() {


		// Utility
		new UIHelper();
		new TermsHelper();


		//Register Post Type `service`
		$dumpster = ( new PostType( NR_TRASH_WIZARD_MAIN_POST_TYPE ) )
			->options( [
				'has_archive'   => true,
				'supports'      => [ 'title', 'revisions' ],
				'show_in_rest'  => true,
				'menu_position' => 1,
			] )
			->icon( 'dashicons-trash' )
			->register();

		$service_type = ( new Taxonomy( 'service-type' ) )->options( [
			'publicly_queryable' => false,
			'show_in_rest'       => true,
			'hierarchical'       => false,
		] )->posttype( NR_TRASH_WIZARD_MAIN_POST_TYPE )->register();

		$service_tag = ( new Taxonomy( 'service-tag' ) )->options( [
			'publicly_queryable' => false,
			'hierarchical'       => false,
			'show_in_rest'       => true,
		] )->posttype( NR_TRASH_WIZARD_MAIN_POST_TYPE )->labels( [ 'separate_items_with_commas' => __( 'Residential or Commercial' ), ] )->register();

		$regions = ( new Taxonomy( 'region' ) )->options( [
			'publicly_queryable' => false,
			'show_in_rest'       => true,
			'hierarchical'       => false
		] )->posttype( NR_TRASH_WIZARD_MAIN_POST_TYPE )->register();


		//Register API Routes
		$this->apiRoutes();

		//Register Data to Template Storage
		$this->templateStore();
	}

	private function apiRoutes() {
		$routes = self::$routes;
		if ( empty( $routes ) ) {
			return;
		}

		add_action( 'rest_api_init', function () use ( $routes ) {
			foreach ( $routes as $routeName => $routeObject ) {
				register_rest_route( 'trash-wizard/v1', $routeObject['route'] ?? $routeObject[1], [
					'methods'  => $routeObject['method'] ?? $routeObject[0],
					'callback' => Helper::getCallable( $routeObject['callback'] ?? $routeObject[2] )
				] );

			}
		} );
	}


	private function templateStore() {


		add_action( 'init', function () {
			$routes     = self::$routes;
			$pluginData = [];
			foreach ( $routes as $routeName => $routeObject ) {
				$pluginData[ $routeName ] = (array) Helper::call( $routeObject['callback'] ?? $routeObject[2] );
			}
			add_filter( 'nr_1055_template_data', function ( $data ) use ( $pluginData ) {
				return array_merge( $data, Helper::convertToArray( $pluginData ) );
			} );
		} );

	}

	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR WP GALLERY instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	public function update_checker() {
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_TRASH_WIZARD_PLUGIN_MAIN_DIR_NAME,
			NR_TRASH_WIZARD_PLUGIN_MAIN_FILE,
			NR_TRASH_WIZARD_PLUGIN_MAIN_DIR_NAME
		);
	}


	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load( $main_file ) {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static( $main_file );

		// register plugin after plugin is activated
		static::$instance->register();

		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ] );

		return true;
	}
}
