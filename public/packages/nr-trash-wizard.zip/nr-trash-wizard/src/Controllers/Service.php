<?php


namespace nativerank\Trash_Wizard\Controllers;


class Service {


	const POST_TYPE = NR_TRASH_WIZARD_MAIN_POST_TYPE;

	private $posts = [];

	private $taxonomies = [];


	public function __construct( $filter = [] ) {

		$filter = array_merge( $filter,
			[
				'post_type'     => self::POST_TYPE,
				'numberofposts' => - 1
			] );

		$this->posts = get_posts( $filter );

		return $this;
	}

	public function all() {
		$this->get_taxonomies();
		$this->combine();

		return $this->posts;
	}

	private function get_taxonomies() {
		$this->taxonomies = get_object_taxonomies( self::POST_TYPE );
	}


	private function combine() {
		foreach ( $this->posts as $post ) {
			$post->link_page = get_field( 'link_page', $post->ID );

			$post->taxonomies = $this->taxonomies;
			foreach ( $post->taxonomies as $taxonomy ) {
				$post->{$taxonomy} = wp_get_post_terms( $post->ID, $taxonomy );
			}
		}
	}

}
