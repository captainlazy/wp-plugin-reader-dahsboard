<?php


namespace nativerank\Trash_Wizard\Controllers;


class ServiceType {

	const TAXONOMY = 'service-type';

	private $terms = [];


	public function __construct() {

		$this->terms = get_terms( array(
			'taxonomy'   => self::TAXONOMY,
			'hide_empty' => true
		) );

		return $this;
	}

	public function all() {
		return $this->terms;
	}

	public function withPosts() {

		foreach ( $this->terms as $term ) {
			$term->posts = ( new Service( [
				'post_type'   => 'any',
				'numberposts' => - 1,
				'tax_query'   => [
					[
						'taxonomy'         => self::TAXONOMY,
						'field'            => 'term_id',
						'terms'            => $term->term_id,
						'include_children' => false
					]
				]
			] ) )->all();

			$term = $term;
		}


		return $this->all();
	}

}
