<?php

/*
 *
 *
 * @returns ['route_name' => [method => 'GET', route => '/route', 'callback' => callback()]]
 */

return [

	'service_types_all' => [
		'GET',
		'/service-types/all',
		'\nativerank\Trash_Wizard\Controllers\ServiceType@all'
	],

	'service_types_all_with_services' => [
		'GET',
		'/service-types/all-with-services',
		'\nativerank\Trash_Wizard\Controllers\ServiceType@withPosts'
	],
	'service_tags_all'                => [
		'GET',
		'/service-tags/all',
		'\nativerank\Trash_Wizard\Controllers\ServiceTag@all'
	],

	'service_tags_all_with_services' => [
		'GET',
		'/service-tags/all-with-services',
		'\nativerank\Trash_Wizard\Controllers\ServiceTag@withPosts'
	],

	'services_all' => [
		'GET',
		'/services/all',
		'\nativerank\Trash_Wizard\Controllers\Service@all'
	]

];
