=== NR Trash Wizard ===
 Plugin URL: https://nativerank.com/
 Description: Trash Wizard by NATIVE RANK
 Author: Native Rank
 Author URI: https://www.nativerank.com
 Requires at Least: 4.5
 Tested Up To: 4.5
 Requires PHP: 7.0
    
== Description ==

Table of Contents
=================
* [Endpoints](#endpoints)
    * [service_types_all](#service_types_all)
    * [service_types_all_with_services](#service_types_all_with_services)
    * [service_tags_all](#service_tags_all)
    * [service_tags_all_with_services](#service_tags_all_with_services)
    * [services_all](#services_all)

== Endpoints ==

= service_types_all =
`GET  /service-types/all`

> Returns
<pre>[
    {
        "term_id": 5,
        "name": "Additional",
        "slug": "additional",
        "term_group": 0,
        "term_taxonomy_id": 5,
        "taxonomy": "service-type",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
    },
    {
        "term_id": 8,
        "name": "Primary",
        "slug": "primary",
        "term_group": 0,
        "term_taxonomy_id": 8,
        "taxonomy": "service-type",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
    }
]</pre>

= service_types_all_with_services =
`GET : /service-types/all-with-services`

>Returns
<pre>[
  {
    "term_id": 5,
    "name": "Additional",
    "slug": "additional",
    "term_group": 0,
    "term_taxonomy_id": 5,
    "taxonomy": "service-type",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw",
    "posts": [
      {
        "ID": 78699,
        "post_author": "1",
        "post_date": "2020-07-23 08:21:48",
        "post_date_gmt": "2020-07-23 15:21:48",
        "post_content": "",
        "post_title": "Recycling Pickup",
        "post_excerpt": "",
        "post_status": "publish",
        "comment_status": "closed",
        "ping_status": "closed",
        "post_password": "",
        "post_name": "recycling-pickup",
        "to_ping": "",
        "pinged": "",
        "post_modified": "2020-07-23 08:25:32",
        "post_modified_gmt": "2020-07-23 15:25:32",
        "post_content_filtered": "",
        "post_parent": 0,
        "guid": "https://nr-wp.test/?post_type=service&#038;p=78699",
        "menu_order": 0,
        "post_type": "service",
        "post_mime_type": "",
        "comment_count": "0",
        "filter": "raw",
        "taxonomies": [
          "service-type",
          "service-tag",
          "region"
        ],
        "service-type": [
          {
            "term_id": 5,
            "name": "Additional",
            "slug": "additional",
            "term_group": 0,
            "term_taxonomy_id": 5,
            "taxonomy": "service-type",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "service-tag": [
          {
            "term_id": 6,
            "name": "Commercial",
            "slug": "commercial",
            "term_group": 0,
            "term_taxonomy_id": 6,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          },
          {
            "term_id": 7,
            "name": "Industrial",
            "slug": "industrial",
            "term_group": 0,
            "term_taxonomy_id": 7,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "region": [
          {
            "term_id": 4,
            "name": "Default",
            "slug": "default",
            "term_group": 0,
            "term_taxonomy_id": 4,
            "taxonomy": "region",
            "description": "",
            "parent": 0,
            "count": 2,
            "filter": "raw",
            "zip_codes": [
              "29585",
              "29440",
              "29585"
            ]
          }
        ]
      }
    ]
  },
  {
    "term_id": 8,
    "name": "Primary",
    "slug": "primary",
    "term_group": 0,
    "term_taxonomy_id": 8,
    "taxonomy": "service-type",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw",
    "posts": [
      {
        "ID": 78705,
        "post_author": "1",
        "post_date": "2020-07-23 08:27:22",
        "post_date_gmt": "2020-07-23 15:27:22",
        "post_content": "",
        "post_title": "Trash Pickup",
        "post_excerpt": "",
        "post_status": "publish",
        "comment_status": "closed",
        "ping_status": "closed",
        "post_password": "",
        "post_name": "trash-pickup",
        "to_ping": "",
        "pinged": "",
        "post_modified": "2020-07-23 08:27:22",
        "post_modified_gmt": "2020-07-23 15:27:22",
        "post_content_filtered": "",
        "post_parent": 0,
        "guid": "https://nr-wp.test/?post_type=service&#038;p=78705",
        "menu_order": 0,
        "post_type": "service",
        "post_mime_type": "",
        "comment_count": "0",
        "filter": "raw",
        "taxonomies": [
          "service-type",
          "service-tag",
          "region"
        ],
        "service-type": [
          {
            "term_id": 8,
            "name": "Primary",
            "slug": "primary",
            "term_group": 0,
            "term_taxonomy_id": 8,
            "taxonomy": "service-type",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "service-tag": [
          {
            "term_id": 9,
            "name": "Residential",
            "slug": "residential",
            "term_group": 0,
            "term_taxonomy_id": 9,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "region": [
          {
            "term_id": 4,
            "name": "Default",
            "slug": "default",
            "term_group": 0,
            "term_taxonomy_id": 4,
            "taxonomy": "region",
            "description": "",
            "parent": 0,
            "count": 2,
            "filter": "raw",
            "zip_codes": [
              "29585",
              "29440",
              "29585"
            ]
          }
        ]
      }
    ]
  }
]</pre>

= service_tags_all =
`GET : /service-tags/all`

> Returns
<pre>[
  {
    "term_id": 6,
    "name": "Commercial",
    "slug": "commercial",
    "term_group": 0,
    "term_taxonomy_id": 6,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw"
  },
  {
    "term_id": 7,
    "name": "Industrial",
    "slug": "industrial",
    "term_group": 0,
    "term_taxonomy_id": 7,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw"
  },
  {
    "term_id": 9,
    "name": "Residential",
    "slug": "residential",
    "term_group": 0,
    "term_taxonomy_id": 9,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw"
  }
]</pre>

= service_tags_all_with_services =
`GET : /service-tags/all-with-services`

> Returns
<pre>[
  {
    "term_id": 6,
    "name": "Commercial",
    "slug": "commercial",
    "term_group": 0,
    "term_taxonomy_id": 6,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw",
    "posts": [
      {
        "ID": 78699,
        "post_author": "1",
        "post_date": "2020-07-23 08:21:48",
        "post_date_gmt": "2020-07-23 15:21:48",
        "post_content": "",
        "post_title": "Recycling Pickup",
        "post_excerpt": "",
        "post_status": "publish",
        "comment_status": "closed",
        "ping_status": "closed",
        "post_password": "",
        "post_name": "recycling-pickup",
        "to_ping": "",
        "pinged": "",
        "post_modified": "2020-07-23 08:25:32",
        "post_modified_gmt": "2020-07-23 15:25:32",
        "post_content_filtered": "",
        "post_parent": 0,
        "guid": "https://nr-wp.test/?post_type=service&#038;p=78699",
        "menu_order": 0,
        "post_type": "service",
        "post_mime_type": "",
        "comment_count": "0",
        "filter": "raw",
        "taxonomies": [
          "service-type",
          "service-tag",
          "region"
        ],
        "service-type": [
          {
            "term_id": 5,
            "name": "Additional",
            "slug": "additional",
            "term_group": 0,
            "term_taxonomy_id": 5,
            "taxonomy": "service-type",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "service-tag": [
          {
            "term_id": 6,
            "name": "Commercial",
            "slug": "commercial",
            "term_group": 0,
            "term_taxonomy_id": 6,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          },
          {
            "term_id": 7,
            "name": "Industrial",
            "slug": "industrial",
            "term_group": 0,
            "term_taxonomy_id": 7,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "region": [
          {
            "term_id": 4,
            "name": "Default",
            "slug": "default",
            "term_group": 0,
            "term_taxonomy_id": 4,
            "taxonomy": "region",
            "description": "",
            "parent": 0,
            "count": 2,
            "filter": "raw",
            "zip_codes": [
              "29585",
              "29440",
              "29585"
            ]
          }
        ]
      }
    ]
  },
  {
    "term_id": 7,
    "name": "Industrial",
    "slug": "industrial",
    "term_group": 0,
    "term_taxonomy_id": 7,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw",
    "posts": [
      {
        "ID": 78699,
        "post_author": "1",
        "post_date": "2020-07-23 08:21:48",
        "post_date_gmt": "2020-07-23 15:21:48",
        "post_content": "",
        "post_title": "Recycling Pickup",
        "post_excerpt": "",
        "post_status": "publish",
        "comment_status": "closed",
        "ping_status": "closed",
        "post_password": "",
        "post_name": "recycling-pickup",
        "to_ping": "",
        "pinged": "",
        "post_modified": "2020-07-23 08:25:32",
        "post_modified_gmt": "2020-07-23 15:25:32",
        "post_content_filtered": "",
        "post_parent": 0,
        "guid": "https://nr-wp.test/?post_type=service&#038;p=78699",
        "menu_order": 0,
        "post_type": "service",
        "post_mime_type": "",
        "comment_count": "0",
        "filter": "raw",
        "taxonomies": [
          "service-type",
          "service-tag",
          "region"
        ],
        "service-type": [
          {
            "term_id": 5,
            "name": "Additional",
            "slug": "additional",
            "term_group": 0,
            "term_taxonomy_id": 5,
            "taxonomy": "service-type",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "service-tag": [
          {
            "term_id": 6,
            "name": "Commercial",
            "slug": "commercial",
            "term_group": 0,
            "term_taxonomy_id": 6,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          },
          {
            "term_id": 7,
            "name": "Industrial",
            "slug": "industrial",
            "term_group": 0,
            "term_taxonomy_id": 7,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "region": [
          {
            "term_id": 4,
            "name": "Default",
            "slug": "default",
            "term_group": 0,
            "term_taxonomy_id": 4,
            "taxonomy": "region",
            "description": "",
            "parent": 0,
            "count": 2,
            "filter": "raw",
            "zip_codes": [
              "29585",
              "29440",
              "29585"
            ]
          }
        ]
      }
    ]
  },
  {
    "term_id": 9,
    "name": "Residential",
    "slug": "residential",
    "term_group": 0,
    "term_taxonomy_id": 9,
    "taxonomy": "service-tag",
    "description": "",
    "parent": 0,
    "count": 1,
    "filter": "raw",
    "posts": [
      {
        "ID": 78705,
        "post_author": "1",
        "post_date": "2020-07-23 08:27:22",
        "post_date_gmt": "2020-07-23 15:27:22",
        "post_content": "",
        "post_title": "Trash Pickup",
        "post_excerpt": "",
        "post_status": "publish",
        "comment_status": "closed",
        "ping_status": "closed",
        "post_password": "",
        "post_name": "trash-pickup",
        "to_ping": "",
        "pinged": "",
        "post_modified": "2020-07-23 08:27:22",
        "post_modified_gmt": "2020-07-23 15:27:22",
        "post_content_filtered": "",
        "post_parent": 0,
        "guid": "https://nr-wp.test/?post_type=service&#038;p=78705",
        "menu_order": 0,
        "post_type": "service",
        "post_mime_type": "",
        "comment_count": "0",
        "filter": "raw",
        "taxonomies": [
          "service-type",
          "service-tag",
          "region"
        ],
        "service-type": [
          {
            "term_id": 8,
            "name": "Primary",
            "slug": "primary",
            "term_group": 0,
            "term_taxonomy_id": 8,
            "taxonomy": "service-type",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "service-tag": [
          {
            "term_id": 9,
            "name": "Residential",
            "slug": "residential",
            "term_group": 0,
            "term_taxonomy_id": 9,
            "taxonomy": "service-tag",
            "description": "",
            "parent": 0,
            "count": 1,
            "filter": "raw"
          }
        ],
        "region": [
          {
            "term_id": 4,
            "name": "Default",
            "slug": "default",
            "term_group": 0,
            "term_taxonomy_id": 4,
            "taxonomy": "region",
            "description": "",
            "parent": 0,
            "count": 2,
            "filter": "raw",
            "zip_codes": [
              "29585",
              "29440",
              "29585"
            ]
          }
        ]
      }
    ]
  }
]
</pre>

= services_all =
`GET : /services/all`

> Returns
<pre>[
  {
    "ID": 78705,
    "post_author": "1",
    "post_date": "2020-07-23 08:27:22",
    "post_date_gmt": "2020-07-23 15:27:22",
    "post_content": "",
    "post_title": "Trash Pickup",
    "post_excerpt": "",
    "post_status": "publish",
    "comment_status": "closed",
    "ping_status": "closed",
    "post_password": "",
    "post_name": "trash-pickup",
    "to_ping": "",
    "pinged": "",
    "post_modified": "2020-07-23 08:27:22",
    "post_modified_gmt": "2020-07-23 15:27:22",
    "post_content_filtered": "",
    "post_parent": 0,
    "guid": "https://nr-wp.test/?post_type=service&#038;p=78705",
    "menu_order": 0,
    "post_type": "service",
    "post_mime_type": "",
    "comment_count": "0",
    "filter": "raw",
    "link_page" : 116,
    "taxonomies": [
      "service-type",
      "service-tag",
      "region"
    ],
    "service-type": [
      {
        "term_id": 8,
        "name": "Primary",
        "slug": "primary",
        "term_group": 0,
        "term_taxonomy_id": 8,
        "taxonomy": "service-type",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
      }
    ],
    "service-tag": [
      {
        "term_id": 9,
        "name": "Residential",
        "slug": "residential",
        "term_group": 0,
        "term_taxonomy_id": 9,
        "taxonomy": "service-tag",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
      }
    ],
    "region": [
      {
        "term_id": 4,
        "name": "Default",
        "slug": "default",
        "term_group": 0,
        "term_taxonomy_id": 4,
        "taxonomy": "region",
        "description": "",
        "parent": 0,
        "count": 2,
        "filter": "raw",
        "zip_codes": [
          "29585",
          "29440",
          "29585"
        ]
      }
    ]
  },
  {
    "ID": 78699,
    "post_author": "1",
    "post_date": "2020-07-23 08:21:48",
    "post_date_gmt": "2020-07-23 15:21:48",
    "post_content": "",
    "post_title": "Recycling Pickup",
    "post_excerpt": "",
    "post_status": "publish",
    "comment_status": "closed",
    "ping_status": "closed",
    "post_password": "",
    "post_name": "recycling-pickup",
    "to_ping": "",
    "pinged": "",
    "post_modified": "2020-07-23 08:25:32",
    "post_modified_gmt": "2020-07-23 15:25:32",
    "post_content_filtered": "",
    "post_parent": 0,
    "guid": "https://nr-wp.test/?post_type=service&#038;p=78699",
    "menu_order": 0,
    "post_type": "service",
    "link_page" : null,
    "post_mime_type": "",
    "comment_count": "0",
    "filter": "raw",
    "taxonomies": [
      "service-type",
      "service-tag",
      "region"
    ],
    "service-type": [
      {
        "term_id": 5,
        "name": "Additional",
        "slug": "additional",
        "term_group": 0,
        "term_taxonomy_id": 5,
        "taxonomy": "service-type",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
      }
    ],
    "service-tag": [
      {
        "term_id": 6,
        "name": "Commercial",
        "slug": "commercial",
        "term_group": 0,
        "term_taxonomy_id": 6,
        "taxonomy": "service-tag",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
      },
      {
        "term_id": 7,
        "name": "Industrial",
        "slug": "industrial",
        "term_group": 0,
        "term_taxonomy_id": 7,
        "taxonomy": "service-tag",
        "description": "",
        "parent": 0,
        "count": 1,
        "filter": "raw"
      }
    ],
    "region": [
      {
        "term_id": 4,
        "name": "Default",
        "slug": "default",
        "term_group": 0,
        "term_taxonomy_id": 4,
        "taxonomy": "region",
        "description": "",
        "parent": 0,
        "count": 2,
        "filter": "raw",
        "zip_codes": [
          "29585",
          "29440",
          "29585"
        ]
      }
    ]
  }
]
</pre>
