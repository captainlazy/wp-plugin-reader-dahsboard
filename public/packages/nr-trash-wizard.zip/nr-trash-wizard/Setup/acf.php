<?php
if ( function_exists( 'acf_add_local_field_group' ) ):
	acf_add_local_field_group( array(
		'key'                   => 'group_5f19a2e623d4b',
		'title'                 => 'Dumpster Region Options',
		'fields'                => array(
			array(
				'key'               => 'field_5f19a2f00a058',
				'label'             => 'Zip Codes',
				'name'              => 'zip_codes',
				'type'              => 'textarea',
				'instructions'      => 'Separate zip codes by `comma`, `space` or `new line`',
				'required'          => 1,
				'conditional_logic' => 0,
				'wrapper'           => array(
					'width' => '',
					'class' => '',
					'id'    => '',
				),
				'default_value'     => '',
				'placeholder'       => '75001, 80213 80239',
				'maxlength'         => '',
				'rows'              => 5,
				'new_lines'         => '',
			),
		),
		'location'              => array(
			array(
				array(
					'param'    => 'taxonomy',
					'operator' => '==',
					'value'    => 'region',
				),
			),
		),
		'menu_order'            => 0,
		'position'              => 'normal',
		'style'                 => 'default',
		'label_placement'       => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen'        => '',
		'active'                => true,
		'description'           => '',
	) );

	acf_add_local_field_group( array(
		'key'                   => 'group_5f19ab39f1895',
		'title'                 => 'Service Options',
		'fields'                => array(
			array(
				'key'               => 'field_5f19ac7447c69',
				'label'             => 'Product Image',
				'name'              => 'product_image',
				'type'              => 'image',
				'instructions'      => '',
				'required'          => 0,
				'conditional_logic' => 0,
				'wrapper'           => array(
					'width' => '50',
					'class' => '',
					'id'    => '',
				),
				'return_format'     => 'id',
				'preview_size'      => 'medium',
				'library'           => 'all',
				'min_width'         => '',
				'min_height'        => '',
				'min_size'          => '',
				'max_width'         => '',
				'max_height'        => '',
				'max_size'          => '',
				'mime_types'        => '',
			),
			array(
				'key'               => 'field_5f19ab4946f70',
				'label'             => 'Link Page',
				'name'              => 'link_page',
				'type'              => 'post_object',
				'instructions'      => '',
				'required'          => 0,
				'conditional_logic' => 0,
				'wrapper'           => array(
					'width' => '50',
					'class' => '',
					'id'    => '',
				),
				'post_type'         => '',
				'taxonomy'          => '',
				'allow_null'        => 0,
				'multiple'          => 0,
				'return_format'     => 'id',
				'ui'                => 1,
			),
		),
		'location'              => array(
			array(
				array(
					'param'    => 'post_type',
					'operator' => '==',
					'value'    => 'service',
				),
			),
		),
		'menu_order'            => 0,
		'position'              => 'normal',
		'style'                 => 'default',
		'label_placement'       => 'top',
		'instruction_placement' => 'label',
		'hide_on_screen'        => '',
		'active'                => true,
		'description'           => '',
	) );

endif;
