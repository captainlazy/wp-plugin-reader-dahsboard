<?php

/*
 * Plugin Name: NR Trash Wizard
 * Plugin URI: https://nativerank.com/
 * Description: Trash Wizard by NATIVE RANK
 * Version: 0.0.4
 * Author: Native Rank
 * Author URI: https://www.nativerank.com
 * Text Domain: nr-trash-wizard
 * Domain Path: /i18n/languages/
 * Requires at least: 4.5
 * Requires PHP: 7.0
 *
 * @package nr-trash-wizard
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( class_exists( '\NATIVERANK\NRTrashWizard\Plugin' ) ) {
	die();
}

require __DIR__ . '/vendor/autoload.php';

// Define most essential constants.
define( 'NR_TRASH_WIZARD_VERSION', '0.0.4' );
define( 'NR_TRASH_WIZARD_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_TRASH_WIZARD_PLUGIN_MAIN_DIR', __DIR__ );
define( 'NR_TRASH_WIZARD_PLUGIN_MAIN_DIR_NAME', basename( NR_TRASH_WIZARD_PLUGIN_MAIN_DIR ) );
define( 'NR_TRASH_WIZARD_PLUGIN_NAME', 'nr_trash_wizard' );
define( 'NR_TRASH_WIZARD_PHP_MINIMUM', '7.0' );
define( 'NR_TRASH_WIZARD_CACHE_KEY', 'nr_trash_wizard_cache' );
define( 'NR_TRASH_WIZARD_MAIN_POST_TYPE', 'service' );


/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_TRASH_WIZARD_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR Trash Wizard requires PHP version %s', 'nr-trash-wizard' ), NR_TRASH_WIZARD_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-trash-wizard' )
		);
	}


	flush_rewrite_rules( true );

	do_action( 'nr_trash_wizard_activation' );

} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_TRASH_WIZARD_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_trash_wizard_deactivation', $network_wide );
} );

/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_trash_wizard_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_TRASH_WIZARD_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}


if ( version_compare( PHP_VERSION, NR_TRASH_WIZARD_PHP_MINIMUM, '>=' ) ) {
	\nativerank\Trash_Wizard\Plugin::load( NR_TRASH_WIZARD_PLUGIN_MAIN_FILE );
}

