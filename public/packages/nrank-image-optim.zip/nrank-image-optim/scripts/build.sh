#!/usr/bin/env bash


rm -rf vendor
rm composer-lock.json
composer install --no-interaction --no-dev --prefer-dist

php bin/doctum.phar update bin/docs-config.php
