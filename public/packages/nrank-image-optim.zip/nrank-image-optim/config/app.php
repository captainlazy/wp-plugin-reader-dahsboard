<?php

return [
	'options_prefix'           => 'nrank-image-optim_',
	'allowed_image_extensions' => [ 'jpg', 'jpeg', 'jpe', 'png' ]
];
