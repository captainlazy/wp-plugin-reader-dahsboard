<?php

return [
	'max_size'           => [ 1700, 1700 ],
	'quality'            => 65,
	'optimize_on_upload' => true,
	'delete_original'    => true
];
