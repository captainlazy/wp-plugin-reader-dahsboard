

(function(root) {

    var bhIndex = null;
    var rootPath = '';
    var treeHtml = '<ul><li data-name="namespace:NRank" class="opened"><div style="padding-left:0px" class="hd"><span class="icon icon-play"></span><a href="NRank.html">NRank</a></div><div class="bd"><ul><li data-name="namespace:NRank_ImageOptim" class="opened"><div style="padding-left:18px" class="hd"><span class="icon icon-play"></span><a href="NRank/ImageOptim.html">ImageOptim</a></div><div class="bd"><ul><li data-name="namespace:NRank_ImageOptim_Framework" ><div style="padding-left:36px" class="hd"><span class="icon icon-play"></span><a href="NRank/ImageOptim/Framework.html">Framework</a></div><div class="bd"><ul><li data-name="namespace:NRank_ImageOptim_Framework_Optimizers" ><div style="padding-left:54px" class="hd"><span class="icon icon-play"></span><a href="NRank/ImageOptim/Framework/Optimizers.html">Optimizers</a></div><div class="bd"><ul><li data-name="class:NRank_ImageOptim_Framework_Optimizers_Image" ><div style="padding-left:80px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Optimizers/Image.html">Image</a></div></li></ul></div></li><li data-name="namespace:NRank_ImageOptim_Framework_Storage" ><div style="padding-left:54px" class="hd"><span class="icon icon-play"></span><a href="NRank/ImageOptim/Framework/Storage.html">Storage</a></div><div class="bd"><ul><li data-name="class:NRank_ImageOptim_Framework_Storage_Options" ><div style="padding-left:80px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Storage/Options.html">Options</a></div></li><li data-name="class:NRank_ImageOptim_Framework_Storage_Options_Interface" ><div style="padding-left:80px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Storage/Options_Interface.html">Options_Interface</a></div></li></ul></div></li><li data-name="namespace:NRank_ImageOptim_Framework_Traits" ><div style="padding-left:54px" class="hd"><span class="icon icon-play"></span><a href="NRank/ImageOptim/Framework/Traits.html">Traits</a></div><div class="bd"><ul><li data-name="class:NRank_ImageOptim_Framework_Traits_With_Options" ><div style="padding-left:80px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Traits/With_Options.html">With_Options</a></div></li></ul></div></li><li data-name="class:NRank_ImageOptim_Framework_Context" ><div style="padding-left:62px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Context.html">Context</a></div></li><li data-name="class:NRank_ImageOptim_Framework_Helpers" ><div style="padding-left:62px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Helpers.html">Helpers</a></div></li><li data-name="class:NRank_ImageOptim_Framework_Optimizer" ><div style="padding-left:62px" class="hd leaf"><a href="NRank/ImageOptim/Framework/Optimizer.html">Optimizer</a></div></li></ul></div></li><li data-name="class:NRank_ImageOptim_Plugin" ><div style="padding-left:44px" class="hd leaf"><a href="NRank/ImageOptim/Plugin.html">Plugin</a></div></li></ul></div></li></ul></div></li></ul>';

    var searchTypeClasses = {
        'Namespace': 'label-default',
        'Class': 'label-info',
        'Interface': 'label-primary',
        'Trait': 'label-success',
        'Method': 'label-danger',
        '_': 'label-warning'
    };

    var searchIndex = [
                        {"type":"Namespace","link":"NRank.html","name":"NRank","doc":"Namespace NRank"},{"type":"Namespace","link":"NRank/ImageOptim.html","name":"NRank\\ImageOptim","doc":"Namespace NRank\\ImageOptim"},{"type":"Namespace","link":"NRank/ImageOptim/Framework.html","name":"NRank\\ImageOptim\\Framework","doc":"Namespace NRank\\ImageOptim\\Framework"},{"type":"Namespace","link":"NRank/ImageOptim/Framework/Optimizers.html","name":"NRank\\ImageOptim\\Framework\\Optimizers","doc":"Namespace NRank\\ImageOptim\\Framework\\Optimizers"},{"type":"Namespace","link":"NRank/ImageOptim/Framework/Storage.html","name":"NRank\\ImageOptim\\Framework\\Storage","doc":"Namespace NRank\\ImageOptim\\Framework\\Storage"},{"type":"Namespace","link":"NRank/ImageOptim/Framework/Traits.html","name":"NRank\\ImageOptim\\Framework\\Traits","doc":"Namespace NRank\\ImageOptim\\Framework\\Traits"},                                                 {"type":"Interface","fromName":"NRank\\ImageOptim\\Framework\\Storage","fromLink":"NRank/ImageOptim/Framework/Storage.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","doc":"Interface for Options implementations."},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_get","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::get","doc":"Gets the value of the given option."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_set","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::set","doc":"Sets the value for a option."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_delete","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::delete","doc":"Deletes the given option."},
            
                                                        {"type":"Class","fromName":"NRank\\ImageOptim\\Framework","fromLink":"NRank/ImageOptim/Framework.html","link":"NRank/ImageOptim/Framework/Context.html","name":"NRank\\ImageOptim\\Framework\\Context","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Context","fromLink":"NRank/ImageOptim/Framework/Context.html","link":"NRank/ImageOptim/Framework/Context.html#method___construct","name":"NRank\\ImageOptim\\Framework\\Context::__construct","doc":null},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Context","fromLink":"NRank/ImageOptim/Framework/Context.html","link":"NRank/ImageOptim/Framework/Context.html#method_logger","name":"NRank\\ImageOptim\\Framework\\Context::logger","doc":""},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim\\Framework","fromLink":"NRank/ImageOptim/Framework.html","link":"NRank/ImageOptim/Framework/Helpers.html","name":"NRank\\ImageOptim\\Framework\\Helpers","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Helpers","fromLink":"NRank/ImageOptim/Framework/Helpers.html","link":"NRank/ImageOptim/Framework/Helpers.html#method_get_temp_path","name":"NRank\\ImageOptim\\Framework\\Helpers::get_temp_path","doc":null},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Helpers","fromLink":"NRank/ImageOptim/Framework/Helpers.html","link":"NRank/ImageOptim/Framework/Helpers.html#method_is_debug","name":"NRank\\ImageOptim\\Framework\\Helpers::is_debug","doc":null},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Helpers","fromLink":"NRank/ImageOptim/Framework/Helpers.html","link":"NRank/ImageOptim/Framework/Helpers.html#method_wait_for_file","name":"NRank\\ImageOptim\\Framework\\Helpers::wait_for_file","doc":null},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim\\Framework","fromLink":"NRank/ImageOptim/Framework.html","link":"NRank/ImageOptim/Framework/Optimizer.html","name":"NRank\\ImageOptim\\Framework\\Optimizer","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Optimizer","fromLink":"NRank/ImageOptim/Framework/Optimizer.html","link":"NRank/ImageOptim/Framework/Optimizer.html#method_boot","name":"NRank\\ImageOptim\\Framework\\Optimizer::boot","doc":null},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Optimizer","fromLink":"NRank/ImageOptim/Framework/Optimizer.html","link":"NRank/ImageOptim/Framework/Optimizer.html#method_resize_from_meta_data","name":"NRank\\ImageOptim\\Framework\\Optimizer::resize_from_meta_data","doc":"Read the image paths from an attachment's meta data and process each image"},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Optimizer","fromLink":"NRank/ImageOptim/Framework/Optimizer.html","link":"NRank/ImageOptim/Framework/Optimizer.html#method_image_optim","name":"NRank\\ImageOptim\\Framework\\Optimizer::image_optim","doc":"Process an image with Smush."},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim\\Framework\\Optimizers","fromLink":"NRank/ImageOptim/Framework/Optimizers.html","link":"NRank/ImageOptim/Framework/Optimizers/Image.html","name":"NRank\\ImageOptim\\Framework\\Optimizers\\Image","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Optimizers\\Image","fromLink":"NRank/ImageOptim/Framework/Optimizers/Image.html","link":"NRank/ImageOptim/Framework/Optimizers/Image.html#method___construct","name":"NRank\\ImageOptim\\Framework\\Optimizers\\Image::__construct","doc":null},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Optimizers\\Image","fromLink":"NRank/ImageOptim/Framework/Optimizers/Image.html","link":"NRank/ImageOptim/Framework/Optimizers/Image.html#method_save","name":"NRank\\ImageOptim\\Framework\\Optimizers\\Image::save","doc":""},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim\\Framework\\Storage","fromLink":"NRank/ImageOptim/Framework/Storage.html","link":"NRank/ImageOptim/Framework/Storage/Options.html","name":"NRank\\ImageOptim\\Framework\\Storage\\Options","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options","fromLink":"NRank/ImageOptim/Framework/Storage/Options.html","link":"NRank/ImageOptim/Framework/Storage/Options.html#method___construct","name":"NRank\\ImageOptim\\Framework\\Storage\\Options::__construct","doc":"Constructor."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options","fromLink":"NRank/ImageOptim/Framework/Storage/Options.html","link":"NRank/ImageOptim/Framework/Storage/Options.html#method_get","name":"NRank\\ImageOptim\\Framework\\Storage\\Options::get","doc":"Gets the value of the given option."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options","fromLink":"NRank/ImageOptim/Framework/Storage/Options.html","link":"NRank/ImageOptim/Framework/Storage/Options.html#method_set","name":"NRank\\ImageOptim\\Framework\\Storage\\Options::set","doc":""},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options","fromLink":"NRank/ImageOptim/Framework/Storage/Options.html","link":"NRank/ImageOptim/Framework/Storage/Options.html#method_delete","name":"NRank\\ImageOptim\\Framework\\Storage\\Options::delete","doc":""},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim\\Framework\\Storage","fromLink":"NRank/ImageOptim/Framework/Storage.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","doc":"Interface for Options implementations."},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_get","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::get","doc":"Gets the value of the given option."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_set","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::set","doc":"Sets the value for a option."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface","fromLink":"NRank/ImageOptim/Framework/Storage/Options_Interface.html","link":"NRank/ImageOptim/Framework/Storage/Options_Interface.html#method_delete","name":"NRank\\ImageOptim\\Framework\\Storage\\Options_Interface::delete","doc":"Deletes the given option."},
            
                                                {"type":"Trait","fromName":"NRank\\ImageOptim\\Framework\\Traits","fromLink":"NRank/ImageOptim/Framework/Traits.html","link":"NRank/ImageOptim/Framework/Traits/With_Options.html","name":"NRank\\ImageOptim\\Framework\\Traits\\With_Options","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Framework\\Traits\\With_Options","fromLink":"NRank/ImageOptim/Framework/Traits/With_Options.html","link":"NRank/ImageOptim/Framework/Traits/With_Options.html#method___construct","name":"NRank\\ImageOptim\\Framework\\Traits\\With_Options::__construct","doc":"With_Options constructor."},
            
                                                {"type":"Class","fromName":"NRank\\ImageOptim","fromLink":"NRank/ImageOptim.html","link":"NRank/ImageOptim/Plugin.html","name":"NRank\\ImageOptim\\Plugin","doc":null},
                                {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method___construct","name":"NRank\\ImageOptim\\Plugin::__construct","doc":"Sets the plugin main file."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method_context","name":"NRank\\ImageOptim\\Plugin::context","doc":"Retrieves the plugin context object."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method_register","name":"NRank\\ImageOptim\\Plugin::register","doc":"Registers the plugin with WordPress."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method_instance","name":"NRank\\ImageOptim\\Plugin::instance","doc":"Retrieves the main instance of the plugin."},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method_update_checker","name":"NRank\\ImageOptim\\Plugin::update_checker","doc":"Check the repo for updates"},
        {"type":"Method","fromName":"NRank\\ImageOptim\\Plugin","fromLink":"NRank/ImageOptim/Plugin.html","link":"NRank/ImageOptim/Plugin.html#method_load","name":"NRank\\ImageOptim\\Plugin::load","doc":"Loads the plugin main instance and initializes it."},
            
                                // Fix trailing commas in the index
        {}
    ];

    /** Tokenizes strings by namespaces and functions */
    function tokenizer(term) {
        if (!term) {
            return [];
        }

        var tokens = [term];
        var meth = term.indexOf('::');

        // Split tokens into methods if "::" is found.
        if (meth > -1) {
            tokens.push(term.substr(meth + 2));
            term = term.substr(0, meth - 2);
        }

        // Split by namespace or fake namespace.
        if (term.indexOf('\\') > -1) {
            tokens = tokens.concat(term.split('\\'));
        } else if (term.indexOf('_') > 0) {
            tokens = tokens.concat(term.split('_'));
        }

        // Merge in splitting the string by case and return
        tokens = tokens.concat(term.match(/(([A-Z]?[^A-Z]*)|([a-z]?[^a-z]*))/g).slice(0,-1));

        return tokens;
    };

    root.Doctum = {
        /**
         * Cleans the provided term. If no term is provided, then one is
         * grabbed from the query string "search" parameter.
         */
        cleanSearchTerm: function(term) {
            // Grab from the query string
            if (typeof term === 'undefined') {
                var name = 'search';
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)");
                var results = regex.exec(location.search);
                if (results === null) {
                    return null;
                }
                term = decodeURIComponent(results[1].replace(/\+/g, " "));
            }

            return term.replace(/<(?:.|\n)*?>/gm, '');
        },

        /** Searches through the index for a given term */
        search: function(term) {
            // Create a new search index if needed
            if (!bhIndex) {
                bhIndex = new Bloodhound({
                    limit: 500,
                    local: searchIndex,
                    datumTokenizer: function (d) {
                        return tokenizer(d.name);
                    },
                    queryTokenizer: Bloodhound.tokenizers.whitespace
                });
                bhIndex.initialize();
            }

            results = [];
            bhIndex.get(term, function(matches) {
                results = matches;
            });

            if (!rootPath) {
                return results;
            }

            // Fix the element links based on the current page depth.
            return $.map(results, function(ele) {
                if (ele.link.indexOf('..') > -1) {
                    return ele;
                }
                ele.link = rootPath + ele.link;
                if (ele.fromLink) {
                    ele.fromLink = rootPath + ele.fromLink;
                }
                return ele;
            });
        },

        /** Get a search class for a specific type */
        getSearchClass: function(type) {
            return searchTypeClasses[type] || searchTypeClasses['_'];
        },

        /** Add the left-nav tree to the site */
        injectApiTree: function(ele) {
            ele.html(treeHtml);
        }
    };

    $(function() {
        // Modify the HTML to work correctly based on the current depth
        rootPath = $('body').attr('data-root-path');
        treeHtml = treeHtml.replace(/href="/g, 'href="' + rootPath);
        Doctum.injectApiTree($('#api-tree'));
    });

    return root.Doctum;
})(window);

$(function() {

    
    
        // Toggle left-nav divs on click
        $('#api-tree .hd span').on('click', function() {
            $(this).parent().parent().toggleClass('opened');
        });

        // Expand the parent namespaces of the current page.
        var expected = $('body').attr('data-name');

        if (expected) {
            // Open the currently selected node and its parents.
            var container = $('#api-tree');
            var node = $('#api-tree li[data-name="' + expected + '"]');
            // Node might not be found when simulating namespaces
            if (node.length > 0) {
                node.addClass('active').addClass('opened');
                node.parents('li').addClass('opened');
                var scrollPos = node.offset().top - container.offset().top + container.scrollTop();
                // Position the item nearer to the top of the screen.
                scrollPos -= 200;
                container.scrollTop(scrollPos);
            }
        }

    
    
        var form = $('#search-form .typeahead');
        form.typeahead({
            hint: true,
            highlight: true,
            minLength: 1
        }, {
            name: 'search',
            displayKey: 'name',
            source: function (q, cb) {
                cb(Doctum.search(q));
            }
        });

        // The selection is direct-linked when the user selects a suggestion.
        form.on('typeahead:selected', function(e, suggestion) {
            window.location = suggestion.link;
        });

        // The form is submitted when the user hits enter.
        form.keypress(function (e) {
            if (e.which == 13) {
                $('#search-form').submit();
                return true;
            }
        });

    
});


