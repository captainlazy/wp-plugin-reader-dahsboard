<?php


namespace NRank\ImageOptim\Framework;


use Adbar\Dot;
use Monolog\ErrorHandler;
use Monolog\Handler\ChromePHPHandler;
use Monolog\Handler\StreamHandler;
use Monolog\Logger;
use PHLAK\Config\Config;
use PHLAK\Config\Exceptions\InvalidContextException;

final class Context {

	/**
	 * @var Dot
	 */
	public $config;

	/**
	 * @var Dot
	 */
	public $options;


	public function __construct() {

		try {
			$this->config  = new Dot( ( new Config( NRANKIMAGEOPTIM_CONFIG_DIR_PATH . '/app.php' ) )->toArray() );
			$this->options = new Dot( ( new Config( NRANKIMAGEOPTIM_CONFIG_DIR_PATH . '/options.php' ) )->toArray() );
		} catch ( InvalidContextException $e ) {
			$this->logger()->error( $e );
		}

	}


	/**
	 * @return Logger
	 */
	public function logger() {
		$logger = new Logger( 'app' );
		$logger->pushHandler( new StreamHandler( NRANKIMAGEOPTIM_PLUGIN_DIR . '/app.log', Helpers::is_debug() ? Logger::DEBUG : Logger::ERROR ) );
		if ( Helpers::is_debug() ) {
			$logger->pushHandler( new ChromePHPHandler() );
		}

		ErrorHandler::register( $logger );

		return $logger;
	}
}
