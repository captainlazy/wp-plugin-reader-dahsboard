<?php


namespace NRank\ImageOptim\Framework;


use NRank\ImageOptim\Framework\Optimizers\Image;
use NRank\ImageOptim\Framework\Traits\With_Options;


class Optimizer {

	use With_Options;


	public function boot() {

		return call_user_func_array( [ $this, 'resize_from_meta_data' ], func_get_args() );
	}

	/**
	 * Read the image paths from an attachment's meta data and process each image
	 *
	 * Called after `wp_generate_attachment_metadata` is completed.
	 *
	 * @param $meta
	 * @param null $ID
	 *
	 * @return mixed
	 */
	function resize_from_meta_data( $meta, $ID = null ) {

		if ( $ID && wp_attachment_is_image( $ID ) === false ) {
			return $meta;
		}

		//File path and URL for original image
		$attachment_file_path = get_attached_file( $ID );

		// TODO: new GifOptimizer
		$image_exts = $this->context->config->get( 'allowed_image_extensions' );
		$ext        = wp_check_filetype( $attachment_file_path )['ext'];

		if ( ! in_array( $ext, $image_exts ) ) {
			return $meta;
		}

		// If images has other registered size, optimize them first
		if ( ! empty( $meta['sizes'] ) ) {

			foreach ( $meta['sizes'] as $size_key => $size_data ) {

				// We take the original image. The 'sizes' will all match the same URL and
				// path. So just get the dirname and replace the filename.

				$sub_attachment_file_path = trailingslashit( dirname( $attachment_file_path ) ) . $size_data['file'];

				//Store details for each size key
				$response = $this->image_optim( $sub_attachment_file_path, true );

				if ( is_wp_error( $response ) ) {
					return $response;
				}
			}
		}

		$full_image_response = $this->image_optim( $attachment_file_path, null );

		$meta['width']  = $full_image_response->getWidth();
		$meta['height'] = $full_image_response->getHeight();


		if ( $this->options->get( 'delete_original' ) ) {
			if ( isset( $meta['original_image'] ) && $meta['original_image'] !== $meta['file'] ) {
				$original_image         = trailingslashit( dirname( $attachment_file_path ) ) . $meta['original_image'];
				$raw_file_name_with_dir = $meta['file'];
				$file_name_ar           = explode( '/', $raw_file_name_with_dir );
				$file_name              = array_pop( $file_name_ar );

				$file = trailingslashit( dirname( $attachment_file_path ) ) . $file_name;

				$helper = new Helpers();

				$helper->wait_for_file( $file );

				$this->delete_file( $original_image );

				$rename_success = @rename( $file, $original_image );

				if ( ! $rename_success ) {
					copy( $file, $original_image );
					$this->delete_file( $file );
				}

				if ( file_exists( $original_image ) && ! file_exists( $file ) ) {
					update_attached_file( $ID, $original_image );
				}

				$meta['file'] = preg_replace( "/{$file_name}$/", $meta['original_image'], $meta['file'], 1 );
			}
		}
		
		return $meta;
	}


	/**
	 * Process an image with Smush.
	 *
	 * Returns an array of the $file $results.
	 *
	 * @param string $file_path Full absolute path to the image file
	 * @param bool $ignore_max_size
	 *
	 * @return bool|\Intervention\Image\Image
	 */
	function image_optim( $file_path = '', $ignore_max_size = false ) {

		if ( empty( $file_path ) ) {
			$this->context->logger()->error( "empty_path", [ __( "File path is empty", 'nrank-image-optim' ) ] );

			return false;
		}

		// check that the file exists
		if ( ! file_exists( $file_path ) || ! is_file( $file_path ) ) {
			$this->context->logger()->error( "file_not_found", [ sprintf( __( "Could not find %s", 'nrank-image-optim' ), $file_path ) ] );

			return false;
		}

		// check that the file is writable
		if ( ! is_writable( dirname( $file_path ) ) ) {
			$this->context->logger()->error( "not_writable", [ sprintf( __( "%s is not writable", 'nrank-image-optim' ), dirname( $file_path ) ) ] );

			return false;
		}

		$file_size = file_exists( $file_path ) ? filesize( $file_path ) : 0;

		//Check if file exists
		if ( $file_size == 0 ) {
			$this->context->logger()->error( "image_not_found", [ sprintf( __( 'Skipped (%s), image not found.', 'nrank-image-optim' ), $this->format_bytes( $file_size ) ) ] );

			return false;
		}

		$tempfile = Helpers::get_temp_path( $file_path );

		$max_size = $ignore_max_size ? null : $this->options->get( 'max_size' );

		$response = new Image( $file_path, $max_size, $this->options->get( 'quality' ) );

		$response = $response->save( $tempfile );

		if ( ! $response instanceof \Intervention\Image\Image ) {
			$this->context->logger()->error( "false_response", $response['message'] );
		}
		//If there is no data
		if ( empty( $response ) ) {
			$this->context->logger()->error( "no_data", __( 'Unknown API error', 'nrank-image-optim' ) );
		}

		//replace the file
		$success = @rename( $tempfile, $file_path );

		//If file renaming was successful
		if ( ! $success ) {
			copy( $tempfile, $file_path );
			$this->delete_file( $tempfile );
		}

		return $response;
	}


	private function delete_file( $file ) {
		//if tempfile still exists, unlink it
		if ( file_exists( $file ) ) {
			unlink( $file );
		}
	}

	/**
	 * Return the filesize in a humanly readable format.
	 * Taken from http://www.php.net/manual/en/function.filesize.php#91477
	 *
	 * @param $bytes
	 * @param int $precision
	 *
	 * @return string
	 */
	private function format_bytes( $bytes, $precision = 2 ) {
		$units = array( 'B', 'KB', 'MB', 'GB', 'TB' );
		$bytes = max( $bytes, 0 );
		$pow   = floor( ( $bytes ? log( $bytes ) : 0 ) / log( 1024 ) );
		$pow   = min( $pow, count( $units ) - 1 );
		$bytes /= pow( 1024, $pow );

		return round( $bytes, $precision ) . ' ' . $units[ $pow ];
	}


}
