<?php


namespace NRank\ImageOptim\Framework\Optimizers;


use Intervention\Image\ImageManager;

class Image {


	/**
	 * @var int
	 */
	protected $max_width = 1500;

	/**
	 * @var int
	 */
	protected $max_height = 1500;

	/**
	 * @var int
	 */
	protected $quality = 80;


	/**
	 * @var ImageManager
	 */
	protected $manager;

	/**
	 * @var \Intervention\Image\Image
	 */
	protected $image;

	/**
	 * @var string
	 */
	protected $file_path;


	public function __construct( $file_path, $max_size = [ 1500, 1500 ], $quality ) {


		$this->file_path = $file_path;
		$this->manager   = new ImageManager();

		$this->image = $this->manager->make( $file_path );

		$this->quality = (int) $quality;

		if ( $max_size !== null && is_array( $max_size ) ) {
			$this->max_width  = (int) $max_size[0];
			$this->max_height = (int) $max_size[1];
			$this->resize();
		}


		return $this;
	}

	private function resize() {
		$this->image->resize( $this->max_width, $this->max_height, function ( $constraint ) {
			$constraint->aspectRatio();
			$constraint->upsize();
		} );
	}

	/**
	 * @param $path
	 *
	 * @return \Intervention\Image\Image
	 */
	public function save( $path ) {
		return $this->image->save( $path, $this->quality );
	}


}
