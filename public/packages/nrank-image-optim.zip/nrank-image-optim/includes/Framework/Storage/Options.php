<?php


namespace NRank\ImageOptim\Framework\Storage;


use NRank\ImageOptim\Framework\Context;

class Options implements Options_Interface {

	/**
	 * Plugin context.
	 *
	 * @since 0.0.1
	 * @var Context
	 */
	private $context;

	const optionDoesNotExistMessage = "%s does not exist in config/options.php";

	/**
	 * Options will be stored with this prefix.
	 *
	 * @since 0.0.2
	 * @var string
	 */
	protected $prefix;

	/**
	 * Constructor.
	 *
	 * @param Context $context Plugin context.
	 *
	 * @since 0.0.1
	 *
	 */
	public function __construct( Context $context ) {
		$this->context = $context;

		$this->prefix = $this->context->config->get( 'options_prefix' );
	}

	/**
	 * Gets the value of the given option.
	 *
	 * @param string $option Option name.
	 *
	 * @param mixed $default Default value.
	 *
	 * @return mixed Value set for the option, or false if not set.
	 * @since 0.0.1
	 */
	public function get( $option, $default = null ) {
		if ( ! $this->existsInConfig( $option ) ) {
			return $this->logError( $option );
		}

		$default = $default ?? $this->context->options->get( $option );

		return get_option( $this->prefix . $option, $default );
	}

	/**
	 * @inheritDoc
	 */
	public function set( $option, $value ) {
		if ( ! $this->existsInConfig( $option ) ) {
			return $this->logError( $option );
		}

		return update_option( $this->prefix . $option, $value );
	}

	/**
	 * @inheritDoc
	 */
	public function delete( $option ) {


		return delete_option( $option );
	}

	private function existsInConfig( $option ) {

		return $this->context->options->has( $option );
	}

	private function logError( $option ) {
		$message = sprintf( self::optionDoesNotExistMessage, $option );
		$this->context->logger()->error( $message );

		return new \Exception( $message );
	}
}
