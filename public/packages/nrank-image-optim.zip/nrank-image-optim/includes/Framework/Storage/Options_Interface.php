<?php


namespace NRank\ImageOptim\Framework\Storage;


/**
 * Interface for Options implementations.
 *
 * @since 0.0.1
 * @access private
 * @ignore
 */
interface Options_Interface {


	/**
	 * Gets the value of the given option.
	 *
	 * @param string $option Option name.
	 *
	 * @param mixed $default Default value.
	 *
	 * @return mixed Value set for the option, or false if not set.
	 * @since 0.0.1
	 */
	public function get( $option, $default );

	/**
	 * Sets the value for a option.
	 *
	 * @param string $option Option name.
	 * @param mixed $value Option value. Must be serializable if non-scalar.
	 *
	 * @return bool True on success, false on failure.
	 * @since 0.0.1
	 *
	 */
	public function set( $option, $value );

	/**
	 * Deletes the given option.
	 *
	 * @param string $option Option name.
	 *
	 * @return bool True on success, false on failure.
	 * @since 0.0.1
	 *
	 */
	public function delete( $option );
}
