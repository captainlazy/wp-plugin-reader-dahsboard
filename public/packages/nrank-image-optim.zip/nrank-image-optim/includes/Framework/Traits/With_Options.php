<?php


namespace NRank\ImageOptim\Framework\Traits;


use NRank\ImageOptim\Framework\Context;
use NRank\ImageOptim\Framework\Storage\Options;

trait With_Options {


	/**
	 * @var Options
	 */
	protected $options;


	/**
	 * @var Context
	 */
	protected $context;

	/**
	 * With_Options constructor.
	 *
	 * @param Options $options
	 * @param Context $context
	 */
	public function __construct( Options $options, Context $context ) {
		$this->options = $options;
		$this->context = $context;
	}

}
