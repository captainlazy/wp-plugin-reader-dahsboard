<?php

namespace NRank\ImageOptim\Framework;


class Helpers {

	private $TRY_INCREMENT = 0;

	public static function get_temp_path( $path ) {
		$path = pathinfo( $path );

		return "{$path['dirname']}/{$path['filename']}.tmp.{$path['extension']}";
	}

	public static function is_debug() {
		return defined( 'WP_DEBUG' ) && true === WP_DEBUG;
	}

	public function wait_for_file( $file_path, $try = 4 ) {

		if ( ! file_exists( $file_path ) ) {
			$this->TRY_INCREMENT += 1;
			if ( $this->TRY_INCREMENT > $try ) {
				return false;
			}
			sleep( 2 );
		}

		return true;
	}
}
