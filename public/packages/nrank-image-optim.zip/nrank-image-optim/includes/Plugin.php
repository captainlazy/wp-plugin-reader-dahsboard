<?php


namespace NRank\ImageOptim;


use NRank\ImageOptim\Framework\Context;
use NRank\ImageOptim\Framework\Optimizer;
use NRank\ImageOptim\Framework\Storage\Options;
use Puc_v4_Factory;

final class Plugin {

	/**
	 * The plugin context object.
	 *
	 * @since 0.0.1
	 * @var Context
	 */
	private $context;

	/**
	 * Main instance of the plugin.
	 *
	 * @since 0.0.1
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 *
	 * @since 0.0.1
	 *
	 */
	public function __construct() {
		$this->context = new Context();
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 * @since 0.0.1
	 *
	 */
	public function context() {
		return $this->context;
	}

	/**
	 * Registers the plugin with WordPress.
	 *
	 * @since 0.0.1
	 */
	public function register() {

		$display_nrank_image_optim_meta = function () {
			printf( '<meta name="generator" content="NRank Image Optim by Native Rank %s" />', esc_attr( NRANKIMAGEOPTIM_VERSION ) );
		};
		add_action( 'wp_head', $display_nrank_image_optim_meta );
		add_action( 'login_head', $display_nrank_image_optim_meta );

		$options = new Options( $this->context );


		if ( $options->get( 'optimize_on_upload' ) ) {
			add_filter( 'wp_generate_attachment_metadata', array(
				( new Optimizer( $options, $this->context ) ),
				'boot'
			), 15, 2 );
		}
	}


	/**
	 * Retrieves the main instance of the plugin.
	 *
	 * @return Plugin Plugin main instance.
	 * @since 0.0.1
	 *
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Check the repo for updates
	 * @since 0.0.4
	 */
	public function update_checker() {
		Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NRANKIMAGEOPTIM_PLUGIN_DIR_NAME,
			NRANKIMAGEOPTIM_PLUGIN_MAIN_FILE,
			NRANKIMAGEOPTIM_PLUGIN_DIR_NAME
		);
	}


	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 * @since 0.0.1
	 *
	 */
	public static function load() {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static();
		static::$instance->register();


		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ] );

		return true;
	}
}


