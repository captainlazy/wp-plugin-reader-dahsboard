<?php
/**
 * Plugin Name: NRank Image Optim
 * Plugin URI: https://nativerank.com/
 * Description: An Image Optimizer by Native Rank
 * Version: 0.0.61
 * Author: Native Rank
 * Author URI: https://www.nativerank.com
 * Text Domain: nrank-image-optim
 * Domain Path: /i18n/languages/
 * Requires at least: 5.0.0
 * Requires PHP: 7.0
 *
 * @package nrank-seo
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NRANKIMAGEOPTIM_VERSION', '0.0.61' );
define( 'NRANKIMAGEOPTIM_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NRANKIMAGEOPTIM_PLUGIN_DIR', __DIR__ );
define( 'NRANKIMAGEOPTIM_PLUGIN_DIR_NAME', basename( __DIR__ ) );
define( 'NRANKIMAGEOPTIM_PHP_MINIMUM', '5.6.0' );
define( 'NRANKIMAGEOPTIM_CONFIG_DIR_PATH', __DIR__ . '/config' );

$loader = require __DIR__ . '/vendor/autoload.php';


/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated with an insufficient version of PHP.
 *
 * @param bool $network_wide Whether to activate network-wide.
 *
 * @since 0.0.1
 * @access private
 *
 */
function nrankimageoptim_activate_plugin( $network_wide ) {
	if ( version_compare( PHP_VERSION, NRANKIMAGEOPTIM_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'Site Kit requires PHP version %s', 'nrank-image-optim' ), NRANKIMAGEOPTIM_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nrank-image-optim' )
		);
	}

	if ( $network_wide ) {
		return;
	}

	do_action( 'nrankimageoptim_activation', $network_wide );
}

register_activation_hook( __FILE__, 'nrankimageoptim_activate_plugin' );


/**
 * Handles plugin deactivation.
 *
 * @param bool $network_wide Whether to deactivate network-wide.
 *
 * @since 0.0.1
 * @access private
 *
 */
function nrankimageoptim_deactivate_plugin( $network_wide ) {
	if ( version_compare( PHP_VERSION, NRANKIMAGEOPTIM_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( $network_wide ) {
		return;
	}

	do_action( 'nrankimageoptim_deactivation', $network_wide );
}

register_deactivation_hook( __FILE__, 'nrankimageoptim_deactivate_plugin' );


/**
 * Resets opcache if possible.
 *
 * @since 0.0.1
 * @access private
 */
function nrankimageoptim_opcache_reset() {
	if ( version_compare( PHP_VERSION, NRANKIMAGEOPTIM_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}


	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nrankimageoptim_opcache_reset' );

if ( version_compare( PHP_VERSION, NRANKIMAGEOPTIM_PHP_MINIMUM, '>=' ) ) {


	\NRank\ImageOptim\Plugin::load();

}
