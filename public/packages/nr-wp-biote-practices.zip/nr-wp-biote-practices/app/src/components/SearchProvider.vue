<template>
    <div>
        <div class="uk-container uk-container-small">

            <div class="uk-margin-top uk-margin-bottom uk-text-center uk-flex-middle uk-flex uk-flex-center">

                <a class="uk-margin-right uk-h3 uk-margin-remove-bottom" @click="$emit('defaultView')" uk-tooltip
                   title="Search practices near your location"><i
                        class="fas fa-arrow-left"></i></a>
                <div class="uk-inline">

                    <span class="uk-form-icon" uk-icon="icon: search"></span>
                    <input class="uk-input uk-width-large uk-display-block uk-margin-auto"
                           placeholder="Search for a practitioner" v-model="searchInput">
                </div>

            </div>
            <virtual-list :size="52" :remain="14" :bench="38" wtag="ul" :start="0"
                          wclass="transfer_accordion" v-if="providers" ref="virtualList">
                <li v-for="(provider,idx) in filteredProviders" :key="idx"
                    v-if="`${provider.first_name} ${provider.last_name}, ${provider.degree}`.length > 2"
                >
                    <a class="uk-accordion-title"
                       href="#"
                       @click="selectedProvider = null, getPractices(provider.practices)"
                       v-html="highlightSearch(`${provider.first_name} ${provider.last_name}, ${provider.degree}` )"
                    ></a>
                    <div class="uk-accordion-content">
                        <div class="uk-flex-middle" uk-grid="">
                            <div class="uk-margin-auto" v-if="!selectedProvider">
                                <span style="color:#f57e20" uk-spinner="ratio: 2.5"></span>
                            </div>
                            <div v-if="selectedProvider" class="uk-width-expand@m">
                                <div class="uk-card uk-card-default location-card simple uk-margin"
                                     v-for="(provider, idx) in selectedProvider"
                                     :key="idx">
                                    <div class="uk-flex-middle uk-grid-small uk-grid" uk-grid="">
                                        <div class="uk-width-expand@m uk-first-column"
                                             :class="((provider.website  && provider.website !== 'http://') || provider.phone) ? 'divider' : ''">
                                            <div class="">
                                                Practice Name:
                                                <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                                   target="_self">
                                                    <h3 class="uk-margin-remove">
                                                        {{provider.name}}</h3></a>
                                                <address class="uk-margin-small">{{provider.address.street_address}},
                                                    {{provider.address.city}}, {{provider.address.state}}
                                                    {{provider.address.zip}}
                                                </address>
                                                <div class="uk-margin-small-top"><a
                                                        :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                                        class="uk-text-primary uk-margin-right" target="_blank"><i
                                                        class="fas fa-location-arrow"></i>
                                                    Get Directions</a><a
                                                        :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                                        class="uk-button uk-button-primary uk-magrin-left"
                                                        disabled><i class="fas fa-info-circle"></i> Details</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-auto@m"
                                             v-if="(provider.website  && provider.website != 'http://') || provider.phone">
                                            <div class="links ">
                                                <div v-if="provider.website  && provider.website != 'http://'">
                                                    <a :href="provider.website"
                                                       target="_blank">
                                                        <i class="fas fa-globe uk-text-primary uk-margin-small-right "></i>
                                                        Website
                                                    </a>
                                                </div>
                                                <div class="uk-margin">
                                                    <a :href="`tel:+${provider.country_code + provider.phone.raw}`"
                                                       v-if="provider.phone">
                                                        <i class="fas fa-phone uk-text-primary uk-margin-small-right "></i>
                                                        {{provider.phone.raw | formatPhoneNumber}}</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </li>
            </virtual-list>
        </div>
    </div>
</template>

<script>/* */
import axios from 'axios';
import virtualList from 'vue-virtual-scroll-list';
import debounce from 'lodash/debounce';

export default {
    name: 'SearchProvider',
    components: {'virtual-list': virtualList},
    data() {
        return {
            providers: null,
            searchInput: '',
            selectedProvider: null,
            apiHost: (window.nr_biote_locator_globals && window.nr_biote_locator_globals.site_url) || 'https://www.biotemedical.com',
        };
    },
    computed: {
        filteredProviders() {
            if (this.searchInput === '') {
                return this.providers.filter(function (input) {
                    let name = `${input.first_name} ${input.last_name}, ${input.degree}`
                    return name.length > 3
                });
            }
            return this.providers.filter(input => `${input.first_name} ${input.last_name}, ${input.degree}`.length > 3 && `${input.first_name} ${input.last_name}, ${input.degree}`.toUpperCase()
                .indexOf(this.searchInput.toUpperCase()) > -1
            );
        },
    },
    methods: {
        highlightSearch(value) {
            const query = this.searchInput;
            if (query === '') {
                return value;
            }
            const re = new RegExp(query, 'ig');
            return value.replace(re, (match) => {
                return `<span>${match}</span>`;
            });
        },
        getPractices: debounce(function (practiceIds) {
            axios.get(`${this.apiHost}/wp-json/nativerank/v1/providers/practice_ids/q=${practiceIds}`)
                .then((res) => {
                    this.selectedProvider = res.data;
                });
        }, 500),
    },
    mounted() {
        axios.get(`${this.apiHost}/wp-json/nativerank/v1/practitioners/all`)
            .then((res) => {
                this.providers = res.data;
                setTimeout(() => {
                    UIkit.accordion(document.querySelector('.transfer_accordion'));
                }, 10);
            });
    },
};
</script>

<style>
    .transfer_accordion:not(.uk-accordion) {
        opacity: 0;
    }
</style>
