<template>
    <div id="bioTEApp" class="desktop">
        <section class="uk-section-default uk-position-relative uk-position-z-index">
            <div class="uk-section uk-section-small uk-background-cover uk-background-center-center"
                 :data-src="apiHost + '/wp-content/uploads/2019/04/hero-1.jpg'" uk-img>
                <div class="uk-container uk-container-large">
                    <h1 class="uk-text-center uk-h1">
                        {{ title }}
                    </h1>
                    <div v-if="defaultView"
                         class="uk-card provider_search uk-margin-auto uk-position-relative uk-animation-slide-top uk-animation-fast">
                        <gmap-autocomplete class="uk-input" :value="user.search" :select-first-on-enter="true"
                                           @place_changed="setPlace"
                                           placeholder="Zip Code or City, State" ref="userSearch">
                        </gmap-autocomplete>
                        <button class="nr-form-icon uk-button uk-button-primary" style="z-index: 9;"
                                @click="userCustomSearch()">
                            <i class="fas fa-search"></i>
                        </button>
                        <i class="clear fas fa-times uk-position-absolute"
                           v-if="user.search && user.search.length > 0"
                           @click="user.search = '', $refs.userSearch.$el.value = '', $refs.userSearch.$el.focus()"></i>
                    </div>
                    <div v-if="defaultView"
                         class="uk-panel uk-margin-small uk-margin-auto uk-animation-slide-top uk-animation-fast"
                         :style="{maxWidth: '500px'}">
                        <div uk-grid="uk-child-width-auto" class="uk-flex-middle uk-flex-between">
                            <div>
                                <button class="uk-button uk-button-default current_location"
                                        @click="getCurrentLocation">
                                    <i role="button" class="fas fa-location-arrow"></i> Current Location
                                </button>
                            </div>
                            <div>
                <span id="search_by_name">Search By <span
                    class="link" @click="searchByPractice">Practice</span> | <span
                    class="link" @click="searchByProvider">Practitioner</span></span>
                            </div>
                        </div>
                        <div class="uk-flex-center uk-margin-top uk-child-width-1-1@m" uk-grid="">
                            <div class="providerMessage uk-text-center"
                                 :class="loading || loadingCurrentLocation ? `loading ${loadingCurrentLocation ? 'current-location-loading' : ''}` : ''"
                                 v-html="providerMessage">
                            </div>
                            <div v-if="providers"
                                 class="uk-flex uk-flex-middle uk-flex-center uk-margin-small-top">
                                <div class="uk-inline">
                                    <div>
                                        <input class="userRadius" style="cursor: pointer" readonly v-model="user.radius"
                                               @click="radiusOptions">
                                        <span>Miles Radius</span>
                                    </div>
                                    <div id="radius-options"
                                         class="uk-padding-remove miles-dropdown"
                                         uk-dropdown="pos: bottom-left;mode:click" style="z-index: 9999;">
                                        <ul class="uk-nav uk-dropdown-nav uk-padding-remove">
                                            <li v-for="mile in [50, 75, 100, 150, 200]" :key="mile"
                                                :class="user.radius === mile ? 'uk-active' : ''">
                                                <a @click="user.radius = mile">{{ mile }} Miles</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>
        <section class="uk-section uk-section-small uk-section-muted"
                 id="mapSection"
                 v-if="defaultView && providers && (providers.length > 0)">
            <div class="uk-container">
                <div class="uk-child-width-auto@m" uk-grid="">
                    <div>
                        <div class="uk-panel" v-if="recentlySearched.length > 0" id="recentlySearched">
                            <h3 class="uk-light uk-margin-remove uk-h4 uk-margin-remove">Recently Visited</h3>
                            <div uk-slider="finite:true" class="uk-margin-small-bottom">
                                <div class="uk-position-relative" tabindex="-1">
                                    <div class="uk-slider-container">
                                        <ul class="uk-slider-items uk-grid-small uk-child-width-1-2@s uk-grid">
                                            <li v-for="(provider, idx) in recentlySearched" :key="idx">
                                                <div class="uk-card uk-card-default uk-card-small uk-card-body">
                                                    <a class="title"
                                                       :title="provider.name"
                                                       @click="gtmTracking('Provider Page Link', 'Click', provider.name)"
                                                       :href="`/bioidentical-hormone-replacement-therapy-provider/${provider.slug}`">{{
                                                            provider.name
                                                        }}</a>
                                                    <hr class="uk-margin-remove">
                                                    <div class="uk-flex uk-flex-between">
                                                        <div>
                    <span class="uk-text-meta uk-display-block">
                      {{ provider.distance | miles }} MILES:
                    </span>
                                                            <a :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                                               class="uk-margin-right link" target="_blank"
                                                               @click="gtmTracking('Provider Get Direction Link', 'Click', provider.name)">
                                                                <i class="fas fa-location-arrow"></i>
                                                                Directions</a>
                                                        </div>
                                                        <div>
                                                            <span class="uk-text-meta uk-display-block ">Phone:</span>
                                                            <a class="link"
                                                               :href="`tel:+${provider.country_code + provider.phone.raw}`"
                                                               v-if="provider.phone"
                                                               @click="gtmTracking('Provider Phone Link', 'Click', provider.name)">
                                                                <i class="fas fa-phone"></i>
                                                                {{ provider.phone.raw | formatPhoneNumber }}</a>
                                                        </div>

                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>

                                    <a class="uk-position-center-left-out uk-position-small"
                                       style="margin-left:5px;margin-right:5px;"
                                       href="#" uk-slidenav-previous
                                       uk-slider-item="previous"></a>
                                    <a class="uk-position-center-right-out uk-position-small"
                                       style="margin-left:5px;margin-right:5px;"
                                       href="#" uk-slidenav-next
                                       uk-slider-item="next"></a>
                                </div>
                                <ul class="uk-slider-nav uk-dotnav uk-flex-center uk-margin"></ul>

                            </div>


                        </div>
                        <div>
                            <div v-for="(provider , idx) in providers" :key="idx"
                            >
                                <div class="uk-card uk-card-default location-card uk-margin" :data-idx="idx"
                                     @mouseenter="selectedProvider = provider, selectedProvider.index=idx,
                      seelctCard($event)">
                                    <div class="uk-flex-middle uk-grid-small uk-grid" uk-grid="">
                                        <div class="uk-width-expand@m uk-first-column"
                                             :class="((provider.website  && provider.website !== 'http://') || provider.phone) ? 'divider' : ''">
                                            <div class="">
                                                <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                                   target="_self"
                                                   @click="gtmTracking('Provider Page Link', 'Click', provider.name), checkRecentlySearched(provider, 'set')">
                                                    <h3 class="uk-margin-remove">
                                                        {{ provider.name }}</h3></a>
                                                <address class="uk-margin-small">{{ provider.address.street_address }},
                                                    {{ provider.address.city }}, {{ provider.address.state }}
                                                    {{ provider.address.zip }}
                                                </address>
                                                <span class="uk-text-meta"><a
                                                    target="_blank"
                                                    @click="gtmTracking('Provider Get Direction Link', 'Click', provider.name)"
                                                    :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                                    class="uk-link-reset">{{
                                                        provider.distance | miles
                                                    }} MI FROM YOU</a></span>
                                                <div><a
                                                    :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                                    class="uk-text-primary uk-margin-right" target="_blank"
                                                    @click="gtmTracking('Provider Get Direction Link', 'Click', provider.name)"><i
                                                    class="fas fa-location-arrow"></i>
                                                    Get Directions</a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="uk-width-auto@m"
                                             v-if="(provider.website  && provider.website != 'http://') || provider.phone">
                                            <div class="links ">
                                                <div v-if="provider.website  && provider.website != 'http://'">
                                                    <a :href="provider.website"
                                                       target="_blank"
                                                       class="uk-width-1-1"
                                                       @click="gtmTracking('Provider Website External Link', 'Click', provider.name)"><i
                                                        class="fas fa-globe uk-text-primary uk-margin-small-right "></i>Website</a>
                                                </div>
                                                <hr class="uk-margin-small"
                                                    v-if="provider.website  && provider.website != 'http://'">
                                                <div class="uk-margin-small" v-if="provider.phone">
                                                    <a :href="`tel:+${provider.country_code + provider.phone.raw}`"
                                                       v-if="provider.phone"
                                                       @click="gtmTracking('Provider Phone Link', 'Click', provider.name)"><i
                                                        class="fas fa-phone uk-text-primary uk-margin-small-right "></i>{{
                                                            provider.phone.raw
                                                                |
                                                                formatPhoneNumber
                                                        }}</a>
                                                </div>
                                                <hr class="uk-margin-small" v-if="provider.phone">
                                                <div>
                                                    <a
                                                        :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                                        class="uk-button uk-button-primary uk-magrin-left"
                                                        @click="gtmTracking('Provider Page Link', 'Click', provider.name), checkRecentlySearched(provider, 'set')"
                                                        disabled><i class="fas fa-info-circle"></i> Details</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <a href="#" class="uk-width-1-1 uk-text-center" uk-totop uk-scroll></a>
                        </div>

                    </div>

                    <div class="uk-width-expand@m" :class="flip">
                        <GmapMap :center="map.center" :zoom="user.zoom"

                                 @tilesloaded="fixMapHeight"
                                 uk-sticky="offset:140;bottom:true"
                                 :options="{zoomControl: true, mapTypeControl: false,scaleControl: true,streetViewControl: false,rotateControl: false,fullscreenControl: false,disableDefaultUi: false}"
                                 style="width: 100%; height: 580px">
                            <GmapInfoWindow v-if="infoWindow" :options="{pixelOffset:{width: 0,height: -35}}"
                                            :position="infoWindow.position"
                                            :opened="infoWindow.open"
                                            @closeclick="infoWindow.open=false, markerClicked(-1)">
                                <div id="infoWindowContentDisplay">
                                    <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+infoWindow.slug"
                                       @click="gtmTracking('Provider Page Link', 'Click', infoWindow.name)"
                                       class="uk-link-reset"><strong>{{ infoWindow.name }}</strong></a>
                                    <p class="uk-margin-remove uk-margin-small-top">
                                        {{ infoWindow.street }}
                                        <br>{{ infoWindow.fulladdress }}
                                    </p>
                                    <div class="uk-margin-small-top">
                                        <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+infoWindow.slug"
                                           @click="gtmTracking('Provider Page Link', 'Click', infoWindow.name)"
                                           class="uk-button uk-button-primary uk-button-small uk-margin-small-right"
                                           style="border-radius:0;">Details</a>
                                        <a :href="'https://www.google.com/maps/dir/?api=1&destination=' + infoWindow.street +','+ infoWindow.fulladdress"
                                           class="uk-button uk-button-default uk-button-small" target="_blank"
                                           @click="gtmTracking('Provider Get Direction Link', 'Click', infoWindow.name)"
                                           style="border-radius:0">Directions</a>
                                    </div>
                                </div>
                            </GmapInfoWindow>
                            <GmapMarker v-if="user.latLng" :position="user.latLng" :icon="{ url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAHdElNRQfjBBwFMyENgjruAAAAanRFWHRSYXcgcHJvZmlsZSB0eXBlIGFwcDEACmFwcDEKICAgICAgMzQKNDk0OTJhMDAwODAwMDAwMDAxMDAzMTAxMDIwMDA3MDAwMDAwMWEwMDAwMDAwMDAwMDAwMDUwNjk2MzYxNzM2MTAwMDAK3JU+DAAABOBJREFUSMe9Vk1sVFUU/s65781vmc5MG1o6QFsJGKmVCDSIJiWRxOKGhB0x/myIW7txYTQsIOrCQHBpwsqgIXHhwgSFxAUsxAYI8hsDSEthLIV2pp12ft6bd89xMVRmpkOjG07yNu/e3O9+95zvO4fwjNh9qILN1uCCsRwiipKRGJGGCHAAQIFAlXy1XPJVy0PWyE1j8evBSMvzqPnH0MEqVsUFFY+N6wQJgqYBjRHBAcBN20UVAUAlBeWqgVOIhMUuFBkXDrnPBnrtK0EpSmifK8cNo5tIEwBMjcCKQQCsKhWs4OF8MlqMlRW/f8zLgXYcVFgLaot5SZDNECHyHwCWAaqiAjXZxVJ4zhjo2KEaBAPAwKeKsbtAPOyliGRdKxBRwAugZR9S9iFeAJXl11AiRIhkXTzspcbu1s4GANpy2EO3qWJROO6S9hM3gogCZV9lfQeHXl1vkuvS1G4Vks3rwh+Tdm5yVvxoiJipiZmgokQTQcUuRpJhODEYFAI2Yafa3czECrRzFbkHhkOD2/rNnnScthhGJwiwFo9zRb16adz+cvxc9drMglYN/5sKJUYEii51I+VSkSy9fTSPUiWSYpK++qqyAt3eZxIfjbjvZlK8r1DW9PUHgqm8gAhYk2QMrGUkopTL5uXHr89UT1wct4U6MAAQUZ6IRSp5J7cY5agj6frqEgU6V5E7OuK+n0nzexf+ss73v/m49VBQ9msnREPApm7GO6+H0kMbzAejIy6PfiffzC5qUPeMhqDpfDE6z9EQRYg0Vv9kZV/lwLA72JPivWN3rHPklIcrkwIvAAzXPi8ArkwKjpzyMHbHOj1J3ntglztY9lUai0NjYUNRVpU4nqh9iU0mxaFt/WakUNaOk+d9PCooDDeKjlADfFRQnDzvo1DWjm19ZiST4lBTNTqAxJig4frcVC10a69JpuI0eDMruD0t4GY/qAtm4Pa04GbWIhWnV7b2mWTVNkiDiTTMRGQa9CLQ3g5qdxhd2Zyg5LXwqSZmJQ/I5hQOY3VvB7WLNGqQiEzLu1qFgABaCaEZkGqoViCt1llVbdNT0P2cFgKL6Z4UIxZe2YcUQCwM9KQYgcX0/ZwWuLHEoaqWFeQBT2/hGtDle3Y+X9RrmzOMjV0MkWcDiQAbuxibM4x8Ua9dvmfnXdOoJVXymIiLAIKnmQOyefEvjdvTiSjN7t8ZwuoEwUojMwVgBVidIOzfGUIiSrOXJuzpbF78JjsKAC6ZruHPrMNoI0J0acUxRH9Oycwbm8yql3rM4PpO5scFwXxJ4QeAKhBxgYEM48M3w9ixwQR/z8kPX/zkn6paaF1uSZUWPEuPnXRbWUqVSI6gCTwpcyZgZkGrx05Xvx19y5WhF8y+F9dE0tcfWEzlFURAd5Lxcp0FHTtTPdHkd0/qinKpeFlo5+EABDUhU+0j0hRameoud3B7v9mTijWY6ky+pFcvjtufj59dZqpLbPK+dScUZGn3UR+VOQ9OxLSRat+KbaLXJNemqV3k/7cJAmrN6cY9YNcmL82OrAVpCC0aX9VCl8TIDHINiJdrjaDkS8APzt4K5wZ6gRuf0/Nr5c9/OFmKluMWaYwAt8V+VaAK/Z/jVn0Mf1nBmojBRNFyCBQlkhizhpdMWFWtCHmqXPKh5b64kamKxblPWg+Q/wD5SqudsOjbnAAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNC0yOFQwNTo1MTozMy0wNDowMP+zAj4AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDQtMjhUMDU6NTE6MzMtMDQ6MDCO7rqCAAAAAElFTkSuQmCC',
                              size: { width: 26, height: 26, f: 'px', b: 'px' },
                             }"></GmapMarker>
                            <GmapCluster :grid-size="10">
                                <GmapMarker id="mainMarker" v-for="(m, index) in providers"
                                            :position="m.position"
                                            :clickable="true"
                                            :icon="map.markerImage.red"
                                            ref="markers"
                                            @click="selectedProvider = m, selectedProvider.index = index"
                                            :key="index"></GmapMarker>
                            </GmapCluster>
                        </GmapMap>


                    </div>
                </div>
            </div>
        </section>

        <search-practice class="uk-animation-slide-right" v-if="!defaultView && viewName === 'practice'"
                         v-on:defaultView="defaultView = true"></search-practice>
        <search-provider class="uk-animation-slide-right" v-if="!defaultView && viewName === 'provider'"
                         v-on:defaultView="defaultView = true"></search-provider>
        <section v-if="userMessage">
            <div v-html="userMessage"></div>
        </section>
    </div>
</template>

<script>/* eslint-disable */
import axios from 'axios';
import debounce from 'lodash/debounce';
import SearchPractice from '@/components/SearchPractice.vue';
import SearchProvider from '@/components/SearchProvider.vue';

export default {
    name: 'App',
    components: {
        'search-practice': SearchPractice,
        'search-provider': SearchProvider
    },
    data() {
        return {
            flip: window.location.hash.indexOf('flip') > -1 ? `uk-flex-first@m` : ``,
            titleDefault: `Search Practices Near You`,
            title: `Search Practices Near You`,
            defaultView: true,
            viewName: `practice`,
            scrollIndex: 0,
            apiHost: (window.nr_biote_locator_globals && window.nr_biote_locator_globals.site_url) || 'https://www.biotemedical.com',
            tempMile: 50,
            user: {
                search: '',
                latLng: null,
                zoom: 12,
                radius: 50
            },
            infoWindow: {
                position: null,
                open: false
            },
            map: {
                center: null,
                markerImage: {
                    red: {
                        path: 'M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z',
                        anchor: {x: 12, y: 17},
                        fillOpacity: 1,
                        fillColor: '#EA4335',
                        strokeWeight: 2,
                        strokeColor: 'white',
                        scale: 2
                    },
                    active: {
                        path: 'M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z',
                        anchor: {x: 12, y: 17},
                        fillOpacity: 1,
                        fillColor: '#5e328b',
                        strokeWeight: 2,
                        strokeColor: 'white',
                        scale: 2.5
                    }
                }
            },
            approximateSearch: null,
            selectedProvider: null,
            providers: null,
            loading: false,
            loadingCurrentLocation: false,
            providerMessage: null,
            userMessage: null,
            recentlySearched: [],
            defaultVals: {
                radius: 50,
                zoom: 12
            },
            providersCount: null
        };
    },
    watch: {
        defaultView(val) {
            val && (this.title = this.titleDefault);
        },
        user: {
            handler: function (val, oldVal) {

                this.getProviders();
                this.checkUserLocation('set');
            },
            deep: true
        },
        providers(val) {
            val && (this.providersCount = val.length);
        },
        loading(val) {
            val && (this.providerMessage = 'Finding Practices...');
            this.providers && this.approximateSearch && (this.providerMessage = `Found <b>${this.providers.length} Practices</b> near ${this.approximateSearch.formatted_address}`);
            this.providers && !this.approximateSearch && (this.providerMessage = `Found <b>${this.providersCount} Practices</b> near you`);
        },
        loadingCurrentLocation(val) {
            val && (this.providerMessage = 'Getting Current Location...');
        },
        selectedProvider: debounce(function (provider) {
            //this.user.zoom = 13;
            this.infoWindow = {
                position: provider.position,
                name: provider.name,
                street: provider.address.street_address,
                fulladdress: `${provider.address.city}, ${provider.address.state} ${provider.address.zip}`,
                slug: provider.slug,
                open: true
            };
            this.markerClicked(provider.index);
        }, 200)
    },
    computed: {
        allProvidersApiUrl() {
            return `${this.apiHost}/wp-json/nativerank/v1/providers/lat=${this.user.latLng.lat}/lng=${this.user.latLng.lng}/dist=${this.user.radius}`;
        }
    },
    methods: {
        radiusOptions() {

        },
        searchByPractice() {
            this.defaultView = false;
            this.viewName = 'practice';
            this.title = `Find Practice by Name`;
        },
        searchByProvider() {
            this.defaultView = false;
            this.viewName = 'provider';
            this.title = `Find Practitioner by Name`;
        },
        markerClicked(index) {

            this.$refs.markers.map((marker, idx) => this.$refs.markers[idx].$markerObject.setIcon(this.map.markerImage.red));
            //this.$refs.markers[index].$markerObject.setAnimation(google.maps.Animation.BOUNCE);
            index !== -1 && (this.$refs.markers[index].$markerObject.setIcon(this.map.markerImage.active));
        },
        log(item) {
            console.log(item);
        },
        setPlace(place) {
            this.approximateSearch = null;
            this.defaultVals.zoom = 12;
            this.resetUser('zoom');
            this.resetUser('radius');
            if (!place) return;
            this.user.search = place.formatted_address;
            this.user.latLng = {
                lat: place.geometry.location.lat(),
                lng: place.geometry.location.lng(),
            };
        },
        resetUser(settingName) {

            this.user[settingName] = this.defaultVals[settingName];
        },
        userCustomSearch(currentLocation) {
            this.approximateSearch = null;
            this.loadingCurrentLocation = false;
            this.resetUser('radius');
            let userEntry = this.$refs.userSearch.$el.value;
            try {
                let geoCoder = new google.maps.Geocoder();
            } catch (e) {
                setTimeout(_ => {
                    this.userCustomSearch(currentLocation);
                }, 50);
                return;
            }

            let geoCoder = new google.maps.Geocoder();
            let searchQuery = currentLocation ? {placeId: currentLocation} : {address: userEntry};
            geoCoder.geocode(searchQuery, (result, status) => {
                if (status === 'OK') {
                    let place = result[0];
                    this.user.search = place.formatted_address;
                    this.user.latLng = {
                        lat: place.geometry.location.lat(),
                        lng: place.geometry.location.lng(),
                    };
                } else {

                    if (status == 'ZERO_RESULTS') {
                        this.predictLocation();
                        return;
                    }
                    console.log(
                        'Geocode was not successful for the following reason: ' + status
                    );
                }
            });
        },
        predictLocation() {
            let userEntry = this.$refs.userSearch.$el.value;
            let service = new google.maps.places.AutocompleteService();
            service.getQueryPredictions({input: userEntry}, (predictions, status) => {
                this.userCustomSearch(predictions[0].place_id);
            });
        },
        getProviders() {
            this.loadingCurrentLocation = false;
            this.userMessage = null;
            this.resetUser('zoom');
            this.map.center = this.user.latLng;
            this.infoWindow.open = false;
            this.providers = null;
            this.loading = true;
            axios.get(this.allProvidersApiUrl)
                .then(res => {

                    if (res.data && res.data.length < 5 && this.user.radius < 101) {
                        this.user.radius *= 2;
                        return;
                    }

                    this.providers = res.data;
                    if (this.providers.length > 0) {
                        this.plotMarkers();
                    }
                    this.loading = false;
                    this.loadingCurrentLocation = false;
                    this.providers && (this.providers.length < 1) && (this.userMessage = `<div class="uk-text-center uk-section uk-section-xsmall"><h2>No Practices found near you.</h2><a href="${this.apiHost}/biote/nominate-a-provider/" class="uk-button uk-button-primary">Nominate A Provider</a></div>`);
                    console.log(this.$refs.userSearch.$el.value);
                    if (this.$refs.userSearch.$el.value !== '') {
                        setTimeout(() => {
                            UIkit.scroll('.nr-form-icon', {offset: 140})
                                .scrollTo('#mapSection');
                        }, 10);

                    }
                    this.gtmTracking('form-search-provider', 'Form', 'Search Practices');
                })
                .catch(e => console.log(e));
        },
        getCurrentLocation() {
            this.defaultVals.zoom = 12;
            this.resetUser('zoom');
            this.resetUser('radius');
            this.loading = true;
            this.approximateSearch = null;
            this.loadingCurrentLocation = true;

            if ('geolocation' in navigator) {
                navigator.geolocation.getCurrentPosition(position => {
                    this.loadingCurrentLocation = false;
                    this.loading = false;
                    !position && (this.userMessage = '<div class="uk-text-center">We are having a hard time finding you location. Please use the search box to find your location.</div>');
                    this.user.latLng = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    this.user.search = 'Current Location';
                });

            } else {
                this.userMessage = '<div class="uk-text-center">Your browser is not up to dat. Please update your browser to use our Geo Locator.</div>';
            }
        },
        checkUserLocation(request) {
            request === 'set' && window.localStorage.setItem('userSettings', JSON.stringify(this.user));
            if (request === 'get') {


                if (typeof window.nr1055_existting_zip !== 'undefined') {
                    this.$refs.userSearch.$el.value = window.nr1055_existting_zip;
                    this.userCustomSearch();
                    return true;
                }

                if (window.location.hash.indexOf('currentLocation') > -1) {
                    if (window.localStorage.getItem('clt') && window.localStorage.getItem('clg')) {
                        this.defaultVals.zoom = 12;
                        this.resetUser('zoom');
                        this.resetUser('radius');
                        this.loading = true;
                        this.approximateSearch = null;
                        this.loadingCurrentLocation = true;
                        this.user.latLng = {
                            lat: Number(window.localStorage.getItem('clt')),
                            lng: Number(window.localStorage.getItem('clg'))
                        };
                        this.user.search = 'Current Location';
                    } else {
                        this.getCurrentLocation();
                    }

                    return true;
                }

                if (window.localStorage.getItem('userSettings')) {
                    this.user = JSON.parse(window.localStorage.getItem('userSettings'));
                } else {
                    this.globalPosition();
                }
                return true;
            }
            return false;
        },
        checkRecentlySearched(provider, request) {
            let history = window.localStorage.getItem('userHistory');
            if (typeof history !== "object") {
                history = ''
            }
            history ? (history = JSON.parse(history)) : (history = []);
            request === 'get' && (this.recentlySearched = history.reverse());

            if (request === 'set') {
                history.push(provider);

                window.localStorage.setItem('userHistory', JSON.stringify(history));
                return;
            }
        },
        plotMarkers() {
            this.providers.map(provider => {
                provider.position = {
                    lat: Number(provider.lat),
                    lng: Number(provider.lng)
                };
            });
        },
        gtmTracking(event, category, label) {
            const providerEngagementEvent = {event: 'Provider Engagement', engagementType: event, providerName: label};
            const primaryEventObject = {event: event, engagementType: event, providerName: label};
            const localStorageKey = 'bioteProviderEngagement'
            const currentTimestamp = {timestamp: Date.now()}
            const thirtyMinutesInMilliseconds = 1800000
            const isNewPageVisitor = window.localStorage.getItem('newFindAProviderPageVisitor') !== null
            const pushEvent = (eventObject) => {
                let dataLayerAvailable = "undefined" != typeof dataLayer
                dataLayerAvailable && dataLayer.push(eventObject)
                if (!dataLayerAvailable) {
                    console.log(eventObject)
                }
            }

            pushEvent(primaryEventObject)

            if (event === 'Provider Page Link' || category !== 'Click') {
                return
            }

            if (isNewPageVisitor) {
                let e = {
                    event: 'New Provider Form - Old Engagement Type',
                    engagementType: event,
                    providerName: label
                }
                pushEvent(e)
                return
            }

            checkForPreviousEngagement: try {
                const lastProviderEngagement = JSON.parse(window.localStorage.getItem(localStorageKey))
                const noPreviousEngagement = lastProviderEngagement === null || typeof lastProviderEngagement.timestamp === 'undefined'
                if (noPreviousEngagement) {
                    pushEvent(providerEngagementEvent)
                    break checkForPreviousEngagement
                }
                const thirtyMinutesHasPassed = (currentTimestamp.timestamp - lastProviderEngagement.timestamp) > thirtyMinutesInMilliseconds
                thirtyMinutesHasPassed && pushEvent(providerEngagementEvent)
            } catch (e) {
                pushEvent(providerEngagementEvent)
            } finally {
                window.localStorage.setItem(localStorageKey, JSON.stringify(currentTimestamp))
            }

        },
        globalPosition() {

            axios.get('https://ipinfo.io/json?token=8df19af83f7ced')
                .then(res => {
                    this.defaultVals.zoom = 10;
                    this.approximateSearch = {
                        formatted_address: res.data.city
                    };
                    this.user.latLng = {
                        lat: Number(res.data.loc.split(',')[0]),
                        lng: Number(res.data.loc.split(',')[1])
                    };
                })
                .catch(e => console.log(e));

        },

        // highlight: debounce(function (marker, idx) {
        //   this.scrollIndex = idx;
        //   [].forEach.call(document.querySelectorAll('.location-card'), function (el) {
        //     el.classList.remove('active');
        //   });
        //   setTimeout(function () {
        //     document.querySelector('div[data-idx="' + idx + '"]') && document.querySelector('div[data-idx="' + idx + '"]')
        //       .classList
        //       .add('active');
        //   }, 100);
        //
        // }, 200),
        seelctCard(elem) {
            [].forEach.call(document.querySelectorAll('.location-card'), function (el) {
                el.classList.remove('active');
            });
            elem.target.classList.add('active');

        },
        fixMapHeight() {
            let w = window,
                d = document,
                e = d.documentElement,
                g = d.getElementsByTagName('body')[0],
                x = w.innerWidth || e.clientWidth || g.clientWidth,
                y = w.innerHeight || e.clientHeight || g.clientHeight,
                elMap = document.getElementsByClassName('vue-map-container')[0],
                elH = elMap.offsetHeight,
                elHFromB = elMap.getBoundingClientRect().bottom,
                containerFromBottom = y - elHFromB;

            UIkit.util.on(document, 'active', '.vue-map-container', () => {


                containerFromBottom < 0 && !!elMap && (elMap.style.maxHeight = `${elH + containerFromBottom - 20}px`);
            });

            let footerAnchor = UIkit.util.$('.find-a-doctor-2');
            UIkit.util.on(window, 'scroll', () => {
                if (UIkit.util.isInView(footerAnchor)) {
                    elMap.style.maxHeight = `${elH + containerFromBottom - 20}px`;
                } else {
                    elMap.style.maxHeight = 'none';
                }
            });

        }
    },
    filters: {
        //Convert Miles to 2 decimal places
        miles: function miles(_miles) {
            return parseFloat(_miles)
                .toFixed(2);
        },
        highlightSearch: function highlightSearch(value, query) {
            if (query === '') {
                return value;
            }
            var re = new RegExp(query, 'ig');
            return value.replace(re, function (match) {
                return '<span>' + match + '</span>';
            });
        },
        formatPhoneNumber: function formatPhoneNumber(number) {
            if (number.length < 10) {
                return number;
            }

            var cleaned = ('' + number).replace(/\D/g, '');
            var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);

            if (match) {
                var intlCode = match[1] ? '+1 ' : '';
                return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join(
                    ''
                );
            }

            return null;

        }
    },
    mounted() {
        this.checkUserLocation('get');
        this.checkRecentlySearched(null, 'get');
    }
};
</script>

<style lang="less">
#bioTEApp.desktop {
    font-family: Montserrat, sans-serif;

    .miles-dropdown {
        li {
            a {
                padding: 12px 15px;
                border-bottom: 1px solid #cecece;
            }
        }
    }

    .uk-section-muted {
        background: #fbfbfb;
    }

    a:not(.uk-button) {
        font-weight: 500;

        &:active {
            outline: 2px auto Highlight;
            outline-color: #7baaf7;
            outline-style: auto;
            outline-width: 5px;
            outline: 5px auto #7baaf7;
        }


        &:focus {
            background: #f1f3f4;
            outline: 10px solid #f1f3f4;
        }
    }


    .uk-button-primary {
        background: #f57e20;

        &:hover {
            background: darken(#f57e20, 10%);
        }

        &:active {
            outline: 2px auto Highlight;
            outline-color: #7baaf7;
            outline-style: auto;
            outline-width: 5px;
            outline: 5px auto #7baaf7;
        }
    }

    .uk-text-primary {
        color: #f57e20 !important;
    }

    .links {
        a:not(.uk-button) {
            color: #f57e20 !important;
            font-weight: 500;

            &:focus {
                background: #f1f3f4;
                outline: 10px solid #f1f3f4;
            }
        }
    }

    h1 {
        color: #fff;
        font-weight: 300;
        font-size: 42px;
        line-height: 38px;
    }

    .provider_search {
        max-width: 500px;

        .uk-input {
            transition: all .2s ease-in-out;
            border: 1px solid rgba(51, 51, 51, .5) !important;
            border-radius: 4px;
            height: 55px;
            position: relative;
            z-index: 4;

            &:focus {
                outline: 3px auto #f57e20;
                outline-offset: 3px;

                & ~ .clear {
                    color: #1867c0;
                }
            }

        }
    }

    .nr-form-icon {
        position: absolute;
        width: 50px;
        display: inline-flex;
        justify-content: center;
        align-items: center;
        left: auto;
        color: #fff;
        border: none;
        right: 6px;
        top: 6px;
        bottom: 6px;
        border-radius: 3px;
        font-size: 24px;
    }

    .clear {
        top: 50%;
        z-index: 9;
        right: 84px;
        transform: translatey(-50%);
        font-size: 22px;
        cursor: pointer;
        background: #fff;
    }

    .current_location {

        border-radius: 4px;
        background: #fff;
        padding: 5px 10px;
        line-height: normal;
        text-transform: none;
        -webkit-transition: all .25s ease-in-out;
        -moz-transition: all .25s ease-in-out;
        -ms-transition: all .25s ease-in-out;
        -o-transition: all .25s ease-in-out;
        transition: all .25s ease-in-out;

        &:hover {
            background-color: #f57e20;
            color: #fff;
        }
    }

    .providerMessage {
        font-size: 1.5rem;
        line-height: 1.4;
        color: #333;

        &.loading, &.current-location-loading {
            position: relative;
            color: rgba(0, 0, 0, .3);
            font-size: 1.5rem;
            margin-top: 15px;
            display: block;

            &:before {
                content: "Finding Practices...";
                position: absolute;
                overflow: hidden;
                max-width: 7em;
                white-space: nowrap;
                color: #fff;
                -webkit-animation: infinite pro-loading 3s linear;
                animation: infinite pro-loading 3s linear
            }

            &.current-location-loading {
                &:before {
                    content: "Getting Current Location...";
                }
            }

        }
    }

    .userRadius {
        margin-right: 4px;
        font-weight: 800;
        width: 30px;
        text-align: right;
        background: 0 0;
        border: none;
        font-size: 16px;
        border-bottom: 1px solid #fff;

        & + span {
            margin-left: 6px;
            color: #333;
        }
    }

    #infoWindowContentDisplay strong {
        color: #5e328b;
        font-weight: 700;
        font-size: 20px
    }

    #infoWindowContentDisplay p {
        font-size: 14px;
        font-weight: 600
    }

    #infoWindowContentDisplay .uk-button-default {
        background: #4caf50;
        color: #fff
    }

    .location-card {
        padding: 30px;
        box-shadow: none
    }

    .location-card:not(.simple) {
        /*border-radius: 6px;*/
        /*box-shadow: 0 1px 3px 0 rgba(87, 87, 87, .16);*/
        // border: 1px solid rgba(112, 112, 112, .16);
        box-sizing: border-box;
        border: 1px solid transparent;
        max-width: 500px;
        transition: box-shadow 135ms cubic-bezier(.4, 0, .2, 1), width 235ms cubic-bezier(.4, 0, .2, 1);
        box-shadow: 0 1px 1px 0 rgba(60, 64, 67, .08), 0 1px 3px 1px rgba(60, 64, 67, .16);

    }

    .uk-slider-container {
        max-width: 500px;
    }

    .location-card.active {
        border-color: #4caf50;
        box-shadow: inset 0 1px 3px 4px rgba(87, 87, 87, .16);
        box-shadow: 0 3px 1px -2px rgba(0, 0, 0, .2), 0 2px 2px 0 rgba(0, 0, 0, .14), 0 1px 5px 0 rgba(0, 0, 0, .12);
        box-shadow: 0 1px 3px 1px rgba(60, 64, 67, .2), 0 2px 8px 4px rgba(60, 64, 67, .1);
        background: fade(#000, 0.2%);
    }

    .location-card .uk-width-expand {
        padding-right: 5px
    }

    .location-card .uk-width-expand.divider {
        border-right: .5px solid rgba(112, 112, 112, .35)
    }

    .location-card .links a {
        font-size: 15px;
        letter-spacing: 1px;
        line-height: 34px;
    }

    .location-card h3 {
        color: #5e328b;
        font-weight: 600;
        letter-spacing: 1px;
        font-size: 20px;
    }

    .uk-text-meta {
        color: #333;
        font-weight: 700;
        font-size: 14px;
        margin-top: 10px;
        display: block;
    }

    .location-card address {
        color: #8d8d8d;
        font-size: 14px;
        max-width: 220px;
        font-weight: 400;

    }

    .pac-container {
        border-radius: 4px
    }

    .pac-logo:after {
        content: none
    }

    .pac-item-selected {
        background: #c3e3c4
    }

    .pac-matched {
        color: #5e328b
    }

    .pac-item-query {
        font-size: 15px
    }

    .pac-item {
        padding: 9px 8px
    }

    #recentlySearched {
        h3 {
            color: #333;
        }

        .uk-card {
            max-width: 300px;
            margin-top: 10px;
            width: 100%;
            padding: 13px;
            -webkit-border-radius: 3px;
            -moz-border-radius: 3px;
            border-radius: 3px;
            opacity: 0.8;
            transition: .2s;

            &:hover {
                opacity: 1;
            }
        }

        .uk-text-meta {
            font-size: 14px;
            color: #333;
            margin-top: 3px;
        }

        .link {
            font-size: 13px;
        }
    }

    #search_by_name {

        border-radius: 4px;
        color: #000;
        -webkit-transition: all .25s ease-in-out;
        -moz-transition: all .25s ease-in-out;
        -ms-transition: all .25s ease-in-out;
        -o-transition: all .25s ease-in-out;
        transition: all .25s ease-in-out;
        font-size: 15px;
        text-shadow: 0 0 1px rgba(255, 255, 255, .9)
    }

    #search_by_name .link {
        cursor: pointer;
        padding: 2px 5px;
        transition: .1s;
        font-weight: 600
    }

    #search_by_name .link:hover {
        color: #f57e20;
        text-shadow: none;
        background: rgba(0, 0, 0, .3)
    }

    .uk-accordion .uk-accordion-title span {
        background: #f57e20;
        color: #fff;
    }

    .uk-accordion > {
        &:nth-child(n+2) {
            margin-top: 10px;
        }
    }

    .uk-accordion {
        li {
            background: #fff;
            border: solid 1px #e6e6e6;
            padding: 15px;
        }

        .uk-accordion-title {
            color: #5e328b;

            span {
                background: #f57e20;
                color: #fff;
            }
        }
    }

    .slide-fade-enter-active {
        transition: all .3s ease;
    }

    .slide-fade-leave-active {
        transition: all .8s cubic-bezier(1.0, 0.5, 0.8, 1.0);
    }

    .slide-fade-enter, .slide-fade-leave-to
        /* .slide-fade-leave-active below version 2.1.8 */ {
        transform: translateX(10px);
        opacity: 0;
    }

    .uk-slider {
        .uk-card {

            a {
                color: #5e328b;

                &.title {
                    display: block;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
            }
        }
    }

    .vue-map-container {
        transition: box-shadow, height .3s cubic-bezier(.4, 0, .2, 1) .1s;

        &.uk-active {
            box-shadow: 0 2px 2px rgba(0, 0, 0, .2);
            @media screen and (min-height: 835px) {
                height: 660px !important;
            }

            @media screen and (min-height: 910px) {
                height: 720px !important;
            }
        }
    }
}

@-webkit-keyframes pro-loading {
    0% {
        max-width: 0
    }
}

@keyframes pro-loading {
    0% {
        max-width: 0
    }

}
</style>
