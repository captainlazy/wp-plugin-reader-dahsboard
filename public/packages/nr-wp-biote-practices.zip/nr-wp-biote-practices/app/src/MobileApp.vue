<template>
    <div id="bioTEApp" class="mobile">
        <section class="uk-section-default">
            <div class="uk-section uk-section-small uk-background-cover uk-background-center-center"
                 :data-src="this.apiHost + '/wp-content/uploads/2019/04/hero-1.jpg'" uk-img>
                <div class="uk-container">
                    <h1 class="uk-text-center uk-h1">
                        {{ title }}
                    </h1>
                    <div class="uk-child-width-expand" uk-grid="">
                        <div>
                            <div class="uk-card provider_search uk-margin-auto uk-position-relative">
                                <i class="fas fa-bars uk-position-left uk-padding-small"
                                   v-if="defaultView"
                                   style="display: flex!important;display: flex;align-items: center;justify-content: center;z-index: 99;"
                                   uk-toggle="target: #advancedOptions"></i>
                                <i class="fas fa-arrow-left uk-position-left uk-padding-small"
                                   @click="defaultView = true"
                                   v-else
                                   style="display: flex!important;display: flex;align-items: center;justify-content: center;z-index: 99;"
                                ></i>
                                <div id="advancedOptions" uk-offcanvas="overlay: true">
                                    <div class="uk-offcanvas-bar uk-flex uk-flex-column">

                                        <ul class="uk-nav uk-nav-primary uk-nav-center">
                                            <li class="uk-nav-header"><i
                                                class="fas fa-search uk-margin-small-right"></i>Search By
                                            </li>
                                            <li><a @click=" searchByPractice"><i
                                                class="fas fa-hospital-alt uk-margin-small-right"></i>Practice</a>
                                            </li>
                                            <li class="uk-nav-divider"></li>
                                            <li><a @click="searchByProvider">
                                                <i class="fas fa-user-md uk-margin-small-right"></i>
                                                Practitioner</a>
                                            </li>
                                            <li class="uk-nav-divider"></li>
                                            <li class="uk-nav-header" v-if="recentlySearched.length > 0"><i
                                                class="fas fa-history uk-margin-small-right"></i>Recently Visited
                                            </li>
                                            <li>
                                            <li v-for="(provider, idx) in recentlySearched" :key="idx"
                                                class="uk-position-relative"
                                                style="border-top:1px solid #ccc">
                                                <a :title="provider.name"
                                                   class="uk-position-relative"
                                                   style="font-size:15px"
                                                   :href="`/bioidentical-hormone-replacement-therapy-provider/${provider.slug}`">{{
                                                        provider.name
                                                    }} </a>
                                                <span
                                                    class="uk-position-center-right uk-position-small uk-position-z-index"
                                                    style="color: #666;background: #f1f1f1;padding: 3px;font-size: 10px;">
                          {{ provider.distance | miles }} MI
                        </span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <gmap-autocomplete v-if="defaultView" class="uk-input autocomplete_input"
                                                   :value="user.search"
                                                   :select-first-on-enter="true"
                                                   @place_changed="setPlace"
                                                   title="Search"
                                                   placeholder="Enter Zip Code or City, State" ref="userSearch">
                                </gmap-autocomplete>
                                <input v-else v-model="searchBy.input" :placeholder="`Search for a ${viewName}`"
                                       class="uk-input autocomplete_input"
                                       id="searchby_input"
                                       ref="searchby_input"
                                       autocomplete="off"
                                       title="search"
                                       type="search"
                                       autocapitalize="off"
                                       autocorrect="off"
                                       spellcheck="false"
                                       aria-label="Search"
                                >


                                <i class="clear fas fa-times uk-position-absolute"
                                   v-if="user.search && user.search.length > 0"
                                   @click="user.search = '', $refs.userSearch.$el.value = '', $refs.userSearch.$el.focus()"></i>


                                <i class="clear fas fa-times uk-position-absolute"
                                   v-if="searchBy.input"
                                   @click="searchBy.input = '', $refs.searchby_input.$el.focus()"></i>
                            </div>
                        </div>
                    </div>
                    <div class="uk-panel uk-margin-small uk-margin-auto" v-if="defaultView" style="{maxWidth: '500px'}">
                        <div class="uk-child-width-expand uk-grid-small uk-grid-divider" uk-grid="">
                            <div class="uk-text-right">

                                <button class="uk-button uk-button-default current_location uk-width-1-1"
                                        @click="getCurrentLocation">
                                    <i role="button" class="fas fa-location-arrow"></i> Locate Me
                                </button>

                            </div>
                            <div>
                                <button class="nr-form-icon uk-button uk-button-primary uk-width-1-1"
                                        style="z-index: 9;"
                                        @click="userCustomSearch">
                                    Search
                                    <i
                                        class="fas fa-search"></i>
                                </button>
                            </div>

                        </div>
                        <div class="uk-flex-center uk-margin-small-top uk-child-width-1-1@m" uk-grid="">
                            <div class="providerMessage uk-text-center"
                                 :class="loading || loadingCurrentLocation ? `loading ${loadingCurrentLocation ? 'current-location-loading' : ''}` : ''"
                                 v-html="providerMessage">
                            </div>
                            <div v-if="providers"
                                 class="uk-flex uk-flex-middle uk-flex-center uk-margin-remove">
                                <div class="uk-inline">
                                    <div>
                                        <input class="userRadius" v-model="user.radius" readonly>
                                        <span>Miles Radius</span>
                                    </div>

                                    <div id="radius-options"
                                         class="uk-padding-remove miles-dropdown"
                                         uk-dropdown="pos: bottom-left;mode:click" style="z-index: 9999;">
                                        <ul class="uk-nav uk-dropdown-nav uk-padding-remove">
                                            <li v-for="mile in [50, 75, 100, 150, 200]" :key="mile"
                                                :class="user.radius === mile ? 'uk-active' : ''">
                                                <a @click="user.radius = mile">{{ mile }} Miles</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="uk-section uk-section-muted uk-position-relative uk-padding-remove-vertical"
                 v-if="defaultView && providers && (providers.length > 0)">
            <div class="tab-stick uk-background-muted" style="z-index: 999;" uk-sticky="">
                <ul class="uk-child-width-expand uk-grid-collapse uk-margin-remove-bottom"
                    uk-tab="connect: #providerList;swiping:false">
                    <li><a href="#"><i class="fas fa-map"></i> Map View</a></li>
                    <li><a href="#"><i class="fas fa-list"></i> List View <span
                        class="uk-text-bold uk-margin-small-left"
                        v-if="providers.length > 0">({{ providers.length }})</span></a>
                    </li>
                </ul>
            </div>
            <ul id="providerList" class="uk-switcher">
                <li>
                    <GmapMap :center="map.center" :zoom="user.zoom"
                             :options="{zoomControl: true, mapTypeControl: false,scaleControl: true,streetViewControl: false,rotateControl: false,fullscreenControl: false,disableDefaultUi: false}"
                             style="width: 100%; height: 240px">
                        <GmapMarker v-if="user.latLng" :position="user.latLng" :icon="{ url: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABoAAAAaCAYAAACpSkzOAAAAIGNIUk0AAHomAACAhAAA+gAAAIDoAAB1MAAA6mAAADqYAAAXcJy6UTwAAAAGYktHRAD/AP8A/6C9p5MAAAAHdElNRQfjBBwFMyENgjruAAAAanRFWHRSYXcgcHJvZmlsZSB0eXBlIGFwcDEACmFwcDEKICAgICAgMzQKNDk0OTJhMDAwODAwMDAwMDAxMDAzMTAxMDIwMDA3MDAwMDAwMWEwMDAwMDAwMDAwMDAwMDUwNjk2MzYxNzM2MTAwMDAK3JU+DAAABOBJREFUSMe9Vk1sVFUU/s65781vmc5MG1o6QFsJGKmVCDSIJiWRxOKGhB0x/myIW7txYTQsIOrCQHBpwsqgIXHhwgSFxAUsxAYI8hsDSEthLIV2pp12ft6bd89xMVRmpkOjG07yNu/e3O9+95zvO4fwjNh9qILN1uCCsRwiipKRGJGGCHAAQIFAlXy1XPJVy0PWyE1j8evBSMvzqPnH0MEqVsUFFY+N6wQJgqYBjRHBAcBN20UVAUAlBeWqgVOIhMUuFBkXDrnPBnrtK0EpSmifK8cNo5tIEwBMjcCKQQCsKhWs4OF8MlqMlRW/f8zLgXYcVFgLaot5SZDNECHyHwCWAaqiAjXZxVJ4zhjo2KEaBAPAwKeKsbtAPOyliGRdKxBRwAugZR9S9iFeAJXl11AiRIhkXTzspcbu1s4GANpy2EO3qWJROO6S9hM3gogCZV9lfQeHXl1vkuvS1G4Vks3rwh+Tdm5yVvxoiJipiZmgokQTQcUuRpJhODEYFAI2Yafa3czECrRzFbkHhkOD2/rNnnScthhGJwiwFo9zRb16adz+cvxc9drMglYN/5sKJUYEii51I+VSkSy9fTSPUiWSYpK++qqyAt3eZxIfjbjvZlK8r1DW9PUHgqm8gAhYk2QMrGUkopTL5uXHr89UT1wct4U6MAAQUZ6IRSp5J7cY5agj6frqEgU6V5E7OuK+n0nzexf+ss73v/m49VBQ9msnREPApm7GO6+H0kMbzAejIy6PfiffzC5qUPeMhqDpfDE6z9EQRYg0Vv9kZV/lwLA72JPivWN3rHPklIcrkwIvAAzXPi8ArkwKjpzyMHbHOj1J3ntglztY9lUai0NjYUNRVpU4nqh9iU0mxaFt/WakUNaOk+d9PCooDDeKjlADfFRQnDzvo1DWjm19ZiST4lBTNTqAxJig4frcVC10a69JpuI0eDMruD0t4GY/qAtm4Pa04GbWIhWnV7b2mWTVNkiDiTTMRGQa9CLQ3g5qdxhd2Zyg5LXwqSZmJQ/I5hQOY3VvB7WLNGqQiEzLu1qFgABaCaEZkGqoViCt1llVbdNT0P2cFgKL6Z4UIxZe2YcUQCwM9KQYgcX0/ZwWuLHEoaqWFeQBT2/hGtDle3Y+X9RrmzOMjV0MkWcDiQAbuxibM4x8Ua9dvmfnXdOoJVXymIiLAIKnmQOyefEvjdvTiSjN7t8ZwuoEwUojMwVgBVidIOzfGUIiSrOXJuzpbF78JjsKAC6ZruHPrMNoI0J0acUxRH9Oycwbm8yql3rM4PpO5scFwXxJ4QeAKhBxgYEM48M3w9ixwQR/z8kPX/zkn6paaF1uSZUWPEuPnXRbWUqVSI6gCTwpcyZgZkGrx05Xvx19y5WhF8y+F9dE0tcfWEzlFURAd5Lxcp0FHTtTPdHkd0/qinKpeFlo5+EABDUhU+0j0hRameoud3B7v9mTijWY6ky+pFcvjtufj59dZqpLbPK+dScUZGn3UR+VOQ9OxLSRat+KbaLXJNemqV3k/7cJAmrN6cY9YNcmL82OrAVpCC0aX9VCl8TIDHINiJdrjaDkS8APzt4K5wZ6gRuf0/Nr5c9/OFmKluMWaYwAt8V+VaAK/Z/jVn0Mf1nBmojBRNFyCBQlkhizhpdMWFWtCHmqXPKh5b64kamKxblPWg+Q/wD5SqudsOjbnAAAACV0RVh0ZGF0ZTpjcmVhdGUAMjAxOS0wNC0yOFQwNTo1MTozMy0wNDowMP+zAj4AAAAldEVYdGRhdGU6bW9kaWZ5ADIwMTktMDQtMjhUMDU6NTE6MzMtMDQ6MDCO7rqCAAAAAElFTkSuQmCC',
                              size: { width: 26, height: 26, f: 'px', b: 'px' },
                             }"></GmapMarker>
                        <GmapCluster :grid-size="1">
                            <GmapMarker id="mainMarker" v-for="(m, index) in providers"
                                        :position="m.position"
                                        :clickable="true"
                                        :icon="map.markerImage.red"
                                        ref="markers"
                                        @click="selectedProvider = m, selectedProvider.index = index"
                                        :key="index"></GmapMarker>
                        </GmapCluster>
                    </GmapMap>
                    <div>

                        <div v-if="selectedProvider" class="uk-card uk-card-default location-card uk-margin">
                            <div>
                                <transition name="text-change" mode="out-in">
                                    <h3 class="uk-margin-remove" :key="selectedProvider.name">
                                        {{ selectedProvider.name }}</h3>
                                </transition>

                                <address class="uk-margin-remove">{{ selectedProvider.address.street_address }},
                                    {{ selectedProvider.address.city }}, {{ selectedProvider.address.state }}
                                    {{ selectedProvider.address.zip }}
                                </address>
                                <hr class="uk-margin-small">
                                <div class="uk-flex uk-flex-between">
                                    <div>
                    <span class="uk-text-meta uk-display-block">
                      {{ selectedProvider.distance | miles }} MI FROM YOU:
                    </span>
                                        <a :href="'https://www.google.com/maps/dir/?api=1&destination=' + selectedProvider.address.street_address.replace(' ', '+') +','+ selectedProvider.address.city.replace(' ', '+') +','+ selectedProvider.address.state.replace(' ', '+')"
                                           class="uk-margin-right link" target="_blank"
                                           @click="
                       gtmTracking('Provider Get Direction Link', 'Click', selectedProvider.name)
                      ">
                                            <i class="fas fa-location-arrow"></i>
                                            Get Directions</a>
                                    </div>
                                    <div>
                                        <span class="uk-text-meta uk-display-block ">Phone:</span>
                                        <a class="link"
                                           :href="`tel:+${selectedProvider.country_code + selectedProvider.phone.raw}`"
                                           v-if="selectedProvider.phone"
                                           @click="w('Provider Phone Link', 'Click', selectedProvider.name)">
                                            <i class="fas fa-phone"></i>
                                            {{ selectedProvider.phone.raw | formatPhoneNumber }}</a>
                                    </div>

                                </div>
                                <hr class="uk-margin-small">
                                <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div>
                                        <div v-if="selectedProvider.website  && selectedProvider.website != 'http://'">
                                            <a :href="selectedProvider.website"
                                               target="_blank"
                                               class="link"
                                               @click="gtmTracking('Provider Website External Link', 'Click', selectedProvider.name)">
                                                <i class="fas fa-globe"></i>
                                                Website
                                            </a>
                                        </div>
                                    </div>
                                    <div>
                                        <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+selectedProvider.slug"
                                           class="uk-button uk-button-primary uk-magrin-left"
                                           @click="gtmTracking('Provider Page Link', 'Click', selectedProvider.name), checkRecentlySearched(selectedProvider, 'set')"
                                           disabled><i class="fas fa-info-circle"></i> Details</a>
                                    </div>
                                </div>
                            </div>

                        </div>

                    </div>
                </li>
                <li>
                    <a href="#" uk-totop uk-scroll></a>
                    <div role="group" class="allList">
                        <div v-for="(provider , idx) in providers" :key="idx">
                            <div class="uk-card uk-card-default location-card" :data-idx="idx">

                                <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                   target="_self"
                                   @click="gtmTracking('Provider Page Link', 'Click', provider.name), checkRecentlySearched(provider, 'set')">
                                    <h3 class="uk-margin-remove">
                                        {{ provider.name }}</h3></a>
                                <address class="uk-margin-remove">{{ provider.address.street_address }},
                                    {{ provider.address.city }}, {{ provider.address.state }} {{ provider.address.zip }}
                                </address>
                                <hr class="uk-margin-small">

                                <div class="uk-flex uk-flex-between">
                                    <div>
                    <span class="uk-text-meta uk-display-block">
                      {{ provider.distance | miles }} MI FROM YOU:
                    </span>
                                        <a :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                           class="uk-margin-right link" target="_blank"
                                           @click="
                       gtmTracking('Provider Get Direction Link', 'Click', provider.name)
                      ">
                                            <i class="fas fa-location-arrow"></i>
                                            Get Directions</a>
                                    </div>
                                    <div>
                                        <span class="uk-text-meta uk-display-block ">Phone:</span>
                                        <a class="link"
                                           :href="`tel:+${provider.country_code + provider.phone.raw}`"
                                           v-if="provider.phone"
                                           @click="gtmTracking('Provider Phone Link', 'Click', provider.name)">
                                            <i class="fas fa-phone"></i>
                                            {{ provider.phone.raw | formatPhoneNumber }}</a>
                                    </div>

                                </div>
                                <hr class="uk-margin-small">
                                <div class="uk-flex uk-flex-middle uk-flex-between">
                                    <div>
                                        <div v-if="provider.website  && provider.website != 'http://'">
                                            <a :href="provider.website"
                                               target="_blank"
                                               class="link"
                                               @click="gtmTracking('Provider Website External Link', 'Click', provider.name)">
                                                <i class="fas fa-globe"></i>
                                                Website
                                            </a>
                                        </div>
                                    </div>
                                    <div>
                                        <a :href="'/bioidentical-hormone-replacement-therapy-provider/'+provider.slug"
                                           class="uk-button uk-button-primary uk-magrin-left"
                                           @click="gtmTracking('Provider Page Link', 'Click', provider.name), checkRecentlySearched(provider, 'set')"
                                           disabled><i class="fas fa-info-circle"></i> Details</a>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </section>
        <section
            v-if="!defaultView"
            class="uk-section uk-section-muted uk-position-relative uk-section-small uk-padding-remove-top list_view_container">
            <virtual-list :size="52" :remain="14" :bench="38" wtag="div" :start="0"
                          wclass="list_view" v-if="searchBy.providers" ref="virtualList">
                <div v-for="(provider,idx) in filteredProviders" :key="idx"
                     v-if="provider.name.length > 2"
                >
                    <div class="uk-card uk-card-default location-card uk-position-relative">
                        <div uk-grid="" class="uk-flex-middle uk-grid-small uk-grid">
                            <div class="uk-width-expand uk-first-column divider">
                                <div>
                                    <a :href="`/bioidentical-hormone-replacement-therapy-provider/${provider.slug}`"
                                       v-if="provider.slug"
                                       target="_self"><h3 class="uk-margin-remove"
                                                          v-html="highlightSearch(provider.name)"></h3></a>
                                    <h3 v-else class="uk-margin-remove" v-html="highlightSearch(provider.name)"></h3>
                                    <a @click="getCompany(provider.name, provider.company_id)" v-if="!provider.slug"
                                       class="uk-position-cover"></a>
                                    <address class="uk-margin-remove uk-margin-small-top"
                                             v-if="provider.address.street_address">
                                        {{ provider.address.street_address }},
                                        {{ provider.address.city }}, {{ provider.address.state }}
                                        {{ provider.address.zip }}
                                    </address>
                                </div>
                            </div>
                            <div class="uk-width-1-3">
                                <div class="links uk-text-right" v-if="provider.address.street_address"><a
                                    :href="'https://www.google.com/maps/dir/?api=1&destination=' + provider.address.street_address.replace(' ', '+') +','+ provider.address.city.replace(' ', '+') +','+ provider.address.state.replace(' ', '+')"
                                    target="_blank" class="uk-text-primary"><i class="fas fa-directions"></i> <span
                                    class="label">Directions</span></a>
                                    <a v-if="provider.phone"
                                       :href="`tel:+${provider.country_code + provider.phone.raw}`"><i
                                        class="fas fa-phone"></i> <span
                                        class="label">Call</span></a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </virtual-list>
            <div class="uk-text-center uk-padding"
                 v-if="!searchBy.providers || searchBy.providers.length < 1">
                Loading..
            </div>
        </section>
        <section v-if="userMessage">
            <div v-html="userMessage"></div>
        </section>
    </div>
</template>

<script>/* eslint-disable */
import axios from 'axios';
import debounce from 'lodash/debounce';


export default {
    name: 'App',
    data() {
        return {
            titleDefault: `Search Practices Near You`,
            title: `Search Practices Near You`,
            defaultView: true,
            viewName: `practice`,
            scrollIndex: 0,
            apiHost: (window.nr_biote_locator_globals && window.nr_biote_locator_globals.site_url) || 'https://www.biotemedical.com',
            user: {
                search: '',
                latLng: null,
                zoom: 12,
                radius: 50
            },
            infoWindow: {
                position: null,
                open: false
            },
            map: {
                center: null,
                markerImage: {
                    red: {
                        path: 'M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z',
                        anchor: {x: 12, y: 17},
                        fillOpacity: 1,
                        fillColor: '#EA4335',
                        strokeWeight: 2,
                        strokeColor: 'white',
                        scale: 2
                    },
                    active: {
                        path: 'M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z',
                        anchor: {x: 12, y: 17},
                        fillOpacity: 1,
                        fillColor: '#5e328b',
                        strokeWeight: 2,
                        strokeColor: 'white',
                        scale: 2.5
                    }
                }
            },
            approximateSearch: null,
            selectedProvider: null,
            providers: null,
            loading: false,
            loadingCurrentLocation: false,
            providerMessage: null,
            userMessage: null,
            recentlySearched: [],
            defaultVals: {
                radius: 50,
                zoom: 12
            },
            searchBy: {
                providers: null,
                input: null
            },
            existingZip: null
        };
    },
    watch: {
        defaultView(val) {
            val && (this.title = this.titleDefault);
        },
        user: {
            handler: function (val, oldVal) {
                this.getProviders();
                this.checkUserLocation('set');
            },
            deep: true
        },
        loading(val) {
            val && (this.providerMessage = 'Finding Practices...');
            this.providers && this.approximateSearch && (this.providerMessage = `Found <b>${this.providers.length} Practices</b> near ${this.approximateSearch.formatted_address}`);
            this.providers && !this.approximateSearch && (this.providerMessage = `Found <b>${this.providers.length} Practices</b> near you`);

        },
        loadingCurrentLocation(val) {
            val && (this.providerMessage = 'Getting Current Location...');
        },
        selectedProvider: debounce(function (provider) {
            //this.user.zoom = 13;

            this.markerClicked(provider.index);
        }, 150)
    },
    computed: {
        allProvidersApiUrl() {
            return `${this.apiHost}/wp-json/nativerank/v1/providers/lat=${this.user.latLng.lat}/lng=${this.user.latLng.lng}/dist=${this.user.radius}`;
        },
        filteredProviders() {
            if (!this.searchBy.input || this.searchBy.input === '') {
                return this.searchBy.providers.filter(input => input.name.length > 3);
            }
            return this.searchBy.providers.filter(input => input.name.length > 3 && input.name.toUpperCase()
                .indexOf(this.searchBy.input.toUpperCase()) > -1);
        }
    },
    methods: {
        formatPhoneNumber(number) {
            if (number.length < 10) {
                return number;
            }

            const cleaned = ('' + number).replace(/\D/g, '');
            const match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);

            if (match) {
                const intlCode = match[1] ? '+1 ' : '';
                return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join('');
            }

            return null;
        },
        getCompany(doctorName, companyId) {
            axios.get(`${this.apiHost}/wp-json/nativerank/v1/providers/company_id/q=${companyId}`)
                .then((res) => {
                    let provider = res.data[0];

                    UIkit.modal.dialog(`<button class="uk-modal-close-default" type="button" uk-close></button><div class="uk-modal-header">
            <h4><i class="fas fa-user-md uk-margin-small-right"></i> ${doctorName}</h4>
        </div>
        <div class="uk-modal-body">
                        Practice Name:
                        <a href="/bioidentical-hormone-replacement-therapy-provider/${provider.slug}"
                           target="_self">
                          <h3 class="uk-margin-remove">
                            ${provider.name}</h3></a>
                        <address class="uk-margin-small">
                        <a
                        style="color:#222!important;"
                        href="https://www.google.com/maps/dir/?api=1&destination=${provider.address.street_address.replace(' ', '+')},${provider.address.city.replace(' ', '+')},${provider.address.state.replace(' ', '+')}"
                        class="uk-link-rest">
                          ${provider.address.street_address},
                          ${provider.address.city}, ${provider.address.state} ${provider.address.zip}</a>
                        </address>
                        <div class="uk-margin-small-top"><a
                               href="tel:+${provider.country_code + provider.phone.raw}"
                                v-if="provider.phone"
                                class="uk-text-primary uk-margin-right" target="_blank"><i
                                class="fas fa-phone"></i>
                          ${this.formatPhoneNumber(provider.phone.raw)}</a>
                        </div>
                      </div>
        </div>
        <div class="uk-modal-footer">
        <a href="/bioidentical-hormone-replacement-therapy-provider/${provider.slug}"
                                class="uk-button uk-button-primary uk-width-1-1"
                                >Visit Practice<i class="fas fa-arrow-right uk-margin-small-left"></i> </a>
        </div>`);
                });

        },
        searchByPractice() {
            this.searchBy.providers = null;
            this.searchBy.input = '';
            UIkit.offcanvas('#advancedOptions')
                .hide();
            this.defaultView = false;
            this.viewName = 'practice';
            this.title = `Find Practice by Name`;
            axios.get(`${this.apiHost}/wp-json/nativerank/v1/providers/all`)
                .then(res => {
                    this.searchBy.providers = res.data;
                });
        },

        searchByProvider() {
            this.searchBy.providers = null;
            this.searchBy.input = '';
            UIkit.offcanvas('#advancedOptions')
                .hide();
            this.defaultView = false;
            this.viewName = 'provider';
            this.title = `Find Practice by Name`;
            axios.get(`${this.apiHost}/wp-json/nativerank/v1/practitioners/all`)
                .then(res => {
                    this.searchBy.providers = res.data;
                });
        },
        highlightSearch(value) {
            const query = this.searchBy.input;
            if (query === '') {
                return value;
            }
            const re = new RegExp(query, 'ig');
            return value.replace(re, (match) => {
                return `<span class="searchHighlight">${match}</span>`;
            });
        },
        markerClicked(index) {

            this.$refs.markers.map((marker, idx) => this.$refs.markers && this.$refs.markers[idx].$markerObject.setIcon(this.map.markerImage.red));
            //this.$refs.markers[index].$markerObject.setAnimation(google.maps.Animation.BOUNCE);
            index !== -1 && this.$refs.markers && (this.$refs.markers[index].$markerObject.setIcon(this.map.markerImage.active));
        },
        log(item) {
            console.log(item);
        },
        setPlace(place) {
            this.approximateSearch = false;
            this.loadingCurrentLocation = false;
            this.defaultVals.zoom = 12;
            this.resetUser('zoom');
            this.resetUser('radius');
            if (!place) return;
            this.user.search = place.formatted_address;
            this.user.latLng = {
                lat: place.geometry.location.lat(),
                lng: place.geometry.location.lng(),
            };
        },
        resetUser(settingName) {

            this.user[settingName] = this.defaultVals[settingName];
        },
        userCustomSearch(currentLocation) {
            this.approximateSearch = null;
            this.loadingCurrentLocation = false;
            this.resetUser('radius');
            let userEntry = this.existingZip.toString();
            !userEntry && (userEntry = this.$refs.userSearch.$el.value);

            try {
                let geoCoder = new google.maps.Geocoder();
            } catch (e) {
                setTimeout(_ => {
                    this.userCustomSearch(currentLocation);
                }, 50);
                return;
            }

            let geoCoder = new google.maps.Geocoder();
            let searchQuery = currentLocation ? {placeId: currentLocation} : {address: userEntry};
            geoCoder.geocode(searchQuery, (result, status) => {
                if (status === 'OK') {
                    let place = result[0];
                    this.user.search = place.formatted_address;
                    this.user.latLng = {
                        lat: place.geometry.location.lat(),
                        lng: place.geometry.location.lng(),
                    };
                } else {

                    if (status == 'ZERO_RESULTS') {
                        this.predictLocation();
                        return;
                    }
                    console.log(
                        'Geocode was not successful for the following reason: ' + status
                    );
                }
            });
        },
        getProviders() {
            this.userMessage = null;
            this.resetUser('zoom');
            this.map.center = this.user.latLng;
            this.infoWindow.open = false;
            this.providers = null;
            this.loading = true;
            axios.get(this.allProvidersApiUrl)
                .then(res => {
                    if (res.data && res.data.length < 5 && this.user.radius < 101) {
                        this.user.radius *= 2;
                        return;
                    }
                    this.providers = res.data;
                    if (this.providers.length > 0) {
                        this.plotMarkers();
                        this.selectedProvider = this.providers[0];
                        this.selectedProvider.index = 0;
                    }
                    this.loading = false;
                    this.loadingCurrentLocation = false;
                    this.providers && (this.providers.length < 1) && (this.userMessage = `<div class="uk-text-center uk-section uk-section-xsmall"><h2>No Practices found near you.</h2><a href="${this.apiHost}/nominate-a-provider/" class="uk-button uk-button-primary">Nominate A Provider</a></div>`);
                })
                .catch(e => console.log(e));

            this.gtmTracking('Search Providers', 'Provider Locator', 'Current Location');
        },
        getCurrentLocation() {
            this.approximateSearch = false;
            this.defaultVals.zoom = 12;
            this.resetUser('zoom');
            this.resetUser('radius');
            this.loadingCurrentLocation = true;
            if ('geolocation' in navigator) {
                navigator.geolocation.getCurrentPosition(position => {
                    this.loadingCurrentLocation = false;
                    this.user.latLng = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    this.user.search = 'Current Location';

                });

            } else {
                this.userMessage = '<div class="uk-text-center">Your browser is not up to dat. Please update your browser to use our Geo Locator.</div>';
            }
        },
        checkUserLocation(request) {
            request === 'set' && window.localStorage.setItem('userSettings', JSON.stringify(this.user));
            if (request === 'get') {

                if (typeof window.nr1055_existting_zip !== 'undefined') {
                    this.existingZip = window.nr1055_existting_zip;
                    this.userCustomSearch();
                    return true;
                }

                if (window.location.hash.indexOf('currentLocation') > -1) {
                    if (window.localStorage.getItem('clt') && window.localStorage.getItem('clg')) {
                        this.defaultVals.zoom = 12;
                        this.resetUser('zoom');
                        this.resetUser('radius');
                        this.loading = true;
                        this.approximateSearch = null;
                        this.loadingCurrentLocation = true;
                        this.user.latLng = {
                            lat: Number(window.localStorage.getItem('clt')),
                            lng: Number(window.localStorage.getItem('clg'))
                        };
                        this.user.search = 'Current Location';
                    } else {
                        this.getCurrentLocation();
                    }

                    return true;
                }

                if (window.localStorage.getItem('userSettings')) {
                    this.user = JSON.parse(window.localStorage.getItem('userSettings'));
                } else {
                    this.globalPosition();
                }
                return true;
            }
            return false;
        },
        checkRecentlySearched(provider, request) {
            let history = window.localStorage.getItem('userHistory');
            if (typeof history !== "object") {
                history = ''
            }
            history ? (history = JSON.parse(history)) : (history = []);

            request === 'get' && (this.recentlySearched = history);
            if (request === 'set') {
                history.push(provider);
                window.localStorage.setItem('userHistory', JSON.stringify(history));
                return;
            }
        },
        plotMarkers() {
            this.providers.map(provider => {
                provider.position = {
                    lat: Number(provider.lat),
                    lng: Number(provider.lng)
                };
            });
        },
        gtmTracking(event, category, label) {
            let providerEngagementEvent = {event: 'Provider Engagement', engagementType: event, providerName: label};
            let primaryEventObject = {event: event, engagementType: event, providerName: label};
            const localStorageKey = 'bioteProviderEngagement'
            const currentTimestamp = {timestamp: Date.now()}
            const thirtyMinutesInMilliseconds = 1800000
            const isNewPageVisitor = window.localStorage.getItem('newFindAProviderPageVisitor') !== null
            const pushEvent = (eventObject) => {
                let dataLayerAvailable = "undefined" != typeof dataLayer
                dataLayerAvailable && dataLayer.push(eventObject)
                if (!dataLayerAvailable) {
                    console.log(eventObject)
                }
            }

            pushEvent(primaryEventObject)

            if (isNewPageVisitor) {
                let e = {
                    event: 'New Provider Form - Old Engagement Type',
                    engagementType: event,
                    providerName: label
                }
                pushEvent(e)
                return
            }

            checkForPreviousEngagement: try {
                const lastProviderEngagement = JSON.parse(window.localStorage.getItem(localStorageKey))
                const noPreviousEngagement = lastProviderEngagement === null || typeof lastProviderEngagement.timestamp === 'undefined'
                if (noPreviousEngagement) {
                    pushEvent(providerEngagementEvent)
                    break checkForPreviousEngagement
                }
                const thirtyMinutesHasPassed = (currentTimestamp.timestamp - lastProviderEngagement.timestamp) > thirtyMinutesInMilliseconds
                thirtyMinutesHasPassed && pushEvent(providerEngagementEvent)
            } catch (e) {
                pushEvent(providerEngagementEvent)
            } finally {
                window.localStorage.setItem(localStorageKey, JSON.stringify(currentTimestamp))
            }

        },
        globalPosition() {

            axios.get('https://ipinfo.io/json?token=8df19af83f7ced')
                .then(res => {
                    this.defaultVals.zoom = 12;
                    this.approximateSearch = {
                        formatted_address: res.data.city
                    };
                    this.user.latLng = {
                        lat: Number(res.data.loc.split(',')[0]),
                        lng: Number(res.data.loc.split(',')[1])
                    };
                })
                .catch(e => console.log(e));

        },
        // highlight: debounce(function (marker, idx) {
        //   this.scrollIndex = idx;
        //   [].forEach.call(document.querySelectorAll('.location-card'), function (el) {
        //     el.classList.remove('active');
        //   });
        //   setTimeout(function () {
        //     document.querySelector('div[data-idx="' + idx + '"]') && document.querySelector('div[data-idx="' + idx + '"]')
        //       .classList
        //       .add('active');
        //   }, 100);
        //
        // }, 200),
        seelctCard(elem) {
            [].forEach.call(document.querySelectorAll('.location-card'), function (el) {
                el.classList.remove('active');
            });
            elem.target.classList.add('active');

        }
    },
    filters: {
        //Convert Miles to 2 decimal places
        miles: function miles(_miles) {
            return parseFloat(_miles)
                .toFixed(2);
        },
        formatPhoneNumber: function formatPhoneNumber(number) {
            if (number.length < 10) {
                return number;
            }

            var cleaned = ('' + number).replace(/\D/g, '');
            var match = cleaned.match(/^(1|)?(\d{3})(\d{3})(\d{4})$/);

            if (match) {
                var intlCode = match[1] ? '+1 ' : '';
                return [intlCode, '(', match[2], ') ', match[3], '-', match[4]].join(
                    ''
                );
            }
            return null;
        }
    },
    mounted() {
        this.checkUserLocation('get');
        this.checkRecentlySearched(null, 'get');
    }
};
</script>

<style lang="less">
#bioTEApp.mobile {


    .miles-dropdown {
        li {
            a {
                padding: 12px 15px;
                border-bottom: 1px solid #cecece;
            }
        }
    }


    font-family: Montserrat, sans-serif;

    .searchHighlight {
        background: rgba(245, 126, 32, 0.83);
    }

    .list_view_container {
        & > div:first-child {
            overflow-y: scroll !important;
        }
    }

    .list_view {
        .location-card {
            h3 {
                font-size: 14px;
                font-weight: 500;
            }

            address {
                color: rgba(0, 0, 0, .54);
                font-size: 12px;
            }

            .links {
                display: flex;
                align-items: center;
                justify-content: flex-end;

                a {
                    text-align: center;
                    width: 50%;
                }

                .label {
                    color: #333;
                    font-size: 12px;
                    display: block;
                }
            }
        }
    }

    .autocomplete_input {
        padding-left: 46px;
    }

    .fa-bars {
        cursor: pointer;
    }

    a:not(.uk-button) {
        font-weight: 500;

        &:active {
            outline: 2px auto Highlight;
            outline-color: #7baaf7;
            outline-style: auto;
            outline-width: 5px;
            outline: 5px auto #7baaf7;
        }


        &:focus {
            background: #f1f3f4;
            outline: 10px solid #f1f3f4;
        }
    }

    .uk-button-primary {
        background: #f57e20;
    }

    .uk-section-small {
        padding-bottom: 20px;
    }

    h1 {
        color: #fff;
        font-weight: 300;
        font-size: 24px;
        letter-spacing: .5px;
        margin-bottom: 10px;
    }

    .provider_search {
        .uk-input {
            transition: all .2s ease-in-out;
            border: 1px solid rgba(51, 51, 51, .5) !important;
            border-radius: 4px;
            height: 55px;
            position: relative;
            z-index: 4;

            &:focus {
                outline: 3px auto #f57e20;
                outline-offset: 3px;

                & ~ .clear {
                    color: #1867c0;
                }
            }

        }
    }


    .clear {
        top: 1px;
        bottom: 1px;

        z-index: 9;
        right: 0;
        width: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 22px;
        cursor: pointer;
        background: #fff;

    }

    .nr-form-icon {
        color: #fff;
        border-radius: 4px;
        padding: 5px 10px;
        line-height: normal;
        text-transform: none;
        font-size: 16px;
        letter-spacing: .5px;
        border-width: 3px;
    }

    .current_location {
        border-radius: 4px;
        background: transparent;
        border-width: 3px;
        border-color: #f57e20;
        color: #fff;
        padding: 5px 10px;
        line-height: normal;
        text-transform: none;
        -webkit-transition: all .25s ease-in-out;
        -moz-transition: all .25s ease-in-out;
        -ms-transition: all .25s ease-in-out;
        -o-transition: all .25s ease-in-out;
        transition: all .25s ease-in-out;
        font-size: 16px;
        letter-spacing: .5px;

        &:hover {
            background-color: #f57e20;
            color: #fff;
        }
    }

    .links {
        a:not(.uk-button) {
            color: #f57e20 !important;
            font-weight: 500;

            &:focus {
                background: #f1f3f4;
                outline: 10px solid #f1f3f4;
            }
        }
    }

    .providerMessage {
        font-size: 1.2rem;
        line-height: 1.4;
        color: #333;

        &.loading, &.current-location-loading {
            position: relative;
            color: rgba(0, 0, 0, .3);
            font-size: 1.5rem;
            margin-top: 15px;
            display: block;

            &:before {
                content: "Finding Practices...";
                position: absolute;
                overflow: hidden;
                max-width: 7em;
                white-space: nowrap;
                color: #fff;
                -webkit-animation: infinite pro-loading 3s linear;
                animation: infinite pro-loading 3s linear
            }

            &.current-location-loading {
                &:before {
                    content: "Getting Current Location...";
                }
            }

        }
    }

    .userRadius {
        margin-right: 4px;
        font-weight: 800;
        width: 30px;
        text-align: right;
        background: 0 0;
        border: none;
        font-size: 16px;
        border-bottom: 1px solid #fff;
        -webkit-appearance: none;

        & + span {
            margin-left: 6px;
            color: #333;
        }
    }

    #infoWindowContentDisplay strong {
        color: #5e328b;
        font-weight: 700;
        font-size: 20px
    }

    #infoWindowContentDisplay p {
        font-size: 14px;
        font-weight: 600
    }

    #infoWindowContentDisplay .uk-button-default {
        background: #4caf50;
        color: #fff
    }

    .location-card {
        padding: 20px 25px;
        box-shadow: none

    }


    .location-card:not(.simple) {
        border-radius: 0;
        box-shadow: 0 1px 3px 0 rgba(87, 87, 87, .16);
        border: 1px solid rgba(112, 112, 112, .16)
    }

    .location-card.active {
        border-color: #4caf50;
        box-shadow: inset 0 1px 3px 4px rgba(87, 87, 87, .16)
    }

    .location-card {
        .uk-text-meta {
            color: #333;
            font-weight: 700;
            font-size: 15px;
        }

        .uk-button-primary {
            line-height: 28px;
        }
    }

    .location-card .link {
        font-size: 16px;
        color: #f57e20 !important;

    }

    .location-card h3 {
        color: #5e328b;
        font-weight: 600;
        font-size: 18px;
        letter-spacing: 1px
    }

    .location-card address {
        color: #595959;

        font-size: 14px;
        font-weight: 400
    }

    .pac-container {
        border-radius: 4px
    }

    .pac-logo:after {
        content: none
    }

    .pac-item-selected {
        background: #c3e3c4
    }

    .pac-matched {
        color: #5e328b
    }

    .pac-item-query {
        font-size: 15px
    }

    .pac-item {
        padding: 9px 8px
    }

    .tab-stick {
        &.uk-active {
            box-shadow: 0 3px 4px 0 rgba(0, 0, 0, .2);
        }
    }

    .uk-tab {


        a {
            padding: 13px 10px;

            &:focus {
                outline: none;
                background: none;
            }
        }

        & > li > a {
            color: #333;
        }

        & > .uk-active > a {
            border-width: 2px;
            border-color: #5e328b;
            color: #5e328b;
        }
    }

    .allList {
        .location-card {
            hr {
                opacity: 0.5;
            }

            border: none !important;
            border-bottom: 1px solid #e8e8e8 !important;
            box-shadow: none !important;
        }

        & > div:nth-child(2n+2) {
            .uk-card {
                background: #f8f8f8;
            }
        }


    }

    .uk-totop {
        position: fixed;
        bottom: 10px;
        right: 10px;
        z-index: 999;
        background: #5e328b;
        opacity: 0.9;
        color: #fff;
        padding: 15px;
        box-shadow: 0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23);
    }

    .text-change-enter-active {
        transition: all .3s ease;
    }

    .text-change-leave-active {
        transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
    }

    .text-change-enter
        /* .slide-fade-leave-active for <2.1.8 */ {
        background-color: rgba(76, 175, 80, 0.5);
    }

}

@-webkit-keyframes pro-loading {
    0% {
        max-width: 0
    }
}

@keyframes pro-loading {
    0% {
        max-width: 0
    }

}

.uk-modal-dialog {
    h3 {
        color: #5e328b;
    }


    a:not(.uk-button) {
        color: #f57e20 !important;
        font-weight: 500;

        &:focus {
            background: #f1f3f4;
            outline: 10px solid #f1f3f4;
        }
    }

    a:not(.uk-button) {
        font-weight: 500;

        &:active {
            outline: 2px auto Highlight;
            outline-color: #7baaf7;
            outline-style: auto;
            outline-width: 5px;
            outline: 5px auto #7baaf7;
        }


        &:focus {
            background: #f1f3f4;
            outline: 10px solid #f1f3f4;
        }
    }


}

.uk-modal-footer {
    .uk-button-primary {
        background: #f57e20;
    }
}

#advancedOptions {
    .uk-offcanvas-bar {
        background: #fff;
        padding: 0;

        .uk-nav-divider {
            border-color: #cecece;
        }

        .uk-nav-header {
            color: #545454;
            border-bottom: 1px solid #cecece;
            padding: 10px 15px;
        }

        li {

            & > a {
                color: #191919;
                text-align: left;
                font-size: 18px;
                padding: 10px 15px;

                i {
                    color: #f57e20;
                }
            }
        }
    }
}

</style>
