<?php

namespace App\Fields;

use TypeRocket\Core\Config;
use TypeRocket\Elements\Fields\Field;
use TypeRocket\Html\Tag;

class GoogleLocation extends Field
{

	protected $api;

	/**
	 * @inheritDoc
	 */
	protected function init()
	{
		$this->api = Config::locate('app.api_keys.google_maps');
		$this->setType('google_location');

	}


	protected function beforeEcho()
	{

		echo "<script>window.nr_m_a = '{$this->api}'</script>";


		echo "<script>
jQuery(document).ready(function($){
	var addrString = function(){return encodeURIComponent([$('#tr_field_street_address').val(), $('#tr_field_city').val(), $('#tr_field_state').val(), $('#tr_field_zip').val()].join('+')) }
	function getData(){
		console.log(addrString())
		$.ajax({
            url: 'https://maps.googleapis.com/maps/api/geocode/json?address='+addrString()+'&key={$this->api}',
        }).done(function(data) {
            if(data.status !== 'OK')
            	{            
            		alert(data.status + ' - Check your address')
return;
       
            	} 
            		var lat = data.results[0].geometry.location.lat
            		var lng = data.results[0].geometry.location.lng
            		$('#nr_location_lat').val(lat)
            		$('#nr_location_lng').val(lng)
            		if(typeof nr_map !== 'undefined')
            			{
            				   nr_map.setCenter({lat: lat, lng: lng});
 
                          var marker = new google.maps.Marker({
                            position: {lat: lat, lng: lng},
                            map: nr_map,
                            
                          });
 
                        }
          
                            
            
        });
	}
	
	
	$('#getLatLang').click(function(ev){
		getData()
	})  
	
	$('.location_column input').on('change', function(){
		getData()
	})
})
</script>";
	}


	/**
	 * @inheritDoc
	 */
	public function getString()
	{

		$class  = $this->getAttribute('class');
		$values = $this->getValue();
		$name   = $this->getNameAttributeString();
		$lat    = $this->settings['lat'] ?? '0';
		$lng    = $this->settings['lng'] ?? '0';


		$html = '';

		$html .= "<div class='button button-secondary small'  style='display:none;margin-bottom:10px;' id='getLatLang'>Get Lat / lng</div>";

		$html .= '
       
         <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
        min-height: 260px;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
            <div id="map"></div>
<script>

      window.nr_map;
      window.initMap = function () {
        nr_map = new google.maps.Map(document.getElementById(\'map\'), {
          center: {lat: ' . $lat . ', lng: ' . $lng . '},
          zoom: 17
        });
           var marker = new google.maps.Marker({
                            position: {lat: ' . $lat . ', lng: ' . $lng . '},
                            map: nr_map
                           
                          });
      }
       
 
      
    </script>
    <script src="https://maps.googleapis.com/maps/api/js?key=' . $this->api . '&callback=initMap" async defer></script>
        ';

		foreach ($this->settings as $label => $value) {
			$html  .= '<div style="width: 40%;display:inline-block;margin-top:10px;">';
			$attrs = [
				'type' => 'text',
				'value' => esc_attr($value ?? ''),
				'name' => 'tr[' . $label . ']',
				'placeholder' => $label,
				'class' => 'tr_field_location_' . $label,
				'id' => 'nr_location_' . $label,
			];

			$html .= Tag::make('label', ['class' => 'label-thin hidden'], '')->prependInnerTag(Tag::make('input', $attrs));

			$html .= '</div>';

		}


//        $lat_input = (new Generator())->newInput('text', 'lat', $lat);
//        $lng_input = (new Generator())->newInput('text', 'lng', $lng);
//        $html .= $lat_input . $lng_input;
		return $html;
	}
}
