<?php

namespace App\Fields;


use TypeRocket\Elements\Fields\Field;
use TypeRocket\Html\Generator;

class BiotePhoto extends Field
{

	protected function init()
	{
		$this->setType('biote_photo');
	}

	public function getString()
	{
		$generator = new Generator();
		$name      = $this->getNameAttributeString();

		$value    = $this->getValue();
		$id       = $this->settings['id'];
		$url      = $this->settings['url'];
		$pathSlug = "nr/practitioners/$id.jpg";
		$img_dir  = get_home_path() . $pathSlug;
		$slug     = "/" . $pathSlug;
		$saved    = false;
		if (file_exists($img_dir)) {
			$src   = get_site_url() . $slug;
			$attr  = array_merge($this->getAttributes(), ['src' => $src, 'class' => 'biote_photo_id']);
			$input = $generator->newElement('img', $attr);
			return $input->getString();
		} else {
			if (!empty($url)) {
				$saved = save_practitioner_image($url, $img_dir);
			}
		}
		if ($saved === false) {
			return 'BioTE photo not found';
		} else {
			$src = get_site_url() . $slug;
		}

		$attr = array_merge($this->getAttributes(), ['src' => $src, 'class' => 'biote_photo_id', 'style' => 'height: 150px;']);

		$input = $generator->newElement('img', $attr);
		return $input->getString();
	}

}