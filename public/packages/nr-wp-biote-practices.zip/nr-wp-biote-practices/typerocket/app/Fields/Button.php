<?php


namespace App\Fields;


use TypeRocket\Elements\Fields\Field;
use TypeRocket\Html\Generator;

class Button extends Field
{

	protected function init()
	{
		$this->setType('button');
	}

	public function getString()
	{
		$generator = new Generator();
		$name      = $this->getNameAttributeString();

		$value      = $this->getValue();
		$url        = $this->settings['url'];
		$buttonText = $this->settings['text'];
		$attr       = array_merge($this->getAttributes(), ['href' => $url, 'class' => 'button']);

		$input = $generator->newElement('a', $attr, $buttonText);
		return $input->getString();
	}

}