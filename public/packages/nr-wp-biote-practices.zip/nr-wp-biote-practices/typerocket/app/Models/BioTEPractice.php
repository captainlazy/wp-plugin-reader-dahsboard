<?php

namespace App\Models;

use Nativerank\BioTEPractices\Core\Util\Helper;
use TypeRocket\Models\Model;

class BioTEPractice extends Model
{
	protected $resource = 'biote_practices';

	protected $cast = [
		'id' => 'int',
		'address' => 'array',
		'modified' => 'int',
		'marketing_emails' => 'array',
		'phone' => 'object',
		'created' => 'int',
	];

	protected $format = [
		'website' => 'static::strip_url',
		'country_code' => 'static::get_country_code',
		'state' => 'static::get_country_code',
	];

	public function practitioners()
	{
		return $this->belongsToMany('\App\Models\BiotePractitioner', 'wp_biote_practices_biote_practitioners', 'biote_practices_id', 'biote_practitioners_id');
	}

	public static function strip_url($value)
	{
		$url = Helper::strip_url($value);
		return is_string($url) && !empty($url) ? 'http://' . $url : '';
	}

	public static function get_country_code($value)
	{
		if (strlen($value) === 2) {
			return strtoupper($value);
		}

		$country_code = Helper::get_countries_by_name($value);
		if ($country_code) {
			return $country_code;
		}

		return $value;
	}
}