<?php

namespace App\Models;

use TypeRocket\Models\Model;

class BioteAdmin extends Model
{
	protected $resource = 'bioteadmins';
}