<?php

namespace App\Models;

use TypeRocket\Models\Model;

class BiotePractitioner extends Model
{
	protected $resource = 'biote_practitioners';

	protected $cast = [
		'id' => 'int',
		'modified' => 'int',
		'created' => 'int',
		'phone' => 'object',
	];

	protected $format = [

	];

	public function practices()
	{
		return $this->belongsToMany('\App\Models\BioTEPractice', 'wp_biote_practices_biote_practitioners', 'biote_practitioners_id', 'biote_practices_id');
	}

}
