<?php

namespace App\Controllers;

use App\Models\BioTEPractice;
use Nativerank\BioTEPractices\Core\Util\Helper;
use TypeRocket\Controllers\Controller;

class BiotePracticeController extends Controller {

	protected $modelClass = BioTEPractice::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
		return tr_view( 'biote_practices.index' );
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add() {
		$form = tr_form( 'biote_practice', 'create' );

		return tr_view( 'biote_practices.add', [ 'form' => $form ] );
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param array $request
	 *
	 * @return mixed
	 */
	public function create( $request = [] ) {
		if ( empty( $request ) ) {
			$request = $this->request->getFields();
		}
		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Practice Name is Required!', 'warning' );
		}

		if ( ! empty( $request['id'] ) ) {
			$existing_practice = ( new BioTEPractice() )->find( $request['id'] );
			if ( $existing_practice ) {
				return $this->response->flashNext( 'ERROR: Practice with that ID already exists!', 'warning' );
			}
		}

		$practice = new BioTEPractice();
		$practice = $this->updateFields( $practice, $request );
		$practice->save();

		return $this->response->flashNext( 'Practice added!' )->setRedirect( tr_redirect()->toPage( 'biote_practice', 'index' )->url );

	}

	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit( $id ) {
		$form = tr_form( 'biote_practice', 'update', $id );

		return tr_view( 'biote_practices.edit', [ 'form' => $form, 'practice_id' => $id ] );
	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param BioTEPractice $practice
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function update( $id, BioTEPractice $practice ) {
		$request = $this->request->getFields();
		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Practice Name is Required!', 'warning' );
		}

		$request['modified'] = ( new \DateTime() )->getTimestamp();

		$practice = $this->updateFields( $practice, $request );
		$practice->save();

		return $this->response->flashNext( 'Practice updated!' )->setRedirect( tr_redirect()->toPage( 'biote_practice', 'index', $id )->url );
	}

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show( $id ) {
		// TODO: Implement show() method.
	}

	/**
	 * The delete page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function delete( $id ) {
		$form = tr_form( 'biote_practice', 'destroy', $id );

		return tr_view( 'biote_practices.delete', [ 'form' => $form ] );
	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function destroy( $id ) {
		$biote_practice = new BioTEPractice();
		$delete         = $this->request->getFields( 'delete_record' );
		if ( $delete === '1' ) {
			$biote_practice->findOrDie( $id );
			$biote_practice->delete();
			$this->response->flashNext( 'Practice deleted', 'warning' );

			return tr_redirect()->toPage( 'biote_practice', 'index' );
		} else {
			$this->response->flashNext( 'Unable to delete Practice!', 'error' );

			return tr_redirect()->toPage( 'biote_practice', 'delete', $id );
		}

	}

	/**
	 * @param BioTEPractice $biote_practice
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return BioTEPractice
	 */
	private function updateFields( BioTEPractice $biote_practice, $request = [] ) {
		if ( ! empty( $request['phone'] ) ) {
			foreach ( $request['phone'] as $index => $phone ) {
				$request['phone'][ $index ]['number'] = $this->format_phone( $request['phone'][ $index ]['number'], $request['country_code'], $request['name'] );
			}
		}

		if ( ! empty( $request['marketing_effective_date'] ) ) {
			$request['marketing_effective_date'] = ( new \DateTime( str_replace( '/', '-', $request['marketing_effective_date'] ) . 'T11:00:00' ) )->getTimestamp();
		}

		$request['slug'] = Helper::getSlug( $request );


		$request['address'] = $this->formatAddress( $request );
		$request['lat']     = $request['lat'] ?? $request['location']['lat'] ?? '';
		$request['lng']     = $request['lng'] ?? $request['location']['lng'] ?? '';
		unset( $request['location'] );

		if ( ( (int) $request['status'] ) === 1 ) {
			Helper::removePracticeRedirect( $request );
		}

		if ( ( (int) $request['status'] ) === 0 ) {
			Helper::addPracticeRedirect( $request );
		}

		foreach ( $request as $fieldLabel => $fieldValue ) {
			$biote_practice->{$fieldLabel} = $fieldValue;
		}

		return $biote_practice;
	}

	public function format_phone( $phone, $country_code, $name ) {
		return Helper::build_phone_number( $phone, $country_code, $name );
	}

	public function formatAddress( &$request ) {
		return [
			'street_address' => Helper::array_remove_key( $request, 'street_address' ),
			'city'           => Helper::array_remove_key( $request, 'city' ),
			'state'          => Helper::array_remove_key( $request, 'state' ),
			'zip'            => Helper::array_remove_key( $request, 'zip' )
		];
	}

	public function singleView( $slug ) {
		$practice = ( new BioTEPractice() )->where( 'slug', $slug )->where( 'status', 1 )->take( 1 )->get();

		if ( $practice ) {
			return tr_view( 'biote_practices.single', [ 'practice' => $practice ] );
		}

		$redirect = Helper::findPracticeRedirect( $slug );

		if ( $redirect === null ) {
			ob_start();
			include get_404_template();

			return ob_get_clean();
		}

		if ( isset( $redirect['redirect'] ) ) {
			$practice = ( new BioTEPractice() )->where( 'slug', $redirect['redirect'] )->where( 'status', 1 )->take( 1 )->get();

			if ( $practice ) {
				return tr_view( 'biote_practices.single', [ 'practice' => $practice ] );
			}
		}


		wp_redirect( get_site_url( null, ( $redirect['redirect'] ?? '' ) ), 301 );

		exit;

		return;
	}

}