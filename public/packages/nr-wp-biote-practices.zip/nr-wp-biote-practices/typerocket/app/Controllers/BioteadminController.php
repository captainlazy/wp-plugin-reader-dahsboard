<?php

namespace App\Controllers;

use App\Models\BioteAdmin;
use TypeRocket\Controllers\Controller;

class BioteadminController extends Controller {

	protected $modelClass = BioteAdmin::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
		return tr_view( 'biote_admin.index' );
	}

	public function updateAlertStatus( $request = [] ) {
		if ( empty( $request ) ) {
			$request = $this->request->getFields();
		}

		$current_status = get_option( NR_BIOTE_PRACTICES_ALERTS_OPTION );

		$status = isset( $request['alert_status'] );

		if ( $status === $current_status ) {
			return $this->response->flashNow( 'Alert status is unchanged!', 'success' );
		}

		$updated = update_option( NR_BIOTE_PRACTICES_ALERTS_OPTION, $status, true );
		if ( $updated ) {
			return $this->response->flashNow( 'Alert status updated!', 'success' );
		}

		return $this->response->flashNow( 'Alert status failed to update!', 'warning' );

	}
}