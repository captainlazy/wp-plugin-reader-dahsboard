<?php

namespace App\Controllers;

use App\Models\BiotePractitioner;
use Nativerank\BioTEPractices\Core\Util\Helper;
use TypeRocket\Controllers\Controller;


class BiotePractitionerController extends Controller
{

	protected $modelClass = BiotePractitioner::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index()
	{
		return tr_view('biote_practitioners.index');
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add()
	{
		$form = tr_form('biote_practitioner', 'create');

		return tr_view('biote_practitioners.add', ['form' => $form]);
		//NOTE: Save the data we pass over from the view using the create() method.
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function create($request = [])
	{
		$practitioner = new BiotePractitioner;
		if (empty($request)) {
			$request = $this->request->getFields();
		}
		if (empty($request['first_name']) || empty($request['last_name'])) {
			return $this->response->flashNext('ERROR: Practitioner Name is Required!', 'warning');
		}

		$existing_practitioner = (new BiotePractitioner())->find($request['id']);
		if ($existing_practitioner) {
			return $this->response->flashNext('ERROR: Practitioner with that ID already exists!', 'warning');
		}


		$practitioner = $this->updateFields($practitioner, $request);
		$practitioner->save();

		return $this->response->flashNext('Practitioner added!')->setRedirect(tr_redirect()->toPage('biote_practitioner', 'index')->url);

	}

	/**
	 * @param BiotePractitioner $practitioner
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return BiotePractitioner
	 */
	public function updateFields(BiotePractitioner $practitioner, $request = [])
	{

		if (!empty($request['phone'])) {
			$request['phone'] = $this->format_phone($request['phone'], null, $request['first_name'] . " " . $request['last_name']);
		}

		foreach ($request as $fieldLabel => $fieldValue) {

			$practitioner->{$fieldLabel} = $fieldValue;

		}

		return $practitioner;
	}


	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit($id)
	{
		$form = tr_form('biote_practitioner', 'update', $id);

		return tr_view('biote_practitioners.edit', ['form' => $form]);
	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param BiotePractitioner $practitioner
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function update($id, BiotePractitioner $practitioner)
	{
		$request = $this->request->getFields();

		if (empty($request['first_name']) || empty($request['last_name'])) {
			return $this->response->flashNext('ERROR: Practitioner Name is Required!', 'warning');
		}

		// Update modified time
		$request['modified'] = (new \DateTime())->getTimestamp();

		$practitioner = $this->updateFields($practitioner, $request);
		$practitioner->save();

		$this->response->flashNext('Practitioner updated!');

		return tr_redirect()->toPage('biote_practitioner', 'edit', $id);
	}

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show($id)
	{
		// TODO: Implement show() method.
	}

	/**
	 * The delete page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function delete($id)
	{
		$form = tr_form('biote_practitioner', 'destroy', $id);

		return tr_view('biote_practitioners.delete', ['form' => $form]);
	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function destroy($id)
	{
		$practitioner = new BiotePractitioner();
		$delete       = $this->request->getFields('delete_record');

		if ($delete == '1') {
			$practitioner->findOrDie($id);
			$practitioner->delete();
			$this->response->flashNext('Practitioner deleted!', 'warning');

			return tr_redirect()->toPage('biote_practitioner', 'index');
		} else {
			$this->response->flashNext('Unable to delete practitioner!', 'error');

			return tr_redirect()->toPage('biote_practitioner', 'delete', $id);
		}
	}

	public function format_phone($phone, $country_code, $name)
	{
		return Helper::build_phone_number($phone, $country_code, $name);
	}

}
