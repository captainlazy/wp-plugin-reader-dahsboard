window.TypeRocket={httpCallbacks:[],repeaterCallbacks:[],lastSubmittedForm:!1,redactorSettings:{},builderCallbacks:[]};
