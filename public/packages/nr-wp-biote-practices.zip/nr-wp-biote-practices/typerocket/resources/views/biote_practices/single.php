<?php

// TODO: add SEO format for title and meta description below
add_filter( 'wpseo_title', function ( $trim ) use ( $practice ) {
	return "{$practice->name} | BioTE® Hormone Replacement Therapy";
} );
add_filter( 'wpseo_metadesc', function ( $trim ) use ( $practice ) {
	$trim = "Contact {$practice->name}, your local BioTE® Medical practice in ";
	$trim .= implode( " ", [
		$practice->address["city"] . ",",
		$practice->address["state"],
		$practice->address["zip"]
	] );
	$trim .= ". We use bioidentical hormone replacement therapy (BHRT) to help you live healthier and happier.";

	return $trim;
} );


$NRTemplate = new \Nativerank\BioTEPractices\Core\Util\template\NRPracticeTemplate( $practice );

gravity_form_enqueue_scripts( 6, true );

get_header();

if ( isset( $NRTemplate ) ) {
	$NRTemplate->render();
}


?>
    <div id="provider-form" class="uk-flex-top" uk-modal>
        <div class="uk-modal-dialog uk-modal-body uk-margin-auto-vertical uk-padding uk-background-default"
             uk-overflow-auto
             style="box-shadow: 0 10px 20px 0 rgba(0,0,0,.2);">

            <button class="uk-modal-close-default" type="button" uk-close></button>
            <div>
                <h2 class="uk-text-center">Contact <?= $practice->name ?></h2>
            </div>

			<?php
			$emails = [];
			if ( $practice->marketing_emails ) {
				foreach ( array_values( $practice->marketing_emails ) as $marketing_email ) {
					$emails[] = $marketing_email['email'];
				}
			}

			gravity_form( 6, false, false, false, array(
				'practice_name'   => $practice->name,
				'marketing_email' => implode( ',', $emails )
			), true, - 1, true );
			?>
        </div>
    </div>

    <script>jQuery(document).ready(function (a) {
            var nr1055PushEvent = function (event, category, label) {
                let providerEngagementEvent = {
                    event: 'Provider Engagement',
                    engagementType: event,
                    providerName: label
                };
                const primaryEventObject = {event: event, engagementType: event, providerName: label};
                const localStorageKey = 'bioteProviderEngagement'
                const currentTimestamp = {timestamp: Date.now()}
                const thirtyMinutesInMilliseconds = 1800000
                const isNewPageVisitor = window.localStorage.getItem('newFindAProviderPageVisitor') !== null
                const pushEvent = (eventObject) => {
                    let dataLayerAvailable = "undefined" != typeof dataLayer
                    dataLayerAvailable && dataLayer.push(eventObject)
                    if (!dataLayerAvailable) {
                        console.log(eventObject)
                    }
                }

                pushEvent(primaryEventObject)

                if (isNewPageVisitor) {
                    let e = {
                        event: 'New Provider Form - Old Engagement Type',
                        engagementType: event,
                        providerName: label
                    }
                    pushEvent(e)
                    return
                }

                checkForPreviousEngagement: try {
                    const lastProviderEngagement = JSON.parse(window.localStorage.getItem(localStorageKey))
                    const noPreviousEngagement = lastProviderEngagement === null || typeof lastProviderEngagement.timestamp === 'undefined'
                    if (noPreviousEngagement) {
                        pushEvent(providerEngagementEvent)
                        break checkForPreviousEngagement
                    }
                    const thirtyMinutesHasPassed = (currentTimestamp.timestamp - lastProviderEngagement.timestamp) > thirtyMinutesInMilliseconds
                    thirtyMinutesHasPassed && pushEvent(providerEngagementEvent)
                } catch (e) {
                    pushEvent(providerEngagementEvent)
                } finally {
                    window.localStorage.setItem(localStorageKey, JSON.stringify(currentTimestamp))
                }

            };
            a(".uk-button.phoneNumber").click(function () {
                nr1055PushEvent("Provider Profile - Phone Click", "Provider Profile - Phone Click", "<?= $practice->name ?>")
            });
            a(".uk-button.wellnessQuiz").click(function () {
                nr1055PushEvent("Provider Profile - Wellness Quiz Click",
                    "Provider Profile - Wellness Quiz Click", "<?= $practice->name ?>")
            });
            a(".uk-button.getDirections").click(function () {
                nr1055PushEvent("Provider Profile - Get Directions Click", "Provider Profile - Get Directions Click", "<?= $practice->name ?>")
            });
            a(".uk-button.externalWebsite").click(function () {
                nr1055PushEvent("Provider Profile - Website Click", "Provider Profile - Website Click", "<?= $practice->name ?>")
            })
        });
    </script>
    <style>
        #tm-main, .blog #tm-main {
            padding: 0 !important;
        }

        @media screen and (min-width: 641px) {
            .gfield_radio {

        & > li {
              display: inline-block;
              margin-right: 20px !important;
          }
        }

        }
    </style>
<?php

get_footer();
