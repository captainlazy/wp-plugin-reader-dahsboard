<?php

use App\Fields\GoogleLocation;use Nativerank\BioTEPractices\Core\Util\Helper;

$tabs = tr_tabs();

$form->useAjax()->setDebugStatus(false);
echo $form->open();
$practice = (new \App\Models\BioTEPractice())->find($practice_id);
if ($practice) {
	$practitioners = $practice->practitioners()->get();
	if (!empty($practitioners)) {
		$practitioners = $practitioners->toArray();
		usort($practitioners, function ($practitioner1, $practitioner2) {
			if (($practitioner1['status'] === $practitioner2['status'])) {
				return 0;
			}
			if (!$practitioner1['status']) {
				return 1;
			}
			return -1;
		});
		$practitioners = array_chunk($practitioners, 4);
	}
}
$address = $form->text('address')->getValue();

$tabs->addTab('Practice Info', function () use ($form) {
	echo $form->row(
		$form->column(
			$form->text('Name')->required(),
			$form->text('ID')->setType('number')->required()->setAttribute('readonly', 'readonly')
		),
		$form->column(
			$form->text('Email')->setType('email'),
			$form->text('Website')
		),
		$form->column(
			$form->repeater('Phone')->setLabel('Phone Numbers')->setFields([
				$form->text('Number')->setLabel('Phone Number')->setCast(function ($val) {
					if (empty($val) || !is_array($val)) {
						return $val;
					}
					return $val['formatted'] ?? $val['raw'];
				})
			])
		)
	);

});

$tabs->addTab('Location', function () use ($form, $address) {
	echo $form->row(
		$form->column(
			$form->text('Street Address')->setDefault($address['street_address'] ?? ''),
			$form->text('City')->setDefault($address['city'] ?? ''),
			$form->text('State')->setDefault($address['state'] ?? ''),
			$form->text('ZIP')->setDefault($address['zip'] ?? ''),
			$form->select('Country')->setOptions(Helper::get_countries_by_name())
		)->setAttribute('class', 'location_column'),
		$form->column(
			(new GoogleLocation('Location', $form))->setSettings(['lat' => $form->text('lat')->getValue(), 'lng' => $form->text('lng')->getValue()])
            )
	);
});

$tabs->addTab('Marketing', function () use ($form) {
	echo $form->row(
		$form->column(
			$form->select('Marketing Program')->setLabel('Program')->setOptions(['Certified' => 'certified', 'Legacy' => 'legacy', 'Platinum' => 'platinum']),
			$form->date('Marketing Effective Date')->setLabel('Effective Date')->setCast(function ($arg) {
				return $arg ? (new DateTime("@$arg"))->format('d/m/Y') : $arg;
			})
		),
		$form->column(
			$form->repeater('Marketing Emails')->setFields([
				$form->text('Email')->setType('email')
			])
		),
		$form->column(
			$form->toggle('Marketing Status')->setLabel('Status')->setText('Active')->setDefault(true)
		)
	);
});

$tabs->setSidebar(function () use ($form) {
	echo $form->submit('Update');
	$status = $form->toggle('Status')->setLabel('Practice Status')->setText('Active');
	echo $status;
    $slug = $form->text('Slug');
    if($status->getValue()) {
        $slugValue = $slug->getValue();
        echo '<div class="control-section"><div class="control"><a href="' . get_site_url() . "/" . NR_BIOTE_PRACTICES_PARENT_SLUG . "/" . $slugValue . '" class="button" target="_blank">View Practice</a></div></div>';
    }
    echo $slug;

	echo $form->text('Modified')->setLabel('Last Modified')->setAttribute('readonly', 'readonly')->setCast(function ($arg) {
		return (new DateTime("@$arg"))->format('F j, Y, g:i a');
	});

	echo $form->text('Created')->setLabel('Date Added')->setAttribute('readonly', 'readonly')->setCast(function ($arg) {
		return (new DateTime("@$arg"))->format('F j, Y, g:i a');
	});
});


$tabs->render('box');

echo $form->close();

if (!empty($practitioners)) {
	?>
    <style>
        .practitioners_header {
            margin: 40px 0 20px;
        }

        .practitioners_header .button {
            margin-left: 4px;
            position: relative;
            top: -3px;
        }

        .practitioners {
            display: flex;
            flex-wrap: wrap;
            padding: 40px;
            margin: 0 20px 0 0;
            background: #fff;
        }

        .practitioners .cell {
            flex-basis: 25%;
        }

        .practitioner {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }

        .practitioner.in-active {
            opacity: 50%;
        }

        .practitioner .image {
            text-align: center;
        }

        .practitioner .image img {
            height: 150px;
        }

        .practitioner .image .divider {
            margin: 0 5px;
        }

        .practitioner .name {
            font-weight: bold;
        }

        .practitioner > * {
            padding-left: 10px;
        }
    </style>
    <div class="practitioners_header">
        <h2>Practitioners&nbsp;
            <a href="<?= tr_redirect()->toPage('biote_practitioner', 'add')->url . "&practice_id={$practice_id}" ?>"
               class="button" target="_blank">
                Add New
            </a>
        </h2>
    </div>
    <div class="practitioners">

	<?php foreach ($practitioners as $chunk) { ?>
		<?php foreach ($chunk as $practitioner) {
			$photo = $practitioner['photo_id'] ? wp_get_attachment_image($practitioner['photo_id'] ?? null) : false;
			if ($photo === false) {
                $saved = true;

			    if(!isset($practitioner['biote_photo_id'])) {
                    $src = get_site_url() . "/nr/assets/practitioner.svg";
                    $photo = "<img src='{$src}'>";
			    } else {

			        $photo = $practitioner['biote_photo_id'];

                    $img_dir = get_home_path() . "nr/practitioners/$photo.jpg";
                    if (file_exists($img_dir)) {
                        $src = get_site_url() . "/nr/practitioners/$photo.jpg";
                    } else {
                        if(!empty($practitioner['biote_photo_url'])) {
                            $saved = save_practitioner_image($practitioner['biote_photo_url'], $img_dir);
                        }
                    }
                    if($saved === false) {
                        $src = get_site_url() . "/nr/assets/practitioner.svg";
                    } else {
                        $src = get_site_url() . "/nr/practitioners/$photo.jpg";
                    }
				    $photo = "<img src='{$src}' style='height:150px;'>";
			    }
			}
			?>
            <div class="cell">
                <div class="practitioner<?php
				if (!$practitioner['status']) {
					echo ' in-active';
				}
				?>">
                    <div class="image">
						<?= $photo ?>
                        <br>
                        <span>
                            <a href="<?= tr_redirect()->toPage('biote_practitioner', 'edit', $practitioner['id'])->url ?>"
                                       target="_blank">Edit</a>
                        </span>
                        <span class="divider">
                            |
                        </span>
                        <span>
                            <a href="<?= tr_redirect()->toPage('biote_practitioner', 'delete', $practitioner['id'])->url ?>"
                                       target="_blank">Delete</a>
                        </span>
                    </div>
                    <div>
								<span class="name">
									<?= $practitioner['first_name'] . " " . $practitioner['last_name']; ?>
								</span>
                        <br>
                        <span class="degree">
									<?= $practitioner['degree']; ?>
								</span>
                    </div>
                </div>
            </div>
		<?php }

	}
}