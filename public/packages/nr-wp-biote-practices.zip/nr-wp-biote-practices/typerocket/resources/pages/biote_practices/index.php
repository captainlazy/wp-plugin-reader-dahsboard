<?php

$table = tr_tables()->setOrder('modified', 'desc');
$table->setLimit(100);
$table->setSearchColumns([
	'name' => 'Name',
	'id' => 'ID',
]);
$table->setColumns('name', [
	'name' => [
		'sort' => true,
		'label' => 'Practice',
		'delete_ajax' => false,
		'actions' => ['edit', 'delete', 'view'],
		'view_url' => function ($slug, $practice) {
			if (empty($practice->status)) {
				return '';
			}
			if (is_string($practice->slug)) {
				return get_site_url() . "/" . NR_BIOTE_PRACTICES_PARENT_SLUG . "/" . $practice->slug;
			}

			return '#';
		},
	],
	'status' => [
		'sort' => true,
		'label' => 'Status',
		'callback' => function ($status) {
			return $status ? 'Active' : 'In-Active';
		}
	],
	'address' => [
		'label' => 'Address',
		'callback' => function ($address) {
			if (is_array($address)) {
				return implode(" ", $address);
			}

			return $address;
		}
	],
	'phone' => [
		'label' => 'Phone Number(s)',
		'callback' => function ($phones) {
			return is_array($phones) ? implode(',', array_map(function ($phone) {
				return $phone['number']['formatted'] ?? $phone['number']['raw'];
			}, $phones)) : $phones;
		}
	],
	'modified' => [
		'sort' => true,
		'label' => 'Last Modified',
		'callback' => function ($timestamp) {

			return $timestamp ? '<div title ="' . (new DateTime("@$timestamp"))->format('F j, Y, g:i a') . '">' . (new DateTime("@$timestamp"))->format('M j, g:i a') . '</div>' : '';
		}
	],

]);
$table->render();

echo "<style>.tr-list-table tbody td{vertical-align: middle}</style>";