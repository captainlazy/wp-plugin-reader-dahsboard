<?php

use App\Fields\GoogleLocation;
use Nativerank\BioTEPractices\Core\Util\Helper;

$tabs = tr_tabs();

$form->useAjax()->setDebugStatus(false);

echo $form->open();

$tabs->addTab('Practice Info', function () use ($form) {
	echo $form->row(
		$form->column(
			$form->text('Name')->required(),
			$form->text('ID')->setType('number')
		),
		$form->column(
			$form->hidden('Created')->setLabel('Practice Added')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp()),
			$form->hidden('Modified')->setLabel('Practice Modified')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp()),
			$form->text('Email')->setType('email'),
			$form->text('Website')
		),
		$form->column(
			$form->repeater('Phone')->setLabel('Phone Numbers')->setFields([
				$form->text('Number')->setLabel('Phone Number')
			])
		)
	);
});

$tabs->addTab('Location', function () use ($form) {
	echo $form->row(
		$form->column(
			$form->text('Street Address')->required(),
			$form->text('City')->required(),
			$form->text('State')->required(),
			$form->text('ZIP'),
			$form->select('Country')->setOptions(Helper::get_countries_by_name())->setDefault('US')
		)->setAttribute('class', 'location_column'),
		$form->column(
			(new GoogleLocation('Location', $form))->setSettings(['lat' => $form->text('lat')->getValue(), 'lng' => $form->text('lng')->getValue()])
		)

	);
});

$tabs->addTab('Marketing', function () use ($form) {
	echo $form->row(
		$form->column(
			$form->select('Marketing Program')->setLabel('Program')->setOptions(['Certified' => 'certified', 'Legacy' => 'legacy', 'Platinum' => 'platinum']),
			$form->date('Marketing Effective Date')->setLabel('Effective Date')
		),
		$form->column(
			$form->repeater('Marketing Emails')->setFields([
				$form->text('Email')->setType('email')
			])
		),
		$form->column(
			$form->toggle('Marketing Status')->setLabel('Status')->setText('Active')->setDefault(true)
		)
	);
});

$tabs->setSidebar(function () use ($form) {
	echo $form->submit('Add Practice');
	echo $form->toggle('Status')->setLabel('Practice Status')->setText('Active')->setDefault(true);
});


$tabs->render('box');


echo $form->close();
