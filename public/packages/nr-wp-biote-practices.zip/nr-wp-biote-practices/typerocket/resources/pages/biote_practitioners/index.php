<?php

$table = tr_tables()->setOrder('modified', 'desc');
$table->setLimit(100);

$table->setSearchColumns([
	'first_name' => 'First Name',
	'last_name' => 'Last Name',
	'id' => 'ID',
	'profile_id' => 'Profile ID',
	'biote_practices_id' => 'Practice ID',
]);
$table->setColumns('name', [
	'id' => [
		'sort' => true,
		'label' => 'ID'
	],
	'last_name' => [
		'sort' => true,
		'label' => 'Last Name',
		'delete_ajax' => false,
		'actions' => ['edit', 'delete']
	],
	'first_name' => [
		'sort' => true,
		'label' => 'First Name'
	],
	'status' => [
		'sort' => true,
		'label' => 'Status',
		'callback' => function ($status) {
			return $status ? 'Active' : 'In-Active';
		}
	],
	'modified' => [
		'sort' => true,
		'label' => 'Last Modified',
		'callback' => function ($timestamp) {
			return '<div title ="' . (new DateTime("@$timestamp"))->format('F j, Y, g:i a') . '">' . (new DateTime("@$timestamp"))->format('M j, g:i a') . '</div>';
		}
	],

]);
$table->render();

echo "<style>.tr-list-table tbody td{vertical-align: middle}</style>";