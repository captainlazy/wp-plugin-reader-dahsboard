<?php

use App\Fields\BiotePhoto;
use App\Models\BiotePractitioner;

$form->useAjax()->setDebugStatus(false);
echo $form->open();

$practices    = (new BiotePractitioner())->find($_GET['route_id'])->practices()->get() ?: [];
$practiceList = [];
foreach ($practices as $practice) {
	$practiceList[] = ['name_and_id' => "{$practice->name}  - {$practice->id}", 'edit' => tr_redirect()->toPage('biote_practice', 'edit', $practice->id)->url, 'view' => $practice->slug && $practice->status ? get_site_url() . "/" . NR_BIOTE_PRACTICES_PARENT_SLUG . "/" . $practice->slug : '#'];
}

$biotePhotoField = $form->text('Biote Photo ID')->setLabel('Image ID');
$biotePhotoId    = $biotePhotoField->getValue();
$bioteImageUrl   = $form->hidden('Biote Photo URL')->getValue();
$biotePhoto      = (new BiotePhoto('', $form))->setSetting('id', $biotePhotoId)->setSetting('url', $bioteImageUrl);

$photoUploader = $form->image('Photo ID')->setLabel('Upload Image');
$photoID       = $photoUploader->getValue();

echo $form->row(
	$form->column(
		$form->text('First Name')->required(),
		$form->text('Last Name')->required(),
		$form->text('Degree'),
		$form->text('ID')->setType('number')->setAttribute('readonly', 'readonly'),
		$form->text('Modified')->setLabel('Last Modified')->setAttribute('readonly', 'readonly')->setCast(function ($arg) {
			return (new DateTime("@$arg"))->format('F j, Y, g:i a');
		}),
		$form->text('Created')->setLabel('Date Added')->setAttribute('readonly', 'readonly')->setCast(function ($arg) {
			return (new DateTime("@$arg"))->format('F j, Y, g:i a');
		})
	),
	$form->column(
		$form->text('Email')->setType('email'),
		$form->text('Phone')->setLabel('Phone Number')->setCast(function ($val) {
			if (empty($val) || !is_array($val)) {
				return $val;
			}
			return $val['formatted'] ?? $val['raw'];
		}),
		$biotePhotoField,
		$photoID ? '' : $biotePhoto,
		$photoUploader
	),
	$form->column(
		$form->editor('Bio')
	)
);


echo $form->toggle('Status')->setLabel('Practitioner Status')->setText('Active');

echo $form->submit('Update');

echo $form->close();


?>
    <h2>Practices</h2>

<?php

foreach ($practiceList as $practice) {
	$output = "{$practice['name_and_id']} | ";
	$output .= "<a href='{$practice['edit']}'>Edit</a>";
	if ($practice['view'] !== '#') {
		$output .= " | <a href='{$practice['view']}'>View</a>";
	}
	$output .= "<br>";
	echo $output;
}
