<?php


$form->useAjax()->setDebugStatus(false);

echo $form->open();

$practice_id_field = $form->text('BioTE Practices ID')->setLabel('Practice ID')->setType('number');
if (isset($_GET['practice_id'])) {
	$practice_id_field->setAttribute('value', $_GET['practice_id']);
}

echo $form->row(
	$form->column(
		$form->text('First Name')->required(),
		$form->text('Last Name')->required(),
		$form->text('Degree'),
		$form->text('ID')->setType('number'),
		$practice_id_field
	),
	$form->column(
		$form->hidden('Created')->setLabel('Practitioner Added')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp()),
		$form->hidden('Modified')->setLabel('Practitioner Modified')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp()),
		$form->text('Email')->setType('email'),
		$form->text('Phone')->setLabel('Phone Number'),
		$form->text('Biote Photo ID')->setLabel('Image ID'),
		$form->image('Photo ID')->setLabel('Upload Image')
	),
	$form->column(
		$form->editor('Bio')
	)
);


echo $form->toggle('Status')->setLabel('Practitioner Status')->setText('Active')->setDefault(true);
echo $form->submit('Add Practitioner');


echo $form->close();