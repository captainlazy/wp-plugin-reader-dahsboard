<?php

use Nativerank\BioTEPractices\ClinicLogGetter;

$buttons = [
	[
		'getClinicLog'    => [ 'button_text' => 'Get Updated Clinics Log', 'method' => 'get' ],
		'importPractices' => [ 'button_text' => 'Import Clinics', 'method' => 'post' ]
	],
	[
		'updatePractices'     => [ 'button_text' => 'Update Practices', 'method' => 'post' ],
		'updatePractitioners' => [ 'button_text' => 'Update Practitioners', 'method' => 'post' ]
	],
	[
		'handleInactivePractices'     => [ 'button_text' => 'Deactivate Inactive Practices', 'method' => 'post' ],
		'handleInactivePractitioners' => [ 'button_text' => 'Deactivate Inactive Practitioners', 'method' => 'post' ]
	],
	[
		'saveLogs' => [ 'button_text' => 'Save Logs To File', 'method' => 'post' ],
		'emailLog' => [ 'button_text' => 'Send Log Email', 'method' => 'post' ]
	],
];
?>
<table style="text-align: center">
	<?php foreach ( $buttons as $buttons_chunk ) { ?>
        <tr>
			<?php
			foreach ( $buttons_chunk as $key => $button ) {
				$form_name  = "form_{$key}";
				$$form_name = tr_form()->useAjax()->useUrl( $button["method"], "bioteImporter/{$key}" );
				echo '<td>';
				echo $$form_name->open();
				echo $$form_name->submit( $button["button_text"] );
				echo $$form_name->close();
				echo '</td>';
			}
			?>

        </tr>
	<?php } ?>
</table>
<span>
    Note: the import and update tasks run on up to 1000 of each item at a time
    <br>
    WARNING: 'Get All Clinics' should generally only be run once, when you install the plugin
</span>

<?php

$getAllForm = tr_form()->useAjax()->useUrl( 'get', "bioteImporter/getAll" );
echo $getAllForm->open();
echo $getAllForm->submit( 'Get All Clinics' );
echo $getAllForm->close();

$alertStatus     = get_option( NR_BIOTE_PRACTICES_ALERTS_OPTION );
$alertStatusForm = tr_form()->useAjax()->useUrl( 'post', "bioteImporter/updateAlertStatus" );

echo $alertStatusForm->open();
?>
<label for="alert_status">Alert Status</label>
<input id="alert_status" type="checkbox" <?= $alertStatus ? 'checked' : '' ?> name="tr[alert_status]">
<?php
echo $alertStatusForm->submit( "Update Alert Status" );
echo $alertStatusForm->close();

$lastClinicLogFetched = get_option( ( new ClinicLogGetter() )->getLastRanOption() );
echo 'Log last fetched ' . ( new \DateTime() )->setTimestamp( $lastClinicLogFetched )->format( 'm/d/Y H:i:s' );

$clinicLog                 = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_CLINIC_IDS );
$practicesToUpdate         = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_IMPORTED_CLINICS );
$practitionersToUpdate     = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_IMPORTED_PROFILES );
$practicesToDeactivate     = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_INACTIVE_CLINICS );
$practitionersToDeactivate = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_INACTIVE_PROFILES );

?>

<table id="queueView">
    <thead>
    <tr>
        <th>
            Clinics to Import
        </th>
        <th>
            Practices to Update
        </th>
        <th>
            Practitioners to Update
        </th>
        <th>
            Practices to Deactivate
        </th>
        <th>
            Practitioners to Deactivate
        </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>
			<?php foreach ( $clinicLog as $clinicID ) { ?>
				<?= $clinicID ?><br>
			<?php } ?>
        </td>
        <td>
			<?php foreach ( $practicesToUpdate as $practice ) { ?>
				<?php $active = ( ( $practice['active'] ?? false ) && ( $practice['locatorActive'] ?? false ) );
				echo "{$practice['id']} | {$practice['clinicName']} | " . ( $active ? 'Active' : 'In-Active' ); ?>
                <br>
			<?php } ?>
        </td>
        <td>
			<?php foreach ( $practitionersToUpdate as $practitioner ) { ?>
				<?php $status = $practitioner['is_active'] ? 'Active' : 'In-Active';
				echo "{$practitioner['id']} | {$practitioner['first_name']} {$practitioner['last_name']}, {$practitioner['degree']} | {$status}"; ?>
                <br>
			<?php } ?>
        </td>
        <td>
			<?php foreach ( $practicesToDeactivate as $practice ) { ?>
				<?= $practice ?>
                <br>
			<?php } ?>
        </td>
        <td>
			<?php foreach ( $practitionersToDeactivate as $practitioner ) { ?>
				<?= $practitioner ?>
                <br>
			<?php } ?>
        </td>
    </tr>
    </tbody>
</table>

<style>
    #queueView {
        border-spacing: 10px;
        text-align: center;
    }

    #queueView th {
        border: 1px solid black;
        padding: 5px;
    }

    #queueView td {
        padding: 0 10px;
        vertical-align: top;
    }
</style>
