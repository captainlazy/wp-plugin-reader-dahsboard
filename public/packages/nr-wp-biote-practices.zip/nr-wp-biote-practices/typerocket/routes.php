<?php
/*
|--------------------------------------------------------------------------
| TypeRocket Routes
|--------------------------------------------------------------------------
|
| Manage your web routes here.
|
*/

use Nativerank\BioTEPractices\ClinicLogGetter;
use Nativerank\BioTEPractices\Importers\ClinicImporter;
use Nativerank\BioTEPractices\Logger\Logger;
use Nativerank\BioTEPractices\Logger\MailLog;
use Nativerank\BioTEPractices\Updaters\PracticeUpdater;
use Nativerank\BioTEPractices\Updaters\PractitionerUpdater;
use TypeRocket\Http\Response;

tr_route()->get()->noTrailingSlash()->match( NR_BIOTE_PRACTICES_PARENT_SLUG . '/([^\/?]+)', [ 'slug', ] )->do( 'singleView@BiotePractice' );
tr_route()->get()->match( NR_BIOTE_PRACTICES_PARENT_SLUG . '/([^\/?]+)', [ 'slug', ] )->do( 'singleView@BiotePractice' );

tr_route()->post()->match( 'bioteImporter/saveLogs' )->do( function () {
	$result = ( new Logger() )->run();

	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->get()->match( 'bioteImporter/getClinicLog' )->do( function () {
	$result   = ( new ClinicLogGetter() )->run();
	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->get()->match( 'bioteImporter/getAll' )->do( function () {
	$result   = ( new ClinicLogGetter() )->getAllClinics();
	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/importPractices' )->do( function () {
	$result = ( new ClinicImporter() )->run();

	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/updatePractices' )->do( function () {
	$result = ( new PracticeUpdater() )->run();

	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/updatePractitioners' )->do( function () {
	$result   = ( new PractitionerUpdater() )->run();
	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/handleInactivePractices' )->do( function () {
	$result   = ( new PracticeUpdater() )->handleInactive();
	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/handleInactivePractitioners' )->do( function () {
	$result = ( new PractitionerUpdater() )->handleInactive();

	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/emailLog' )->do( function () {
	$result = ( new MailLog() )->run();

	$response = new Response();

	$response->setMessage( $result['message'] );
	$response->exitJson( $result['status'] );

	return;
} );

tr_route()->post()->match( 'bioteImporter/updateAlertStatus' )->do( "updateAlertStatus@Bioteadmin" );