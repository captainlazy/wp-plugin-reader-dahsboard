<?php

/*
 * Use this file to modify NRTemplate
 * with the hooks
 * nr_1055_template_helpers
 * nr_1055_template_data
 * nr_1055_template_partials
 * nr_1055_template_files_FILENAME
 *
 * Some of these hooks are already being used below
 * See other comments for built-in shortcuts to use them
 *
 */

// add helpers to NRTemplate, in the $newHelpers array
// as 'name' => function() {} pairs
$newHelpers = [
	// or register static functions from \Nativerank\BioTEPractices\Core\Util\Helper
	// by name (key only, no value), like this
	'strip_url'
];
$newHelpers = \Nativerank\BioTEPractices\Core\Util\Helper::getHelpers($newHelpers);


// You can add filters like this to modify data
// just set a key in $data with the name of your
// data variable
add_filter('nr_1055_template_data', function ($data) {
	// for example,
	// $data['galleryImages'] = SOME VALUE;
	return $data;
});

/*
 * STOP EDITING
 * These filters are set in place to allow you to add/overwrite
 * helpers, partials and templates in NRTemplate
 *
 * Helpers can be added up at the top of the file inside $newHelpers
 *
 * To add templates and/or partials,
 * Just place files in the /templates
 * and /templates/partials directories inside this plugin's root directory
 * Then you can use them for nr_page_type
 * or use the partials in your templates
 *
 * WARNING
 * If you name a template or partial the same as one in your theme, it will override it
 *
 * There is also a directory inside partials, named after the plugin, biote-practices/
 * Putting partials in there is an easy way to scope them to your plugin
 * and avoid name conflicts
 *
 * */

if (!empty(NR_BIOTE_PRACTICES_TEMPLATES_DIR)) {
	if (!file_exists(NR_BIOTE_PRACTICES_TEMPLATES_DIR)) {
		mkdir(NR_BIOTE_PRACTICES_TEMPLATES_DIR, 0775, true);
	}
	if ($handle = opendir(NR_BIOTE_PRACTICES_TEMPLATES_DIR)) {
		while (false !== ($entry = readdir($handle))) {
			$fileInfo = pathinfo($entry);
			if (array_key_exists('extension', $fileInfo) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs') {
				add_filter('nr_1055_template_files_' . $fileInfo['filename'], function ($path) use ($fileInfo) {
					$replacement = NR_BIOTE_PRACTICES_TEMPLATES_DIR . $fileInfo['filename'] . '.hbs';
					if (file_exists($replacement)) {
						return $replacement;
					}

					return $path;
				}, 20);
			}
		}
		closedir($handle);
	}
	if (!empty(NR_BIOTE_PRACTICES_PARTIALS_DIR)) {
		if (!file_exists(NR_BIOTE_PRACTICES_PARTIALS_DIR)) {
			mkdir(NR_BIOTE_PRACTICES_PARTIALS_DIR, 0775, true);
		}
		if (!file_exists(NR_BIOTE_PRACTICES_PARTIALS_DIR . "biote-practices/")) {
			mkdir(NR_BIOTE_PRACTICES_PARTIALS_DIR . "biote-practices/", 0775, true);
		}
		add_filter('nr_1055_template_partials', function ($dirs) {
			$sub_directories = array_filter(glob(NR_BIOTE_PRACTICES_PARTIALS_DIR . '*/'), 'is_dir');

			return array_merge($dirs, [NR_BIOTE_PRACTICES_PARTIALS_DIR], $sub_directories);
		}, 11);
		$footer = NR_BIOTE_PRACTICES_PARTIALS_DIR . "footer.hbs";
		if (file_exists($footer)) {
			add_filter('nr_1055_template_files_footer', function ($path) use ($footer) {
				return $footer;
			});
		}
	}
}