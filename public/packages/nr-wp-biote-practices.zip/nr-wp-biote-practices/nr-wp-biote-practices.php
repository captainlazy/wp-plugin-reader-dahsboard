<?php

/*
Plugin Name: NR BioTE Practices
Plugin URI: https://nativerank.com
Description: Creates, imports, and manages BioTE Practices and Practitioners.
Version: 1.6.7
Author: sahil
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

use function _\filter;
use function _\map;
use function _\remove;
use function _\sortBy;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_BIOTE_PRACTICES_VERSION', '1.6.7' );
define( 'NR_BIOTE_PRACTICES_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_BIOTE_PRACTICES_PHP_MINIMUM', '5.6.0' );
define( 'NR_BIOTE_PRACTICES_DIR_NAME', basename( __DIR__ ) );
define( 'NR_BIOTE_PRACTICES_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_BIOTE_PRACTICES_PLUGIN_URI', plugins_url( NR_BIOTE_PRACTICES_DIR_NAME ) );

define( 'NR_BIOTE_PRACTICES_TEMPLATES_DIR', NR_BIOTE_PRACTICES_PLUGIN_PATH . 'templates/' );
define( 'NR_BIOTE_PRACTICES_PARTIALS_DIR', NR_BIOTE_PRACTICES_TEMPLATES_DIR . 'partials/' );

define( 'NR_BIOTE_PRACTICES_OPTION_PREFIX', 'nr_1055_biote_' );
define( 'NR_BIOTE_PRACTICES_GRAPHQL_ENDPOINT', 'https://wapp-enterpriseapi.azurewebsites.net/graphql/' );
define( 'NR_BIOTE_PRACTICES_PARENT_SLUG', 'bioidentical-hormone-replacement-therapy-provider' );
define( 'NR_BIOTE_PRACTICES_CLINIC_IDS', 'practice_ids_to_import' );
define( 'NR_BIOTE_PRACTICES_INACTIVE_CLINICS', 'inactive_practices' );
define( 'NR_BIOTE_PRACTICES_IMPORTED_SUFFIX', 's_to_update' );
define( 'NR_BIOTE_PRACTICES_IMPORTED_CLINICS', 'practice' . NR_BIOTE_PRACTICES_IMPORTED_SUFFIX );
define( 'NR_BIOTE_PRACTICES_IMPORTED_PROFILES', 'practitioner' . NR_BIOTE_PRACTICES_IMPORTED_SUFFIX );
define( 'NR_BIOTE_PRACTICES_INACTIVE_PROFILES', 'inactive_practitioners' );
define( 'NR_BIOTE_PRACTICES_CRON_STATUS_OPTION', NR_BIOTE_PRACTICES_OPTION_PREFIX . 'pause_cron_jobs' );
define( 'NR_BIOTE_PRACTICES_ALERTS_OPTION', NR_BIOTE_PRACTICES_OPTION_PREFIX . 'send_alerts' );

if ( class_exists( '\Nativerank\BioTEPractices\Plugin' ) ) {
	die();
}

require 'vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_BIOTE_PRACTICES_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR BioTE Practices requires PHP version %s', 'nr-biote-practices' ), NR_BIOTE_PRACTICES_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-biote-practices' )
		);
	}

	//Create DB Tables
	( new \Nativerank\BioTEPractices\Database\Migrations() );

	do_action( 'nr_biote_practices_activation' );

} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_BIOTE_PRACTICES_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_biote_practices_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_biote_practices_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_BIOTE_PRACTICES_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_biote_practices_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_BIOTE_PRACTICES_PHP_MINIMUM, '>=' ) ) {
	\Nativerank\BioTEPractices\Plugin::load( NR_BIOTE_PRACTICES_PLUGIN_MAIN_FILE );
}

add_action( 'init', function () {
//	var_dump(get_option(NR_BIOTE_PRACTICES_OPTION_PREFIX . '301_redirects'));
	if ( file_exists( NR_BIOTE_PRACTICES_PLUGIN_PATH . 'nr-template-hooks.php' ) ) {
		include NR_BIOTE_PRACTICES_PLUGIN_PATH . 'nr-template-hooks.php';
	}
} );


//Providers REST API
function nr_bpi_return_API_data( $data ) {
	$latitude  = $data["lat"];
	$longitude = $data["lng"];
	$distance  = $data["dist"];

	$practices = ( new \App\Models\BioTEPractice() )
		->select( 'id', 'name', 'address', 'website', 'phone', 'lat', 'lng', 'slug', 'country_code' )
		->where( 'status', 1 )
		->get();

	if ( $practices ) {
		$practices = map( $practices, function ( $practice ) use ( $latitude, $longitude ) {
			$practice->distance = nr_1055_biote_locator_distance( $practice->lat, $practice->lng, $latitude, $longitude );
			if ( ! empty( $practice->phone ) and is_array( $practice->phone ) ) {
				$practice->phone = $practice->phone[ array_key_first( $practice->phone ) ]['number'];
			}

			return $practice;
		} );
		$practices = filter( $practices, function ( $practice ) use ( $distance ) {
			return $practice->distance < $distance;
		} );
		$practices = sortBy( $practices, 'distance' );

		return $practices;
	}

	return null;
}

//Providers REST API
function nr_bpi_API_all_practices( $data ) {
	$practices = ( new \App\Models\BioTEPractice() )
		->select( 'id', 'name', 'address', 'website', 'phone', 'lat', 'lng', 'slug', 'country_code' )
		->where( 'status', 1 )
		->where( 'name', '<>', '' )
		->orderBy( 'name' )
		->get();

	if ( $practices ) {
		$practices = map( $practices, function ( $practice ) {
			if ( ! empty( $practice->phone ) and is_array( $practice->phone ) ) {
				$practice->phone = $practice->phone[ array_key_first( $practice->phone ) ]['number'];
			}

			return $practice;
		} );

		return $practices;
	}

	return null;
}

//Providers REST API
function nr_bpi_API_searchPractices( $data ) {
	$q = $data["q"];

	$practices = ( new \App\Models\BioTEPractice() )
		->select( 'id', 'name', 'address', 'website', 'phone', 'lat', 'lng', 'slug', 'country_code' )
		->where( 'name', '<>', '' )
		->where( 'name', 'like', "%{$q}%" )
		->orderBy( 'name' )
		->get();

	if ( $practices ) {
		$practices = map( $practices, function ( $practice ) {
			if ( ! empty( $practice->phone ) and is_array( $practice->phone ) ) {
				$practice->phone = $practice->phone[ array_key_first( $practice->phone ) ]['number'];
			}

			return $practice;
		} );

		return $practices;
	}

	return null;
}

//Providers REST API By Company ID
function nr_bpi_API_searchPracticesByIDs( $data ) {
	$q = explode( '-', $data["q"] );

	$practices = ( new \App\Models\BioTEPractice() )
		->select( 'id', 'name', 'address', 'website', 'phone', 'lat', 'lng', 'slug', 'country_code' )
		->where( 'status', 1 )
		->where( 'id', 'in', $q )
		->where( 'name', '<>', '' )
		->get();

	if ( $practices ) {
		$practices = map( $practices, function ( $practice ) {
			if ( ! empty( $practice->phone ) and is_array( $practice->phone ) ) {
				$practice->phone = $practice->phone[ array_key_first( $practice->phone ) ]['number'];
			}

			return $practice;
		} );

		return $practices;
	}

	return null;
}

//Providers Ind REST API
function nr_bpi_API_searchPractitioners( $data ) {
	$practitioners = ( new \App\Models\BiotePractitioner() )->orderBy()->get();
	if ( $practitioners ) {
		$practitioners = map( $practitioners, function ( $practitioner ) {
			$practices               = $practitioner->practices()->where( 'status', 1 )->get();
			$practitioner->practices = implode( '-', map( $practices, 'id' ) );

			return $practitioner;
		} );
		remove( $practitioners, function ( $practitioner ) {
			return empty( $practitioner->practices );
		} );

		return $practitioners;
	}

	return null;
}

function nr_bpi_API_options_updated() {

	register_rest_route( 'nativerank/v1', '/providers/lat=(?P<lat>[a-z0-9 .\-]+)/lng=(?P<lng>[a-z0-9 .\-]+)/dist=(?P<dist>[0-9]+)', array(
		'methods'  => 'GET',
		'callback' => 'nr_bpi_return_API_data'
	) );

	register_rest_route( 'nativerank/v1', '/providers/all', array(
		'methods'  => 'GET',
		'callback' => 'nr_bpi_API_all_practices'
	) );
	register_rest_route( 'nativerank/v1', '/practitioners/all', array(
		'methods'  => 'GET',
		'callback' => 'nr_bpi_API_searchPractitioners'
	) );

	register_rest_route( 'nativerank/v1', '/providers/q=(?P<q>[a-z0-9 .\-]+)', array(
		'methods'  => 'GET',
		'callback' => 'nr_bpi_API_searchPractices'
	) );

	register_rest_route( 'nativerank/v1', '/providers/practice_ids/q=(?P<q>[a-z0-9 .\-]+)', array(
		'methods'  => 'GET',
		'callback' => 'nr_bpi_API_searchPracticesByIDs'
	) );
}

add_action( 'rest_api_init', 'nr_bpi_API_options_updated' );

function nr_1055_biote_locator_distance( $lat1, $lon1, $lat2, $lon2, $unit = "M" ) {
	if ( ( $lat1 == $lat2 ) && ( $lon1 == $lon2 ) ) {
		return 0;
	} else {
		$theta = $lon1 - $lon2;
		$dist  = sin( deg2rad( $lat1 ) ) * sin( deg2rad( $lat2 ) ) + cos( deg2rad( $lat1 ) ) * cos( deg2rad( $lat2 ) ) * cos( deg2rad( $theta ) );
		$dist  = acos( $dist );
		$dist  = rad2deg( $dist );
		$miles = $dist * 60 * 1.1515;
		$unit  = strtoupper( $unit );

		if ( $unit == "K" ) {
			return ( $miles * 1.609344 );
		} else if ( $unit == "N" ) {
			return ( $miles * 0.8684 );
		} else {
			return $miles;
		}
	}
}
