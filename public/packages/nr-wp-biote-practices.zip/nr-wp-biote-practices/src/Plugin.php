<?php


namespace Nativerank\BioTEPractices;


use Nativerank\BioTEPractices\Core\Custom_Resource;
use Nativerank\BioTEPractices\Core\Util\Scheduler;
use Nativerank\BioTEPractices\Resources\BioTEPractice;
use Nativerank\BioTEPractices\Resources\BioTEPractitioner;
use Puc_v4_Factory;
use TypeRocket\Register\PostType;
use TypeRocket\Register\Resourceful;
use TypeRocket\Register\Taxonomy;


/**
 * Class Plugin
 * @package Nativerank\BioTEPractices
 */
class Plugin
{

	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;

	/**
	 * Plugin Update Checker Object
	 *
	 * @var Puc_v4_Factory
	 */
	private $updateChecker;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 */
	public function __construct($main_file)
	{
		$this->context = new Context($main_file);

	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context()
	{
		return $this->context;
	}


	public function update_checker()
	{
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_BIOTE_PRACTICES_DIR_NAME,
			NR_BIOTE_PRACTICES_PLUGIN_MAIN_FILE,
			NR_BIOTE_PRACTICES_DIR_NAME
		);
	}


	/**
	 * Registers the plugin with WordPress.
	 */
	public function register()
	{

		// Register CTP & CTT
		$this->customPostTypes();

		// Register Custom Resources
		$this->resources();

		// Register any other classes
		$this->classes();

		// add admin pages
		$this->pages();

		do_action('nr_biote_practices_init');
	}

	/**
	 * Register Custom Post Types and Taxonomies
	 * @return PostType[]|Taxonomy[]
	 */
	public function customPostTypes()
	{
		return [
//            Custom_Post_Type::make('Example')
		];
	}

	/**
	 * @return Resourceful[]
	 */
	public function resources()
	{
		return [
			(new BioTEPractitioner()),
			(new BioTEPractice())
		];
	}

	/**
	 * @return array
	 */
	public function classes()
	{
		return [
			(new Scheduler()),
		];
	}

	public function pages()
	{
		$adminPage = tr_page('Bioteadmin', 'index', 'BioTE Importer', ['position' => 4]);
		$adminPage->useController();
	}


	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR BioTE Practices instance.
	 */
	public static function instance()
	{
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load($main_file)
	{
		if (null !== static::$instance) {
			return false;
		}

		static::$instance = new static($main_file);

		// register plugin after typerocket is loaded
		add_action('typerocket_loaded', [static::$instance, 'register']);
		add_action('plugins_loaded', [static::$instance, 'update_checker']);
		return true;
	}

}
