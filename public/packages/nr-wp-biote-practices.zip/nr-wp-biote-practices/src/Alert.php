<?php


namespace Nativerank\BioTEPractices;


class Alert {

	protected $to = [ 'websupport@nativerank.com' ];
	protected $priority = 2;

	public function __construct() {

	}

	/**
	 * @param string[] $to
	 *
	 * @return $this
	 */
	public function to( array $to ) {
		$this->to = $to;

		return $this;
	}

	public function send( $message ) {
		$alerts_on = get_option( NR_BIOTE_PRACTICES_ALERTS_OPTION );
		if ( $alerts_on ) {
			date_default_timezone_set( 'America/Denver' );
			$date      = date( 'm/d/Y', time() );
			$headers   = array();
			$headers[] = 'From: Nativerank Bot for BioTE <me@example.net>';
			$headers[] = 'Reply-To: Sahil Khanna <sahil.khanna@nativerank.com>';
			$headers[] = 'Content-Type: text/html; charset=UTF-8';

			$subject = 'BioTE Importer Alert - ';
			$subject .= $this->priority > 1 ? $this->getPriority() : $date;
			$subject .= $this->priority > 1 ? $date : '';

			$sent = wp_mail( $this->to, $subject, $message, $headers );

			return ( $sent ? ' Alert sent ' : ' Alert failed to send! ' );
		}

		return 'Alerts disabled!';
	}

	public function priority( $priority = 2 ) {
		$this->priority = $priority;

		return $this;
	}

	public function getPriority() {
		switch ( $this->priority ) {
			case 2:
				return 'MEDIUM PRIORITY ';
				break;
			case 3:
				return 'HIGH PRIORITY ';
				break;
			default:
				return 'LOW PRIORITY ';
				break;
		}
	}
}
