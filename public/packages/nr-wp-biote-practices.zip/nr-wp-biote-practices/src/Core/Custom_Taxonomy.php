<?php

namespace Nativerank\BioTEPractices\Core;


use Nativerank\BioTEPractices\Core\Util\CTT;

/**
 * Class Custom_Taxonomy
 */
class Custom_Taxonomy extends CTT
{


}
