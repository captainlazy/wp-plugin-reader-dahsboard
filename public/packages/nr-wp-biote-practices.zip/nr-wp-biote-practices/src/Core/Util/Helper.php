<?php


namespace Nativerank\BioTEPractices\Core\Util;


use App\Models\BioTEPractice;
use Closure;
use libphonenumber\NumberParseException;
use libphonenumber\PhoneNumberFormat;
use libphonenumber\PhoneNumberUtil;
use function _\find;
use function _\remove;
use function _\takeRight;
use function _\union;
use function _\unionBy;

class Helper {

	private static $us_state_abbrevs_names = array(
		'AL' => 'ALABAMA',
		'AK' => 'ALASKA',
		'AS' => 'AMERICAN SAMOA',
		'AZ' => 'ARIZONA',
		'AR' => 'ARKANSAS',
		'CA' => 'CALIFORNIA',
		'CO' => 'COLORADO',
		'CT' => 'CONNECTICUT',
		'DE' => 'DELAWARE',
		'DC' => 'DISTRICT OF COLUMBIA',
		'FM' => 'FEDERATED STATES OF MICRONESIA',
		'FL' => 'FLORIDA',
		'GA' => 'GEORGIA',
		'GU' => 'GUAM GU',
		'HI' => 'HAWAII',
		'ID' => 'IDAHO',
		'IL' => 'ILLINOIS',
		'IN' => 'INDIANA',
		'IA' => 'IOWA',
		'KS' => 'KANSAS',
		'KY' => 'KENTUCKY',
		'LA' => 'LOUISIANA',
		'ME' => 'MAINE',
		'MH' => 'MARSHALL ISLANDS',
		'MD' => 'MARYLAND',
		'MA' => 'MASSACHUSETTS',
		'MI' => 'MICHIGAN',
		'MN' => 'MINNESOTA',
		'MS' => 'MISSISSIPPI',
		'MO' => 'MISSOURI',
		'MT' => 'MONTANA',
		'NE' => 'NEBRASKA',
		'NV' => 'NEVADA',
		'NH' => 'NEW HAMPSHIRE',
		'NJ' => 'NEW JERSEY',
		'NM' => 'NEW MEXICO',
		'NY' => 'NEW YORK',
		'NC' => 'NORTH CAROLINA',
		'ND' => 'NORTH DAKOTA',
		'MP' => 'NORTHERN MARIANA ISLANDS',
		'OH' => 'OHIO',
		'OK' => 'OKLAHOMA',
		'OR' => 'OREGON',
		'PW' => 'PALAU',
		'PA' => 'PENNSYLVANIA',
		'PR' => 'PUERTO RICO',
		'RI' => 'RHODE ISLAND',
		'SC' => 'SOUTH CAROLINA',
		'SD' => 'SOUTH DAKOTA',
		'TN' => 'TENNESSEE',
		'TX' => 'TEXAS',
		'UT' => 'UTAH',
		'VT' => 'VERMONT',
		'VI' => 'VIRGIN ISLANDS',
		'VA' => 'VIRGINIA',
		'WA' => 'WASHINGTON',
		'WV' => 'WEST VIRGINIA',
		'WI' => 'WISCONSIN',
		'WY' => 'WYOMING',
		'AE' => 'ARMED FORCES AFRICA \ CANADA \ EUROPE \ MIDDLE EAST',
		'AA' => 'ARMED FORCES AMERICA (EXCEPT CANADA)',
		'AP' => 'ARMED FORCES PACIFIC'
	);
	public static $locationDirectoryPrefix = 'biote-providers';
	private static $redirectOption = '301_redirects';

	static function strip_url( $url ) {
		if ( empty( $url ) ) {
			return '';
		}

		$url = parse_url( trim( strtolower( $url ) ) );
		if ( ! isset( $url['host'] ) ) {
			$url = $url['path'];
			$re  = '/^(?:www\.)?(.*?)($|\/)/mi';
			preg_match_all( $re, $url, $matches, PREG_SET_ORDER, 0 );
			$url = $matches[0][1];
		} else {
			$url = str_replace( 'www.', '', $url['host'] );
		}

		return $url;
	}


	/**
	 * Removes an item from the array and returns its value.
	 *
	 * @param array $arr The input array
	 * @param String $key The key pointing to the desired value
	 *
	 * @return String|array|object|null The value mapped to $key or null if none
	 */
	static function array_remove_key( array &$arr, $key ) {
		if ( array_key_exists( $key, $arr ) ) {
			$val = $arr[ $key ];
			unset( $arr[ $key ] );

			return $val;
		}

		return null;
	}

	static function build_phone_number( $phone, $country_code = null, $name = '' ) {
		$res = [ 'raw' => strval( $phone ) ];
		if ( $country_code === null ) {
			$country_code = "US";
		}
		try {
			$util                = ( PhoneNumberUtil::getInstance() );
			$phone               = $util->parse( $phone, $country_code );
			$res['country_code'] = $phone->getCountryCode();
			$res['national']     = $phone->getNationalNumber();
			if ( $util->isValidNumber( $phone ) ) {
				$res['link']      = $util->format( $phone, PhoneNumberFormat::RFC3966 );
				$res['formatted'] = $util->formatInOriginalFormat( $phone, $country_code );
			} else {
				$res['errors'][] = "[Bad Phone Number] {$res['raw']} | Provider: $name | CC: " . $phone->getCountryCode();
			}

		} catch ( NumberParseException $e ) {
			$res['errors'][] = "[Bad Phone Number] {$res['raw']} | Provider: $name | Exception: {$e->__toString()}";
		}

		return $res;
	}

	static function get_countries_by_name( $name = null ) {
		$countries           = countries();
		$formatted_countries = [];

		foreach ( $countries as $country ) {
			$formatted_countries[ $country['name'] ] = $country['iso_3166_1_alpha2'];
		}
		ksort( $formatted_countries );

		if ( $name ) {
			return $formatted_countries[ $name ];
		}

		return $formatted_countries;
	}

	static function get_country_calling_code_by_country_code( $code = "US" ) {
		$country = country( $code );

		return $country->getCallingCode();
	}

	/**
	 * @param $request
	 *
	 * @return mixed|string
	 */
	static function getSlug( $request ) {
		$request['slug'] = self::buildSlug( $request );

		return self::uniqueSlug( $request );
	}

	/**
	 * @param $request
	 *
	 * @return string
	 */
	static function buildSlug( $request ) {
		return sanitize_title( ( $request['name'] ?? '' ) . " " . ( $request['city'] ?? '' ) . " " . ( $request['state'] ?? '' ) . " " . ( $request['zip'] ?? '' ) );
	}

	/**
	 * @param $request
	 *
	 * @return mixed|string
	 */
	static function uniqueSlug( $request ) {
		$slug      = $request['slug'];
		$foundSlug = ( new BioTEPractice() )->where( 'slug', $slug )->where( 'status', 1 );

		if ( isset( $request['id'] ) ) {
			$foundSlug = $foundSlug->where( 'id', '!=', $request['id'] );
		}
		$foundSlug = $foundSlug->get();

		if ( $foundSlug ) {
			$suffix = 2;
			do {
				$newSlug   = "{$slug}-{$suffix}";
				$foundSlug = ( new BioTEPractice() )->where( 'slug', $newSlug )->where( 'status', 1 );
				if ( isset( $request['id'] ) ) {
					$foundSlug = $foundSlug->where( 'id', '!=', $request['id'] );
				}
				$foundSlug = $foundSlug->get();
				$suffix ++;
			} while ( $foundSlug );
			$slug = $newSlug;
		}

		return $slug;
	}

	static function addPracticeRedirect( $request, $endingSlug = '' ) {
		$redirects    = self::getPracticeRedirects();
		$foundSlug    = null;
		$startingSlug = $request->slug ?? $request['slug'];
		$updated      = [];

		if ( $redirects === false ) {
			$redirects = [];
		}

		$foundSlug = find( $redirects, function ( $redirect ) use ( $startingSlug, $endingSlug ) {
			return ( ( ( $redirect['start'] ?? '' ) === $startingSlug ) && ( empty( $endingSlug ) || ( ( $redirect['redirect'] ?? '' ) === $endingSlug ) ) );
		} );
		if ( ! empty( $endingSlug ) ) {
			$updated = remove( $redirects, function ( $redirect ) use ( $startingSlug, $endingSlug ) {
				return ( ( ( $redirect['start'] ?? '' ) === $startingSlug ) && ( ( $redirect['redirect'] ?? '' ) !== $endingSlug ) );
			} );
		}
		$updated = array_merge( $updated, remove( $redirects, function ( $redirect ) use ( $startingSlug ) {
			return ( ( $redirect['redirect'] ?? '' ) === $startingSlug );
		} ) );

		if ( $foundSlug === null || empty( $foundSlug['redirect'] ) ) {
			$address  = $request->address ?? $request['address'];
			$redirect = empty( $endingSlug ) ? sanitize_title( self::$us_state_abbrevs_names[ $address['state'] ] ?? '' ) : $endingSlug;
			if ( empty( $endingSlug ) && ! empty( $redirect ) ) {
				$redirect = trailingslashit( static::$locationDirectoryPrefix ) . $redirect;
				if ( isset( $address['city'] ) ) {
					$redirect .= "/" . sanitize_title( $address['city'] );
				}
			}
			foreach ( $updated as $index => $removedRedirect ) {
				$updated[ $index ]['redirect'] = $redirect;
			}
			array_merge( $redirects, $updated );

			$redirects[] = [ 'start' => $startingSlug, 'redirect' => $redirect ];
			update_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . self::$redirectOption, $redirects );
		}
	}

	static function removePracticeRedirect( $request ) {
		$redirects    = self::getPracticeRedirects();
		$startingSlug = $request->slug ?? $request['slug'];
		if ( is_array( $redirects ) ) {
			remove( $redirects, function ( $redirect ) use ( $startingSlug ) {
				return $redirect['start'] === $startingSlug;
			} );
		}

		update_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . self::$redirectOption, $redirects );
	}

	static function getPracticeRedirects() {
		return get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . self::$redirectOption, [] );
	}

	static function findPracticeRedirect( $slug ) {
		$redirects = self::getPracticeRedirects();
		if ( is_array( $redirects ) ) {
			return find( $redirects, function ( $redirect ) use ( $slug ) {
				return $redirect['start'] === $slug;
			} );
		}

		return null;
	}

	/**
	 * @param $option
	 * @param $values
	 */
	static function union_update_option( $option, $values ) {
		$option    = NR_BIOTE_PRACTICES_OPTION_PREFIX . $option;
		$old_value = get_option( $option );
		if ( is_array( $old_value ) && is_array( $values ) ) {
			$values = union( $old_value, $values );
		}
		update_option( $option, $values );
	}

	/**
	 * @param $option
	 * @param $values
	 * @param string $by
	 */
	static function union_by_update_option( $option, $values, $by = 'id' ) {
		$option    = NR_BIOTE_PRACTICES_OPTION_PREFIX . $option;
		$old_value = get_option( $option );
		if ( is_array( $old_value ) && is_array( $values ) ) {
			$values = unionBy( $old_value, $values, $by );
		}
		update_option( $option, $values );
	}

	/**
	 * @param $option
	 * @param $values
	 * @param $cross_values
	 */
	static function remove_update_option( $option, $values, $cross_values ) {
		$old_value = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . $option );

		if ( is_array( $old_value ) && is_array( $values ) && is_array( $cross_values ) ) {
			remove( $old_value, function ( $value ) use ( $cross_values ) {
				return in_array( $value, $cross_values );
			} );
			$values = union( $old_value, $values );
		}

		update_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . $option, $values );
	}

	static function log_json_string( $name, $string ) {
		$path     = NR_BIOTE_PRACTICES_PLUGIN_PATH . "logs/json/";
		$logTime  = ( new \DateTime() )->format( 'Y-m-d_H-i-s' );
		$filename = "{$name}_{$logTime}.json";

		if ( ! file_exists( $path ) ) {
			mkdir( $path, 775, true );
		}
		$files = scandir( $path );
		if ( $files !== false ) {
			$files = array_values( array_diff( $files, array( '.', '..' ) ) );

			if ( count( $files ) > 1000 ) {
				$files = takeRight( $files, ( count( $files ) - 1000 ) );
				foreach ( $files as $file ) {
					unlink( $path . $file );
				}
			}

			file_put_contents( $path . $filename, $string );
		}

	}

	/**
	 * @param $option
	 * @param $values
	 */
	static function merge_update_option( $option, $values ) {
		$option = NR_BIOTE_PRACTICES_OPTION_PREFIX . $option;

		$old_value = get_option( $option );
		if ( is_array( $old_value ) && is_array( $values ) ) {
			$values = array_merge( $old_value, $values );
		}
		update_option( $option, $values );
	}

	static function log_update_option( $option, $value ) {
		$option = NR_BIOTE_PRACTICES_OPTION_PREFIX . $option;

		$log = get_option( $option );
		if ( is_array( $log ) ) {
			array_unshift( $log, $value );
			if ( count( $log ) > 180 ) {
				$log = array_slice( $log, 0, 180 );
			}
		} else {
			$log = [ $value ];
		}
		update_option( $option, $log );
	}

	/**
	 * @param \Exception $e
	 *
	 * @return string
	 */
	static function get_error_message( \Exception $e ) {
		return implode( "\n", [ $e->getCode(), $e->getMessage(), $e->getTraceAsString() ] );
	}

	static function getHelpers( $helpers ) {
		$HelperClassMethods = get_class_methods( self::class );
		foreach ( $HelperClassMethods as $method ) {
			$key = array_search( $method, $helpers );
			if ( $key !== false ) {
				if ( function_exists( self::class . "::{$method}" ) ) {
					$helpers[ $method ] = Closure::fromCallable( self::class . "::{$method}" );
				}
				unset( $helpers[ $key ] );
			}
		}

		return $helpers;
	}

}
