<?php


namespace Nativerank\BioTEPractices\Core\Util;

use Nativerank\BioTEPractices\ClinicLogGetter;
use Nativerank\BioTEPractices\Importers\ClinicImporter;
use Nativerank\BioTEPractices\Logger\Logger;
use Nativerank\BioTEPractices\Logger\MailLog;
use Nativerank\BioTEPractices\Updaters\PracticeUpdater;
use Nativerank\BioTEPractices\Updaters\PractitionerUpdater;

class Scheduler {

	protected $interval = 1800;

	public function __construct() {
		add_filter( 'cron_schedules', [ $this, 'add_intervals' ] );
		$this->add_actions();
		$this->add_cron_events();
	}

	private function add_actions() {
		add_action( 'biote_all_clinics_cron_hook', [ $this, 'biote_all_clinics_getter_cron_callback' ] );
		add_action( 'biote_terminate_full_import_cron_hook', [ $this, 'biote_terminate_full_import_cron_callback' ] );
		add_action( 'biote_logger_cron_hook', [ $this, 'biote_logger_cron_callback' ] );
		add_action( 'biote_email_log_cron_hook', [ $this, 'biote_email_log_cron_callback' ] );

		add_action( 'biote_clinic_log_getter_cron_hook', [ $this, 'biote_clinic_log_getter_cron_callback' ] );
		add_action( 'biote_clinic_importer_cron_hook', [ $this, 'biote_clinic_importer_cron_callback' ] );
		add_action( 'biote_practice_updater_cron_hook', [ $this, 'biote_practice_updater_cron_callback' ] );
		add_action( 'biote_practitioner_updater_cron_hook', [ $this, 'biote_practitioner_updater_cron_callback' ] );
		add_action( 'biote_handle_inactive_practices_cron_hook', [
			$this,
			'biote_handle_inactive_practices_cron_callback'
		] );
		add_action( 'biote_handle_inactive_practitioners_cron_hook', [
			$this,
			'biote_handle_inactive_practitioners_cron_callback'
		] );
	}

	public function add_intervals( $schedules ) {
		$schedules['half_hour'] = array(
			'interval' => $this->interval,
			'display'  => esc_html__( 'Every half hour' ),
		);

		return $schedules;
	}

	private function add_cron_events() {
		if ( ! wp_next_scheduled( 'biote_logger_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 0, 0 )->getTimestamp(), 'daily', 'biote_logger_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_all_clinics_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 0, 30 )->getTimestamp(), 'daily', 'biote_all_clinics_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_terminate_full_import_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 30 )->getTimestamp(), 'daily', 'biote_terminate_full_import_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_clinic_log_getter_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 35 )->getTimestamp(), 'half_hour', 'biote_clinic_log_getter_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_clinic_importer_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 40 )->getTimestamp(), 'half_hour', 'biote_clinic_importer_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_practice_updater_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 45 )->getTimestamp(), 'half_hour', 'biote_practice_updater_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_practitioner_updater_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 50 )->getTimestamp(), 'half_hour', 'biote_practitioner_updater_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_handle_inactive_practices_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 53 )->getTimestamp(), 'half_hour', 'biote_handle_inactive_practices_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_handle_inactive_practitioners_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 6, 56 )->getTimestamp(), 'half_hour', 'biote_handle_inactive_practitioners_cron_hook' );
		}
		if ( ! wp_next_scheduled( 'biote_email_log_cron_hook' ) ) {
			wp_schedule_event( ( new \DateTime() )->setTime( 7, 30 )->getTimestamp(), 'weekly', 'biote_email_log_cron_hook' );
		}
	}

	public function biote_logger_cron_callback() {
		( new Logger() )->run();
	}

	public function biote_all_clinics_getter_cron_callback() {
		update_option( NR_BIOTE_PRACTICES_CRON_STATUS_OPTION, true );
		( new ClinicLogGetter() )->getAllClinics();
	}

	public function biote_terminate_full_import_cron_callback() {
		update_option( NR_BIOTE_PRACTICES_CRON_STATUS_OPTION, false );
		$option = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_CLINIC_IDS );
	}

	public function biote_clinic_log_getter_cron_callback() {
		if ( get_option( NR_BIOTE_PRACTICES_CRON_STATUS_OPTION ) === false ) {
			( new ClinicLogGetter() )->run();
		}
	}

	public function biote_clinic_importer_cron_callback() {
		( new ClinicImporter() )->run();
	}

	public function biote_practice_updater_cron_callback() {
		( new PracticeUpdater() )->run();
	}

	public function biote_practitioner_updater_cron_callback() {
		( new PractitionerUpdater() )->run();
	}

	public function biote_handle_inactive_practices_cron_callback() {
		( new PracticeUpdater() )->handleInactive();
	}

	public function biote_handle_inactive_practitioners_cron_callback() {
		( new PractitionerUpdater() )->handleInactive();
	}

	public function biote_email_log_cron_callback() {
		( new MailLog() )->run();
	}

}