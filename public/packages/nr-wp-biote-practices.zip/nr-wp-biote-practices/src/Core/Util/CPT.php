<?php


namespace Nativerank\BioTEPractices\Core\Util;


use TypeRocket\Register\PostType;

/**
 * Class CPT
 * @package Nativerank\BioTEPractices\Core
 */
abstract class CPT extends PostType {


	/**
	 *  Custom Post Type Name
	 *
	 * @var string
	 */
	protected $name;

	/**
	 *  Custom Post Type Unique ID
	 *
	 * @var string
	 */
	protected $id;


	/**
	 * Custom Post Type Object
	 *
	 * @var \TypeRocket\Register\PostType
	 */
	protected $post_type;


	/**
	 * CPT constructor.
	 * Create a new Custom Post Type
	 *
	 * @param $name string Name of Custom Post Type
	 * @param $settings array Custom Post Type $args
	 * https://developer.wordpress.org/reference/functions/register_post_type/#parameters
	 *
	 * @return \TypeRocket\Register\PostType
	 */
	public function __construct( $name, $settings = [] ) {
		$this->name      = $name;
		$this->post_type = tr_post_type( $name, null, $settings );

		return $this->post_type;
	}


	/**
	 * Create a new element.
	 *
	 * @return static
	 */
	public static function make( ...$arguments ) {
		return new static( ...$arguments );
	}


}
