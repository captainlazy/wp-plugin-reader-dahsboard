<?php


namespace Nativerank\BioTEPractices\Core\Util\template;

use LightnCandy\LightnCandy;

if ( isset( $_GET['debug'] ) ) {
	ini_set( 'display_errors', 1 );
	ini_set( 'display_startup_errors', 1 );
	error_reporting( E_ALL );
}


if ( ! class_exists( 'NRPracticeTemplate' ) ) {
	/**
	 * Class NRTemplate
	 */
	class NRPracticeTemplate {
		protected $templateName = 'practice-single';
		protected $pageDefaults;
		protected $structuredData;
		protected $globals;
		protected $customData;
		protected $practice;
		protected $basePath;
		protected $cachePath;
		protected $partialsPath;
		public $partials = [];
		public $availableForm = null;

		public function __construct( $practice ) {
			isset( $_GET['zip'] ) && ( $existing_zip = $_GET['zip'] );

			if ( ! empty( $existing_zip ) ) {
				echo "<script>var nr1055_existting_zip=$existing_zip;</script>";
			}
			$this->customData = json_decode( file_get_contents( get_stylesheet_directory() . '/data.json', true ), true );

			$this->practice = $practice;
			$this->renderFormScripts();
			$this->pageDefaults = (object) [];
			$this->globals      = (object) [];
			$this->basePath     = __DIR__ . '/templates/';
			$this->partialsPath = get_stylesheet_directory() . '/templates/partials/';
			$this->cachePath    = 'cache/views/';
			$this->getPageDefaults();
			$this->addEditPracticeLink();
		}

		public function render() {
			try {
				$renderer = $this->getTemplate();
				echo $renderer( $this->getData() );
			} catch ( Exception $e ) {
				echo 'Caught exception: ', $e->getMessage(), "\n";
			}
		}

		private function addEditPracticeLink() {
			add_action( 'admin_bar_menu', function ( $admin_bar ) {
				$admin_bar->add_menu( array(
						'id'    => 'edit-practice',
						'title' => 'Edit Practice',
						'href'  => tr_redirect()->toPage( 'biote_practice', 'edit', $this->practice->id )->url,
						'meta'  => array(
							'title' => __( 'Edit Practice' ),
						),
					)
				);
			}, 100 );
		}

		private function get_home_path() {
			$home    = set_url_scheme( get_option( 'home' ), 'http' );
			$siteurl = set_url_scheme( get_option( 'siteurl' ), 'http' );

			if ( ! empty( $home ) && 0 !== strcasecmp( $home, $siteurl ) ) {
				$wp_path_rel_to_home = str_ireplace( $home, '', $siteurl ); /* $siteurl - $home */
				$pos                 = strripos( str_replace( '\\', '/', $_SERVER['SCRIPT_FILENAME'] ), trailingslashit( $wp_path_rel_to_home ) );
				$home_path           = substr( $_SERVER['SCRIPT_FILENAME'], 0, $pos );
				$home_path           = trailingslashit( $home_path );
			} else {
				$home_path = ABSPATH;
			}

			return str_replace( '\\', '/', $home_path );
		}

		private function renderFormScripts() {
			if ( ! isset( $this->customData['forms'] ) ) {
				echo '<pre>Missing <code><em>\'forms\'</em></code> key in <b><i>data.json</i></b> file</pre>';

				return;
			}

			if ( empty( $this->customData['forms'] ) ) {
				echo "<pre><code><em>'forms'</em></code> key is empty in <b><i>data.json</i></b> file;<hr>Example:\n <code>\"forms\": [\n\t\t\t{\n\t\t\t\t\"page_id\": 677,\n\t\t\t\t\"form_id\": 1\n\t\t\t}\n\t\t],</code></pre>";

				return;
			}

			$form = array_filter( $this->customData['forms'], function ( $v ) {
				return isset( $v['page_id'] ) && $v['page_id'] == $this->practice->id;
			} );

			if ( ! empty( $form ) ) {
				$form_id             = array_values( $form )[ count( $form ) - 1 ]['form_id'];
				$this->availableForm = $form_id;
				gravity_form_enqueue_scripts( $form_id, true );
			}
		}

		private function getPageDefaults() {
			$this->pageDefaults->practitioners = $this->getPractitioners();
			$this->pageDefaults->h1            = $this->getH1();
//			$this->pageDefaults->neighbors     = $this->getNeighbors();
		}

		private function getPractitioners() {
			$practitioners = $this->practice->practitioners()->get();

			return $practitioners ? $practitioners->toArray() : [];
		}


		private function getH1() {
			$h1 = "Bioidentical Hormone Replacement Therapy in " . $this->practice->address['city'] . ', ' . $this->practice->address['state'] . ' ' . $this->practice->address['zip'];

			return $h1;
		}


		private function get_excerpt( $limit, $source = null ) {

			$excerpt = $source;
			$excerpt = preg_replace( " (\[.*?\])", '', $excerpt );
			$excerpt = strip_shortcodes( $excerpt );
			$excerpt = strip_tags( $excerpt );
			$excerpt = substr( $excerpt, 0, $limit );
			$excerpt = substr( $excerpt, 0, strripos( $excerpt, " " ) );
			$excerpt = trim( preg_replace( '/\s+/', ' ', $excerpt ) );
			$excerpt = $excerpt . '...';

			return $excerpt;
		}


		private function parsePages( $pages ) {

			foreach ( $pages as $page ) {
				$page->post_title   = trim( preg_replace( '~\x{00a0}~siu', ' ', $page->post_title ) );
				$page->image_id     = get_post_thumbnail_id( $page->ID );
				$page->post_excerpt = $this->get_excerpt( 120, $page->post_content );
				$page->permalink    = get_permalink( $page->ID );
			}
			wp_reset_query();

			return json_decode( json_encode( $pages ), true );
		}


		public function getPartials() {
			$dirs = array_filter( glob( $this->partialsPath . '*/' ), 'is_dir' );
			$dirs = array_merge( [ $this->partialsPath ], apply_filters( 'nr_1055_template_partials', $dirs, $this->practice ) );
			foreach ( $dirs as $dir ) {
				$this->collectPartials( $dir );
			}

			return $this->partials;
		}


		private function collectPartials( $path = '' ) {

			if ( empty( $path ) ) {
				$path = $this->partialsPath;
			}

			if ( ! file_exists( $path ) ) {
				mkdir( $path, 0775, true );
			}

			if ( $handle = opendir( $path ) ) {


				while ( false !== ( $entry = readdir( $handle ) ) ) {

					$fileInfo = pathinfo( $entry );
					if ( array_key_exists( 'extension', $fileInfo ) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs' ) {
						if ( strpos( $path, $this->partialsPath ) > - 1 ) {
							$sub = rtrim( str_replace( $this->partialsPath, '', $path ), '/' );
						} else {
							$sub = rtrim( preg_replace( '/.*\/partials\/(.*)/', '$1', $path ), '/' );
						}

						$fileName                    = empty( $sub ) ? $fileInfo['filename'] : $sub . '.' . $fileInfo['filename'];
						$this->partials[ $fileName ] = file_get_contents( $path . $entry );
					}
				}

				closedir( $handle );
			}

			return $this->partials;
		}

		private function getTemplate() {

			if ( ! file_exists( $this->cachePath ) ) {
				mkdir( $this->cachePath, 0775, true );
			}

			$templateName = $this->templateName;

			$cachedView   = $this->cachePath . $templateName . '.php';
			$templateFile = $this->basePath . $templateName . '.hbs';
			$templateFile = apply_filters( 'nr_1055_template_files_' . $templateName, $templateFile, $this->practice );

			$cacheOk = file_exists( $cachedView ) && filemtime( $cachedView ) >= filemtime( $templateFile );

			if ( is_user_logged_in() ) {
				$cacheOk = false;
			}

			if ( ! $cacheOk ) {
				if ( ! file_exists( $templateFile ) ) {
					throw new Exception( "Unable to load $templateName from $templateFile" );
				}
				$templateStr = file_get_contents( $templateFile );

				$phpStr = LightnCandy::compile( $templateStr, $this->getCompileOptions() );

				$phpStr = '<?php ' . $phpStr . '?>';

				file_put_contents( $cachedView, $phpStr );
			}
			$renderFunction = include $cachedView;

			return $renderFunction;
		}


		protected function getCompileOptions() {
			return array(
				'flags' => LightnCandy::FLAG_NAMEDARG |
				           LightnCandy::FLAG_NOESCAPE |
				           LightnCandy::FLAG_STANDALONEPHP |
				           LightnCandy::FLAG_ADVARNAME |
				           LightnCandy::FLAG_SPVARS |
				           LightnCandy::FLAG_PARENT |
				           LightnCandy::FLAG_ELSE |
				           LightnCandy::FLAG_RUNTIMEPARTIAL,

				'basedir'  => array(
					$this->basePath,
					$this->basePath . 'partials'
				),
				'partials' => $this->getPartials(),
				'fileext'  => array(
					'.hbs',
				),
				'helpers'  => $this->getHelpers()
			);
		}

		private function contains_in( $instance, $entries ) {
			foreach ( $entries as $entry ) {
				if ( strpos( $instance, $entry ) > - 1 ) {
					return true;
				}
			}

			return false;
		}

		private function starts_with( $instance, $entries ) {
			foreach ( $entries as $entry ) {
				if ( strpos( $instance, $entry ) == 0 ) {
					return true;
				}
			}

			return false;
		}

		private function ends_with( $instance, $entries ) {
			foreach ( $entries as $entry ) {
				if ( substr_compare( $instance, $entry, - strlen( $entry ) ) === 0 ) {
					return true;
				}
			}

			return false;
		}


		protected function getHelpers() {
			return array(
				"shortcode"          => function ( $arg ) {
					return do_shortcode( $arg );
				},
				"imageSrc"           => function ( $options ) {
					return $this->imgSrcHelper( $options );
				},
				'alias'              => function ( $context, $options ) {
					if ( ! isset( $this->customData['alias'] ) ) {
						echo '<pre>Missing <code><em>\'alias\'</em></code> key in <b><i>data.json</i></b> file</pre>';
					}

					$key   = $options['hash']['key'];
					$value = $options['hash']['return'];

					foreach ( $this->customData['alias'] as $alias ) {
						if ( $alias[ $key ] == html_entity_decode( $context ) ) {
							return $alias[ $value ];
						}
					}

					return null;
				},
				"relatedPages"       => function ( $context, $options ) {
					if ( ! $this->practice->post_parent ) {
						return $options['inverse']();
					}
					$pages = $this->parsePages( get_pages( array(
						'child_of'    => wp_get_post_parent_id( get_the_ID() ),
						'exclude'     => get_the_ID(),
						'post_type'   => 'page',
						'sort_column' => 'menu_order',
						'post_status' => 'publish'
					) ) );

					$res = '';
					foreach ( $pages as $cx ) {
						$res .= $options['fn']( $cx );
					}

					return $res;

				},
				"explode"            => function ( $context, $options ) {

					$res = '';

					$delimiter = $options['hash']['delimiter'];
					$string    = $context;

					$items = explode( $delimiter, $string );

					foreach ( $items as $item ) {
						$res .= $options['fn']( $item );
					}

					if ( empty( $res ) ) {
						return $options['inverse']();
					}

					return $res;


				},
				"filterPages"        => function ( $context, $options ) {
					$res      = '';
					$key      = $options['hash']['key'];
					$operator = $options['hash']['operator'];
					$value    = $options['hash']['value'];


					switch ( $operator ) {
						case 'contains':
							foreach ( $context as $page ) {

								if ( $this->contains_in( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'does_not_contain':
							foreach ( $context as $page ) {
								if ( ! $this->contains_in( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'exactly_matches';
							foreach ( $context as $page ) {
								if ( in_array( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'does_not_exactly_match';
							foreach ( $context as $page ) {
								if ( ! in_array( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'starts_with';
							foreach ( $context as $page ) {
								if ( $this->starts_with( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'does_not_start_with';
							foreach ( $context as $page ) {
								if ( ! $this->starts_with( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'ends_with';
							foreach ( $context as $page ) {
								if ( $this->ends_with( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
						case 'does_not_end_with';
							foreach ( $context as $page ) {
								if ( ! $this->ends_with( html_entity_decode( $page[ $key ] ), explode( ';', $value ) ) ) {
									$res .= $options['fn']( $page );
								}
							}
							break;
					}

					if ( empty( $res ) ) {
						return $options['inverse']();
					}

					return $res;
				},
				'count'              => function ( $options ) {
					if ( is_array( $options ) ) {
						return count( $options );
					}

					return false;

				},
				"image"              => function ( $options ) {
					return $this->imageHelper( $options );
				},
				"headerImage"        => function ( $options ) {
					$html                  = '';
					$settings              = $options['hash'];
					$options['hash']['id'] = $this->pageDefaults->headerImage;
					$rSettings             = get_field( 'responsive_images' );

					if ( is_array( $rSettings ) && ! empty( $rSettings ) ) {
						$alias = [
							'small'   => 's',
							'medium'  => 'm',
							'large'   => 'l',
							'x_large' => 'xl'
						];

						foreach ( $rSettings as $size => $imageID ) {
							if ( ! isset( $alias[ $size ] ) ) {
								continue;
							}
							if ( empty( $imageID ) ) {
								continue;
							}
							$cSettings                  = $options;
							$cSettings['hash']['id']    = $rSettings[ $size ];
							$cSettings['hash']['class'] = ( $cSettings['hash']['class'] ?? '' ) . ' uk-hidden@' . $alias[ $size ];
							$options['hash']['class']   = ( $options['hash']['class'] ?? '' ) . ' uk-visible@' . $alias[ $size ];
							$html                       .= $this->imageHelper( $cSettings );
						}
					}
					$html .= $this->imageHelper( $options );

					return $html;
				},
				"link"               => function ( $options ) {
					if ( ! empty( $options['hash']['href'] ) ) {
						return get_site_url() . $options['hash']['href'];
					}

					return get_site_url();
				},
				"getImageFromPageId" => function ( $options ) {
					$options['hash']['id'] = get_post_thumbnail_id( $options['hash']['id'] );
					$size                  = 'medium_large';
					$atts                  = array();
					if ( isset( $options['hash']['size'] ) ) {
						$size = $options['hash']['size'];
					}

					if ( isset( $options['hash']['uk-cover'] ) ) {
						$atts = array( 'uk-cover' => null );
					}

					return $this->nr_get_image_html( $options['hash']['id'], $size, $atts );
				},
				"getPermalink"       => function ( $option ) {
					if ( ! empty( $option ) ) {
						return get_permalink( $option );
					}

					return '';
				},
				"formatPhone"        => function ( $option ) {

					if ( ! empty( $option ) ) {
						$data = $option;
						if ( strlen( $data ) < 10 ) {
							return $data;
						}

						return '(' . substr( $data, 0, 3 ) . ') ' . substr( $data, 3, 3 ) . '-' . substr( $data, 6 );
					}

					return '';
				},
				"providerImage"      => function ( $options ) {
					$photo_id = $options['hash']['id'];
					$url      = $options['hash']['url'];

					if ( is_int( $photo_id ) ) {
						$attachment = wp_get_attachment_image_src( $photo_id, 'small' );
						if ( $attachment ) {
							return $attachment[0];
						}
					}

					$img_dir = $this->get_home_path() . "nr/practitioners/$photo_id.jpg";

					if ( file_exists( $img_dir ) ) {
						return get_site_url() . "/nr/practitioners/$photo_id.jpg";
					} else {
						$saved = save_practitioner_image( $url, $img_dir );
					}
					if ( $saved ) {
						return get_site_url() . "/nr/practitioners/$photo_id.jpg";
					}

					return get_site_url() . "/nr/assets/practitioner.svg";
				},
				"getForm"            => function ( $option ) {

					if ( $this->availableForm ) {
						return gravity_form( $this->availableForm, false, false, false, '', true, 1, false );
					}

					return "Not A Contact Form Page.";

				},
				"sanitize"           => function ( $option ) {
					return sanitize_title( $option );
				},
				"is_array"           => function () {
					$args = func_get_args();

					$context = $args[ count( $args ) - 1 ];
					if ( is_array( $args[0] ) ) {
						return $context['fn']();
					}

					return $context['inverse'] ? $context['inverse']() : '';

				},
				"_if"                => function () {
					$args = func_get_args();

					$instance = $args[0];
					is_array( $instance ) && $instance = count( $instance );

					$count = $args[2];

					$context = $args[ count( $args ) - 1 ];
					switch ( $args[1] ) {
						case '<':
							if ( $instance < $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case '>':
							if ( $instance > $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case '<=':
							if ( $instance <= $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case '>=':
							if ( $instance >= $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case '!=':
							if ( $instance != $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case '==':
							if ( $instance == $count ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case 'contains':
							if ( strpos( $instance, $count ) > - 1 ) {
								return $context['fn']();
							} else {
								return $context['inverse'] ? $context['inverse']() : '';
							}
							break;
						case 'contains_in':
							$entries = explode( ';', $count );
							if ( is_array( $entries ) ) {
								if ( $this->contains_in( $instance, $entries ) ) {
									return $context['fn']();
								}

								return $context['inverse'] ? $context['inverse']() : '';

							} else {
								echo '<pre>ERROR: Expected value is  {{#_if post_title \'contains_in\' \'Residential;Commercial\'}}</pre>';
							}
							break;
						case '!contains_in':
							$entries = explode( ';', $count );
							if ( is_array( $entries ) ) {
								if ( ! $this->contains_in( $instance, $entries ) ) {
									return $context['fn']();
								}

								return $context['inverse'] ? $context['inverse']() : '';

							} else {
								echo '<pre>ERROR: Expected value is  {{#_if post_title \'contains_in\' \'Residential;Commercial\'}}</pre>';
							}
							break;
					}
				}
			);
		}

		private function imageHelper( $options ) {

			$ukImg = isset( $options['hash']['uk-img'] ) ? $options['hash']['uk-img'] : false;

			$size = 'medium_large';
			$atts = array();
			if ( isset( $options['hash']['size'] ) ) {
				$size = $options['hash']['size'];
			}

			if ( isset( $options['hash']['uk-cover'] ) ) {
				$atts = array( 'uk-cover' => null );
			}

			if ( isset( $options['hash']['class'] ) ) {
				$atts = array_merge( $atts, array( 'class' => $options['hash']['class'] ) );
			}

			return $this->nr_get_image_html( $options['hash']['id'], $size, $atts, $ukImg );
		}


		private function imgSrcHelper( $options ) {
			$size = 'medium_large';
			if ( isset( $options['hash']['size'] ) ) {
				$size = $options['hash']['size'];
			}
			if ( ! empty( wp_get_attachment_image_src( $options['hash']['id'], $size )[0] ) ) {
				return str_replace( parse_url( get_site_url(), PHP_URL_SCHEME ) . '://' . parse_url( get_site_url(), PHP_URL_HOST ), '', wp_get_attachment_image_src( $options['hash']['id'], $size )[0] );
			}

			return "not-found";
		}

		private function nr_get_image_html( $id, $size = 'medium_large', $attrs = array() ) {

			$ukImg = null;
			if ( isset( $attrs['uk-img'] ) ) {
				$ukImg = $attrs['uk-img'];
			}
			if ( isset( $attrs['class'] ) ) {
				$class = $attrs['class'] . ' uk-img';
			} else {
				$class = 'uk-img';
			}
			$alt = wp_get_attachment_caption( $id );
			if ( ! $alt ) {
				$alt = get_the_title( $id );
				if ( strpos( $alt, 'Adobe' ) > - 1 ) {
					$alt = '';
				}

				if ( strpos( $alt, 'stock' ) > - 1 ) {
					$alt = '';
				}

			}
			$attrs = array_merge( $attrs, array( 'class' => $class, 'uk-img' => $ukImg, 'alt' => $alt ) );
			$html  = wp_get_attachment_image( $id, $size, false, $attrs );
			if ( empty( $html ) ) {
				$ukCover = key_exists( 'uk-cover', $attrs ) ? 'uk-cover' : '';

				return '<img data-src="' . get_site_url() . $this->customData['placeholder'] . '" alt="Placeholder" ' . $ukCover . ' uk-img/>';
			}
			$html = str_replace( parse_url( get_site_url(), PHP_URL_SCHEME ) . '://' . parse_url( get_site_url(), PHP_URL_HOST ), '', $html );

			if ( array_key_exists( 'uk-img', $attrs ) ) {
				$html = preg_replace( '/[\w-]*src\b/', 'data-src', $html );
				$html = preg_replace( '/[\w-]*sizes\b/', 'data-sizes', $html );
				$html = preg_replace( '/[\w-]*srcset\b/', 'data-srcset', $html );
			}

			return $html;
		}

		private function convertToArray( $var ) {
			return json_decode( json_encode( $var ), true );
		}


		private function getData() {
			return array(
				'h1'                    => $this->pageDefaults->h1,
				'label'                 => $this->practice->name,
				'data'                  => $this->customData,
				'city'                  => $this->practice->address['city'],
				'state'                 => $this->practice->address['state'],
				'zip'                   => $this->practice->address['zip'],
				'street_address'        => $this->practice->address['street_address'],
				'permalink'             => get_site_url( null, NR_BIOTE_PRACTICES_PARENT_SLUG . "/" . $this->practice->slug . "/" ),
				'geolocation_latitude'  => $this->practice->lat,
				'geolocation_longitude' => $this->practice->lng,
				'program'               => $this->practice->marketing_program,
				'phone_numbers'         => ( is_array( $this->practice->phone ) ? array_values( $this->practice->phone ) : null ),
				'country_code'          => $this->practice->country_code,
				'website'               => $this->practice->website,
				'practitioners'         => $this->pageDefaults->practitioners
			);
		}

	}
}
