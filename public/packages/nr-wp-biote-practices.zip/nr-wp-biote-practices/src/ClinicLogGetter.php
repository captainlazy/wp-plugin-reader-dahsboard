<?php


namespace Nativerank\BioTEPractices;


use Exception;
use GuzzleHttp\Client;
use Nativerank\BioTEPractices\Core\Util\Helper;
use TypeRocket\Core\Config;
use function _\map;
use function _\partition;
use function _\uniqBy;

class ClinicLogGetter {
	protected $client;
	protected $startDate;
	protected $log;
	protected $body;
	protected $logOption = 'by_date_log';
	protected $result;
	protected $response;
	protected $numberOfMinutes = 35;
	protected $openBody = "{'query':'{\\n  ";
	protected $closeBody = "}\\n'}";
	protected $lastRanOption = NR_BIOTE_PRACTICES_OPTION_PREFIX . 'last_log_fetched_time';
	protected $interval;
	protected $fiveMinuteInterval = "PT5M";

	public function __construct() {
		$this->client = new Client();
	}

	public function getAllClinics() {
		$logBody         = $this->openBody;
		$logBody         .= "clinics {\\n    id\\n    active\\n  }\\n  ";
		$this->body      = $logBody . $this->closeBody;
		$this->logOption = 'all_clinics_log';
		$this->handle();
		$this->response['message'] = empty( $this->log ) ? $this->response['message'] : 'Fetched all clinics';

		return $this->response;
	}

	/**
	 * @param int $days
	 */
	public function changeIntervalToDays( $days = 1 ) {
		$this->startDate = ( new \DateTime() )->sub( new \DateInterval( "P{$days}D" ) )->format( 'Y/m/d' );
	}

	public function handle() {
		$this->sendRequest();
		$this->setLog();
		if ( empty( $this->log ) ) {
			if ( empty( $this->response['message'] ) ) {
				$this->response["message"] = 'No updated practices found';
			}
			$this->logEmpty();

			return $this->response;
		}
		Helper::log_json_string( $this->logOption, json_encode( array_merge( [ $this->startDate ], $this->log ) ) );

		$this->filterIdsByStatusAndSave();

		return $this->response;
	}

	public function run() {
		$this->setStartDate();
		$this->setBody();

		return $this->handle();
	}

	private function setStartDate() {
		$lastRan                        = ( new \DateTime() )->setTimestamp( get_option( $this->lastRanOption ) );
		$now                            = new \DateTime();
		$thirty_five_minutes_in_seconds = 2100;
		$this->interval                 = ( ( $now->getTimestamp() - $lastRan->getTimestamp() ) > $thirty_five_minutes_in_seconds ) ? date_diff( $now, $lastRan, true ) : new \DateInterval( "PT{$this->numberOfMinutes}M" );
		$this->startDate                = ( $now )->sub( $this->interval )->format( 'Y/m/d H:i:s' );
	}

	public function getLastRanOption() {
		return $this->lastRanOption;
	}

	public function getLogOption() {
		return $this->logOption;
	}

	private function setBody() {
		$logBody    = $this->openBody;
		$logBody    .= "clinicLog:  getByClinicLogByDate(startDate: \\\"{$this->startDate}\\\") {\\n    id\\n    active\\n  }\\n  ";
		$this->body = $logBody . $this->closeBody;
	}

	/**
	 *
	 */
	private function sendRequest() {
		try {
			$result         = $this->client->post( NR_BIOTE_PRACTICES_GRAPHQL_ENDPOINT, [
				'connect_timeout' => 10,
				'timeout'         => 30,
				'headers'         => [
					'Ocp-Apim-Subscription-Key' => Config::locate( 'app.api_keys.biote_graphql' ),
					'Content-Type'              => 'application/json'
				],
				'body'            => $this->body
			] );
			$this->result   = json_decode( $result->getBody(), true );
			$this->response = [
				'status'  => $result->getStatusCode(),
				'message' => 'Fetched log of updated practices'
			];
		} catch ( Exception $e ) {
			$message = "Clinic log fetch failed: " . Helper::get_error_message( $e );

			$alert = new Alert();
			$alert->priority( 3 );
			$message .= $alert->send( $message );

			$this->response = [ 'status' => $e->getCode(), 'message' => $message ];
		}

	}

	public function filterIdsByStatusAndSave() {
		$total_rows      = count( $this->log );
		$clinicsByStatus = partition( $this->log, function ( $clinic ) {
			return ( isset( $clinic["active"] ) && $clinic["active"] );
		} );
		$clinics         = map( $clinicsByStatus[0], 'id' );
		$inactiveClinics = map( $clinicsByStatus[1], 'id' );

		$log     = [
			'timestamp'  => ( new \DateTime() )->format( 'm/d/Y H:i:s' ),
			'start_date' => $this->startDate,
			'message'    => implode( " ", $this->response ),
			'total_rows' => $total_rows
		];
		$options = [
			NR_BIOTE_PRACTICES_CLINIC_IDS => $clinics,
		];

		foreach ( $options as $option => $value ) {
			$log[ $option ] = count( $value );
			Helper::union_update_option( $option, $value );
		}

		$option         = NR_BIOTE_PRACTICES_INACTIVE_CLINICS;
		$log[ $option ] = count( $inactiveClinics );

		Helper::remove_update_option( $option, $inactiveClinics, $clinics );
		Helper::log_update_option( $this->logOption, $log );
		update_option( $this->lastRanOption, ( new \DateTime() )->sub( new \DateInterval( $this->fiveMinuteInterval ) )->getTimestamp() );
	}

	/**
	 *
	 */
	private function setLog() {
		$this->log = empty( $this->result ) ? false : uniqBy( ( $this->result["data"]["clinicLog"] ?? $this->result["data"]["clinics"] ), 'id' );
	}

	/**
	 *
	 */
	private function logEmpty() {
		$log = [
			'timestamp'  => ( new \DateTime() )->format( 'm/d/Y H:i:s' ),
			'startDate'  => $this->startDate,
			'message'    => implode( " ", $this->response ),
			'total_rows' => 0
		];
		Helper::log_update_option( $this->logOption, $log );
	}

}
