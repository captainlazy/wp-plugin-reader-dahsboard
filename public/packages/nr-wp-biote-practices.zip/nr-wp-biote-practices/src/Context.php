<?php


namespace Nativerank\BioTEPractices;


/**
 * Class Context
 * @package Nativerank\BioTEPractices
 */
class Context {

}
