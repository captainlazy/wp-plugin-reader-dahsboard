<?php


namespace Nativerank\BioTEPractices\Updaters;

use Nativerank\BioTEPractices\Core\Util\Helper;
use function _\remove;

class Updater {

	protected $logOption;
	protected $resource;
	protected $resources;
	protected $resourceList;
	protected $resourceCount = 0;
	protected $response;
	protected $keySwitches = [];
	protected $new = [];
	protected $deactivated = [];
	protected $updated = [];
	protected $errors = [];
	protected $idField = 'id';

	public function __construct() {
		$this->response["status"] = 200;
		$this->logOption          = "{$this->resource}_updater_log";
	}

	public function run() {
		$option              = NR_BIOTE_PRACTICES_OPTION_PREFIX . $this->resource . NR_BIOTE_PRACTICES_IMPORTED_SUFFIX;
		$this->resourceList  = $this->resources = get_option( $option );
		$this->resourceCount = count( $this->resources );
		if ( empty( $this->resources ) ) {
			$this->response["message"] = "No {$this->resource}s to update";
			$this->logEmpty();

			return $this->response;
		}

		$this->resourceLoop();

		update_option( $option, $this->resourceList );

		$this->response['message'] = "Updated {$this->resource}s in the database";

		$this->log();

		return $this->response;
	}

	protected function log() {
		array_unshift( $this->new, 'TOTAL: ' . count( $this->new ) );
		foreach ( $this->deactivated as $resource => $value ) {
			array_unshift( $this->deactivated[ $resource ], strtoupper( "TOTAL {$resource} DEACTIVATED: " ) . count( $this->deactivated[ $resource ] ) );
			$this->deactivated[ $resource ] = implode( "\n", $this->deactivated[ $resource ] );
		}
		$log = [
			'timestamp'                  => ( new \DateTime() )->format( 'm/d/Y H:i:s' ),
			'message'                    => implode( " ", $this->response ),
			"updated_{$this->resource}s" => implode( "\n", $this->updated ),
			"new_{$this->resource}s"     => implode( "\n", $this->new ),
			"deactivated"                => implode( "\n", $this->deactivated ),
			'total_rows'                 => $this->resourceCount,
			'errors'                     => implode( "\n", $this->errors )
		];
		Helper::log_update_option( $this->logOption, $log );
	}

	private function resourceLoop() {
		$this->resources = array_slice( $this->resources, 0, 1000 );
		foreach ( $this->resources as $resource ) {
			if ( empty( $resource ) ) {
				continue;
			}
			$id = $resource["id"];
			$this->save( $this->single( $resource ) );
			remove( $this->resourceList, function ( $resource ) use ( $id ) {
				return $resource["id"] === $id;
			} );
		}
	}

	/**
	 * @param $model
	 */
	private function save( $model ) {
		$modelClass = get_class( $model );
		if ( is_callable( $modelClass, 'save' ) ) {
			$model->save();
		}
	}

	protected function logEmpty() {
		$log = [
			'timestamp'  => ( new \DateTime() )->format( 'm/d/Y H:i:s' ),
			'message'    => implode( " ", $this->response ),
			'total_rows' => 0,
			'errors'     => implode( "\n", $this->errors )
		];
		Helper::log_update_option( $this->logOption, $log );
	}

	public function getLogOption() {
		return $this->logOption;
	}

	protected function single( array $resource ) {
		return $resource;
	}

	/**
	 * @param $instance
	 * @param int $id
	 *
	 * @return mixed
	 */
	protected function findOrCreate( $instance, $id ) {
		$new            = false;
		$resourceExists = $instance->where( $this->idField, $id )->take( 1 )->get();
		if ( $resourceExists ) {
			$instance = $resourceExists;
		} else {
			$new               = true;
			$instance->created = ( new \DateTime() )->getTimestamp();
		}

		return [ 'instance' => $instance, 'new' => $new ];
	}

	/**
	 * @param $fields
	 *
	 * @return mixed
	 */
	protected function switchKeys( $fields ) {
		foreach ( $this->keySwitches as $oldKey => $newKey ) {
			$value = $fields[ $oldKey ];
			unset( $fields[ $oldKey ] );
			if ( $newKey === false ) {
				continue;
			}
			$fields[ $newKey ] = $value;
		}

		return $fields;
	}

	/**
	 * @param $resource
	 * @param array $fields
	 *
	 * @return mixed
	 */
	protected function updateFields( $resource, array $fields ) {
		if ( isset( $resource->new ) ) {
			unset( $resource->new );
		}

		$fields = $this->switchKeys( $fields );

		foreach ( $fields as $fieldLabel => $fieldValue ) {
			if ( $fieldValue === "NULL" ) {
				$fieldValue = null;
			}
			
			if ( is_string( $fieldValue ) ) {
				$fieldValue = trim( $fieldValue );
			}

			$resource->{$fieldLabel} = $fieldValue;
		}

		return $resource;
	}
}