<?php


namespace Nativerank\BioTEPractices\Updaters;


use App\Models\BioTEPractice;
use Nativerank\BioTEPractices\Alert;
use Nativerank\BioTEPractices\Core\Util\Helper;
use function _\flatMap;
use function _\map;
use function _\remove;

class PracticeUpdater extends Updater {

	protected $resource = 'practice';
	protected $keySwitches = [
		'clinicName'               => 'name',
		'active'                   => 'status',
		'clinicUrl'                => 'website',
		'clinicLegacyStatus'       => 'marketing_program',
		'effectiveDate'            => 'marketing_effective_date',
		'primaryAddress'           => false,
		'locatorActive'            => false,
		'marketingEmailRecipients' => false,
	];
	protected $deactivated = [
		'practices'     => [],
		'practitioners' => []
	];
	protected $practices;
	protected $inactiveOption = NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_INACTIVE_CLINICS;

	/**
	 * @param array $clinic
	 *
	 * @return BioTEPractice
	 */
	protected function single( array $clinic ) {
		$foundOrCreated = $this->findOrCreate( new BioTEPractice(), $clinic['id'] );
		if ( $foundOrCreated['new'] ) {
			$this->new[] = "{$clinic['id']} | {$clinic['clinicName']} | " . ( $clinic['active'] ? "Active" : "In-Active" );
		}

		$practice = $foundOrCreated['instance'];

		$practice->modified = ( new \DateTime() )->getTimestamp();
		$address            = $clinic["primaryAddress"][0] ?? [];

		$slug = Helper::getSlug( array_merge( [
			"name" => $clinic["clinicName"],
			'id'   => $clinic['id']
		], $this->formatAddress( $address ) ) );

		if ( isset( $practice->slug ) && $slug !== $practice->slug ) {
			( new Alert() )->to( [
				'tamas.zalabai@nativerank.com',
				'Corrissa@nativerank.com'
			] )->priority( 1 )->send( "Practice #{$practice->id} - {$practice->name} - slug {$practice->slug} changed to {$slug}" );
			Helper::addPracticeRedirect( $practice, $slug );
		}

		$practice->slug = $slug;

		$clinic['active'] = ( ( $clinic['active'] ?? false ) && ( $clinic['locatorActive'] ?? false ) );

		$practice->lat          = $address["latitude"] ?? 0;
		$practice->lng          = $address["longitude"] ?? 0;
		$practice->country      = $address["country"][0]["twoLetterIsoCode"] ?? "US";
		$practice->country_code = Helper::get_country_calling_code_by_country_code( $practice->country );

		if ( ! empty( $clinic['marketingEmailRecipients'] ) && $clinic['marketingEmailRecipients'] !== "NULL" ) {
			$clinic['marketing_emails'] = $this->mapEmails( $clinic['marketingEmailRecipients'] );
		}

		if ( ! empty( $address["phoneNumber"] ) && $address['phoneNumber'] !== "NULL" ) {
			$practice->phone = $this->formatNumbers( $address, $clinic["clinicName"] );
			if ( isset( $practice->phone[ array_key_first( $practice->phone ) ]['number']['country_code'] ) ) {
				$practice->country_code = $practice->phone[ array_key_first( $practice->phone ) ]['number']['country_code'];
			}
		}

		$clinic['email'] = trim( $address['email'] );

		// Bust location directory transient/cache
		$cacheKey = 'nr_location_directory_v2_posts_for_';
		$cacheKey .= strtolower( ( $address["stateProvince"][0]['name'] ?? '' ) . '_' . ( $address['city'] ?? '' ) );
		delete_transient( $cacheKey );

		$directory_slug = sanitize_title( $address["stateProvince"][0]['name'] ?? '' ) . "/" . sanitize_title( $address['city'] ?? '' );
		if ( strpos( $directory_slug, "/" ) > 0 ) {
			rocket_clean_files( get_site_url( null, '/biote-providers' ) . "/{$directory_slug}" );
		}


		$address           = $this->formatAddress( $address );
		$practice->address = $address;

		$profiles = flatMap( $clinic['clinicCustomer'], function ( $customer ) {
			return map( $customer['profile'], 'id' );
		} );
		unset( $clinic['clinicCustomer'] );

		remove( $profiles, function ( $id ) {
			return $id === null || $id === 'NULL';
		} );

		$practice = $this->updateFields( $practice, $clinic );

		if ( ! $clinic['active'] ) {
			$this->deactivated['practices'][] = "{$clinic['id']} | {$clinic['clinicName']}";
			Helper::addPracticeRedirect( $practice );
		}
		if ( $clinic['active'] ) {
			Helper::removePracticeRedirect( $practice );
		}

		$practice->practitioners()->detach();
		if ( ! empty( $profiles ) ) {
			$practice->practitioners()->attach( $profiles );
		}

		$this->updated[] = "{$clinic['id']} | {$clinic['clinicName']} | " . ( $clinic['active'] ? "Active" : "In-Active" );

		rocket_clean_files( get_site_url( null, NR_BIOTE_PRACTICES_PARENT_SLUG ) . "/{$practice->slug}" );

		return $practice;
	}

	/**
	 * @param $address
	 *
	 * @return array
	 */
	private function formatAddress( $address ) {
		return [
			'street_address' => trim( ( $address["address1"] ?? "" ) . ( isset( $address["address2"] ) ? " " . $address["address2"] : '' ) ),
			'city'           => trim( $address["city"] ?? "" ),
			'state'          => trim( $address["stateProvince"][0]["abbreviation"] ?? "" ),
			'zip'            => trim( $address["zipPostalCode"] ?? "" ),
		];
	}

	/**
	 * @param $emails
	 *
	 * @return array
	 */
	private function mapEmails( $emails ) {
		$marketingEmails = explode( ";", $emails );
		$formattedEmails = [];
		foreach ( $marketingEmails as $marketingEmail ) {
			$formattedEmails[ ( new \DateTime() )->getTimestamp() ]['email'] = $marketingEmail;
		}

		return $formattedEmails;
	}

	/**
	 * @param $address
	 * @param $clinicName
	 *
	 * @return array
	 */
	private function formatNumbers( $address, $clinicName ) {
		$phoneNumbers     = explode( ";", $address["phoneNumber"] );
		$formattedNumbers = [];
		foreach ( $phoneNumbers as $phoneNumber ) {
			$number = Helper::build_phone_number( $phoneNumber, $address["country"][0]["twoLetterIsoCode"] ?? null, $clinicName );
			if ( isset( $number["errors"] ) ) {
				$this->errors[] = implode( " ", $number["errors"] );
				unset( $number["errors"] );
			}
			$formattedNumbers[ ( new \DateTime() )->getTimestamp() ]['number'] = $number;
		}

		return $formattedNumbers;
	}

	/**
	 *
	 */
	public function handleInactive() {
		$clinics = get_option( $this->inactiveOption );
		if ( empty( $clinics ) ) {
			$this->response["message"] = 'No inactive practices found in the log';
			$this->logEmpty();

			return $this->response;
		}
		$this->practices = ( new BioTEPractice() )->findAll( array_values( $clinics ) )->where( 'status', 1 )->get();

		$this->inactivePracticesLoop();

		$this->log();

		return $this->response;
	}

	private function inactivePracticesLoop() {
		if ( $this->practices ) {
			$practicesArray = $this->practices->toArray();
			$clinics        = map( $practicesArray, 'id' );
			foreach ( $this->practices as $practice ) {
				Helper::addPracticeRedirect( $practice );
				$practice->status = 0;
				remove( $clinics, function ( $clinic ) use ( $practice ) {
					return $clinic === $practice->id;
				} );
				$practice->save();
			}
			$this->deactivated['practices'] = array_merge( $this->deactivated['practices'], map( $practicesArray, function ( $practice ) {
				return "{$practice["id"]} | {$practice["name"]}";
			} ) );
			update_option( $this->inactiveOption, $clinics );
			$this->response["message"] = 'Deactivated inactive practices from log';
		} else {
			update_option( $this->inactiveOption, [] );
			$this->response["message"] = 'No inactive practices from the log, found in the database';
		}
	}

} // end of class