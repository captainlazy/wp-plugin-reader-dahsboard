<?php

namespace Nativerank\BioTEPractices\Updaters;

use App\Models\BioTEPractice;
use App\Models\BiotePractitioner;
use Nativerank\BioTEPractices\Core\Util\Helper;
use function _\map;
use function _\remove;

class PractitionerUpdater extends Updater {
	protected $resource = 'practitioner';
	protected $practitioners;
	protected $keySwitches = [
		'photo_id'  => 'biote_photo_id',
		'imageUrl'  => 'biote_photo_url',
		'is_active' => 'status',
	];
	protected $deactivated = [
		'practitioners' => []
	];
	protected $inactiveOption = NR_BIOTE_PRACTICES_OPTION_PREFIX . NR_BIOTE_PRACTICES_INACTIVE_PROFILES;

	protected function single( array $profile ) {
		$findOrCreate = $this->findOrCreate( new BiotePractitioner(), $profile[ $this->idField ] );
		$practitioner = $findOrCreate['instance'];

		if ( $findOrCreate['new'] ) {
			$this->new[] = "{$profile['id']} | {$profile['first_name']} {$profile['last_name']}, {$profile['degree']}";
		}

		$practitioner->modified = ( new \DateTime() )->getTimestamp();
		$practice               = ( new BiotePractice() )->find( $profile['clinicId'] ?? null );

		if ( $practice ) {
			rocket_clean_files( get_site_url( null, NR_BIOTE_PRACTICES_PARENT_SLUG ) . "/{$practice->slug}" );
		}

		if ( ! empty( $profile["phone"] ) && $profile['phone'] !== "NULL" ) {
			$profile["phone"] = $this->formatNumber( $profile,
				$practice->country_code ?? null,
				$practice->name ?? ''
			);
			if ( isset( $profile['phone']['errors'] ) ) {
				$this->errors = implode( " ", $profile['phone']['errors'] );
			}
		}

		$profile["photo_id"] = pathinfo( $profile['photo_id'] ?? '', PATHINFO_FILENAME );

		if ( isset( $profile['clinicId'] ) ) {
			if ( ! empty( $profile['clinicId'] ) ) {
				$practitioner->id = $profile['id'];
				$practitioner->practices()->attach( $profile['clinicId'] );
			}
			unset( $profile['clinicId'] );
		}
		$practitioner = $this->updateFields( $practitioner, $profile );

		$this->updated[] = "{$profile['id']} | {$profile['first_name']} {$profile['last_name']}, {$profile['degree']}";


		return $practitioner;
	}

	/**
	 * @param $profile
	 * @param $country_code
	 * @param string $practice_name
	 *
	 * @return array
	 */
	private function formatNumber( $profile, $country_code = null, $practice_name = '' ) {
		$phone = Helper::build_phone_number( $profile['phone'], $country_code, $practice_name );
		if ( isset( $phone["errors"] ) ) {
			$this->errors[] = "{$profile['first_name']} {$profile['last_name']}" . implode( "\n", $phone["errors"] );
			unset( $phone["errors"] );
		}

		return $phone;
	}

	public function handleInactive() {
		$profiles = get_option( $this->inactiveOption );
		if ( empty( $profiles ) ) {
			$this->response["message"] = 'No inactive practitioners found in the import';
			$this->logEmpty();

			return $this->response;
		}
		$this->practitioners = ( new BiotePractitioner() )->select( 'id', 'status' )->where( 'id', 'in', $profiles )->where( 'status', 1 )->get();

		$this->inactivePractitionersLoop();

		$this->log();

		return $this->response;
	}

	private function inactivePractitionersLoop() {
		if ( $this->practitioners ) {
			$this->resourceCount = $this->practitioners->count();
			$profiles            = map( $this->practitioners->toArray(), 'id' );
			foreach ( $this->practitioners as $practitioner ) {
				$practitioner->status = 0;
				$practitioner->save();
				remove( $profiles, function ( $profile ) use ( $practitioner ) {
					return $profile === $practitioner->id;
				} );
			}
			update_option( $this->inactiveOption, $profiles );
			$this->response['message'] = 'Deactivated inactive practitioners from log';
		} else {
			update_option( $this->inactiveOption, [] );
			$this->response['message'] = 'No inactive practitioners from the import, found in the database';
		}
	}
}