<?php


namespace Nativerank\BioTEPractices\Logger;

use function _\map;


class MailLog
{
	protected $logger;
	protected $logsPath;
	protected $to = ['sahil.khanna@nativerank.com'];

	public function __construct()
	{
		$this->logger   = new Logger();
		$this->logsPath = $this->logger->getPath();

	}

	public function run()
	{
		$logFiles = $this->logger->getFiles();
		$logFiles = map($logFiles, function ($logFile) {
			return $this->logsPath . $logFile;
		});
		date_default_timezone_set('America/Denver');
		$date      = date('m/d/Y', time());
		$headers   = array();
		$headers[] = 'From: Nativerank Bot for BioTE <me@example.net>';
		$headers[] = 'Reply-To: Sahil Khanna <sahil.khanna@nativerank.com>';
		$headers[] = 'Content-Type: text/html; charset=UTF-8';


		$sent = wp_mail($this->to, 'BioTE Import Logs - ' . $date, 'Logs attached (Beta)', $headers, $logFiles);

		if ($sent) {
			$this->logger->deleteFiles();
		}

		$status  = ($sent ? 200 : 404);
		$message = ($sent ? "Email of the last week's logs sent" : 'Email failed to send!');
		return ['status' => $status, 'message' => $message];

	}
}
