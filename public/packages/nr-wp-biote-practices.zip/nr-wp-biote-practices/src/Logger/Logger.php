<?php


namespace Nativerank\BioTEPractices\Logger;


use Nativerank\BioTEPractices\ClinicLogGetter;
use Nativerank\BioTEPractices\Importers\ClinicImporter;
use Nativerank\BioTEPractices\Updaters\PracticeUpdater;
use Nativerank\BioTEPractices\Updaters\PractitionerUpdater;
use function _\takeRight;

class Logger
{

	protected $path;
	protected $entries;
	protected $new;

	public function __construct()
	{
		$this->path = NR_BIOTE_PRACTICES_PLUGIN_PATH . "logs/";
	}

	public function run()
	{
		$logOptions = [
			(new ClinicLogGetter())->getLogOption(),
			(new ClinicImporter())->getLogOption(),
			(new PracticeUpdater())->getLogOption(),
			(new PractitionerUpdater())->getLogOption(),
		];
		$logTime    = (new \DateTime())->format('Y-m-d');
		$failed     = [];
		foreach ($logOptions as $logOption) {
			$this->entries = get_option(NR_BIOTE_PRACTICES_OPTION_PREFIX . $logOption);
			if (empty($this->entries)) {
				$this->entries = [];
			}
			$this->new = $this->entries;

			$filename = "{$logTime}_{$logOption}.txt";

			$this->implodeEntries();

			if (!$this->pathExists()) {
				mkdir($this->path, 775, true);
			}

			if (file_exists($this->path . $filename)) {
				$this->new .= file_get_contents($this->path . $filename);
			}

			$saved = file_put_contents($this->path . $filename, $this->new);
			if ($saved === false) {
				$failed[] = "$filename failed to save";
			}
			update_option(NR_BIOTE_PRACTICES_OPTION_PREFIX . $logOption, []);
		}

		$this->deleteOld();
		$failed = implode(", ", $failed);

		return ['status' => 200, 'message' => "Logs saved to logs folder in plugin's root directory " . $failed];
	}

	private function implodeEntries()
	{
		if (is_array($this->entries)) {
			$this->new = [];
			foreach ($this->entries as $logEntry) {
				$this->new[] = $this->recursive_implode($logEntry, "\n", true, false);
			}
			$this->new = "---***---\n" . implode("\n\n---***---\n", $this->new);
		}
	}

	public function getPath()
	{
		return $this->path;
	}

	private function pathExists()
	{
		return file_exists($this->path);
	}

	private function deleteOld()
	{
		$files = $this->getFiles();
		if (count($files) > 35) {
			$files = takeRight($files, (count($files) - 35));
			foreach ($files as $file) {
				unlink($this->path . $file);
			}
		}
	}

	public function deleteFiles()
	{
		$files = $this->getFiles();
		foreach ($files as $file) {
			unlink($this->path . $file);
		}
	}

	public function getFiles()
	{
		return array_values(array_diff(scandir($this->path), array('.', '..', 'json')));
	}

	/**
	 * Recursively implodes an array with optional key inclusion
	 *
	 * Example of $include_keys output: key, value, key, value, key, value
	 *
	 * @access  public
	 * @param array $array multi-dimensional array to recursively implode
	 * @param string $glue value that glues elements together
	 * @param bool $include_keys include keys before their values
	 * @param bool $trim_all trim ALL whitespace from string
	 * @return  string  imploded array
	 */
	function recursive_implode(array $array, $glue = ',', $include_keys = false, $trim_all = true)
	{
		$glued_string = '';

		// Recursively iterates array and adds key/value to glued string
		array_walk_recursive($array, function ($value, $key) use ($glue, $include_keys, &$glued_string) {
			$include_keys and $glued_string .= "[" . strtoupper($key) . "]" . $glue;
			$glued_string .= $value . $glue;
		});

		// Removes last $glue from string
		strlen($glue) > 0 and $glued_string = substr($glued_string, 0, -strlen($glue));

		// Trim ALL whitespace
		$trim_all and $glued_string = preg_replace("/(\s)/ixsm", '', $glued_string);

		return (string)$glued_string;
	}


}