<?php


namespace Nativerank\BioTEPractices\Importers;

use Exception;
use GuzzleHttp\Client;
use Nativerank\BioTEPractices\Alert;
use Nativerank\BioTEPractices\ClinicLogGetter;
use Nativerank\BioTEPractices\Core\Util\Helper;
use TypeRocket\Core\Config;

class Importer {
	protected $client;
	protected $openBody = "{'query':'{\\n  ";
	protected $closeBody = "}\\n'}";
	protected $result;
	protected $body;
	protected $type;
	protected $resource;
	protected $response;
	protected $clinics = [];
	protected $remainingClinics = [];
	protected $logOption;
	protected $option;
	protected $empty;
	protected $options;
	protected $noResult = 'Unable to import practices';


	public function __construct() {
		$this->client             = new Client();
		$this->response['status'] = 200;
	}

	public function run() {
		$this->getClinics();
		$this->setBody();
		if ( empty( $this->body ) ) {
			( new ClinicLogGetter() )->run();
			$this->response['message'] = "Clinic log is empty, fetching updated practices instead";
			$this->logEmpty();

			return $this->response;
		}
		$this->sendRequest();

		if ( empty( $this->result ) ) {
			if ( empty( $this->response['message'] ) ) {
				$this->response["message"] = $this->noResult;
			}
			$this->logEmpty();

			return $this->response;
		}
		Helper::log_json_string( "{$this->resource}_importer", json_encode( $this->result["data"] ) );

		$this->filter();
		$this->save();
		$this->log();

		update_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . $this->option, $this->remainingClinics );

		return $this->response;
	}

	protected function filter() {

	}

	protected function save() {

	}

	protected function log() {

	}

	/**
	 *
	 */
	protected function setBody() {
		if ( empty( $this->clinics ) ) {
			return;
		}
		$keys = file_get_contents( NR_BIOTE_PRACTICES_PLUGIN_PATH . "{$this->resource}Keys.graphql" );
		$body = $this->openBody;

		foreach ( $this->clinics as $clinic ) {
			$body .= "{$this->resource}_{$clinic}: {$this->type}(id:{$clinic}) " . $keys;
		}

		$this->body = $body . $this->closeBody;
	}

	protected function logEmpty() {
		$log = [
			'timestamp'  => ( new \DateTime() )->format( 'm/d/Y H:i:s' ),
			'message'    => $this->response['message'],
			'total_rows' => 0
		];
		Helper::log_update_option( $this->logOption, $log );
	}

	public function getLogOption() {
		return $this->logOption;
	}

	protected function getClinics() {
		$clinics = get_option( NR_BIOTE_PRACTICES_OPTION_PREFIX . $this->option );
		if ( empty( $clinics ) ) {
			return;
		}
		$this->clinics          = array_slice( $clinics, 0, 300 );
		$this->remainingClinics = array_slice( $clinics, 300 );
	}

	/**
	 *
	 */
	private function sendRequest() {
		try {
			$result         = $this->client->post( NR_BIOTE_PRACTICES_GRAPHQL_ENDPOINT, [
				'connect_timeout' => 10,
				'timeout'         => 30,
				'headers'         => [
					'Ocp-Apim-Subscription-Key' => Config::locate( 'app.api_keys.biote_graphql' ),
					'Content-Type'              => 'application/json'
				],
				'body'            => $this->body
			] );
			$this->result   = json_decode( $result->getBody(), true );
			$this->response = [
				'status'  => $result->getStatusCode(),
				'message' => 'Fetched updated practice info from log'
			];
		} catch ( Exception $e ) {
			$message = "Import failed: " . Helper::get_error_message( $e );
			$alert   = new Alert();
			$alert->priority( 3 );
			$message        .= $alert->send( $message );
			$this->response = [ 'status' => $e->getCode(), 'message' => $message ];
		}
	}

}
