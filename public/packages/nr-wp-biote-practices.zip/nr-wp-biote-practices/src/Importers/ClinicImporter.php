<?php


namespace Nativerank\BioTEPractices\Importers;

use Nativerank\BioTEPractices\Core\Util\Helper;
use function _\filter;
use function _\map;
use function _\partition;
use function _\union;
use function _\uniqBy;


class ClinicImporter extends Importer
{
	protected $logOption = 'clinic_importer_log';
	protected $option = NR_BIOTE_PRACTICES_CLINIC_IDS;
	protected $resource = 'clinic';
	protected $type = 'getClinicByClinicId';
	protected $practices;
	protected $inactivePractices = [];
	protected $profiles = [];
	protected $inactiveProfiles = [];

	/**
	 *
	 */
	protected function filter()
	{
		$this->practices = $this->result["data"];
		if(empty($this->practices)) {
			if(empty($this->response['message'])) {
				$this->response["message"] = $this->noResult;
			}
			$this->logEmpty();
			return;
		}

		foreach($this->practices as $clinicIndex => $clinic) {
			$showInLocator = (($clinic['active'] ?? false) && ($clinic['locatorActive'] ?? false));
			foreach($clinic["clinicCustomer"] as $customerIndex => $clinicCustomer) {
				if(empty($clinicCustomer["profile"])) {
					continue;
				}

				$customerActive = ((isset($clinicCustomer['active'])) && ($clinicCustomer['active'] === true));

				if($showInLocator && $customerActive) {
					foreach($clinicCustomer["profile"] as $index => $profile) {
						$clinicCustomer["profile"][$index]['clinicId'] = $clinic['id'];
					}
				}


				$profilesByStatus = partition($clinicCustomer["profile"], function($profile) {
					return (isset($profile["is_active"]) && $profile["is_active"]);
				});


				$this->profiles         = array_merge($this->profiles, $profilesByStatus[0]);
				$this->inactiveProfiles = union($this->inactiveProfiles, map($profilesByStatus[1], 'id'));

                if(!$customerActive) {
                    unset($this->practices[$clinicIndex]['clinicCustomer'][$customerIndex]);
                }
			}
			if($showInLocator !== true) {
				if(isset($clinic['id']) && $clinic['id'] !== null) {
					$this->inactivePractices = union($this->inactivePractices, [$clinic['id']]);
				}
				unset($this->practices[$clinicIndex]);
			}
		}

		$this->profiles = map($this->profiles, function($profile) {
			$otherProfiles       = filter($this->profiles, function($otherProfile) use ($profile) {
				return ($otherProfile['id'] === $profile['id']) && isset($otherProfile['clinicId']) && !empty($otherProfile['clinicId']) && ($otherProfile['clinicId'] !== "NULL");
			});
			$clinicIds           = map($otherProfiles, 'clinicId');
			$profile['clinicId'] = $clinicIds;
			return $profile;
		});
		$this->profiles = uniqBy($this->profiles, 'id');
	}

	protected function save()
	{
		$this->options = [
			NR_BIOTE_PRACTICES_IMPORTED_CLINICS => $this->practices,
			NR_BIOTE_PRACTICES_INACTIVE_CLINICS => $this->inactivePractices,
			NR_BIOTE_PRACTICES_IMPORTED_PROFILES => $this->profiles,
			NR_BIOTE_PRACTICES_INACTIVE_PROFILES => $this->inactiveProfiles
		];

		Helper::merge_update_option(NR_BIOTE_PRACTICES_IMPORTED_CLINICS, $this->options[NR_BIOTE_PRACTICES_IMPORTED_CLINICS]);
		Helper::merge_update_option(NR_BIOTE_PRACTICES_IMPORTED_PROFILES, $this->options[NR_BIOTE_PRACTICES_IMPORTED_PROFILES]);

		Helper::union_update_option(NR_BIOTE_PRACTICES_INACTIVE_CLINICS, $this->options[NR_BIOTE_PRACTICES_INACTIVE_CLINICS]);
		Helper::union_update_option(NR_BIOTE_PRACTICES_INACTIVE_PROFILES, $this->options[NR_BIOTE_PRACTICES_INACTIVE_PROFILES]);

		$this->response['message'] = 'Imported updated practices from log';
	}

	protected function log()
	{
		$log = [
			'timestamp' => (new \DateTime())->format('m/d/Y H:i:s'),
			'message' => implode(" ", $this->response),
			'total_rows' => count($this->result['data']),
			'imported' => implode("\n", map($this->practices, function($practice) {
				return "{$practice['id']} | {$practice['clinicName']}";
			})),
		];
		foreach($this->options as $option => $value) {
			$log[$option] = count($value);
		}
		Helper::log_update_option($this->logOption, $log);


	}

}