<?php


namespace Nativerank\BioTEPractices\Resources;


class BioTEPractice {
	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;


	public function __construct( $name = 'BioTE Practice' ) {
		$this->resource = tr_resource_pages( $name, $name . 's', [ 'position'   => 2,
		                                                           'capability' => 'edit_posts'
		] )->setIcon( 'office' );

		return $this->resource;
	}
}