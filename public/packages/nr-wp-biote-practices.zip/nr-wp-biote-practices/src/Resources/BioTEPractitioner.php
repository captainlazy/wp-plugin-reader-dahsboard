<?php


namespace Nativerank\BioTEPractices\Resources;


/**
 * Class Example
 * @package Nativerank\BioTEPractices\Resources
 */
class BioTEPractitioner
{

	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;


	public function __construct($name = 'BioTE Practitioner')
	{
		$this->resource = tr_resource_pages($name, $name . 's', ['position' => 3, 'capability' => 'edit_posts'])->setIcon('stethoscope');

		return $this->resource;
	}


}
