<?php


namespace Nativerank\BioTEPractices\Database;


use wpdb;

/**
 * Class Migrations
 * @package Nativerank\BioTEPractices\Database
 */
class Migrations
{

	/**
	 * @var wpdb
	 */
	protected $db;

	/**
	 * @var string
	 */
	protected $charset_collate;

	/**
	 * @var string
	 */
	protected $db_prefix;

	/**
	 * Migrations constructor.
	 */
	public function __construct()
	{
		global $wpdb;

		$this->db              = $wpdb;
		$this->charset_collate = $wpdb->get_charset_collate();
		$this->db_prefix       = $wpdb->prefix;

		$this->register_all_DBs();
	}


	/**
	 * Register Tables
	 * @return array[] each set of arrays will contain [TableSchema function, TableName]
	 */
	private function register()
	{
		return [
			['practiceSchema', 'biote_practices'],
			['practitionerSchema', 'biote_practitioners'],
			['practiceAndPractitionerSchema', 'biote_practices_biote_practitioners'],
		];
	}


	/**
	 * @return string[]
	 */
	private function practiceSchema()
	{
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'status BOOL',
			'name VARCHAR(150) DEFAULT NULL',
			'address TEXT',
			'country VARCHAR(20) DEFAULT NULL',
			'country_code TINYINT(4) DEFAULT 1',
			'website VARCHAR(2083) DEFAULT NULL',
			'phone TEXT DEFAULT NULL',
			'email VARCHAR(320) DEFAULT NULL',
			'marketing_emails TEXT',
			'marketing_program VARCHAR(20) DEFAULT "certified"',
			'marketing_status BOOL DEFAULT 1',
			'marketing_effective_date INT(11)',
			'lat FLOAT( 10, 6 )',
			'lng FLOAT( 10, 6 )',
			'slug VARCHAR(2083) DEFAULT NULL',
			'modified INT(11)',
			'created INT(11) DEFAULT \'00000000000\' NOT NULL',
			'UNIQUE KEY id (id)'
		];
	}

	private function practiceAndPractitionerSchema()
	{
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'biote_practices_id BIGINT(20) NOT NULL',
			'biote_practitioners_id BIGINT(20) NOT NULL',
			'UNIQUE KEY id (id)',
		];
	}

	/**
	 * @return string[]
	 */
	private function practitionerSchema()
	{
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'first_name VARCHAR(60) DEFAULT NULL',
			'last_name VARCHAR(60) DEFAULT NULL',
			'degree VARCHAR(320) DEFAULT NULL',
			'bio TEXT DEFAULT NULL',
			'phone TEXT DEFAULT NULL',
			'email VARCHAR(320) DEFAULT NULL',
			'photo_id BIGINT(20) DEFAULT NULL',
			'biote_photo_id VARCHAR(320) DEFAULT ""',
			'biote_photo_url TEXT DEFAULT ""',
			'status BOOL',
			'modified INT(11)',
			'created INT(11) DEFAULT \'00000000000\' NOT NULL',
			'UNIQUE KEY id (id)'
		];
	}


	/**
	 *
	 * @param string[]|string $queries Optional. The query to run. Can be multiple queries
	 *                                 in an array, or a string of queries separated by
	 *                                 semicolons. Default empty string.
	 */
	private function dbDelta($queries)
	{
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($queries);
	}

	// Register all DBs
	private function register_all_DBs()
	{
		foreach ($this->register() as $db) {
			$table_name = $this->db_prefix . $db[1];
			$tableCols  = $this->{$db[0]}();
			$tableCols  = implode(",\n", $tableCols);
			$sql        = sprintf("CREATE TABLE `%s` ( %s ) %s;", $table_name, $tableCols, $this->charset_collate);
			$this->dbDelta($sql);
		}
	}

}
