<?php

use Intervention\Image\ImageManager;

if (!function_exists('save_practitioner_image')) {
	function save_practitioner_image($url, $img_dir)
	{
		$manager = new ImageManager();
		try {
			$image = $manager->make($url)->encode('jpg');
			$image->orientate();
			return $image->save($img_dir);
		} catch (Exception $e) {
			return false;
		}
	}
}
