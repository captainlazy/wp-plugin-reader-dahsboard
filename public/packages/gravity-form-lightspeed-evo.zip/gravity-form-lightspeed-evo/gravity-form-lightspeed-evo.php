<?php

/*
Plugin Name: Gravity Form Lightspeed Evo
Plugin URI: https://nativerank.com
Description: Sends form submissions to CDK Global LightspeedEVO CRM
Version: 0.0.1
Author: Sahil Khanna (sahil.khanna@nativernak.com)
Author URI: https://nativerank.com
*/


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define most essential constants.
define('GRAVITY_FORM_LIGHTSPEED_EVO_VERSION', '0.1.4');
define('GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_MAIN_FILE', __FILE__);
define('GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM', '7.4.0');
define('GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME', basename(__DIR__));
define('GRAVITY_FORM_LIGHTSPEED_EVO_slug', 'gflightspeedevoaddon');
define('GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_URI', plugins_url(GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME));

if (class_exists('\GFLightspeedEVO\Plugin')) {
    die();
}


require plugin_dir_path(__FILE__) . './vendor/autoload_packages.php';


/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook(__FILE__, function () {
    if (version_compare(PHP_VERSION, GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM, '<')) {
        wp_die(
        /* translators: %s: version number */
            esc_html(sprintf(__('NR Gravity Form LightspeedEVO requires PHP version %s', 'gf-lightspeedevo'), GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM)),
            esc_html__('Error Activating', 'gravity-form-lightspeed-evo')
        );
    }

    flush_rewrite_rules();
    do_action('gravity_form_lightspeed_evo_activation');

});


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook(__FILE__, function ($network_wide) {
    if (version_compare(PHP_VERSION, GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM, '<')) {
        return;
    }

    do_action('gravity_form_lightspeed_evo_deactivation', $network_wide);
});


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function gravity_form_lightspeed_evo_opcache_reset()
{
    if (version_compare(PHP_VERSION, GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM, '<')) {
        return;
    }

    if (!function_exists('opcache_reset')) {
        return;
    }

    if (!empty(ini_get('opcache.restrict_api')) && strpos(__FILE__, ini_get('opcache.restrict_api')) !== 0) {
        return;
    }

    // `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
    if (defined('WPCOM_IS_VIP_ENV') && WPCOM_IS_VIP_ENV) {
        return;
    }

    opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action('upgrader_process_complete', 'gravity_form_lightspeed_evo_opcache_reset');

if (version_compare(PHP_VERSION, GRAVITY_FORM_LIGHTSPEED_EVO_PHP_MINIMUM, '>=')) {


	\GFLightspeedEVO\Plugin::load( GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_MAIN_FILE );


}
