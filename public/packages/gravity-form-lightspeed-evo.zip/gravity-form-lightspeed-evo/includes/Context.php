<?php


namespace GFLightspeedEVO;


/**
 * Class Context
 * @package GFLightspeedEVO
 */
class Context
{

    public function __construct($main_file)
    {
    }
}
