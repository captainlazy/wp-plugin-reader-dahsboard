<?php


namespace GFLightspeedEVO\Processor;


use GFLightspeedEVO\Client\LightspeedEVOClient;
use GFLightspeedEVO\Model\Auth;
use GFLightspeedEVO\Model\Lead as LeadModel;
use GFLightspeedEVO\Model\Payload;

class Lead {


	/**
	 * @var Payload
	 */
	protected $payload;

	/**
	 * @var LeadModel
	 */
	private $lead;

	/**
	 * @var Auth
	 */
	private $auth;
	/**
	 * @var LightspeedEVOClient
	 */
	private $client;


	/**
	 * Lead constructor.
	 *
	 * @param array $fieldValues Mapped field values from gravity forml
	 * @param string $apiKey
	 * @param string $sourceId
	 * @param string $dealerId
	 */
	public function __construct( array $fieldValues, string $apiKey, string $sourceId, string $dealerId ) {


		$this->checkForErrors( [
			'fields'   => $fieldValues,
			'apiKey'   => $apiKey,
			'sourceUd' => $sourceId,
			'dealerId' => $dealerId
		] );


		$this->lead = new LeadModel( $fieldValues );

		// Need auth and payload for the request
		$this->auth    = new Auth( $apiKey, $sourceId );
		$this->payload = new Payload( $this->lead, $dealerId );

		$this->client = new LightspeedEVOClient( $this->payload, $this->auth );

	}


	private function checkForErrors( array $fields ) {
		if ( collect( $fields )->count() !== collect( $fields )->filter()->count() ) {
			throw new \Error( 'Missing one of the required fields ' . json_encode( $fields ) );
		};
	}


	/**
	 * @return array|\Psr\Http\Message\ResponseInterface
	 */
	public function process() {
		return $this->client->sendLead();
	}

}
