<?php

namespace GFLightspeedEVO;

use Puc_v4_Factory;

class Plugin
{


    /**
     * The plugin context object.
     *
     * @var Context
     */
    private $context;


    /**
     * Main instance of the plugin.
     *
     * @var Plugin|null
     */
    private static $instance = null;

    /**
     * Sets the plugin main file.
     *
     * @param string $main_file Absolute path to the plugin main file.
     */
    public function __construct(string $main_file)
    {
        $this->context = new Context($main_file);
    }

    /**
     * Retrieves the plugin context object.
     *
     * @return Context Plugin context.
     */
    public function context()
    {
        return $this->context;
    }

    /**
     * Registers the plugin with WordPress.
     */
    public function register()
    {
        add_action('gform_loaded', array('GFLightspeedEVO\Bootstrap\GF_LightspeedEVO_Feed_AddOn_Bootstrap', 'load'), 5);


        do_action('gravity_form_lightspeed_evo_init');

    }

    public function update_checker()
    {
        Puc_v4_Factory::buildUpdateChecker(
            'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME,
            GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_MAIN_FILE,
            GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME
        );
    }

    /**
     * Retrieves the main instance of the plugin.
     *
     *
     * @return Plugin Plugin instance.
     */
    public static function instance()
    {
        return static::$instance;
    }

    /**
     * Loads the plugin main instance and initializes it.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     * @return Plugin|null
     */
    public static function load(string $main_file): ?Plugin
    {


        if (null !== static::$instance) {
            return static::$instance;
        }


	    if ( static::$instance === null ) {
		    static::$instance = new static( $main_file );
	    }

	    ( static::$instance )->register();

	    // register plugin and update checker once plugins are loaded
//        add_action('plugins_loaded', [static::$instance, 'register'], 11);
	    add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ], 12 );

	    return static::$instance;
    }

}
