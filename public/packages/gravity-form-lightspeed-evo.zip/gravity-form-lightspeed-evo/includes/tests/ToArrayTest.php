<?php

namespace GFLightspeedEVO\Tests;

use PHPUnit\Framework\TestCase;

class ToArrayTest extends TestCase
{


    public function test_ToArrayConversion()
    {
        $xmlString = file_get_contents(__DIR__ . '/../../lib/RequestExample.xml');

        $ar = (new ToArray($xmlString))->withName()->toArray();

        $this->assertEquals($this->sampleArrayReturn(), $ar);
    }


    private function sampleArrayReturn()
    {
        return [
            'AddProspect' =>
                [
                    "Item" => [
                        'SourceProspectId' => 'leadsourceexample',
                        'DealershipId' => '76000000',
                        'Email' => 'johndoe@example.com',
                        'Name' => 'John Doe',
                        'Phone' => '555-555-5555',
                        'Notes' => 'Test Notes',
                    ]
                ]

        ];
    }

}
