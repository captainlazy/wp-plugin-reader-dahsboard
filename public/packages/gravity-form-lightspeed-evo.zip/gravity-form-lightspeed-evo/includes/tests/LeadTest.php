<?php

namespace GFLightspeedEVO\Tests;

use GFLightspeedEVO\Model\Lead;
use PHPUnit\Framework\TestCase;

class LeadTest extends TestCase
{

    public function testLead()
    {
        $lead = [
            'Email' => 'jondoe@example.com',
            'Name' => "Jon Doe",
            "Notes" => "Need New Boat"
        ];


        $leadAr = (new Lead($lead))->toArray();

        $this->assertEquals($lead, $leadAr);
    }

}
