<?php

namespace GFLightspeedEVO\Lib;

use Illuminate\Support\Collection;

class LeadFields {

	const FIELDS = [
		[
			"name"     => "SourceProspectId",
			'required' => true,
			"notes"    => "Internal Identifier for where the lead came from. Example: 'website-contact-form'. Can be mapped to Form Title"
		],
		[ "name" => "Name", 'required' => true ],
		[ "name" => "Email", 'required' => false ],
		[ "name" => "Phone", 'required' => false ],
		[ "name" => "AltPhone", 'required' => false ],
		[ "name" => "PreferredContactMethod", 'required' => false, "notes" => "String (e.g. Text Message)" ],
		[ "name" => "SourceDate", 'required' => false ],
		[ "name" => "Address1", 'required' => false ],
		[ "name" => "Address2", 'required' => false ],
		[ "name" => "City", 'required' => false ],
		[ "name" => "State", 'required' => false ],
		[ "name" => "ZipCode", 'required' => false ],
		[ "name" => "Country", 'required' => false ],
		[ "name" => "Birthdate", 'required' => false ],
		[ "name" => "Gender", 'required' => false ],
		[ "name" => "ProspectType", 'required' => false ],
		[ "name" => "SourceProspectType", 'required' => false ],
		[ "name" => "DLNumber", "required" => false, "notes" => "Driver’s license number" ],
		[ "name" => "SSN", "required" => false ],
		[ "name" => "Gender", "required" => false ],
		[
			"name"     => "VehicleNewUsed",
			"required" => false,
			"notes"    => "Condition of the vehicle. Values: “new”, “used”"
		],
		[ "name" => "VehicleMake", "required" => false ],
		[ "name" => "VehicleModel", "required" => false ],
		[ "name" => "VehicleType", "required" => false ],
		[ "name" => "VehicleYear", "required" => false ],
		[ "name" => "VehicleColor", "required" => false ],
		[ "name" => "VehicleVIN", "required" => false ],
		[ "name" => "VehicleStockNum", "required" => false ],
		[
			"name"     => "VehiclePrice",
			"required" => false,
			"notes"    => "Must consist of number values only, string values will result in failure."
		],
		[ "name" => "TradeVehicleYear", "required" => false ],
		[ "name" => "TradeVehicleMake", "required" => false ],
		[ "name" => "TradeVehicleModel", "required" => false ],
		[ "name" => "TradeOdometer", "required" => false ],
		[ "name" => "TradeColor", "required" => false ],
		[ "name" => "TradePayoff", "required" => false ],
		[ "name" => "ItemSKU", "required" => false ],
		[ "name" => "ItemSupplierCode", "required" => false ],
		[ "name" => "ItemDescription", "required" => false ],
		[ "name" => "PurchaseTimeframe", "required" => false ],
		[ "name" => "Notes", "required" => false ],

	];


	/**
	 * @return Collection
	 */
	public static function get() {
		return collect( self::FIELDS );
	}

	/**
	 * @return array[]
	 */
	public static function toArray() {
		return self::FIELDS;
	}


}
