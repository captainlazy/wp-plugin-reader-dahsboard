<?php

namespace GFLightspeedEVO\Bootstrap;

use GFAddOn;

class GF_LightspeedEVO_Feed_AddOn_Bootstrap
{

    public static function load()
    {

        if (!method_exists('GFForms', 'include_feed_addon_framework')) {
            return;
        }

        GFAddOn::register('GFLightspeedEVO\AddOn\GF_Lightspeed_Feed_AddOn');


    }
}
