<?php

namespace GFLightspeedEVO\AddOn;

use GFLightspeedEVO\Lib\LeadFields;
use GFLightspeedEVO\Parser\ToArray;
use Psr\Http\Message\ResponseInterface;

\GFForms::include_feed_addon_framework();

class GF_Lightspeed_Feed_AddOn extends \GFFeedAddOn {
	protected $_version = GRAVITY_FORM_LIGHTSPEED_EVO_VERSION;
	protected $_min_gravityforms_version = '1.9.16';
	protected $_slug = GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME;
	protected $_path = GRAVITY_FORM_LIGHTSPEED_EVO_DIR_NAME . '/' . GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_MAIN_FILE;
	protected $_full_path = GRAVITY_FORM_LIGHTSPEED_EVO_PLUGIN_PATH;
	protected $_title = 'Gravity Forms LightspeedEVO Feed Add-On';
	protected $_short_title = 'LightspeedEVO';
	protected $_bypass_feed_delay = true;

	private static $_instance = null;

	/**
	 * Get an instance of this class.
	 *
	 * @return GF_Lightspeed_Feed_AddOn
	 */
	public static function get_instance() {
		if ( self::$_instance == null ) {
			self::$_instance = new GF_Lightspeed_Feed_AddOn();
		}

		return self::$_instance;
	}

	/**
	 * Plugin starting point. Handles hooks, loading of language files and PayPal delayed payment support.
	 */
	public function init() {

		parent::init();

	}



	// # FEED PROCESSING -----------------------------------------------------------------------------------------------

	/**
	 * Process the feed e.g. subscribe the user to a list.
	 *
	 * @param array $feed The feed object to be processed.
	 * @param array $entry The entry object currently being processed.
	 * @param array $form The form object currently being processed.
	 *
	 * @return bool|void
	 */
	public function process_feed( $feed, $entry, $form ) {


		// Retrieve the name => value pairs for all fields mapped in the 'mappedFields' field map.
		$field_map = $this->get_field_map_fields( $feed, 'mappedFields' );

		// Loop through the fields from the field map setting building an array of values to be passed to the third-party service.
		$merge_vars = array();
		foreach ( $field_map as $name => $field_id ) {

			// Get the field value for the specified field id
			$merge_vars[ $name ] = $this->get_field_value( $form, $entry, $field_id );

		}


		$dealerid = $this->get_plugin_setting( 'dealerid' );
		$apikey   = $this->get_plugin_setting( 'apikey' );
		$sourceid = $this->get_plugin_setting( 'sourceid' );


		/** @var array|ResponseInterface $response */
		$response = ( new \GFLightspeedEVO\Processor\Lead( $merge_vars, $apikey, $sourceid, $dealerid ) )->process();

		$this->log_debug( "[RESPONSE BODY] => " . $response->getBody() );

		if ( $response instanceof ResponseInterface ) {
			if ( $response->getStatusCode() === 200 ) {


				$ar = new ToArray( $response->getBody() );
				if ( $ar->data instanceof \SimpleXMLElement ) {

					if ( $ar->data->Error ) {

						$this->note_error( $entry, print_r( $ar->toArray(), true ), $form, true );

						return;
					}
					$this->add_note( $entry['id'], "Lead Successfully Sent:\n" . json_encode( $ar->toArray() ), 'success' );
				} else {

					$this->note_error( $entry, $response->getBody(), $form, true );

				}

			} else {
				$this->note_error( $entry, $response->getBody(), $form, true );

			}
		} else {
			$this->note_error( $entry, $response, $form, true );

		}
	}


	private function note_error( $entry, $message, $form, $critical = false ) {
		if ( ! is_string( $message ) ) {
			$message = json_encode( $message );
		}

		if ( $critical ) {
			wp_mail( 'websupport@nativerank.com', 'Gravity Form LightspeedEVO Integration Error on ' . get_site_url(), $message );
		}

		$this->add_feed_error( "$message", $this, $entry, $form );
	}

	/**
	 * Configures the settings which should be rendered on the add-on settings tab.
	 *
	 * @return array
	 */
	public function plugin_settings_fields() {
		return [
			[
				'title'  => esc_html__( 'LightspeedEVO Add-On Settings', 'gflightspeedfeedaddon' ),
				'fields' => [
					[
						'name'    => 'dealerid',
						'tooltip' => esc_html__( 'Enter Dealer ID', 'gflightspeedfeedaddon' ),
						'label'   => esc_html__( 'Dealer ID', 'gflightspeedfeedaddon' ),
						'type'    => 'text',
						'class'   => 'small',
					],
					[
						'name'       => 'apikey',
						'tooltip'    => esc_html__( 'Enter LightspeedEVO Unique API Key', 'gflightspeedfeedaddon' ),
						'label'      => esc_html__( 'API Key', 'gflightspeedfeedaddon' ),
						'type'       => 'text',
						'input_type' => 'password',
						'class'      => 'small',
					],
					[
						'name'    => 'sourceid',
						'tooltip' => esc_html__( 'Enter LightspeedEVO Source ID', 'gflightspeedfeedaddon' ),
						'label'   => esc_html__( 'SourceId', 'gflightspeedfeedaddon' ),
						'type'    => 'text',
						'class'   => 'small',
					],
				],
			],
		];
	}

	/**
	 * Configures the settings which should be rendered on the feed edit page in the Form Settings > Simple Feed Add-On area.
	 *
	 * @return array
	 */
	public function feed_settings_fields() {
		return [
			[
				'title'  => esc_html__( 'Simple Feed Settings', 'gflightspeedfeedaddon' ),
				'fields' => [
					[
						'label'    => esc_html__( 'Feed name', 'gflightspeedfeedaddon' ),
						'type'     => 'text',
						'required' => 1,
						'name'     => 'feedName',
						'class'    => 'small',
					],
					[
						'name'      => 'mappedFields',
						'label'     => esc_html__( 'Map Fields', 'gflightspeedfeedaddon' ),
						'type'      => 'field_map',
						'field_map' => LeadFields::get()->transform( function ( $field ) {
							return [
								'name'     => $field['name'],
								'label'    => esc_html__( $field['name'], 'gflightspeedfeedaddon' ),
								'required' => $field['required'],
								'tooltip'  => esc_html__( $field['notes'] ?? '', 'gflightspeedfeedaddon' ),
							];
						} )->toArray()

					],

				],
			],
		];
	}

	/**
	 * Configures which columns should be displayed on the feed list page.
	 *
	 * @return array
	 */
	public function feed_list_columns() {
		return array(
			'feedName' => esc_html__( 'Name', 'gflightspeedfeedaddon' ),
		);
	}


}
