<?php


namespace GFLightspeedEVO\Client;


use GFLightspeedEVO\Model\Auth;
use GFLightspeedEVO\Model\Payload;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

/*
 *
 * CDK LightspeedEVO Documentation:
 * https://s3.amazonaws.com/lightspeed.misc.dev/CDKGlobal+Lead+Integration+Specification.pdf
 *
 */

class LightspeedEVOClient extends Client {

	const BASE_URL = "https://pch.v-sept.com/VSEPTPCHPostService.aspx";
	const TIMEOUT = 20;
	const METHOD = 'POST';

	const FORM_PARAM_PAYLOAD_KEY = "ProspectXML";
	const QUERY_PARAM_API_METHOD = "AddProspect";

	/**
	 * @var Payload
	 */
	private $payload;

	/**
	 * @var Auth
	 */
	private $auth;

	public function __construct( Payload $payload, Auth $auth ) {

		$this->payload = $payload;
		$this->auth    = $auth;

		$config = $this->config();
		$this->log_debug( '[REQUEST] => ' . print_r( $config, true ) );
		parent::__construct( $config );
	}


	public function log_debug( $message ) {
		if ( class_exists( 'GFLogging' ) ) {
			\GFLogging::include_logger();
			\GFLogging::log_message( 'lightspeedeno', $message, \KLogger::DEBUG );
		}
	}


	protected function config() {
		return [
			'base_uri'    => self::BASE_URL,
			'timeout'     => self::TIMEOUT,
			'query'       => [
				$this->auth->getSourceIdLabel() => $this->auth->getSourceIdValue(),
				'method'                        => self::QUERY_PARAM_API_METHOD
			],
			'headers'     => [
				$this->auth->getApiKeyLabel() => $this->auth->getApiKeyValue()
			],
			'form_params' => [
				self::FORM_PARAM_PAYLOAD_KEY => $this->payload->asXMLString()
			]
		];
	}

	/**
	 * @return array|\Psr\Http\Message\ResponseInterface
	 */
	public function sendLead() {
		try {
			return $this->request( 'POST' );
		} catch ( GuzzleException $e ) {
			return [
				'error'   => 'failed to send request to the API endpoint',
				'message' => $e->getMessage()
			];
		}

	}
}
