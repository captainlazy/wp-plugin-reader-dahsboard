<?php


namespace GFLightspeedEVO\Model;


class Auth {

	const API_KEY_LABEL = "X-PCHAPIKey";

	const SOURCE_ID_LABEL = "sourceid";


	/**
	 * @var string
	 */
	private $apiKey;

	/**
	 * @var string
	 */
	private $sourceId;


	/**
	 * Auth constructor.
	 *
	 * @param string $apiKey
	 * @param string $sourceId
	 */
	public function __construct( string $apiKey, string $sourceId ) {
		$this->apiKey   = $apiKey;
		$this->sourceId = $sourceId;
	}


	public function getApiKeyLabel() {
		return self::API_KEY_LABEL;
	}

	public function getApiKeyValue() {
		return $this->apiKey;
	}

	public function getApiKey() {
		return [ self::API_KEY_LABEL => $this->apiKey ];
	}


	public function getSourceIdLabel() {
		return self::SOURCE_ID_LABEL;
	}

	public function getSourceIdValue() {
		return $this->sourceId;
	}

	public function getSourceId() {
		return [ self::SOURCE_ID_LABEL => $this->sourceId ];
	}

}
