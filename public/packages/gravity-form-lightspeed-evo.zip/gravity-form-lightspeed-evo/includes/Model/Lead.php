<?php

namespace GFLightspeedEVO\Model;

class Lead {
	/**
	 * @var array
	 */
	private $raw_data;

	/**
	 * @var array
	 */
	private $clean_data;


	/**
	 * Lead constructor.
	 *
	 * @param array $lead
	 */
	public function __construct( array $lead ) {
		$this->raw_data = $lead;


		$this->removeFalsey();

		return $this;
	}

	public function toArray() {
		return $this->clean_data;
	}

	protected function removeFalsey() {
		$this->clean_data = collect( $this->raw_data )->filter()->toArray();
	}

}
