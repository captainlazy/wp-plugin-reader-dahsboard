<?php


namespace GFLightspeedEVO\Model;


use Error;
use Illuminate\Support\Collection;
use SimpleXMLElement;

class Payload {
	private const ITEM_NAME = "Item";

	/**
	 * @var Collection
	 */
	private $leads;

	/**
	 * @var string
	 */
	private $name;

	/**
	 * @var SimpleXMLElement
	 */
	private $XMLPayload;

	/**
	 * @var string
	 */
	private $dealershipId;

	/**
	 * Payload constructor.
	 *
	 * @param Lead|Lead[] $leads
	 * @param string $dealershipId
	 * @param string $name
	 */
	public function __construct( $leads, string $dealershipId, $name = "AddProspect" ) {
		if ( ! is_array( $leads ) && ! ( $leads instanceof Lead ) ) {
			throw new Error( 'Must pass an instance of Lead or Lead[] in ' . self::class );
		}

		if ( empty( $dealershipId ) ) {
			throw new Error( 'DealershipID is required in settings' );
		}

		if ( ! is_array( $leads ) ) {
			$leads = [ $leads ];
		}
		$this->dealershipId = (string) $dealershipId;

		$this->leads = Collection::wrap( $leads )->transform( function ( Lead $lead ) {
			return $lead->toArray();
		} );

		$this->name = $name;
	}

	/**
	 * @return SimpleXMLElement
	 */
	public function toXML() {

		$this->XMLPayload = ( new SimpleXMLElement( "<{$this->name}/>" ) );

		$this->leads->each( function ( $val ) {
			$item = $this->XMLPayload->addChild( self::ITEM_NAME );

			$item->addChild( 'DealershipId', $this->dealershipId );

			Collection::wrap( $val )->each( function ( $val, $label ) use ( $item ) {
				$item->addChild( $label, htmlspecialchars( $val ) );
			} );
		} );


		return $this->XMLPayload;
	}


	/**
	 * @return mixed
	 */
	public function asXMLString() {
		if ( ! $this->XMLPayload && $this->XMLPayload instanceof SimpleXMLElement ) {
			return $this->XMLPayload->saveXML();
		}

		return $this->toXML()->saveXML();
	}

	/**
	 * @return array[]
	 */
	public function toArray() {
		$res = [ $this->name => [] ];

		$this->leads->each( function ( $lead ) use ( $res ) {
			$res[ $this->name ][] = [ self::ITEM_NAME => $lead ];
		} );

		return $res;

	}

}
