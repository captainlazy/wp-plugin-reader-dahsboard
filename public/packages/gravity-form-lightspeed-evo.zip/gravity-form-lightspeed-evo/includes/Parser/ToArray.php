<?php

namespace GFLightspeedEVO\Parser;

use SimpleXMLElement;

class ToArray {
	/**
	 * @var SimpleXMLElement
	 */
	public $data;

	/**
	 * @var string
	 */
	private $raw_xml;

	/**
	 * @var string|null
	 */
	private $name = null;


	/**
	 * ToArray constructor.
	 *
	 * @param string $xmlString
	 */
	public function __construct( string $xmlString ) {

		$this->raw_xml = $xmlString;
		$this->data    = new SimpleXMLElement( $xmlString );

		return $this;
	}

	/**
	 * @param SimpleXMLElement $xmlObject
	 *
	 * @return array
	 */
	private static function xmlToArray( SimpleXMLElement $xmlObject ) {
		$out = [];
		foreach ( (array) $xmlObject as $index => $node ) {
			$out[ $index ] = ( is_object( $node ) ) ? self::xmlToArray( $node ) : $node;
		}

		return $out;
	}

	public function withName() {
		$this->name = $this->data->getName();

		return $this;
	}

	public function toArray() {
		if ( $this->name ) {
			return [ $this->name => self::xmlToArray( $this->data ) ];
		}

		return self::xmlToArray( $this->data );
	}


}

