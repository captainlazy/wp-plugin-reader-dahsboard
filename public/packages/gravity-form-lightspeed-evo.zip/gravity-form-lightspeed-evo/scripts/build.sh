composer install --no-interaction --prefer-dist --optimize-autoloader
