<?php

namespace GFLightspeedEVO\Tests;

use GFLightspeedEVO\Model\Lead;
use GFLightspeedEVO\Model\Payload;
use PHPUnit\Framework\TestCase;

class PayloadTest extends TestCase
{
    protected const LEADS = [
        [
            'Email' => 'jondoe@example.com',
            'Name' => "Jon Doe",
            "Notes" => "Need New Boat"
        ],
        [
            'Email' => 'sam@example.com',
            'Name' => "Sam Foss",
            "Notes" => "Want to sell my boat"
        ]
    ];

    public function testSingleLeadPayload()
    {
        $lead = new Lead(self::LEADS[0]);
        $payload = new Payload($lead);
        $payloadResult = $payload->asXMLString();
        $this->assertStringContainsStringIgnoringCase('<?xml version="1.0"?>', $payloadResult);

        collect($lead->toArray())->each(function ($value, $label) use ($payloadResult) {
            $this->assertStringContainsStringIgnoringCase($value, $payloadResult);
            $this->assertStringContainsStringIgnoringCase("<{$label}>", $payloadResult);
            $this->assertStringContainsStringIgnoringCase("</{$label}>", $payloadResult);
        });
    }


    public function testMultipleLeadsPayload()
    {
        $leads = [];
        collect(self::LEADS)->each(function ($lead) use (&$leads) {
            $lead = new Lead($lead);

            $leads[] = $lead;

        });


        $payload = new Payload($leads);
        $payloadResult = $payload->asXMLString();


        echo "Payload in XML" . PHP_EOL;
        echo $payloadResult . PHP_EOL;


        $this->assertStringContainsStringIgnoringCase('<?xml version="1.0"', $payloadResult);

        collect(self::LEADS)->each(function ($lead) use ($payloadResult) {


            collect($lead)->each(function ($value, $label) use ($payloadResult) {
                $this->assertStringContainsStringIgnoringCase($value, $payloadResult);
                $this->assertStringContainsStringIgnoringCase("<{$label}>", $payloadResult);
                $this->assertStringContainsStringIgnoringCase("</{$label}>", $payloadResult);
            });
        });
    }

}
