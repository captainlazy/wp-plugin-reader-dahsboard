# nr-wp-theme editor
Edit template and less files in WP admin