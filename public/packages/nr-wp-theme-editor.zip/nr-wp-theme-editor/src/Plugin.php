<?php


namespace Nativerank\ThemeEditor;

use Nativerank\ThemeEditor\Core\Util\Scheduler;
use Puc_v4_Factory;

/**
 * Class Plugin
 * @package Nativerank\ThemeEditor
 */
class Plugin {

	/**
	 * The plugin context object.
	 *
	 * @var Context
	 */
	private $context;

	/**
	 * Main instance of the plugin.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Sets the plugin main file.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 */
	public function __construct( $main_file ) {
		$this->context = new Context( $main_file );
	}

	/**
	 * Retrieves the plugin context object.
	 *
	 * @return Context Plugin context.
	 */
	public function context() {
		return $this->context;
	}

	/**
	 * Registers the plugin with WordPress.
	 */
	public function register() {

		// Register any other classes
		$this->classes();

		$this->initialize();

		do_action( 'nr_theme_editor_init' );
	}

	public function initialize() {
		return [
			( new AdminPage() ),
		];
	}


	public function update_checker() {
		$this->updateChecker = Puc_v4_Factory::buildUpdateChecker(
			'https://wp-plugins.nativerank.com/wp-update-server/?action=get_metadata&slug=' . NR_THEME_EDITOR_DIR_NAME,
			NR_THEME_EDITOR_PLUGIN_MAIN_FILE,
			NR_THEME_EDITOR_DIR_NAME
		);
	}

	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR BP PLUGIN NAME instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load( $main_file ) {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static( $main_file );

		// register plugin after plugin is activated
		add_action( 'init', [ static::$instance, 'register' ], 100 );
		add_action( 'plugins_loaded', [ static::$instance, 'update_checker' ] );


		return true;
	}

	/**
	 * @return array
	 */
	public function classes() {
		return [
			( new Scheduler() ),
		];
	}

}
