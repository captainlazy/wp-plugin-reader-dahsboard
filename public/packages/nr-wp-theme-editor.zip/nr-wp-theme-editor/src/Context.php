<?php


namespace Nativerank\ThemeEditor;


/**
 * Class Context
 * @package Nativerank\ThemeEditor
 */
class Context {

}
