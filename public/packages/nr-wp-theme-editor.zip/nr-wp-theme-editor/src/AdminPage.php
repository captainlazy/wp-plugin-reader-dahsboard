<?php


namespace Nativerank\ThemeEditor;

class AdminPage {

	public function __construct() {
		if ( get_option( 'nativerank_seo_1055_subscriptionID' ) ) {
			add_action( 'admin_menu', [ $this, 'menu' ] );

			if ( is_admin() && isset( $_GET['page'] ) && $_GET['page'] == NR_THEME_EDITOR_DIR_NAME ) {
				add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ], 100 );
			}

			$this->ajax();
		}
	}

	public function menu() {
		add_menu_page(
			__( 'NR Theme Editor' ),
			__( 'NR Theme Editor' ),
			'administrator',
			NR_THEME_EDITOR_DIR_NAME,
			[ $this, 'contents' ],
			'dashicons-admin',
			2
		);
	}

	public function enqueue() {
		$uri = NR_THEME_EDITOR_PLUGIN_URI;
		wp_enqueue_style( 'nr-seo-1055-theme-editor-css', "${uri}/dist/main.min.css", [], WP_DEBUG ? null : NR_THEME_EDITOR_VERSION );
		wp_enqueue_style( 'nr-seo-1055-theme-editor-toasted-css', 'https://cdn.jsdelivr.net/npm/vue-toasted@1.1.28/dist/vue-toasted.min.css', [], null );
		wp_register_script( 'nr-seo-1055-theme-editor-monaco-loader', 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.20.0/min/vs/loader.min.js', [], null, true );
		// TODO: change src argument below for production
		wp_enqueue_script( 'nr-seo-1055-theme-editor', "{$uri}/dist/main.min.js", [
			'nr-seo-1055-theme-editor-monaco-loader',
			'lodash',
		], WP_DEBUG ? null : NR_THEME_EDITOR_VERSION, true );
	}

	public function contents() {
		?>
        <div class="nr_SEO_1055_theme_editor" id="nr_SEO_1055_theme_editor">
        </div>
		<?php
	}

	private function ajax() {
		$editorController = new EditorController();
		add_action( 'wp_ajax_nr_1055_theme_editor', [ $editorController, 'collectTheme' ] );
		add_action( 'wp_ajax_nr_1055_theme_editor_get_file_contents', [ $editorController, 'getFileContents' ] );
		add_action( 'wp_ajax_nr_1055_theme_editor_save_file', [ $editorController, 'saveFile' ] );
	}

}