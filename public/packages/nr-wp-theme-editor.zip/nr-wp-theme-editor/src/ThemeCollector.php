<?php


namespace Nativerank\ThemeEditor;


use Adbar\Dot;

class ThemeCollector {

	/**
	 * @var string
	 */
	private $templatesPath;

	/**
	 * @var
	 */
	private $themeRootPlaceholder;

	/**
	 * @var string
	 */
	private $lessPath;

	/**
	 * @var string
	 */
	private $partialsPath;

	/**
	 * @var
	 */
	private $childThemePath;

	/**
	 * @var array
	 */
	private $theme = [];

	/**
	 * @var string[]
	 */
	private $folders = [];

	private $currentFile = false;

	private $keysToSkipNesting = [
		'children',
		'state'
	];

	public function __construct( $currentFile = false ) {
		$this->childThemePath       = get_stylesheet_directory();
		$this->lessPath             = "{$this->childThemePath}/less/src/";
		$this->templatesPath        = "{$this->childThemePath}/templates/";
		$this->partialsPath         = "{$this->templatesPath}partials/";
		$this->themeRootPlaceholder = NR_THEME_EDITOR_THEME_FOLDER_ALIAS;
		$this->currentFile          = $currentFile;
	}

	public function getChildThemePath() {
		return $this->childThemePath;
	}

	/**
	 *
	 */
	private function findFolders() {
		$this->folders = array_filter( glob( $this->templatesPath . '*/' ), 'is_dir' );
		$this->folders = array_merge( array_filter( glob( $this->partialsPath . '*/' ), 'is_dir' ), $this->folders );
		$this->folders = array_merge( [
			$this->lessPath,
			$this->templatesPath
		], $this->folders );
	}

	public function collect() {
		$this->findFolders();
		$this->collectFolderFiles();

		return $this;
	}

	public function getTheme() {
		return $this->theme;
	}

	/**
	 * @return array|string
	 */
	function collectFolderFiles() {
		$tree  = new Dot();
		$files = [];

		foreach ( $this->folders as $path ) {
			if ( ! file_exists( $path ) ) {
				mkdir( $path, 0775, true );
			}

			if ( $handle = opendir( $path ) ) {
				while ( false !== ( $entry = readdir( $handle ) ) ) {

					$fileInfo = pathinfo( $entry );
					if ( $this->validateFilePath( $entry, $fileInfo ) ) {
						$filePath     = str_replace( '//', '/', "{$path}/{$entry}" );
						$relativePath = str_replace( $this->childThemePath, "", $filePath );
						$dotPath      = str_replace( $fileInfo['basename'], '', trim( $relativePath, '/' ) );
						$dotPath      = str_replace( '.', '', $dotPath );
						$dotPath      = rtrim( str_replace( '/', '.children.', $dotPath ), '.' );
						$id           = md5( $relativePath );
						$dot          = new Dot();

						$fileArray = [
							'id'       => $id,
							'text'     => $fileInfo['basename'],
							'path'     => $relativePath,
							'contents' => file_get_contents( $filePath )
						];

						$files[] = $fileArray;

						if ( $this->currentFile !== false && is_string( $this->currentFile ) && $id === $this->currentFile ) {
							$fileArray['state']['selected'] = true;
							$dot                            = $this->recursivelySetStateExpanded( $dot, $dotPath );
						}

						$dot->set( $dotPath, [ $fileArray ] );
						$tree->mergeRecursive( $dot );

					}
				}

				closedir( $handle );
			}
		}

		$tree                = $tree->all();
		$this->theme['tree'] = $this->recursivelyNestKeys( $tree );

		$this->theme['files'] = $files;

		$this->addCustomDataFile();

		set_transient( NR_THEME_EDITOR_THEME_TRANSIENT_NAME, $this->theme['files'] );

		return $this->theme;
	}

	private function recursivelySetStateExpanded( $dot, $dotPath ) {
		$parentDotPath = preg_replace( '/\.children$/i', '.state.expanded', $dotPath );
		$dot->set( $parentDotPath, true );
		do {
			$parentDotPath = preg_replace( '/\.children\.(?!.*\.children).*$/i', '.state.expanded', $parentDotPath );
			$dot->set( $parentDotPath, true );
		} while ( preg_match( '/children/i', $parentDotPath ) );

		return $dot;
	}

	private function recursivelyNestKeys( array $array ) {
		foreach ( $array as $key => $value ) {
			if ( is_string( $key ) && is_array( $value ) ) {
				if ( $key === 'children' ) {
					$value         = $this->recursivelyNestKeys( $value );
					$array[ $key ] = $value;
				}
				if ( array_search( $key, $this->keysToSkipNesting ) !== false ) {
					continue;
				}
				$value         = $this->recursivelyNestKeys( $value );
				$value['text'] = $key;
				$array[]       = $value;
				unset( $array[ $key ] );
			}
		}

		return $array;
	}

	private function addCustomDataFile() {
		$relativeCustomDataPath = 'data.json';
		$customDataPath         = "{$this->childThemePath}/{$relativeCustomDataPath}";
		if ( file_exists( $customDataPath ) ) {
			$customData             = [
				'id'       => md5( $relativeCustomDataPath ),
				'text'     => $relativeCustomDataPath,
				'path'     => $relativeCustomDataPath,
				'icon'     => 'mdi-file-icon',
				'contents' => file_get_contents( $customDataPath )
			];
			$this->theme['tree'][]  = $customData;
			$this->theme['files'][] = $customData;
		}
	}

	public function validateFilePath( $entry, $fileInfo ) {
		return array_key_exists( 'extension', $fileInfo )
		       && $entry != "."
		       && $entry != ".."
		       && (
			       $fileInfo['extension'] == 'hbs'
			       || $fileInfo['extension'] == 'less'
			       || $fileInfo['basename'] == 'data.json'
		       );
	}


}