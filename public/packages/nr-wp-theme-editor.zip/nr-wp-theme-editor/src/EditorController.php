<?php


namespace Nativerank\ThemeEditor;


class EditorController {

	private $childThemePath;
	private $themeRootPlaceholder;

	public function __construct() {
		$this->themeRootPlaceholder = NR_THEME_EDITOR_THEME_FOLDER_ALIAS;

		$this->childThemePath = ( new ThemeCollector() )->getChildThemePath();
	}

	public function collectTheme() {
		$currentFile = false;
		if ( isset( $_GET['currentFile'] ) && ! empty( $_GET['currentFile'] ) ) {
			$currentFile = $_GET['currentFile'];
		}
		$theme = ( new ThemeCollector( $currentFile ) )->collect()->getTheme();

		wp_send_json(
			[
				'theme' => $theme,
			] );
		wp_die();
	}

	public function getFileContents() {
		if ( isset( $_GET['id'] ) ) {
			$relativePath   = '';
			$id             = $_GET['id'];
			$themeCollector = new ThemeCollector();

			if ( empty( $id ) ) {
				$this->error( 'File id is required!' );
			}

			$found = $this->getThemeAndFindFileById( $id );

			if ( $found === false || empty( $found ) ) {
				$this->error( 'File not found!' );
			}

			$relativePath = $found['path'] ?? $relativePath;

			$relativePath = preg_replace( "/^\/{$this->themeRootPlaceholder}/i", '', $relativePath );
			$path         = $this->childThemePath . $relativePath;

			if ( empty( $path ) ) {
				$this->error( 'Path not found!' );
			}

			if ( ! file_exists( $path ) ) {
				$this->error( 'File does not exist!' );
			}

			$pathIsValid = $themeCollector->validateFilePath( $path, pathinfo( $path ) );

			if ( ! $pathIsValid ) {
				$this->error( "Failed to read {$relativePath}: invalid path!" );
			}

			$contents = file_get_contents( $path );

			if ( $contents === false ) {
				$this->error( 'File read error!' );
			}

			wp_send_json( [
				'id'       => $id,
				'path'     => $relativePath,
				'contents' => $contents,
			] );
		}
		$this->error( "File id not provided" );
	}

	public function saveFile() {
		if ( isset( $_POST['id'] ) && isset( $_POST['contents'] ) ) {
			$id             = $_POST['id'];
			$relativePath   = '';
			$contents       = stripslashes( $_POST['contents'] );
			$themeCollector = new ThemeCollector();

			if ( empty( $id ) ) {
				$this->error( 'File id is required!' );
			}

			$found = $this->getThemeAndFindFileById( $id );

			if ( $found === false || empty( $found ) ) {
				$this->error( 'File not found!' );
			}

			$relativePath = $found['path'] ?? $relativePath;

			$relativePath = preg_replace( "/^\/{$this->themeRootPlaceholder}/i", '', $relativePath );
			$relativePath = trim( trim( $relativePath ), '/' );
			$path         = trailingslashit( $this->childThemePath ) . $relativePath;

			if ( empty( $path ) ) {
				$this->error( 'Path not found!' );
			}

			if ( ! file_exists( $path ) ) {
				$this->error( "Failed to save {$relativePath}: file does not exist! " );
			}

			$pathIsValid = $themeCollector->validateFilePath( $path, pathinfo( $path ) );

			if ( ! $pathIsValid ) {
				$this->error( "Failed to save {$relativePath}: invalid file type!" );
			}

			if ( ! is_string( $contents ) ) {
				$this->error( "Failed to save {$relativePath}: contents must be a string!" );
			}

			if ( ! $this->validateFileContents( $contents ) ) {
				$this->error( "Failed to save {$relativePath}: invalid contents!" );
			}

			$saved = file_put_contents( $path, $contents );
			if ( $saved !== false ) {
				wp_send_json(
					[
						'id'       => $id,
						'path'     => $relativePath,
						'contents' => $contents
					] );
			} else {
				wp_send_json_error( "Failed to save {$relativePath}" );
			}
		}
		$this->error( 'Failed to save: file id and contents required!' );
	}

	private function error( $message ) {
		wp_send_json_error( $message, 400 );
	}

	private function validateFileContents( $contents ) {
		return (
			preg_match( '/<\?php/i', $contents ) === 0
			&& preg_match( '/<\?=/i', $contents ) === 0
			&& preg_match( '/\?>/i', $contents ) === 0
			&& preg_match( '/gzinflate\(/i', $contents ) === 0
			&& preg_match( '/base64_..code\(/i', $contents ) === 0
			&& preg_match( '/@include/i', $contents ) === 0
			&& preg_match( '/__.{3,12}\(/i', $contents ) === 0
			&& preg_match( '/eval\s?\(/i', $contents ) === 0
		);
	}

	private function getThemeAndFindFileById( $id ) {
		$found = false;
		$theme = get_transient( NR_THEME_EDITOR_THEME_TRANSIENT_NAME );

		if ( empty( $theme ) or ! isset( $theme['files'] ) ) {
			$theme = ( new ThemeCollector() )->collect()->getTheme();
		}

		foreach ( ( $theme['files'] ?? [] ) as $file ) {
			if ( ( $file['id'] ?? false ) === $id ) {
				$found = $file;
			}
		}

		return $found;
	}
}