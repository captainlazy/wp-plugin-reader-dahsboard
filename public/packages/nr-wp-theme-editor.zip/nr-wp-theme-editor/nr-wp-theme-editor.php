<?php

/*
Plugin Name: NR Theme Editor
Plugin URI: https://nativerank.com
Description: Edit NativeRank Wordpress Child Theme
Version: 0.2.2
Author: Native Rank
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_THEME_EDITOR_VERSION', '0.2.2' );
define( 'NR_THEME_EDITOR_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_THEME_EDITOR_PHP_MINIMUM', '5.6.0' );
define( 'NR_THEME_EDITOR_DIR_NAME', basename( __DIR__ ) );
define( 'NR_THEME_EDITOR_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_THEME_EDITOR_PLUGIN_URI', plugins_url( NR_THEME_EDITOR_DIR_NAME ) );
define( 'NR_THEME_EDITOR_THEME_TRANSIENT_NAME', NR_THEME_EDITOR_DIR_NAME . '_theme_files' );
define( 'NR_THEME_EDITOR_THEME_FOLDER_ALIAS', 'nrThemeRoot' );

define( 'NR_THEME_EDITOR_TEMPLATES_DIR', NR_THEME_EDITOR_PLUGIN_PATH . 'templates/' );
define( 'NR_THEME_EDITOR_PARTIALS_DIR', NR_THEME_EDITOR_TEMPLATES_DIR . 'partials/' );

if ( class_exists( '\Nativerank\ThemeEditor\Plugin' ) ) {
	die();
}

require 'vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_THEME_EDITOR_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR BP PLUGIN NAME requires PHP version %s', 'nr-theme-editor' ), NR_THEME_EDITOR_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-theme-editor' )
		);
	}

	//Create DB Tables
	( new \Nativerank\ThemeEditor\Database\Migrations() );


	do_action( 'nr_theme_editor_activation' );

} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_THEME_EDITOR_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_theme_editor_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_theme_editor_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_THEME_EDITOR_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_theme_editor_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_THEME_EDITOR_PHP_MINIMUM, '>=' ) ) {

	\Nativerank\ThemeEditor\Plugin::load( NR_THEME_EDITOR_PLUGIN_MAIN_FILE );

}


