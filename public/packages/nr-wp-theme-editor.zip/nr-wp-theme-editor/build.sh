#!/usr/bin/env bash

rm -rf vendor
rm composer-lock.json
composer install --no-interaction --no-dev --prefer-dist

cd app || exit

npm i

npx google-closure-compiler --js=main.js --js_output_file=../dist/main.min.js
curl -X POST -s --data-urlencode 'input@main.css' https://cssminifier.com/raw > ../dist/main.min.css

