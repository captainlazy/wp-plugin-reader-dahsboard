<?php

/*
Plugin Name: NR Manuals
Plugin URI: https://nativerank.com
Description:  
Version: 0.0.2
Author: Native Rank
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Define most essential constants.
define( 'NR_MANUALS_VERSION', '0.0.2' );
define( 'NR_MANUALS_PLUGIN_MAIN_FILE', __FILE__ );
define( 'NR_MANUALS_PHP_MINIMUM', '5.6.0' );
define( 'NR_MANUALS_DIR_NAME', basename( __DIR__ ) );
define( 'NR_MANUALS_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'NR_MANUALS_PLUGIN_URI', plugins_url( NR_MANUALS_DIR_NAME ) );
define( 'NR_MANUALS_PLUGIN_REST_NAMESPACE', 'nr-wp-manuals/v1' );

define( 'NR_MANUALS_TEMPLATES_DIR', NR_MANUALS_PLUGIN_PATH . 'templates/' );
define( 'NR_MANUALS_PARTIALS_DIR', NR_MANUALS_TEMPLATES_DIR . 'partials/' );

if ( class_exists( '\Nativerank\Manuals\Plugin' ) ) {
	die();
}

require 'vendor/autoload.php';

/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook( __FILE__, function () {
	if ( version_compare( PHP_VERSION, NR_MANUALS_PHP_MINIMUM, '<' ) ) {
		wp_die(
		/* translators: %s: version number */
			esc_html( sprintf( __( 'NR BP PLUGIN NAME requires PHP version %s', 'nr-manuals' ), NR_MANUALS_PHP_MINIMUM ) ),
			esc_html__( 'Error Activating', 'nr-manuals' )
		);
	}

	//Create DB Tables
	( new \Nativerank\Manuals\Database\Migrations() );


	do_action( 'nr_manuals_activation' );

} );


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_MANUALS_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_manuals_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_manuals_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_MANUALS_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_manuals_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_MANUALS_PHP_MINIMUM, '>=' ) ) {

	\Nativerank\Manuals\Plugin::load( NR_MANUALS_PLUGIN_MAIN_FILE );

}

add_action( 'init', function () {
	if ( file_exists( NR_MANUALS_PLUGIN_PATH . 'nr-template-hooks.php' ) ) {
		include NR_MANUALS_PLUGIN_PATH . 'nr-template-hooks.php';
	}
} );

