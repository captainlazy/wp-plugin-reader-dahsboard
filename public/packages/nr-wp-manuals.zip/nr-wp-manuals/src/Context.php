<?php


namespace Nativerank\Manuals;


/**
 * Class Context
 * @package Nativerank\Manuals
 */
class Context {

}
