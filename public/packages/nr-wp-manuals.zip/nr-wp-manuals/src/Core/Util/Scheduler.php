<?php


namespace Nativerank\Manuals\Core\Util;


class Scheduler
{

	protected $events = [];
	protected $time_between_events = 180;
	protected $interval = 'daily';

	public function __construct()
	{
		add_filter('cron_schedules', [$this, 'add_intervals']);
		$this->add_actions();
		$this->add_cron_events();
	}

	private function add_actions()
	{
		foreach ($this->events as $event) {
			$callback = [$this, "{$event}_cron_callback"];
			if (is_callable($callback)) {
				add_action("{$event}_cron_hook", $callback);
			}
		}
	}

	public function add_intervals($schedules)
	{
//		$schedules['half_hour'] = array(
//			'interval' => $this->interval,
//			'display'  => esc_html__( 'Every half hour' ),
//		);

		return $schedules;
	}

	private function add_cron_events()
	{
		foreach ($this->events as $index => $event) {
			if (!wp_next_scheduled("{$event}_cron_hook")) {
				wp_schedule_event(time() + ($this->time_between_events * $index), $this->interval, "{$event}_cron_hook");
			}
		}
	}

}