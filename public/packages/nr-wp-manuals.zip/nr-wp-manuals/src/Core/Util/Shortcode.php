<?php


namespace Nativerank\Manuals\Core\Util;


class Shortcode
{

	protected $name;

	public function __construct()
	{

		add_shortcode($this->name, [$this, 'callback']);
	}

	public function callback()
	{

	}

}