<?php


namespace Nativerank\Manuals\Resources;

use App\Models\Manual as ManualModel;

class Manual {

	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;


	public function __construct( $name = 'Manual' ) {
		$this->resource = tr_resource_pages( $name, null, [ 'position'   => 1,
		                                                    'capability' => 'edit_posts'
		] )->setIcon( 'books' );

		return $this->resource;
	}

	public static function mappedManualsWithCategories() {
		$manuals = ( new ManualModel() )->get();
		if ( ! $manuals ) {
			return [];
		}
		$manuals = $manuals->toArray();
		$manuals = array_map( function ( $manual ) {

			$categories = ( new ManualModel() )->findById( $manual['id'] )->manual_categories()->get();
			if ( $categories ) {
				$categories = $categories->toArray();
				$categories = array_map( function ( $category ) {
					return [ 'id' => $category['id'], 'category' => $category['name'] ];
				}, $categories );

			}

			if ( ! isset( $manual['pdf'] ) || empty( $manual['pdf'] ) ) {
				return array_merge( $manual, [ 'categories' => $categories ] );
			}

			$manual['pdf'] = wp_get_attachment_url( $manual['pdf'] );

			return array_merge( $manual, [ 'categories' => $categories ] );
		}, $manuals );

		return $manuals;
	}


	public function apiRoutes() {
		register_rest_route( NR_MANUALS_PLUGIN_REST_NAMESPACE, '/manuals/all', array(
			'methods'  => 'GET',
			'callback' => [ $this, 'mappedManualsWithCategories' ]
		) );
	}

}