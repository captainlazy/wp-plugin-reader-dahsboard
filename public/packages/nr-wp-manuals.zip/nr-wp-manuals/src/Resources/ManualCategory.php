<?php


namespace Nativerank\Manuals\Resources;


class ManualCategory {

	/**
	 * @var \TypeRocket\Register\Page
	 */
	protected $resource;

	public function __construct( $name = 'Manual Category' ) {
		$singular = 'Manual Category';

		$delete = tr_page( $name, 'delete', 'Delete ' . $singular, [ 'capability' => 'edit_posts' ] )
			->mapActions( [
				'DELETE' => 'destroy',
			] );

		$edit = tr_page( $name, 'edit', __( 'Edit ' . $singular ), [ 'capability' => 'edit_posts' ] )
			->mapActions( [
				'GET' => 'edit',
				'PUT' => 'update',
			] );

		foreach ( [ $edit, $delete ] as $page ) {
			/** @var \TypeRocket\Register\Page $page */
			$page->useController();
			add_action( 'admin_init', function () use ( $page ) {
				remove_menu_page( $page->getSlug() );
			} );
		}
	}

	public static function getManualsByCategory() {
		$categories      = ( new \App\Models\ManualCategory() )->get();
		$categoriesArray = [];
		if ( $categories ) {
			foreach ( $categories as $category ) {
				$manuals = $category->manuals()->get();
				if ( $manuals ) {
					$manuals = $manuals->toArray();
					$manuals = array_map( function ( $manual ) {
						if ( ! isset( $manual['pdf'] ) || empty( $manual['pdf'] ) ) {
							return $manual;
						}
						$manual['pdf'] = wp_get_attachment_url( $manual['pdf'] );

						return $manual;
					}, $manuals );
					usort( $manuals, function ( $a, $b ) {
						return $a['id'] < $b['id'] ? - 1 : ( ( $a['id'] > $b['id'] ) ? 1 : 0 );
					} );
					$categoriesArray[ $category->name ] = $manuals;
				}
			}
		}

		return $categoriesArray;

	}

	public function apiRoutes() {
		register_rest_route( NR_MANUALS_PLUGIN_REST_NAMESPACE, '/manual-categories/all', array(
			'methods'  => 'GET',
			'callback' => [ $this, 'getManualsByCategory' ]
		) );
	}
}