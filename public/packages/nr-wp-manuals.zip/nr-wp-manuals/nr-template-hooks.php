<?php

/*
 * Use this file to modify NRTemplate
 * with the hooks
 * nr_1055_template_helpers
 * nr_1055_template_data
 * nr_1055_template_partials
 * nr_1055_template_files_FILENAME
 *
 * Some of these hooks are already being used below
 * See other comments for built-in shortcuts to use them
 *
 */

// add helpers to NRTemplate, in the $newHelpers array
// as 'name' => function() {} pairs
$newHelpers = [
	// or register static functions from \Nativerank\Manuals\Core\Util\Helper
	// by name (key only, no value), like this
	'strip_url'
];
$newHelpers = \Nativerank\Manuals\Core\Util\Helper::getHelpers( $newHelpers );

add_filter( 'nr_1055_template_helpers', function ( $helpers ) use ( $newHelpers ) {
	foreach ( $newHelpers as $name => $callback ) {
		$helpers[ $name ] = $callback;
	}

	return $helpers;
}, 11 );

// You can add filters like this to modify data
// just set a key in $data with the name of your
// data variable
add_filter( 'nr_1055_template_data', function ( $data ) {
	// for example,
	// $data['galleryImages'] = SOME VALUE;
	return $data;
} );


add_filter( 'nr_1055_template_helpers', function ( $helpers ) use ( $newHelpers ) {

	foreach ( $newHelpers as $name => $callback ) {
		$helpers[ $name ] = $callback;
	}

	return $helpers;
}, 11 );

/*
 * STOP EDITING
 * These filters allow you to add/overwrite partials and templates in the theme.
 * Just place files in the /templates
 * and /templates/partials directories inside this plugin's root directory
 * Then you can use them for nr_page_type
 * or use the partials in your templates
 *
 * WARNING
 * If you name a template or partial the same as one in your theme, it will override it
 *
 * There is also a directory inside partials, named after the plugin, manuals/
 * Putting partials in there is an easy way to scope them to your plugin
 * and avoid name conflicts
 *
 * */

if ( ! empty( NR_MANUALS_TEMPLATES_DIR ) ) {
	if ( ! file_exists( NR_MANUALS_TEMPLATES_DIR ) ) {
		mkdir( NR_MANUALS_TEMPLATES_DIR, 0775, true );
	}
	if ( $handle = opendir( NR_MANUALS_TEMPLATES_DIR ) ) {
		while ( false !== ( $entry = readdir( $handle ) ) ) {
			$fileInfo = pathinfo( $entry );
			if ( array_key_exists( 'extension', $fileInfo ) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs' ) {
				add_filter( 'nr_1055_template_files_' . $fileInfo['filename'], function ( $templateString ) use ( $fileInfo ) {
					$replacement = NR_MANUALS_TEMPLATES_DIR . $fileInfo['filename'] . '.hbs';
					if ( file_exists( $replacement ) ) {
						return file_get_contents( $replacement );
					}

					return $templateString;
				}, 20 );
			}
		}
		closedir( $handle );
	}
	if ( ! empty( NR_MANUALS_PARTIALS_DIR ) ) {
		if ( ! file_exists( NR_MANUALS_PARTIALS_DIR ) ) {
			mkdir( NR_MANUALS_PARTIALS_DIR, 0775, true );
		}
		if ( ! file_exists( NR_MANUALS_PARTIALS_DIR . "manuals/" ) ) {
			mkdir( NR_MANUALS_PARTIALS_DIR . "manuals/", 0775, true );
		}
		add_filter( 'nr_1055_template_partials', function ( $partials ) {
			$dirs = array_filter( glob( NR_MANUALS_PARTIALS_DIR . '*/' ), 'is_dir' );

			foreach ( $dirs as $path ) {

				if ( $handle = opendir( $path ) ) {
					while ( false !== ( $entry = readdir( $handle ) ) ) {

						$fileInfo = pathinfo( $entry );
						if ( array_key_exists( 'extension', $fileInfo ) && $entry != "." && $entry != ".." && $fileInfo['extension'] == 'hbs' ) {
							if ( strpos( $path, NR_MANUALS_PARTIALS_DIR ) > - 1 ) {
								$sub = rtrim( str_replace( NR_MANUALS_PARTIALS_DIR, '', $path ), '/' );
							} else {
								$sub = rtrim( preg_replace( '/.*\/partials\/(.*)/', '$1', $path ), '/' );
							}

							$fileName              = empty( $sub ) ? $fileInfo['filename'] : $sub . '.' . $fileInfo['filename'];
							$partials[ $fileName ] = file_get_contents( $path . $entry );
						}
					}

					closedir( $handle );
				}
			}

			return $partials;
		}, 20 );
	}
}