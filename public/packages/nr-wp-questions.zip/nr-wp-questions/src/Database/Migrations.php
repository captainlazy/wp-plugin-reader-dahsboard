<?php


namespace Nativerank\Questions\Database;


use wpdb;

/**
 * Class Migrations
 * @package Nativerank\Dealer\Database
 */
class Migrations {

	/**
	 * @var wpdb
	 */
	protected $db;

	/**
	 * @var string
	 */
	protected $charset_collate;

	/**
	 * @var string
	 */
	protected $db_prefix;

	/**
	 * Migrations constructor.
	 */
	public function __construct() {
		global $wpdb;

		$this->db              = $wpdb;
		$this->charset_collate = $wpdb->get_charset_collate();
		$this->db_prefix       = $wpdb->prefix;

		$this->register_all_DBs();
	}


	/**
	 * Register Tables
	 * @return array[] each set of arrays will contain [TableSchema function, TableName]
	 */
	private function register() {
		return [
			[ 'questionSchema', 'questions' ],
			[ 'categorySchema', 'faqcategories' ],
			[ 'categoriesAndQuestionsSchema', 'faqcategories_questions' ]
		];
	}


	/**
	 * @return string[]
	 */
	private function questionSchema() {
		return [
            'id BIGINT(20) NOT NULL AUTO_INCREMENT',
            'question VARCHAR(255) DEFAULT NULL',
            'answer TEXT DEFAULT NULL',
            'resources TEXT DEFAULT NULL',
            'modified INT(11)',
            'created INT(11) DEFAULT \'00000000000\' NOT NULL',
            'UNIQUE KEY id (id)'
        ];
	}

	private function categorySchema() {
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'name VARCHAR(60) DEFAULT NULL',
			'UNIQUE KEY id (id)'
		];
	}

	private function categoriesAndQuestionsSchema() {
		return [
			'id BIGINT(20) NOT NULL AUTO_INCREMENT',
			'questions_id BIGINT(20) NOT NULL',
			'faqcategories_id BIGINT(20) NOT NULL',
			'UNIQUE KEY id (id)'
		];
	}

	/**
	 *
	 * @param string[]|string $queries Optional. The query to run. Can be multiple queries
	 *                                 in an array, or a string of queries separated by
	 *                                 semicolons. Default empty string.
	 */
	private function dbDelta( $queries ) {
		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $queries );
	}

	// Register all DBs
	private function register_all_DBs() {
		foreach ( $this->register() as $db ) {
			$table_name = $this->db_prefix . $db[1];
			$tableCols  = $this->{$db[0]}();
			$tableCols  = implode( ",\n", $tableCols );
			$sql        = sprintf( "CREATE TABLE `%s` ( %s ) %s;", $table_name, $tableCols, $this->charset_collate );
			$this->dbDelta( $sql );
		}

	}

}
