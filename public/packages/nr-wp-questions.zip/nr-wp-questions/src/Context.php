<?php


namespace Nativerank\Questions;


/**
 * Class Context
 * @package Nativerank\Dealer
 */
class Context
{

}
