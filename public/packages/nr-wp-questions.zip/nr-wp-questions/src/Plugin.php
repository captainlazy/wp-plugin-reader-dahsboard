<?php


namespace Nativerank\Questions;


use Nativerank\Questions\Core\Custom_Resource;
use Nativerank\Questions\Core\Shortcodes\Questions_By_Category;
use Nativerank\Questions\Core\Shortcodes\Questions_View;
use Nativerank\Questions\Core\Structured_Data;
use Nativerank\Questions\Core\Util\Shortcode;
use Nativerank\Questions\Resources\FaqCategory;
use Nativerank\Questions\Resources\Question;
use TypeRocket\Register\PostType;
use TypeRocket\Register\Resourceful;
use TypeRocket\Register\Taxonomy;


/**
 * Class Plugin
 * @package Nativerank\Dealer
 */
class Plugin
{

    /**
     * The plugin context object.
     *
     * @var Context
     */
    private $context;

    /**
     * Main instance of the plugin.
     *
     * @var Plugin|null
     */
    private static $instance = null;

    private $resources = [];

    /**
     * Sets the plugin main file.
     *
     * @param string $main_file Absolute path to the plugin main file.
     *
     */
    public function __construct($main_file)
    {
        $this->context = new Context($main_file);
    }

    /**
     * Retrieves the plugin context object.
     *
     * @return Context Plugin context.
     */
    public function context()
    {
        return $this->context;
    }

    /**
     * Registers the plugin with WordPress.
     */
    public function register()
    {

        // Register CTP & CTT
        $this->customPostTypes();

        // Register Custom Resources
        $this->resources();

        //Install Add-ons
        $this->addOns();

        $this->shortcodes();

        $this->restRoutes();

        do_action('nr_questions_init');
    }

    /**
     * Register Custom Post Types and Taxonomies
     * @return PostType[]|Taxonomy[]
     */
    public function customPostTypes()
    {
        return [
//            Custom_Post_Type::make('Dealer')
        ];
    }

    /**
     * @return Resourceful[]
     */
    public function resources()
    {
        $this->resources = [
            (new Question()),
            (new FaqCategory())
        ];

        return $this->resources;
    }

    /**
     * @return Shortcode[]
     */
    public function shortcodes()
    {
        return [
            new Questions_View(),
            new Questions_By_Category(),
        ];
    }

    /**
     * @param callable[] $functions
     */
    public function addOns($functions = [])
    {
        $functions = array_merge($functions, [
            [$this, 'installStructuredData']
        ]);

        foreach ($functions as $function) {
            call_user_func($function);
        }
    }


    private function restRoutes()
    {
        if (empty($this->resources)) {
            return false;
        }

        foreach ($this->resources as $resource) {
            if (method_exists($resource, 'apiRoutes')) {
                add_action('rest_api_init', [$resource, 'apiRoutes']);
            }
        }

    }

    private function installStructuredData()
    {
        $schema = (new Structured_Data());

        $questions = (new \App\Models\Question())->findAll()->get();

        if (empty($questions)) {
            return;
        }

        $schema->setData($questions->toArray())->selfInstall(NR_QUESTIONS_PLUGIN_ACTION_IDENTIFIER . '-content-pre-render');

    }

	/**
	 * Retrieves the main instance of the plugin.
	 *
	 *
	 * @return Plugin NR Dealer instance.
	 */
	public static function instance() {
		return static::$instance;
	}

	/**
	 * Loads the plugin main instance and initializes it.
	 *
	 * @param string $main_file Absolute path to the plugin main file.
	 *
	 * @return bool True if the plugin main instance could be loaded, false otherwise.
	 */
	public static function load( $main_file ) {
		if ( null !== static::$instance ) {
			return false;
		}

		static::$instance = new static( $main_file );

		// register plugin after typerocket is loaded
		add_action( 'typerocket_loaded', [ static::$instance, 'register' ] );
		opcache_reset();

		return true;
	}


}
