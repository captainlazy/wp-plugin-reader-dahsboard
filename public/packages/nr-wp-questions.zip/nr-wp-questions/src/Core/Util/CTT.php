<?php


namespace Nativerank\Questions\Core\Util;


use TypeRocket\Register\Taxonomy;

class CTT extends Taxonomy
{


    /**
     *  Custom Taxonomy Name
     *
     * @var string
     */
    protected $name;

    /**
     *  Custom Taxonomy Unique ID
     *
     * @var string
     */
    protected $id;


    /**
     * Custom Taxonomy Object
     *
     * @var \TypeRocket\Register\Taxonomy
     */
    protected $taxonomy;


    /**
     * CPT constructor.
     * Create a new Custom Taxonomy
     *
     * @param $name string Name of Custom Taxonomy
     * @param $settings array Custom Taxonomy $args
     * https://developer.wordpress.org/reference/functions/register_post_type/#parameters
     *
     * @return \TypeRocket\Register\Taxonomy
     */
    public function __construct($name, $settings = [])
    {

        $this->name = $name;
        $this->taxonomy = tr_taxonomy($name, null, $settings);
        return $this->taxonomy;
    }


    /**
     * Create a new CTT.
     *
     * @return static
     */
    public static function make(...$arguments)
    {
        return new static(...$arguments);
    }
}
