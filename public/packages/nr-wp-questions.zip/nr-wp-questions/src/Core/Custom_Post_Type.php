<?php

namespace Nativerank\Questions\Core;


use Nativerank\Questions\Core\Util\CPT;

/**
 * Class Custom_Post_Type
 */
class Custom_Post_Type extends CPT
{


}
