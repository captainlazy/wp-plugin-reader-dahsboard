<?php


namespace Nativerank\Questions\Core;


class Structured_Data {

	const FAQ_PAGE_TYPE = 'FAQPage';

	const SCHEMA_CONTEXT = 'https://schema.org';

	protected $schema;

	public function __construct() {

		$this->schema = (object) [
			"@context"   => self::SCHEMA_CONTEXT,
			"@type"      => self::FAQ_PAGE_TYPE,
			"mainEntity" => []
		];

		return $this;
	}

	/**
	 * @param array[] $data
	 *  Example Input [['question' => 'This is Question One', 'answer' => 'This is Answer One'], ['question' => 'This is Question Two', 'answer' => 'This is Answer Two']]
	 *
	 * @return Structured_Data
	 */
	public function setData( $data = [] ) {
		foreach ( $data as $datum ) {
			$question = $datum['question'] ?? $datum->question;
			$answer   = $datum['answer'] ?? $datum->answer;
			if ( is_array( $this->schema->mainEntity ) ) {
				$this->schema->mainEntity[] = ( new Schema_Question( $question, $answer ) )->get();
			}
		}

		return $this;
	}

	/**
	 * @return object
	 */
	public function raw() {
		return $this->schema;
	}


	/**
	 * @return false|string
	 */
	public function renderHTML() {
		ob_start();
		// @formatter:off
		?>
        <script type="application/ld+json">
            <?= json_encode( $this->raw() ); ?>




        </script>
		<?php
		// @formatter:on

		return ob_get_clean();
	}

	public function selfInstall( $hook ) {
		add_action( $hook, function () {
			echo $this->renderHTML();
		} );
	}

}


class Schema_Question {

	const TYPE_QUESTION = 'Question';
	const TYPE_ANSWER = 'Answer';
	private $question;
	private $answer;

	public function __construct( $question, $answer ) {
		$this->question = $question;
		$this->answer   = $answer;

		return $this;
	}


	public function get() {
		return (object) [

			"@type"          => self::TYPE_QUESTION,
			"name"           => $this->question,
			"acceptedAnswer" => (object) [
				"@type" => self::TYPE_ANSWER,
				"text"  => $this->answer
			]

		];
	}
}
