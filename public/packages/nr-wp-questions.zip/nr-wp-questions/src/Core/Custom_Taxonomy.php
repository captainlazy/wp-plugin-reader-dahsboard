<?php

namespace Nativerank\Questions\Core;


use Nativerank\Questions\Core\Util\CTT;

/**
 * Class Custom_Taxonomy
 */
class Custom_Taxonomy extends CTT
{


}
