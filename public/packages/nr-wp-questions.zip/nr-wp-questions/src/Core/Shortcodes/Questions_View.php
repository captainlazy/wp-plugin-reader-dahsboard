<?php


namespace Nativerank\Questions\Core\Shortcodes;


use Nativerank\Questions\Core\Util\Shortcode;

class Questions_View extends Shortcode {

	protected $name = 'nr_questions';

	public function callback() {
		$categories   = ( new Questions_By_Category() )->callback();
		$questions    = ( new Mapped_Questions_With_Categories() )->callback();
		$overrideView = get_stylesheet_directory() . '/questions_index.php';
		if ( file_exists( $overrideView ) ) {
			ob_start();
			include $overrideView;

			return ob_get_clean();
		}
		$view = tr_view( 'questions.index', [ 'categories' => $categories, 'questions' => $questions ] );

		ob_start();

		$view::load();

		return ob_get_clean();
	}

}