<?php


namespace Nativerank\Questions\Core\Shortcodes;


use Nativerank\Questions\Core\Util\Shortcode;
use Nativerank\Questions\Resources\Question;

class Mapped_Questions_With_Categories extends Shortcode {
	protected $name = 'nr_mapped_questions_with_categories';

	public function callback() {
		return Question::mappedQuestionsWithCategories();
	}

}