<?php


namespace Nativerank\Questions\Core\Shortcodes;


use Nativerank\Questions\Core\Util\Shortcode;
use Nativerank\Questions\Resources\FaqCategory;

class Questions_By_Category extends Shortcode {
	protected $name = 'nr_questions_by_category';

	public function callback() {
		return FaqCategory::getQuestionsByCategory();
	}
}