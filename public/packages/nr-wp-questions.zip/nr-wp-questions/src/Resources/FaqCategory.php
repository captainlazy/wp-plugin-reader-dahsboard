<?php


namespace Nativerank\Questions\Resources;


class FaqCategory {
	protected $resource;

	public function __construct( $name = 'FaqCategory' ) {
//		$this->resource = tr_resource_pages( 'FAQ Category', 'FAQ Categories', [], $name );
		$singular = 'FAQ Category';

		$delete = tr_page( $name, 'delete', 'Delete ' . $singular, [ 'capability' => 'edit_posts' ] )
			->mapActions( [
				'DELETE' => 'destroy',
			] );

		$edit = tr_page( $name, 'edit', __( 'Edit ' . $singular ), [ 'capability' => 'edit_posts' ] )
			->mapActions( [
				'GET' => 'edit',
				'PUT' => 'update',
			] );

		foreach ( [ $edit, $delete ] as $page ) {
			/** @var \TypeRocket\Register\Page $page */
			$page->useController();
			add_action( 'admin_init', function () use ( $page ) {
				remove_menu_page( $page->getSlug() );
			} );
		}
	}

	public static function getQuestionsByCategory() {
		$categoryObjects = ( new \App\Models\FaqCategory() )->get();
		$categoriesArray = [];
		if ( $categoryObjects ) {
			foreach ( $categoryObjects as $categoryObject ) {
				$categoryQuestions = $categoryObject->questions()->get();
				if ( $categoryQuestions ) {
					$categoryQuestions = $categoryQuestions->toArray();
					usort( $categoryQuestions, function ( $a, $b ) {
                        return strnatcmp($a['question'], $b['question']);
                    });
                    $categoriesArray[$categoryObject->name] = $categoryQuestions;
                }
            }
        }

        return $categoriesArray;

    }

    public function apiRoutes()
    {
        register_rest_route(NR_QUESTIONS_PLUGIN_REST_NAMESPACE, '/faq-categories/all', array(
            'methods' => 'GET',
            'callback' => [$this, 'getQuestionsByCategory']
        ));
    }

}
