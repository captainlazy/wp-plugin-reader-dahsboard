<?php


namespace Nativerank\Questions\Resources;


use App\Models\Question as QuestionModel;

/**
 * Class Dealer
 * @package Nativerank\Dealer\Resources
 */
class Question
{

    /**
     * @var \TypeRocket\Register\Page
     */
    protected $resource;


    public function __construct($name = 'Question')
    {
        $this->resource = tr_resource_pages('FAQ', 'FAQs', [
            'position' => 2,
            'capability' => 'edit_posts'
        ], $name)->setIcon('bubbles');

        return $this->resource;
    }

    public static function mappedQuestionsWithCategories()
    {
        $questions = (new QuestionModel())->get();
        if (!$questions) {
            return [];
        }
        $questions = $questions->toArray();
        $questions = array_map(function ($question) {
            $categories = (new QuestionModel())->findById($question['id'])->faq_categories()->get();
            if ($categories) {
                $categories = $categories->toArray();
                $categories = array_map(function ($category) {
                    return ['id' => $category['id'], 'category' => $category['name']];
                }, $categories);


            }
            return array_merge($question, ['categories' => $categories]);
        }, $questions);

        return $questions;
    }

    public function apiRoutes()
    {
        register_rest_route(NR_QUESTIONS_PLUGIN_REST_NAMESPACE, '/questions/all', array(
            'methods' => 'GET',
            'callback' => [$this, 'mappedQuestionsWithCategories']
        ));
    }


}
