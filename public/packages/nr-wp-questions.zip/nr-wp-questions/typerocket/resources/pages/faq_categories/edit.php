<?php
$form->useAjax()->setDebugStatus( false );
echo $form->open();
echo $form->row(
	$form->column(
		$form->text( 'Name' )->required(),
		$form->submit( 'Update' )
	),
	$form->column(
		$form->hidden( 'hidden' )
	),
	$form->column(
		$form->hidden( 'hidden' )
	)
);
echo $form->close();


