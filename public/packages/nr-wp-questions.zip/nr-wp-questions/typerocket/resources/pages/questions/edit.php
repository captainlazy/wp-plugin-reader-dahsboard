<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<?php

use App\Models\FaqCategory;
use App\Models\Question;

$currentCategories = ( new Question() )->findById( $_GET['route_id'] )->faq_categories()->get();
$currentCategories = $currentCategories ? $currentCategories->toArray() : [];
$currentCategories = array_map( function ( $category ) {
	return $category['id'];
}, $currentCategories );


$allCategories = ( new FaqCategory() )->get();
$allCategories = $allCategories ? $allCategories->toArray() : [];

$allCategories = array_map( function ( $category ) {
	return [
		$category['name'],
		$category['id'],
	];
}, $allCategories );


$form->useAjax()->setDebugStatus( false );
echo $form->open();

$select = $form->select( 'FAQ Categories' )->multiple()->setDefault( $currentCategories )->setAttribute( 'id', 'faq_categories' )->setLabel( 'Categories' );
foreach ( $allCategories as $category ) {
	$select->setOption( $category[0], $category[1] );
}

echo $form->row(
	$form->column(
		$form->text('Question')->required(),
        $form->editor('Answer')->required(),
        $form->repeater('Resources')->setFields([
            $form->text('Label'),
            $form->file('File')
        ])
	),

	$form->column(
		$select,
		$form->text( 'Modified' )->setLabel( 'Last Modified' )->setAttribute( 'readonly', 'readonly' )->setCast( function ( $arg ) {
			return ( new DateTime( "@$arg" ) )->format( 'F j, Y, g:i a' );
		} ),
		$form->text( 'Created' )->setLabel( 'Date Added' )->setAttribute( 'readonly', 'readonly' )->setCast( function ( $arg ) {
			return ( new DateTime( "@$arg" ) )->format( 'F j, Y, g:i a' );
		} )
	),
	$form->column(
		$form->hidden( 'Created' )->setLabel( 'Date Added' )->setAttribute( 'readonly', 'readonly' )->setCast( function ( $arg ) {
			return ( new DateTime( "@$arg" ) )->format( 'F j, Y, g:i a' );
		} )
	)
);
?>
<script>
    (function ($) {
        $(document).ready(function () {
            $('#faq_categories').select2({
                tags: true,
                selectOnClose: true,
                placeholder: 'Select or add a new category'
            });
        });
    })(jQuery)

</script>
<?php
echo $form->submit( 'Update' );
echo $form->close();
