<?php
$tabs = tr_tabs();


$table = tr_tables()->setOrder( 'modified', 'desc' )->setModel( new \App\Models\Question() );
$table->setSearchColumns( [
	'question' => 'Question'
] );
$table->setColumns( 'question', [
	'question' => [
		'sort'        => true,
		'label'       => 'Question',
		'delete_ajax' => true,
		'actions'     => [ 'edit', 'delete' ]
	],
	'answer'   => [
		'sort'     => true,
		'label'    => 'Answer',
		'callback' => function ( $answer ) {
			$excerpt = substr( $answer, 0, 255 );

			return $excerpt ? $excerpt . "..." : $answer;
		}
	],
	'modified' => [
		'sort'     => true,
		'label'    => 'Last Modified',
		'callback' => function ( $timestamp ) {
			return '<div title ="' . ( new DateTime( "@$timestamp" ) )->format( 'F j, Y, g:i a' ) . '">' . ( new DateTime( "@$timestamp" ) )->format( 'M j, g:i a' ) . '</div>';
		}
	],
	'category' => [
		'sort'     => true,
		'label'    => 'Category',
		'callback' => function ( $text, $result ) {
            $categoryObjects = $result->faq_categories()->get();
            $categories = [];
            if ($categoryObjects) {
                $categoriesArray = $categoryObjects->toArray();
                foreach ($categoriesArray as $category) {
                    $categories[] = $category['name'];
                }
            }
            if (empty($categories)) {
                $categories = [''];
            }
            $categories = implode(', ', $categories);

            return $categories;
        }
	]
] );

$tabs->addTab( 'Questions', function () use ( $table ) {
	$table->render();
} );

$categoryTable = tr_tables()->setOrder( 'name', 'asc' )->setModel( new \App\Models\FaqCategory() );
$categoryTable->setSearchColumns( [ 'name' => 'Name' ] );
$categoryTable->setColumns( 'name', [
	'name'      => [
		'sort'        => true,
		'label'       => 'Name',
		'delete_ajax' => true
	],
	'questions' => [
		'sort'     => true,
		'label'    => 'Questions',
		'callback' => function ( $text, $result ) {
			$questions = $result->questions()->get();
			if ( empty( $questions ) ) {
				return '';
			}

			return $questions->count();
		}
	],
	'actions'   => [
		'align'    => 'right',
		'label'    => '',
		'callback' => function ( $value, $resource ) {
			if ( strtolower( $resource->name ) === strtolower( NR_QUESTIONS_DEFAULT_CATEGORY ) ) {
				return '';
			}
			$html       = "<a href='" . tr_redirect()->toPage( 'faqcategory', 'edit', $resource->id )->url . "'>Edit</a>";
			$delete_url = tr_redirect()->toPage( 'faqcategory', 'delete', $resource->id )->url;

			$delete_url    = wp_nonce_url( $delete_url, 'form_' . tr_config( 'app.seed' ), '_tr_nonce_form' );
			$delete_class  = 'class="tr-delete-row-rest-button"';
			$delete_target = "data-target='#result-row-{$resource->id}'";
			$del_text      = __( 'Delete' );
			$html          .= " | <span class=\"delete\"><a  {$delete_class} $delete_target href=\"{$delete_url}\">{$del_text}</a></span>";


			return $html;
		}
	]
] );


$tabs->addTab( 'Categories', function () use ( $categoryTable ) {
	$categoryTable->render();
} );

$tabs->render();

echo "<style>.tr-list-table tbody td{vertical-align: middle}</style>";
