<link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>
<?php

use App\Models\FaqCategory;

$categories = ( new FaqCategory() )->get();
$categories = $categories ? $categories->toArray() : [];
$categories = array_map( function ( $category ) {
	return [
		$category['name'],
		$category['id']
	];
}, $categories );

$form->useAjax();
echo $form->open();

$select = $form->select( 'FAQ Categories' )->multiple()->setDefault( $categories )->setAttribute( 'id', 'faq_categories' )->setLabel( 'Categories' );
foreach ( $categories as $category ) {
	$select->setOption( $category[0], $category[1] );
}

echo $form->row(
	$form->column(
        $form->text('Question')->required(),
        $form->editor('Answer')->required(),
        $form->repeater('Resources')->setFields([
            $form->text('Label'),
            $form->file('File')
        ])
    ),
    $form->column(
        $select
    ),
    $form->column(
        $form->hidden('Created')->setLabel('Dealer Added')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp()),
        $form->hidden('Modified')->setLabel('Dealer Modified')->setAttribute('readonly', 'readonly')->setDefault((new DateTime())->getTimestamp())
    )
);

?>
<script>
    (function ($) {
        $(document).ready(function () {
            $('#faq_categories').select2({
                tags: true,
                selectOnClose: true,
                placeholder: 'Select or add a new category'
            });
        });
    })(jQuery)

</script>
<?php
echo $form->submit( 'Add FAQ' );
echo $form->close();


