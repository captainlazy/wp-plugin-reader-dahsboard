<?php
echo $form->open();
echo $form->checkbox( 'Delete Record' )->setText( "I'm sure I want to delete this FAQ" );
echo $form->submit( 'Delete' );
echo $form->close();
