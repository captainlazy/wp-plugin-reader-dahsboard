<script>
    window.$nativerank = window.$nativerank || {}
    window.$nativerank.faqs = <?= json_encode( $questions ) ?>
</script>
<?php
opcache_reset();
do_action( NR_QUESTIONS_PLUGIN_ACTION_IDENTIFIER . '-content-pre-render' );
if ( empty( $categories ) ) {
	echo '<p>Check back here for answers to questions we often get asked!</p>';


} else {
$pluralCategories = count( $categories ) > 1;
?>
<div class="uk-panel" id="<?= NR_QUESTIONS_PLUGIN_ACTION_IDENTIFIER . '-panel' ?>">
    <div class="uk-grid uk-child-width-1-<?= $pluralCategories ? 2 : 1 ?>@m" uk-grid>
		<?php foreach ( $categories as $name => $category ) { ?>
            <div class="<?= strtolower( $name ) === strtolower( NR_QUESTIONS_DEFAULT_CATEGORY ) && count( $categories ) > 2 ? 'uk-width-1-1@m' : '' ?>">
                <h2><?= strtolower( $name ) !== strtolower( NR_QUESTIONS_DEFAULT_CATEGORY ) && $pluralCategories ? $name : '' ?></h2>
                <ul uk-accordion>
					<?php foreach ( $category as $question ) { ?>
                        <li class="uk-background-muted uk-padding-small">
                            <a href="#" class="uk-accordion-title">
								<?= $question['question']; ?>
                            </a>
                            <div class="uk-accordion-content">
								<?= $question['answer']; ?>
                            </div>
                        </li>
						<?php
					}
					?>
                </ul>
            </div>
		<?php }
		} ?>
    </div>
</div>
<?php
do_action( NR_QUESTIONS_PLUGIN_ACTION_IDENTIFIER . '-content-post-render' );
