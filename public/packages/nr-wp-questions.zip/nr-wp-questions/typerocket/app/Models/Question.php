<?php

namespace App\Models;

use TypeRocket\Models\Model;

class Question extends Model {
	protected $resource = 'questions';

	protected $cast = [
		'id'       => 'int',
		'modified' => 'int',
		'created'  => 'int',
        'resources' => 'array'
	];

	protected $format = [
	];

	public function faq_categories() {
		$model = '\App\Models\FaqCategory';
		$table = 'wp_faqcategories_questions';

		return $this->belongsToMany( $model, $table, 'faqcategories_id', 'questions_id' );
	}

}
