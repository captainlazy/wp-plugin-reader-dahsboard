<?php

namespace App\Models;

use TypeRocket\Models\Model;

class FaqCategory extends Model {
	protected $resource = 'faqcategories';
	protected $cast = [
		'id' => 'int'
	];

	public function questions() {
		$model = '\App\Models\Question';
		$table = 'wp_faqcategories_questions';

		return $this->belongsToMany( $model, $table, 'questions_id', 'faqcategories_id' );
	}
}