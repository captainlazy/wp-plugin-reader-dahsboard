<?php

namespace App\Controllers;

use App\Models\FaqCategory;
use TypeRocket\Controllers\Controller;

class FaqcategoryController extends Controller {

	protected $modelClass = FaqCategory::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add() {
		// TODO: Implement add() method.
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @return mixed
	 */
	public function create() {
		// TODO: Implement create() method.
	}

	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit( $id ) {
		$form = tr_form( 'faqcategory', 'update', $id );

		return tr_view( 'faq_categories.edit', [ 'form' => $form ] );
	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param FaqCategory $category
	 *
	 * @return mixed
	 */
	public function update( $id, FaqCategory $category ) {
		$request = $this->request->getFields();
		if ( empty( $request['name'] ) ) {
			return $this->response->flashNext( 'ERROR: Category Name is Required!', 'warning' );
		}
		$category->name = $request['name'];
		$category->save();

		return $this->response->flashNext( 'Category updated', 'success' )->setRedirect( tr_redirect()->toPage( 'question', 'index', $id )->url );
	}

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show( $id ) {
		// TODO: Implement show() method.
	}

	/**
	 * The delete page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function delete( $id ) {

	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function destroy( $id ) {
		$category = new FaqCategory();

		$category->findOrDie( $id );
		$defaultCategory = ( new FaqCategory() )->where( 'name', NR_QUESTIONS_DEFAULT_CATEGORY )->first();
		if ( ! $defaultCategory ) {
			$defaultCategory = $this->createDefaultCategory( new FaqCategory() );
		}
		$defaultCategory = [ $defaultCategory->getID() ];
		$questions       = $category->questions()->get();
		foreach ( $questions as $question ) {
			$numRelatedCategories = $question->faq_categories()->get()->count();
			if ( $numRelatedCategories === 1 ) {
				$question->faq_categories()->attach( $defaultCategory );
			}
		}
		$category->delete();

		return $this->response->flashNow( 'Category deleted', 'warning' );
	}

	private function createDefaultCategory( FaqCategory $category ) {
		$category->name = NR_QUESTIONS_DEFAULT_CATEGORY;
		$category->save();

		return $category;
	}
}