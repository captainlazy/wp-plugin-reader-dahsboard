<?php

namespace App\Controllers;

use App\Models\FaqCategory;
use App\Models\Question;
use TypeRocket\Controllers\Controller;


class QuestionController extends Controller {

	protected $modelClass = Question::class;

	/**
	 * The index page for admin
	 *
	 * @return mixed
	 */
	public function index() {
		return tr_view( 'questions.index' );
	}

	/**
	 * The add page for admin
	 *
	 * @return mixed
	 */
	public function add() {
		$form = tr_form( 'question', 'create' );

		return tr_view( 'questions.add', [ 'form' => $form ] );
		//NOTE: Save the data we pass over from the view using the create() method.
	}

	/**
	 * Create item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function create( $request = [] ) {
        if (empty($request)) {
            $request = $this->request->getFields();
        }
        if (empty($request['question'])) {
            return $this->response->flashNext('ERROR: Question is Required!', 'warning');
        }
        if (empty($request['answer'])) {
            return $this->response->flashNext('ERROR: Answer is Required!', 'warning');
        }

        $existing_question = (int)(new Question())->where('question', $request['question'])->findAll()->count();
        if ($existing_question) {
            return $this->response->flashNext('ERROR: Question Already Exists!', 'warning');
        }

        $request = $this->setDefaultCategory($request);

        $question = new Question();
        $this->attachCategoryAndSaveQuestion($question, $request);

        return $this->response->flashNext('Question added!')->setRedirect(tr_redirect()->toPage('question', 'index')->url);

    }

	/**
	 * The edit page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function edit( $id ) {
		$form = tr_form( 'question', 'update', $id );

		return tr_view( 'questions.edit', [ 'form' => $form ] );
	}

	/**
	 * Update item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @param Question $question
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function update( $id, Question $question )
    {
        $request = $this->request->getFields();
        if (empty($request['question'])) {
            return $this->response->flashNext('ERROR: Question is Required!', 'warning');
        }
        if (empty($request['answer'])) {
            return $this->response->flashNext('ERROR: Answer is Required!', 'warning');
        }

        $request = $this->setDefaultCategory($request);

        // Update modified time
        $request['modified'] = (new \DateTime())->getTimestamp();

        $this->saveEditedQuestion($question, $request);

        return $this->response->flashNext('Question updated!')->setRedirect(tr_redirect()->toPage('question', 'index', $id)->url);

    }

	/**
	 * The show page for admin
	 *
	 * @param string $id
	 *
	 * @return mixed
	 */
	public function show( $id ) {
		// TODO: Implement show() method.
	}

	/**
	 * Destroy item
	 *
	 * AJAX requests and normal requests can be made to this action
	 *
	 * @param string $id
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	public function destroy( $id ) {
		$question = new Question();

		$question->findOrDie( $id );
		$question->delete();

		return $this->response->flashNow( 'Question deleted', 'warning' );
	}

	private function setDefaultCategory( $request )
    {
        $defaultCategory = (new FaqCategory())->where('name', NR_QUESTIONS_DEFAULT_CATEGORY)->first();
        if (!$defaultCategory) {
            $defaultCategory = $this->createDefaultCategory(new FaqCategory());
        }
        $defaultCategory = $defaultCategory->getID();

        if (!isset($request['faq_categories'])) {
            $request['faq_categories'] = [];
            $request['faq_categories'] = [$defaultCategory];

            return $request;
        }
        foreach ($request['faq_categories'] as $index => $category) {
            $categoryObject = (new FaqCategory())->findById($category);
            if ($categoryObject) {
                continue;
            }
			$categoryObject                      = new FaqCategory();
			$categoryObject->name                = $category;
			$request['faq_categories'][ $index ] = $categoryObject->save();
		}

		$request['faq_categories'] = array_filter( $request['faq_categories'], function ( $category ) use ( $defaultCategory ) {
			return (int) $category !== (int) $defaultCategory;
		} );


		return $request;
	}

	private function createDefaultCategory( FaqCategory $category ) {
		$category->name = NR_QUESTIONS_DEFAULT_CATEGORY;
		$category->save();

		return $category;
	}

	private function attachCategoryAndSaveQuestion( Question $question, $request = [] ) {
		$categories = $request['faq_categories'];
		unset( $request['faq_categories'] );

		$question   = $this->updateFields( $question, $request );
		$questionID = $question->save();
		$question   = ( new Question() )->findById( $questionID );

		$question->faq_categories()->attach( $categories );
	}

	private function saveEditedQuestion( Question $question, $request = [] ) {
		$categories = $request['faq_categories'];
		unset( $request['faq_categories'] );
		$currentCategories = $question->faq_categories();
		$currentCategories->detach();

		$question = $this->updateFields( $question, $request );
		$question->save();

		$question->faq_categories()->attach( $categories );
	}

	/**
	 * @param Question $question
	 * @param array $request [name, brand, logo, website, street_address, city, state, zip]
	 *
	 * @return Question
	 */
	public function updateFields( Question $question, $request = [] ) {

		foreach ( $request as $fieldLabel => $fieldValue ) {
			$question->{$fieldLabel} = $fieldValue;
		}

		return $question;
	}

}
