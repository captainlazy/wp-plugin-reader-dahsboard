<?php

/*
Plugin Name: NR Questions
Plugin URI: https://nativerank.com
Description: NR Questions manages an FAQs page
Version: 1.0.4
Author: Native Rank
Author URI: https://nativerank.com
License: A "Slug" license name e.g. GPL2
*/


use Nativerank\Questions\Database\Migrations;
use Nativerank\Questions\Plugin;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Define most essential constants.
define('NR_QUESTIONS_VERSION', '1.0.4');
define('NR_QUESTIONS_PLUGIN_MAIN_FILE', __FILE__);
define('NR_QUESTIONS_PLUGIN_ACTION_IDENTIFIER', 'nr-wp-questions');
define('NR_QUESTIONS_PLUGIN_REST_NAMESPACE', 'nr-wp-questions/v1');
define('NR_QUESTIONS_PHP_MINIMUM', '5.6.0');
define('NR_QUESTIONS_DIR_NAME', basename(__DIR__));
define('NR_QUESTIONS_PLUGIN_URI', plugins_url(NR_QUESTIONS_DIR_NAME));
define('NR_QUESTIONS_DEFAULT_CATEGORY', 'Uncategorized');


if (class_exists('NRPlugin')) {
    die();
}

require 'vendor/autoload.php';


/**
 * Handles plugin activation.
 *
 * Throws an error if the plugin is activated on an older version than PHP 5.6.
 *
 * @access private
 */
register_activation_hook(__FILE__, function () {
    if (version_compare(PHP_VERSION, NR_QUESTIONS_PHP_MINIMUM, '<')) {
        wp_die(
        /* translators: %s: version number */
            esc_html(sprintf(__('NR Dela requires PHP version %s', 'nr-dealer'), NR_QUESTIONS_PHP_MINIMUM)),
            esc_html__('Error Activating', 'nr-dealer')
        );
    }

    //Create DB Tables
    (new Migrations());


    do_action('nr_questions_activation');

});


/**
 * Handles plugin deactivation.
 *
 * @access private
 *
 */
register_deactivation_hook( __FILE__, function ( $network_wide ) {
	if ( version_compare( PHP_VERSION, NR_QUESTIONS_PHP_MINIMUM, '<' ) ) {
		return;
	}

	do_action( 'nr_questions_deactivation', $network_wide );
} );


/**
 * Resets opcache if possible.
 *
 * @access private
 */
function nr_questions_opcache_reset() {
	if ( version_compare( PHP_VERSION, NR_QUESTIONS_PHP_MINIMUM, '<' ) ) {
		return;
	}

	if ( ! function_exists( 'opcache_reset' ) ) {
		return;
	}

	if ( ! empty( ini_get( 'opcache.restrict_api' ) ) && strpos( __FILE__, ini_get( 'opcache.restrict_api' ) ) !== 0 ) {
		return;
	}

	// `opcache_reset` is prohibited on the WordPress VIP platform due to memory corruption.
	if ( defined( 'WPCOM_IS_VIP_ENV' ) && WPCOM_IS_VIP_ENV ) {
		return;
	}

	opcache_reset(); // phpcs:ignore WordPressVIPMinimum.Functions.RestrictedFunctions.opcache_opcache_reset
}

add_action( 'upgrader_process_complete', 'nr_questions_opcache_reset' );


if ( version_compare( PHP_VERSION, NR_QUESTIONS_PHP_MINIMUM, '>=' ) ) {

	Plugin::load( NR_QUESTIONS_PLUGIN_MAIN_FILE );

}
